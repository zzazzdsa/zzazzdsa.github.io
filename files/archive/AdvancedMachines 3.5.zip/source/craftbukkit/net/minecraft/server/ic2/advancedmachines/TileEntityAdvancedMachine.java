package net.minecraft.server.ic2.advancedmachines;

import forge.*;
import ic2.api.*;
import ic2.api.Direction;
import java.util.*;
import net.minecraft.server.*;

public abstract class TileEntityAdvancedMachine extends TileEntityBaseMachine
    implements ISidedInventory, INetworkTileEntityEventListener
{
    private static final int MAX_PROGRESS = 4000;
    private static final int MAX_ENERGY = 5000;
    private static final int MAX_SPEED = 7500;
    private static final int MAX_INPUT = 32;
    private String inventoryName;
    private int inputs[];
    private int outputs[];
    short speed;
    short progress;
    private String dataFormat;
    private int dataScaling;
    private IC2AudioSource audioSource;
    private static final int EventStart = 0;
    private static final int EventInterrupt = 1;
    private static final int EventStop = 2;
    private int energyConsume;
    private int defaultEnergyConsume;
    private int acceleration;
    private int defaultAcceleration;
    private int maxSpeed;
    private ItemStack lastInventory[];

    public TileEntityAdvancedMachine(String s, String s1, int i, int ai[], int ai1[])
    {
        super(ai.length + ai1.length + 5, ai.length, 5000, 32);
        energyConsume = 2;
        defaultEnergyConsume = 3;
        acceleration = 1;
        defaultAcceleration = 1;
        inventoryName = s;
        dataFormat = s1;
        dataScaling = i;
        inputs = ai;
        outputs = ai1;
        speed = 0;
        progress = 0;
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
        speed = nbttagcompound.getShort("speed");
        progress = nbttagcompound.getShort("progress");
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
        nbttagcompound.setShort("speed", speed);
        nbttagcompound.setShort("progress", progress);
    }

    public String getName()
    {
        return inventoryName;
    }

    public int gaugeProgressScaled(int i)
    {
        return (i * progress) / 4000;
    }

    public int gaugeFuelScaled(int i)
    {
        return (i * energy) / maxEnergy;
    }

    public void l_()
    {
        super.l_();
        boolean flag = false;
        if (energy <= maxEnergy)
        {
            flag = provideEnergy();
        }
        boolean flag1 = getActive();
        if (progress >= 4000)
        {
            operate();
            flag = true;
            progress = 0;
            flag1 = false;
            NetworkHelper.initiateTileEntityEvent(this, 2, true);
        }
        boolean flag2 = canOperate();
        if (energy > 0 && (flag2 || isRedstonePowered()))
        {
            setOverclockRates();
            if (speed < maxSpeed)
            {
                speed += acceleration;
                energy -= energyConsume;
            }
            else
            {
                speed = (short)maxSpeed;
                energy -= defaultEnergyConsume;
            }
            flag1 = true;
            NetworkHelper.initiateTileEntityEvent(this, 0, true);
        }
        else
        {
            boolean flag3 = speed != 0;
            speed = (short)(speed - Math.min(speed, 4));
            if (flag3 && speed == 0)
            {
                NetworkHelper.initiateTileEntityEvent(this, 1, true);
            }
        }
        if (flag1 && progress != 0)
        {
            if (!flag2 || speed == 0)
            {
                if (!flag2)
                {
                    progress = 0;
                }
                flag1 = false;
            }
        }
        else if (flag2)
        {
            if (speed != 0)
            {
                flag1 = true;
            }
        }
        else
        {
            progress = 0;
        }
        if (flag1 && flag2)
        {
            progress = (short)(progress + speed / 30);
        }
        if (flag)
        {
            update();
        }
        if (flag1 != getActive())
        {
            world.notify(x, y, z);
            setActive(flag1);
        }
    }

    public int injectEnergy(Direction direction, int i)
    {
        setOverclockRates();
        return super.injectEnergy(direction, i);
    }

    public void operate()
    {
        if (canOperate())
        {
            ItemStack itemstack = getResultFor(inventory[inputs[0]], false).cloneItemStack();
            int ai[] = new int[outputs.length];
            int i = itemstack.getMaxStackSize();
            for (int j = 0; j < outputs.length; j++)
            {
                if (inventory[outputs[j]] == null)
                {
                    ai[j] = i;
                    continue;
                }
                if (inventory[outputs[j]].doMaterialsMatch(itemstack))
                {
                    ai[j] = i - inventory[outputs[j]].count;
                }
            }

            int k = 0;
            do
            {
                if (k >= ai.length)
                {
                    break;
                }
                if (ai[k] > 0)
                {
                    int l = Math.min(itemstack.count, ai[k]);
                    if (inventory[outputs[k]] == null)
                    {
                        inventory[outputs[k]] = itemstack.cloneItemStack();
                    }
                    else
                    {
                        inventory[outputs[k]].count += l;
                    }
                    itemstack.count -= l;
                }
                if (itemstack.count <= 0)
                {
                    break;
                }
                k++;
            }
            while (true);
            if (inventory[inputs[0]].getItem().k())
            {
                inventory[inputs[0]] = new ItemStack(inventory[inputs[0]].getItem().j());
            }
            else
            {
                inventory[inputs[0]].count--;
            }
            if (inventory[inputs[0]].count <= 0)
            {
                inventory[inputs[0]] = null;
            }
        }
    }

    public boolean canOperate()
    {
        if (inventory[inputs[0]] == null)
        {
            return false;
        }
        ItemStack itemstack = getResultFor(inventory[inputs[0]], false);
        if (itemstack == null)
        {
            return false;
        }
        int i = itemstack.getMaxStackSize();
        int j = 0;
        int ai[] = outputs;
        int k = ai.length;
        for (int l = 0; l < k; l++)
        {
            int i1 = ai[l];
            if (inventory[i1] == null)
            {
                j += i;
                continue;
            }
            if (inventory[i1].doMaterialsMatch(itemstack))
            {
                j += i - inventory[i1].count;
            }
        }

        return j >= itemstack.count;
    }

    public abstract ItemStack getResultFor(ItemStack itemstack, boolean flag);

    protected abstract List getResultMap();

    public abstract Container getGuiContainer(PlayerInventory playerinventory);

    public int getStartInventorySide(int i)
    {
        switch (i)
        {
            case 0:
                return inputs.length;

            case 1:
                return inputs[0];
        }
        return outputs[0];
    }

    public int getSizeInventorySide(int i)
    {
        switch (i)
        {
            case 0:
                return 1;

            case 1:
                return inputs.length;
        }
        return outputs.length;
    }

    public String printFormattedData()
    {
        return String.format(dataFormat, new Object[]
                {
                    Integer.valueOf(speed * dataScaling)
                });
    }

    public void i()
    {
        if (audioSource != null)
        {
            IC2AudioSource.removeSource(audioSource);
            audioSource = null;
        }
        super.i();
    }

    public String getStartSoundFile()
    {
        return null;
    }

    public String getInterruptSoundFile()
    {
        return null;
    }

    public void onNetworkEvent(int i)
    {
        if (audioSource == null && getStartSoundFile() != null)
        {
            audioSource = new IC2AudioSource(this, getStartSoundFile());
        }
        switch (i)
        {
            default:
                break;

            case 0:
                setActiveWithoutNotify(true);
                if (audioSource != null)
                {
                    audioSource.play();
                }
                break;

            case 1:
                setActiveWithoutNotify(false);
                if (audioSource == null)
                {
                    break;
                }
                audioSource.stop();
                if (getInterruptSoundFile() != null)
                {
                    IC2AudioSource.playOnce(this, getInterruptSoundFile());
                }
                break;

            case 2:
                setActiveWithoutNotify(false);
                if (audioSource != null)
                {
                    audioSource.stop();
                }
                break;
        }
    }

    public void setOverclockRates()
    {
        if (lastInventory != null && lastInventory.equals(inventory))
        {
            return;
        }
        lastInventory = (ItemStack[])inventory.clone();
        int i = 0;
        int j = 0;
        int k = 0;
        for (int l = 0; l < 4; l++)
        {
            ItemStack itemstack = inventory[(l + inventory.length) - 4];
            if (itemstack == null)
            {
                continue;
            }
            if (itemstack.doMaterialsMatch(Items.getItem("overclockerUpgrade")))
            {
                i += itemstack.count;
                continue;
            }
            if (itemstack.doMaterialsMatch(Items.getItem("transformerUpgrade")))
            {
                j += itemstack.count;
                continue;
            }
            if (itemstack.doMaterialsMatch(Items.getItem("energyStorageUpgrade")))
            {
                k += itemstack.count;
            }
        }

        if (i > 32)
        {
            i = 32;
        }
        if (j > 10)
        {
            j = 10;
        }
        energyConsume = (int)((double)defaultEnergyConsume * Math.pow(2D, i));
        acceleration = (int)(((double)(defaultAcceleration * 2) * Math.pow(1.6000000000000001D, i)) / 2D);
        maxSpeed = 7500 + i * 500;
        maxInput = 32 * (int)Math.pow(4D, j);
        maxEnergy = (5000 + k * 5000 + maxInput) - 1;
        tier = j;
    }
}
