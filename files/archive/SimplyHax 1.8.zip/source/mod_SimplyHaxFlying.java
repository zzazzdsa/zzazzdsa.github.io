import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Properties;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;

public class mod_SimplyHaxFlying extends BaseMod {

   private long lastTime = System.currentTimeMillis();
   private boolean buttonCD = false;
   private boolean isFlying = false;
   private boolean isSprinting = false;
   private static File configfile = new File(Minecraft.b(), "mods/SimplyHaxFlying.txt");
   private static boolean configLoaded = false;
   private static String togglekey = "R";
   private static int itogglekey = Keyboard.getKeyIndex(togglekey);
   private static String sprintkey = "LSHIFT";
   private static int isprintkey = Keyboard.getKeyIndex(sprintkey);
   private static String keyupwards = "SPACE";
   private static int ikeyupwards = Keyboard.getKeyIndex(keyupwards);
   private static String keydownwards = "LCONTROL";
   private static int ikeydownwards = Keyboard.getKeyIndex(keydownwards);
   private static double maxflyspeed = 1.0D;
   private static float fovModifier = 20.0F;
   private float distanceWalkedModified;
   private Minecraft mcinstance;
   private double modMotionX;
   private double modMotionZ;
   private double modposY;


   public mod_SimplyHaxFlying() {
      ModLoader.SetInGameHook(this, true, true);
   }

   public static void InitSettings() {
      Properties properties = new Properties();
      if(configfile.exists()) {
         System.out.println("SimplyHaxFlying config found, proceeding...");

         try {
            properties.load(new FileInputStream(configfile));
         } catch (IOException var4) {
            System.out.println("SimplyHaxFlying config exception: " + var4);
         }

         togglekey = properties.getProperty("flyingToggleKey", "R");
         itogglekey = Keyboard.getKeyIndex(togglekey);
         sprintkey = properties.getProperty("sprintKey", "LSHIFT");
         isprintkey = Keyboard.getKeyIndex(sprintkey);
         keydownwards = properties.getProperty("keydownwards", "LCONTROL");
         ikeydownwards = Keyboard.getKeyIndex(keydownwards);
         keyupwards = properties.getProperty("keyupwards", "SPACE");
         ikeyupwards = Keyboard.getKeyIndex(keyupwards);
         maxflyspeed = Double.parseDouble(properties.getProperty("maxflyspeed", "1.0"));
         fovModifier = Float.parseFloat(properties.getProperty("fovModifier", "20.0"));
      } else {
         System.out.println("No SimplyHaxFlying config found, trying to create...");

         try {
            configfile.createNewFile();
            properties.load(new FileInputStream(configfile));
         } catch (IOException var3) {
            System.out.println("SimplyHaxFlying config exception: " + var3);
         }

         properties.setProperty("flyingToggleKey", "R");
         properties.setProperty("sprintKey", "LSHIFT");
         properties.setProperty("keydownwards", "LCONTROL");
         properties.setProperty("keyupwards", "SPACE");
         properties.setProperty("maxflyspeed", "1.0");
         properties.setProperty("fovModifier", "20.0");

         try {
            FileOutputStream localIOException = new FileOutputStream(configfile);
            properties.store(localIOException, "Derp it\'s the key settings");
         } catch (IOException var2) {
            System.out.println("SimplyHaxFlying config exception: " + var2);
         }
      }

   }

   public boolean OnTickInGame(Minecraft mc) {
      if(this.mcinstance != mc) {
         this.mcinstance = mc;
      }

      if(this.mcinstance.f != null && this.mcinstance.h != null) {
         if(!configLoaded) {
            InitSettings();
            configLoaded = true;
         }

         long l = System.currentTimeMillis();
         if(l > this.lastTime + 200L) {
            this.buttonCD = false;
         }

         this.isSprinting = Keyboard.isKeyDown(isprintkey) && !this.IsMenuOpen();
         if(!this.buttonCD && Keyboard.getEventKeyState() && Keyboard.getEventKey() == itogglekey && !this.IsMenuOpen()) {
            this.lastTime = l;
            this.buttonCD = true;
            this.isFlying = !this.isFlying;
            if(this.isFlying) {
               this.modposY = this.mcinstance.h.p;
               this.distanceWalkedModified = this.mcinstance.h.L;
            }
         }

         if(this.IsAlive(this.mcinstance.h)) {
            float fov;
            if(this.isSprinting) {
               this.MakeHaste(this.mcinstance.h);
               fov = this.GetFOV();
               if(this.GetAbsSpeed(this.mcinstance.h) > 0.1D) {
                  if(fov < fovModifier) {
                     this.SetFOV(fov + fovModifier * 0.25F);
                  }
               } else if(fov > 0.0F) {
                  this.SetFOV(fov - fovModifier * 0.25F);
               }
            } else {
               this.modMotionX = this.mcinstance.h.r;
               this.modMotionZ = this.mcinstance.h.t;
               fov = this.GetFOV();
               if(fov > 0.0F) {
                  this.SetFOV(fov - fovModifier * 0.25F);
               }
            }

            if(this.isFlying) {
               this.MakeFly(this.mcinstance.h);
            }
         }
      }

      return true;
   }

   private void SetFOV(float setting) {
      try {
         Field[] securityexception = iw.class.getDeclaredFields();
         securityexception[19].setAccessible(true);
         securityexception[19].set(this.mcinstance.t, Float.valueOf(setting));
      } catch (IllegalAccessException var3) {
         System.out.println("SimplyHaxFlying exception: " + var3);
      } catch (SecurityException var4) {
         System.out.println("SimplyHaxFlying exception: " + var4);
      }

   }

   private float GetFOV() {
      try {
         Field[] securityexception = iw.class.getDeclaredFields();
         securityexception[19].setAccessible(true);
         return Float.valueOf(((Float)securityexception[19].get(this.mcinstance.t)).floatValue()).floatValue();
      } catch (IllegalAccessException var2) {
         System.out.println("SimplyHaxFlying exception: " + var2);
      } catch (SecurityException var3) {
         System.out.println("SimplyHaxFlying exception: " + var3);
      }

      return 0.0F;
   }

   private void MakeHaste(qs entityplayer) {
      float rotationMovement = (float)(Math.atan2(entityplayer.r, entityplayer.t) * 180.0D / 3.1415D);
      float rotationLook = entityplayer.aS;
      if(rotationLook > 360.0F) {
         rotationLook -= rotationLook % 360.0F * 360.0F;
      } else if(rotationLook < 0.0F) {
         rotationLook += rotationLook * -1.0F % 360.0F * 360.0F;
      }

      if(Math.abs(rotationMovement + rotationLook) > 10.0F) {
         rotationLook -= 360.0F;
      }

      double entspeed = this.GetAbsSpeed(entityplayer);
      if(Math.abs(rotationMovement + rotationLook) > 10.0F) {
         this.modMotionX = this.mcinstance.h.r;
         this.modMotionZ = this.mcinstance.h.t;
      }

      if(!this.isFlying && entspeed < 0.3D) {
         if(this.GetAbsModSpeed() > 0.6D || !entityplayer.z) {
            this.modMotionX /= 1.55D;
            this.modMotionZ /= 1.55D;
         }

         this.modMotionX *= 1.5D;
         entityplayer.r = this.modMotionX;
         this.modMotionZ *= 1.5D;
         entityplayer.t = this.modMotionZ;
      } else if(this.isFlying && entspeed < maxflyspeed) {
         if(this.GetAbsModSpeed() > maxflyspeed * 3.0D) {
            this.modMotionX /= 2.55D;
            this.modMotionZ /= 2.55D;
         }

         this.modMotionX *= 2.5D;
         entityplayer.r = this.modMotionX;
         this.modMotionZ *= 2.5D;
         entityplayer.t = this.modMotionZ;
      }

   }

   private void MakeFly(qs entityplayer) {
      entityplayer.L = this.distanceWalkedModified;
      entityplayer.M = 0.0F;
      entityplayer.z = true;
      if(Keyboard.isKeyDown(ikeyupwards) && !this.IsMenuOpen()) {
         entityplayer.s = this.isSprinting?1.0D:0.35D;
         this.modposY = entityplayer.p;
      } else if(Keyboard.isKeyDown(ikeydownwards) && !this.IsMenuOpen()) {
         entityplayer.s = this.isSprinting?-1.0D:-0.35D;
         this.modposY = entityplayer.p;
      } else if(entityplayer.p < this.modposY) {
         entityplayer.s = this.modposY - entityplayer.p;
      } else {
         entityplayer.s = 0.0D;
      }

   }

   private double GetAbsSpeed(kj ent) {
      return Math.sqrt(ent.r * ent.r + ent.t * ent.t);
   }

   private double GetAbsModSpeed() {
      return Math.sqrt(this.modMotionX * this.modMotionX + this.modMotionZ * this.modMotionZ);
   }

   private boolean IsAlive(wd ent) {
      return ent != null && ent.Y > 0 && !ent.G;
   }

   private boolean IsMenuOpen() {
      return this.mcinstance.r != null;
   }

   public String Version() {
      return "1.8";
   }

}
