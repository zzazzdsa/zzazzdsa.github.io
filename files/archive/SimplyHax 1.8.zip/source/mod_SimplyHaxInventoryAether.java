package net.minecraft.src;

import net.minecraft.client.Minecraft;

import java.lang.reflect.*;


public class mod_SimplyHaxInventoryAether extends BaseMod
{

    private long lastTime;
	private boolean isAetherModInstalled = false;
	
	private ItemStack[] mainInv;
	private ItemStack[] armorInv;
	
	private boolean savedInventory = false;
	

    public mod_SimplyHaxInventoryAether()
    {
        lastTime = System.currentTimeMillis();
        
		isAetherModInstalled = IsAetherInstalled();
		
		if (isAetherModInstalled)
		{
			ModLoader.SetInGameHook(this, true, true);
		}
    }
	
    public boolean OnTickInGame(Minecraft mc)
    {
		if (mc.theWorld != null && mc.thePlayer != null)
		{
			long l = System.currentTimeMillis();
			if(l > lastTime + 1000L)
			{
				lastTime = l;
				// do once a second stuff
				
				HaxInventory(mc.thePlayer);
			}
			
			// do every tick stuff
			
			if ((mc.thePlayer.health <= 0 || mc.thePlayer.isDead) && !savedInventory)
			{
				deleteDroppingItems(mc.thePlayer);
			}
		}
        return true;
    }
	
	private void HaxInventory(EntityPlayerSP entityplayer)
	{
		if (IsAlive(entityplayer) && hasItems(entityplayer))
		{
			int i;
			if (!savedInventory)
			{
				if (isAetherModInstalled && mod_Aether.getPlayer() != null)
				{
					PlayerBaseAether playeraeth = mod_Aether.getPlayer();
					
					mainInv = new ItemStack[36];
					for (i = 0; i < playeraeth.player.inventory.mainInventory.length; i++)
					{
						if (playeraeth.player.inventory.mainInventory[i] != null)
						{
							mainInv[i] = playeraeth.player.inventory.mainInventory[i].copy();
						}
					}
					
					armorInv = new ItemStack[8];
					for (i = 0; i < playeraeth.inv.slots.length; i++)
					{
						if (playeraeth.inv.slots[i] != null)
						{
							armorInv[i] = playeraeth.inv.slots[i].copy();
						}
					}
				}
			}
			else
			{
				if (isAetherModInstalled && mod_Aether.getPlayer() != null)
				{
					PlayerBaseAether playeraeth = mod_Aether.getPlayer();
					playeraeth.player.inventory.mainInventory = mainInv;
					playeraeth.inv.slots = armorInv;
					System.out.println("Restored Aether inv!");
					
					savedInventory = false;
				}
			}
		}
		else
		{
			savedInventory = true;
		}
	}
	
	private void deleteDroppingItems(EntityPlayerSP entityplayer)
	{
		java.util.List list = entityplayer.worldObj.getEntitiesWithinAABBExcludingEntity(entityplayer, entityplayer.boundingBox.expand(2D, 2D, 2D));
		
		if (list.size() > 0)
			System.out.println("Player dead, deleting "+list.size()+" dropped items");
		
		for(int i = 0; i < list.size(); i++)
		{
			Entity ent = (Entity)list.get(i);
			if(!ent.isDead && ent instanceof EntityItem)
			{
				ent.setEntityDead();
			}
		}
	}
	
	private boolean hasItems(EntityPlayer entityplayer)
	{
		return entityplayer.inventory.mainInventory.length > 0 || entityplayer.inventory.armorInventory.length > 0;
	}
	
	private boolean IsAlive(EntityLiving ent)
	{
		return ent != null && ent.health > 0 && !ent.isDead;
	}
	
	private boolean IsAetherInstalled()
	{
        try
        {
            return Class.forName("mod_Aether") != null;
        }
        catch(ClassNotFoundException classnotfoundexception)
        {
            return false;
        }
	}

    public String Version()
    {
        return "1.7.3";
    }
}
