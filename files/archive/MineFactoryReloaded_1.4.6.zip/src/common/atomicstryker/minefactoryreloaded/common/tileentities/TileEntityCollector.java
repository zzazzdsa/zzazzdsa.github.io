package atomicstryker.minefactoryreloaded.common.tileentities;

import java.util.List;

import net.minecraft.entity.item.EntityItem;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import atomicstryker.minefactoryreloaded.common.core.Util;

public class TileEntityCollector extends TileEntityFactory
{    
	@Override
	public boolean canRotate()
	{
		return false;
	}
	
	public void addToChests(EntityItem i)
	{
		ItemStack s = i.func_92014_d();
		List<IInventory> chests = Util.findChests(worldObj, xCoord, yCoord, zCoord);
		for(IInventory inv : chests)
		{
			s.stackSize = Util.addToInventory(inv, s);
			if(s.stackSize == 0)
			{
				i.setDead();
				return;
			}
		}
	}
}
