package atomicstryker.minefactoryreloaded.common.api;

import java.util.List;

import net.minecraft.entity.EntityLiving;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import atomicstryker.minefactoryreloaded.common.tileentities.TileEntityRancher;

public interface IFactoryRanchable
{
	public Class<?> getRanchableEntity();
	
	public List<ItemStack> ranch(World world, EntityLiving entity, TileEntityRancher rancher);
	public boolean getDamageRanchedEntity(World world, EntityLiving entity, List<ItemStack> drops);
	
	public int getDamageAmount(World world, EntityLiving entity, List<ItemStack> drops);
}
