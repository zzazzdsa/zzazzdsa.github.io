package atomicstryker.minefactoryreloaded.common;

import net.minecraft.item.Item;

public class ItemFactory extends Item
{
	public ItemFactory(int i)
	{
		super(i);
	}
	
	@Override
	public String getTextureFile()
	{
        return MineFactoryReloadedCore.itemTexture;
	}
}
