package atomicstryker.minefactoryreloaded.client;

import net.minecraft.entity.player.EntityPlayer;
import atomicstryker.minefactoryreloaded.common.core.IMFRProxy;

public class ClientProxy implements IMFRProxy
{
    @Override
    public void load()
    {
        new MineFactoryClient();
    }

    @Override
    public void movePlayerToCoordinates(EntityPlayer e, double x, double y, double z)
    {
        e.moveEntity(x, y, z);
    }

    @Override
    public int getRenderId()
    {
        return MineFactoryClient.instance().renderId;
    }
}
