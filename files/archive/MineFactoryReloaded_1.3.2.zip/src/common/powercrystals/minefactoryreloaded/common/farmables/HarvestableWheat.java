package powercrystals.minefactoryreloaded.common.farmables;

import net.minecraft.src.Block;
import net.minecraft.src.World;
import powercrystals.minefactoryreloaded.common.api.HarvestType;
import powercrystals.minefactoryreloaded.common.api.IFactoryHarvestable;

public class HarvestableWheat extends HarvestableStandard implements IFactoryHarvestable
{
	public HarvestableWheat()
	{
		super(Block.crops.blockID, HarvestType.Normal);
	}
	
	@Override
	public boolean canBeHarvested(World world, int x, int y, int z)
	{
		int blockMetadata = world.getBlockMetadata(x, y, z);
		return blockMetadata == 7;
	}
}
