package powercrystals.minefactoryreloaded.common.core;

public interface IRotateableTile
{
	public boolean canRotate();
	public void rotate();
}
