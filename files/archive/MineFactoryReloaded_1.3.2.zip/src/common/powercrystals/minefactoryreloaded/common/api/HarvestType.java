package powercrystals.minefactoryreloaded.common.api;

public enum HarvestType
{
	Normal,
	LeaveBottom,
	Tree,
	TreeLeaf
}
