package powercrystals.minefactoryreloaded.common;

import net.minecraft.src.EntityPlayer;
import net.minecraft.src.EntityPlayerMP;
import net.minecraft.src.NetServerHandler;
import net.minecraft.src.World;
import powercrystals.minefactoryreloaded.common.core.IMFRProxy;

public class CommonProxy implements IMFRProxy
{
    @Override
    public void load()
    {
        // NOOP
    }

    @Override
    public void movePlayerToCoordinates(EntityPlayer e, double x, double y, double z)
    {
        if (e instanceof EntityPlayerMP)
        {
            ((EntityPlayerMP)e).serverForThisPlayer.setPlayerLocation(x,y,z, e.cameraYaw, e.cameraPitch);
        }
    }

    @Override
    public int getRenderId()
    {
        return 0;
    }
}
