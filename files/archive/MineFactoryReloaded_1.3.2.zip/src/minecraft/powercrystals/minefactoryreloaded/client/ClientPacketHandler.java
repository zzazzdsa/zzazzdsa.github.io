package powercrystals.minefactoryreloaded.client;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;

import powercrystals.minefactoryreloaded.common.PacketWrapper;
import powercrystals.minefactoryreloaded.common.TileEntityFactory;

import net.minecraft.src.EntityPlayer;
import net.minecraft.src.NetworkManager;
import net.minecraft.src.Packet250CustomPayload;
import net.minecraft.src.TileEntity;
import cpw.mods.fml.common.network.IPacketHandler;
import cpw.mods.fml.common.network.Player;

public class ClientPacketHandler implements IPacketHandler
{

    @Override
    public void onPacketData(NetworkManager manager, Packet250CustomPayload packet, Player player)
    {
        DataInputStream data = new DataInputStream(new ByteArrayInputStream(packet.data));
        int packetType = PacketWrapper.readPacketID(data);
        
        if (packetType == 1)
        {
            Class[] decodeAs = { Integer.class, Integer.class, Integer.class, Integer.class };
            Object[] packetReadout = PacketWrapper.readPacketData(data, decodeAs);
            
            TileEntity te = ((EntityPlayer)player).worldObj.getBlockTileEntity((Integer)packetReadout[0], (Integer)packetReadout[1], (Integer)packetReadout[2]);
            if (te instanceof TileEntityFactory)
            {
                TileEntityFactory tef = (TileEntityFactory) te;
                tef.rotateDirectlyTo((Integer)packetReadout[3]);
            }
        }
    }

}
