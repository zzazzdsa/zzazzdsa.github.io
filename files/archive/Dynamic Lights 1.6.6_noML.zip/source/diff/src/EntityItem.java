// This file ONLY tells you what and where this mod specifically adds to the minecraft sourcecode.

public class EntityItem extends Entity
{

	// new global class variables
	public boolean bIsLight;
	public PlayerTorch itemtorch;
	long time;
	
    public EntityItem(World world, double d, double d1, double d2, 
            ItemStack itemstack)
    {
		// append to class function

		int brightness = PlayerTorchArray.GetItemBrightnessValue(item.itemID);
		if (brightness > 0)
		{
			bIsLight = true;
			itemtorch = new PlayerTorch(this);
			PlayerTorchArray.AddTorchToArray(itemtorch);
			itemtorch.SetTorchBrightness(brightness);
			itemtorch.SetTorchRange(PlayerTorchArray.GetItemLightRangeValue(item.itemID));
			itemtorch.setDeathAge(PlayerTorchArray.GetItemDeathAgeValue(item.itemID));
			itemtorch.SetWorksUnderwater(PlayerTorchArray.GetItemWorksUnderWaterValue(item.itemID));
			itemtorch.setTorchState(worldObj, true);
			time = System.currentTimeMillis();
		}

    }

	
    public void onUpdate()
    {
		// add this inside onUpdate(){}, function can be found by string "random.fizz"
		if (bIsLight)
		{
			this.itemtorch.setTorchPos(worldObj, (float)this.posX, (float)this.posY, (float)this.posZ);
			
			boolean newsecond = false;
			if(System.currentTimeMillis() >= time + 1000L) 
			{
				newsecond = true;
				time = System.currentTimeMillis();
			}
			
			if (this.itemtorch.hasDeathAge())
			{
				if (this.itemtorch.hasReachedDeathAge())
				{
					this.setEntityDead();
					PlayerTorchArray.RemoveTorchFromArray(worldObj, this.itemtorch);
				}
				else if (newsecond)
				{
					this.itemtorch.doAgeTick();
				}
			}
		}
		
		// inside onUpdate(){}, look for the 6000 and add this
        //if(age >= 6000)
        {
			if (bIsLight)
				PlayerTorchArray.RemoveTorchFromArray(worldObj, itemtorch);
			
			// note this previously present call here, look for it in 2 other functions
			setEntityDead();
        }
    }


	// and add the if(bIsLight) statement there aswell
    public boolean attackEntityFrom(Entity entity, int i)
    {
		//...
        //if(health <= 0)
        //{
			if (bIsLight)
				PlayerTorchArray.RemoveTorchFromArray(worldObj, itemtorch);;
		
            setEntityDead();
        //}
		//...
    }

	// and add the if(bIsLight) statement there aswell
    public void onCollideWithPlayer(EntityPlayer entityplayer)
    {
		//...
		/*
        if(delayBeforeCanPickup == 0 && entityplayer.inventory.addItemStackToInventory(item))
        {
            worldObj.playSoundAtEntity(this, "random.pop", 0.2F, ((rand.nextFloat() - rand.nextFloat()) * 0.7F + 1.0F) * 2.0F);
            entityplayer.onItemPickup(this, i);
		*/
			
			if (bIsLight)
				PlayerTorchArray.RemoveTorchFromArray(worldObj, itemtorch);
			
            setEntityDead();
        }
    }
}
