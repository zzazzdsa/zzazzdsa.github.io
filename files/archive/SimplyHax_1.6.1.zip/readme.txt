
To install:

Simply Hax is now a FML coremod. That means drag and drop installation, and the fall bug is fixed!
Simply put the .jar found in /setup/coremods/ into your .minecraft/coremods/ folder!