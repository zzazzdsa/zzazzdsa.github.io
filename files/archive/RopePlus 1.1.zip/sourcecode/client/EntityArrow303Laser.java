// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import java.util.*;
import net.minecraft.client.Minecraft;

// Referenced classes of package net.minecraft.src:
//            EntityArrow303, Block, Item, ItemStack, 
//            Entity, World, Vec3D, MovingObjectPosition, 
//            EnumMovingObjectType, mod_Arrows303, SettingBoolean, EntityReddustFX, 
//            EffectRenderer, EntityLiving

public class EntityArrow303Laser extends EntityArrow303
{

    public void entityInit()
    {
        super.entityInit();
        name = "LaserArrow";
        craftingResults = 1;
        itemId = 2818 + Block.blocksList.length;
        tip = Item.redstone;
        spriteFile = "/arrows/laserarrow.png";
        curvature = 0.0F;
        slowdown = 1.3F;
        precision = 0.0F;
        speed = 2.0F;
        pierced = false;
        piercedMobs = new HashSet();
        item = new ItemStack(itemId, 1, 0);
    }

    public EntityArrow303Laser(World world)
    {
        super(world);
    }

    public EntityArrow303Laser(World world, double d, double d1, double d2)
    {
        super(world, d, d1, d2);
    }

    public EntityArrow303Laser(World world, EntityLiving entityliving)
    {
        super(world, entityliving);
    }

    public boolean onHitTarget(Entity entity)
    {
        entity.attackEntityFrom(DamageSource.causePlayerDamage((EntityPlayer)shooter), 8);
        pierced = true;
        piercedMobs.add(entity);
        target = null;
        worldObj.playSoundAtEntity(this, sound, 1.0F, ((rand.nextFloat() - rand.nextFloat()) * 0.2F + 1.0F) / 0.8F);
        return false;
    }

    public boolean isInSight(Entity entity)
    {
        return canSee(this, entity) && canSee(entity, this);
    }

    public boolean canSee(Entity entity, Entity entity1)
    {
        MovingObjectPosition movingobjectposition = worldObj.rayTraceBlocks(((Vec3D)null).createVector(entity.posX, entity.posY + (double)entity.getEyeHeight(), entity.posZ), ((Vec3D)null).createVector(entity1.posX, entity1.posY + (double)entity1.getEyeHeight(), entity1.posZ));
        return movingobjectposition == null || movingobjectposition.typeOfHit == EnumMovingObjectType.TILE && isTransparent(worldObj.getBlockId(movingobjectposition.blockX, movingobjectposition.blockY, movingobjectposition.blockZ));
    }

    public boolean onHitBlock()
    {
        if(!isTransparent(inTile))
        {
            if(pierced)
            {
                setEntityDead();
            }
            return true;
        } else
        {
            return false;
        }
    }

    public boolean isTransparent(int i)
    {
        return Block.lightOpacity[i] != 255;
    }

    public void tickFlying()
    {
        super.tickFlying();
        if(true)
        {
            EntityReddustFX entityreddustfx = new EntityReddustFX(worldObj, posX, posY, posZ, 0.01F, 0.01F, 0.01F);
            entityreddustfx.motionX = entityreddustfx.motionZ = entityreddustfx.motionY = 0.01D;
            entityreddustfx.renderDistanceWeight = 10D;
            mod_Arrows303.mc.effectRenderer.addEffect(entityreddustfx);
        }
    }

    public boolean canTarget(Entity entity)
    {
        return !piercedMobs.contains(entity) && super.canTarget(entity);
    }

    public boolean pierced;
    public Set piercedMobs;
    public static String sound = "damage.fallbig";

}
