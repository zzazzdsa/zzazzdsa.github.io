// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import java.util.Random;
import net.minecraft.client.Minecraft;

// Referenced classes of package net.minecraft.src:
//            EntityArrow303, Block, Item, ItemStack, 
//            Entity, mod_Arrows303, SettingBoolean, EntityFlameFX, 
//            EntityFX, EntitySmokeFX, EffectRenderer, World, 
//            EntityLiving

public class EntityArrow303Fire extends EntityArrow303
{

    public EntityArrow303Fire(World world)
    {
        super(world);
    }

    public EntityArrow303Fire(World world, EntityLiving entityliving)
    {
        super(world, entityliving);
    }

    public EntityArrow303Fire(World world, double d, double d1, double d2)
    {
        super(world, d, d1, d2);
    }

    public void entityInit()
    {
        super.entityInit();
        name = "FiArrow";
        craftingResults = 1;
        itemId = 129 + Block.blocksList.length;
        tip = Item.coal;
        item = new ItemStack(itemId, 1, 0);
        spriteFile = "/arrows/fiarrow.png";
    }

    public boolean onHit()
    {
        if(tryToPlaceBlock(51))
        {
            setEntityDead();
        }
        return true;
    }

    public boolean onHitTarget(Entity entity)
    {
    	entity.setFire(300/20);
        return true;
    }

    public void tickFlying()
    {
        super.tickFlying();
        if(true)
        {
            if(rand.nextBoolean())
            {
                EntityFlameFX obj = new EntityFlameFX(worldObj, posX, posY, posZ, 0.01D, 0.01D, 0.01D);
				obj.motionX = obj.motionZ = obj.motionY = 0.01D;
				obj.renderDistanceWeight = 10D;
				mod_Arrows303.mc.effectRenderer.addEffect(obj);
            }
			else
            {
                EntitySmokeFX obj = new EntitySmokeFX(worldObj, posX, posY, posZ, 0.01D, 0.01D, 0.01D);
				obj.motionX = obj.motionZ = obj.motionY = 0.01D;
				obj.renderDistanceWeight = 10D;
				mod_Arrows303.mc.effectRenderer.addEffect(obj);
            }
        }
    }
}
