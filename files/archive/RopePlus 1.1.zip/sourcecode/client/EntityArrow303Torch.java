// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;


// Referenced classes of package net.minecraft.src:
//            EntityArrow303, Block, ItemStack, Entity, 
//            World, EntityLiving

public class EntityArrow303Torch extends EntityArrow303
{

    public void entityInit()
    {
        super.entityInit();
        name = "TorchArrow";
        craftingResults = 1;
        itemId = 133 + Block.blocksList.length;
        tip = Block.torchWood;
        spriteFile = "/arrows/torcharrow.png";
        item = new ItemStack(itemId, 1, 0);
    }

    public EntityArrow303Torch(World world)
    {
        super(world);
    }

    public EntityArrow303Torch(World world, EntityLiving entityliving)
    {
        super(world, entityliving);
    }

    public EntityArrow303Torch(World world, double d, double d1, double d2)
    {
        super(world, d, d1, d2);
    }

    public boolean onHit()
    {
        if(tryToPlaceBlock(50))
        {
            setEntityDead();
        }
        return true;
    }

    public boolean onHitTarget(Entity entity)
    {
    	entity.setFire(300/20);
        return true;
    }
}
