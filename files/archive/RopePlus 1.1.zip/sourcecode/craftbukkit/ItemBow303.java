package net.minecraft.server;

import java.util.Random;

public class ItemBow303 extends Item
{
    public static float precisionBase = 1.5F;

    public ItemBow303(int i)
    {
        super(i);
        maxStackSize = 1;
    }

    public void a(ItemStack itemstack, World world, EntityHuman entityhuman, int i)
    {
        mod_Arrows303.inst.selectArrow(world, entityhuman);
        EntityArrow303 entityarrow303 = mod_Arrows303.inst.selectedArrow(entityhuman);
        if (entityarrow303 == null)
        {
            return;
        }
        int j = c(itemstack) - i;
        float f = (float)j / 20F;
        f = (f * f + f * 2.0F) / 3F;
        if ((double)f < 0.10000000000000001D)
        {
            return;
        }
        if (f > 1.0F)
        {
            f = 1.0F;
        }
        EntityArrow entityarrow = new EntityArrow(world, entityhuman, f * 2.0F);
        if (f == 1.0F)
        {
            entityarrow.d = true;
        }
        int k = mod_Arrows303.inst.burstSize;
        do
        {
            if (--entityhuman.inventory.items[mod_Arrows303.inst.selectedSlot(entityhuman)].count <= 0)
            {
                entityhuman.inventory.items[mod_Arrows303.inst.selectedSlot(entityhuman)] = null;
                mod_Arrows303.inst.selectArrow(world, entityhuman);
            }
            world.makeSound(entityhuman, "random.bow", 1.0F, 1.0F / (c.nextFloat() * 0.4F + 1.2F) + f * 0.5F);
            EntityArrow303 entityarrow303_1 = entityarrow303.newArrow(world, entityhuman);
            setPrecision(entityarrow303_1, mod_Arrows303.inst.burstSize, f * 1.5F);
            if (!world.isStatic)
            {
                world.addEntity(entityarrow303_1);
                if (f == 1.0F)
                {
                    entityarrow303_1.arrowCritical = true;
                }
            }
        }
        while (entityarrow303 == mod_Arrows303.inst.selectedArrow(entityhuman) && --k > 0);
        mod_Arrows303.inst.burstSize = 1;
    }

    public ItemStack b(ItemStack itemstack, World world, EntityHuman entityhuman)
    {
        return itemstack;
    }

    public int c(ItemStack itemstack)
    {
        return 0x11940;
    }

    public EnumAnimation d(ItemStack itemstack)
    {
        return EnumAnimation.d;
    }

    public ItemStack a(ItemStack itemstack, World world, EntityHuman entityhuman)
    {
        entityhuman.a(itemstack, c(itemstack));
        return itemstack;
    }

    public void setPrecision(EntityArrow303 entityarrow303, int i, float f)
    {
        float f1 = (float)i * precisionBase;
        float f2 = entityarrow303.speed * f;
        entityarrow303.setArrowHeading(entityarrow303.motX, entityarrow303.motY, entityarrow303.motZ, f2, f1);
    }
}
