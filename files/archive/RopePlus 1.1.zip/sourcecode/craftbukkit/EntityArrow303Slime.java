package net.minecraft.server;

import java.util.Random;

public class EntityArrow303Slime extends EntityArrow303
{
    public void b()
    {
        super.b();
        name = "SlimeArrow";
        craftingResults = 1;
        itemId = 134 + Block.byId.length;
        tip = Item.SLIME_BALL;
        spriteFile = "/arrows/slimearrow.png";
        item = new ItemStack(itemId, 1, 0);
    }

    public EntityArrow303Slime(World world)
    {
        super(world);
    }

    public EntityArrow303Slime(World world, EntityLiving entityliving)
    {
        super(world, entityliving);
    }

    public EntityArrow303Slime(World world, double d, double d1, double d2)
    {
        super(world, d, d1, d2);
    }

    public EntityLiving makeMob()
    {
        EntitySlime entityslime = new EntitySlime(world);
        entityslime.heal(1 << random.nextInt(4));
        return entityslime;
    }

    public boolean onHitBlock()
    {
        EntityLiving entityliving = makeMob();
        entityliving.setPositionRotation(locX, locY, locZ, yaw, pitch);
        if (world.addEntity(entityliving))
        {
            entityliving.ao();
            die();
        }
        return true;
    }

    public boolean onHitTarget(Entity entity)
    {
        EntityLiving entityliving = makeMob();
        entityliving.setPositionRotation(entity.locX, entity.locY, entity.locZ, entity.yaw, entity.pitch);
        if (world.addEntity(entityliving))
        {
            entityliving.ao();
            if (!(entity instanceof EntityHuman))
            {
                entity.die();
            }
        }
        return true;
    }

    public void tickFlying()
    {
    }
}
