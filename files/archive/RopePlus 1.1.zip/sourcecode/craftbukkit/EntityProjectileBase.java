package net.minecraft.server;

import java.util.List;
import java.util.Random;

public abstract class EntityProjectileBase extends Entity
{
    public float speed;
    public float slowdown;
    public float curvature;
    public float precision;
    public float hitBox;
    public int dmg;
    public ItemStack item;
    public int ttlInGround;
    public int xTile;
    public int yTile;
    public int zTile;
    public int inTile;
    public int inData;
    public boolean inGround;
    public int arrowShake;
    public EntityLiving shooter;
    public int ticksInGround;
    public int ticksFlying;
    public boolean shotByPlayer;
    public boolean arrowCritical;

    public EntityProjectileBase(World world)
    {
        super(world);
        arrowCritical = false;
    }

    public EntityProjectileBase(World world, double d, double d1, double d2)
    {
        this(world);
        setPosition(d, d1, d2);
    }

    public EntityProjectileBase(World world, EntityLiving entityliving)
    {
        this(world);
        shooter = entityliving;
        shotByPlayer = entityliving instanceof EntityHuman;
        setPositionRotation(entityliving.locX, entityliving.locY + (double)entityliving.y(), entityliving.locZ, entityliving.yaw, entityliving.pitch);
        locX -= MathHelper.cos((yaw / 180F) * 3.141593F) * 0.16F;
        locY -= 0.10000000149011612D;
        locZ -= MathHelper.sin((yaw / 180F) * 3.141593F) * 0.16F;
        setPosition(locX, locY, locZ);
        motX = -MathHelper.sin((yaw / 180F) * 3.141593F) * MathHelper.cos((pitch / 180F) * 3.141593F);
        motZ = MathHelper.cos((yaw / 180F) * 3.141593F) * MathHelper.cos((pitch / 180F) * 3.141593F);
        motY = -MathHelper.sin((pitch / 180F) * 3.141593F);
        setArrowHeading(motX, motY, motZ, speed, precision);
    }

    protected void b()
    {
        xTile = -1;
        yTile = -1;
        zTile = -1;
        inTile = 0;
        inGround = false;
        arrowShake = 0;
        ticksFlying = 0;
        b(0.5F, 0.5F);
        height = 0.0F;
        hitBox = 0.3F;
        speed = 1.0F;
        slowdown = 0.99F;
        curvature = 0.03F;
        dmg = 4;
        precision = 1.0F;
        ttlInGround = 1200;
        item = null;
    }

    public void die()
    {
        shooter = null;
        super.die();
    }

    public void setArrowHeading(double d, double d1, double d2, float f,
            float f1)
    {
        float f2 = MathHelper.sqrt(d * d + d1 * d1 + d2 * d2);
        d /= f2;
        d1 /= f2;
        d2 /= f2;
        d += random.nextGaussian() * 0.0074999998323619366D * (double)f1;
        d1 += random.nextGaussian() * 0.0074999998323619366D * (double)f1;
        d2 += random.nextGaussian() * 0.0074999998323619366D * (double)f1;
        d *= f;
        d1 *= f;
        d2 *= f;
        motX = d;
        motY = d1;
        motZ = d2;
        float f3 = MathHelper.sqrt(d * d + d2 * d2);
        lastYaw = yaw = (float)((Math.atan2(d, d2) * 180D) / 3.1415927410125732D);
        lastPitch = pitch = (float)((Math.atan2(d1, f3) * 180D) / 3.1415927410125732D);
        ticksInGround = 0;
    }

    public void setVelocity(double d, double d1, double d2)
    {
        motX = d;
        motY = d1;
        motZ = d2;
        if (lastPitch == 0.0F && lastYaw == 0.0F)
        {
            float f = MathHelper.sqrt(d * d + d2 * d2);
            lastYaw = yaw = (float)((Math.atan2(d, d2) * 180D) / 3.1415927410125732D);
            lastPitch = pitch = (float)((Math.atan2(d1, f) * 180D) / 3.1415927410125732D);
        }
    }

    public void y_()
    {
        super.y_();
        if (lastPitch == 0.0F && lastYaw == 0.0F)
        {
            float f = MathHelper.sqrt(motX * motX + motZ * motZ);
            lastYaw = yaw = (float)((Math.atan2(motX, motZ) * 180D) / 3.1415927410125732D);
            lastPitch = pitch = (float)((Math.atan2(motY, f) * 180D) / 3.1415927410125732D);
        }
        if (arrowShake > 0)
        {
            arrowShake--;
        }
        if (inGround)
        {
            int i = world.getTypeId(xTile, yTile, zTile);
            int j = world.getData(xTile, yTile, zTile);
            if (i != inTile || j != inData)
            {
                inGround = false;
                motX *= random.nextFloat() * 0.2F;
                motY *= random.nextFloat() * 0.2F;
                motZ *= random.nextFloat() * 0.2F;
                ticksInGround = 0;
                ticksFlying = 0;
            }
            else
            {
                ticksInGround++;
                tickInGround();
                if (ticksInGround == ttlInGround)
                {
                    die();
                }
                return;
            }
        }
        else
        {
            ticksFlying++;
        }
        tickFlying();
        Vec3D vec3d = Vec3D.create(locX, locY, locZ);
        Vec3D vec3d1 = Vec3D.create(locX + motX, locY + motY, locZ + motZ);
        MovingObjectPosition movingobjectposition = world.a(vec3d, vec3d1);
        vec3d = Vec3D.create(locX, locY, locZ);
        vec3d1 = Vec3D.create(locX + motX, locY + motY, locZ + motZ);
        if (movingobjectposition != null)
        {
            vec3d1 = Vec3D.create(movingobjectposition.f.a, movingobjectposition.f.b, movingobjectposition.f.c);
        }
        Entity entity = null;
        List list = world.getEntities(this, boundingBox.a(motX, motY, motZ).grow(1.0D, 1.0D, 1.0D));
        double d = 0.0D;
        for (int k = 0; k < list.size(); k++)
        {
            Entity entity2 = (Entity)list.get(k);
            if (!canBeShot(entity2))
            {
                continue;
            }
            float f3 = hitBox;
            AxisAlignedBB axisalignedbb = entity2.boundingBox.grow(f3, f3, f3);
            MovingObjectPosition movingobjectposition1 = axisalignedbb.a(vec3d, vec3d1);
            if (movingobjectposition1 == null)
            {
                continue;
            }
            double d1 = vec3d.b(movingobjectposition1.f);
            if (d1 < d || d == 0.0D)
            {
                entity = entity2;
                d = d1;
            }
        }

        if (entity != null)
        {
            movingobjectposition = new MovingObjectPosition(entity);
        }
        if (movingobjectposition != null && ticksFlying > 2 && onHit())
        {
            Entity entity1 = movingobjectposition.entity;
            if (entity1 != null)
            {
                if (onHitTarget(entity1))
                {
                    if ((entity1 instanceof EntityLiving) && !(entity1 instanceof EntityHuman))
                    {
                        ((EntityLiving)entity1).lastDamageByPlayerTime++;
                    }
                    entity1.damageEntity(DamageSource.playerAttack((EntityHuman)shooter), arrowCritical ? dmg * 2 : dmg);
                    die();
                }
            }
            else
            {
                xTile = movingobjectposition.b;
                yTile = movingobjectposition.c;
                zTile = movingobjectposition.d;
                inTile = world.getTypeId(xTile, yTile, zTile);
                inData = world.getData(xTile, yTile, zTile);
                if (onHitBlock(movingobjectposition))
                {
                    motX = (float)(movingobjectposition.f.a - locX);
                    motY = (float)(movingobjectposition.f.b - locY);
                    motZ = (float)(movingobjectposition.f.c - locZ);
                    float f2 = MathHelper.sqrt(motX * motX + motY * motY + motZ * motZ);
                    locX -= (motX / (double)f2) * 0.05000000074505806D;
                    locY -= (motY / (double)f2) * 0.05000000074505806D;
                    locZ -= (motZ / (double)f2) * 0.05000000074505806D;
                    inGround = true;
                    arrowShake = 7;
                    arrowCritical = false;
                }
                else
                {
                    inTile = 0;
                    inData = 0;
                }
            }
        }
        if (arrowCritical)
        {
            for (int l = 0; l < 4; l++)
            {
                world.a("crit", locX + (motX * (double)l) / 4D, locY + (motY * (double)l) / 4D, locZ + (motZ * (double)l) / 4D, -motX, -motY + 0.20000000000000001D, -motZ);
            }
        }
        locX += motX;
        locY += motY;
        locZ += motZ;
        handleMotionUpdate();
        float f1 = MathHelper.sqrt(motX * motX + motZ * motZ);
        yaw = (float)((Math.atan2(motX, motZ) * 180D) / 3.1415927410125732D);
        for (pitch = (float)((Math.atan2(motY, f1) * 180D) / 3.1415927410125732D); pitch - lastPitch < -180F; lastPitch -= 360F) { }
        for (; pitch - lastPitch >= 180F; lastPitch += 360F) { }
        for (; yaw - lastYaw < -180F; lastYaw -= 360F) { }
        for (; yaw - lastYaw >= 180F; lastYaw += 360F) { }
        pitch = lastPitch + (pitch - lastPitch) * 0.2F;
        yaw = lastYaw + (yaw - lastYaw) * 0.2F;
        setPosition(locX, locY, locZ);
    }

    public void handleMotionUpdate()
    {
        float f = slowdown;
        if (i_())
        {
            for (int i = 0; i < 4; i++)
            {
                float f1 = 0.25F;
                world.a("bubble", locX - motX * (double)f1, locY - motY * (double)f1, locZ - motZ * (double)f1, motX, motY, motZ);
            }

            f *= 0.8F;
        }
        motX *= f;
        motY *= f;
        motZ *= f;
        motY -= curvature;
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        nbttagcompound.setShort("xTile", (short)xTile);
        nbttagcompound.setShort("yTile", (short)yTile);
        nbttagcompound.setShort("zTile", (short)zTile);
        nbttagcompound.setByte("inTile", (byte)inTile);
        nbttagcompound.setByte("inData", (byte)inData);
        nbttagcompound.setByte("shake", (byte)arrowShake);
        nbttagcompound.setByte("inGround", (byte)(inGround ? 1 : 0));
        nbttagcompound.setBoolean("player", shotByPlayer);
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        xTile = nbttagcompound.getShort("xTile");
        yTile = nbttagcompound.getShort("yTile");
        zTile = nbttagcompound.getShort("zTile");
        inTile = nbttagcompound.getByte("inTile") & 0xff;
        inData = nbttagcompound.getByte("inData") & 0xff;
        arrowShake = nbttagcompound.getByte("shake") & 0xff;
        inGround = nbttagcompound.getByte("inGround") == 1;
        shotByPlayer = nbttagcompound.getBoolean("player");
    }

    public void a_(EntityHuman entityhuman)
    {
        if (item == null)
        {
            return;
        }
        if (world.isStatic)
        {
            return;
        }
        if (inGround && shotByPlayer && arrowShake <= 0 && entityhuman.inventory.pickup(item.cloneItemStack()))
        {
            world.makeSound(this, "random.pop", 0.2F, ((random.nextFloat() - random.nextFloat()) * 0.7F + 1.0F) * 2.0F);
            entityhuman.receive(this, 1);
            die();
        }
    }

    public boolean canBeShot(Entity entity)
    {
        return entity.e_() && (entity != shooter || ticksFlying >= 2) && (!(entity instanceof EntityLiving) || ((EntityLiving)entity).deathTicks <= 0);
    }

    public boolean onHit()
    {
        return true;
    }

    public boolean onHitTarget(Entity entity)
    {
        world.makeSound(this, "random.drr", 1.0F, 1.2F / (random.nextFloat() * 0.2F + 0.9F));
        return true;
    }

    public void tickFlying()
    {
    }

    public void tickInGround()
    {
    }

    public boolean onHitBlock(MovingObjectPosition movingobjectposition)
    {
        return onHitBlock();
    }

    public boolean onHitBlock()
    {
        world.makeSound(this, "random.drr", 1.0F, 1.2F / (random.nextFloat() * 0.2F + 0.9F));
        return true;
    }

    public float getShadowSize()
    {
        return 0.0F;
    }
}
