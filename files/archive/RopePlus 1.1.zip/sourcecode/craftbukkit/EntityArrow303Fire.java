package net.minecraft.server;

public class EntityArrow303Fire extends EntityArrow303
{
    public EntityArrow303Fire(World world)
    {
        super(world);
    }

    public EntityArrow303Fire(World world, EntityLiving entityliving)
    {
        super(world, entityliving);
    }

    public EntityArrow303Fire(World world, double d, double d1, double d2)
    {
        super(world, d, d1, d2);
    }

    public void b()
    {
        super.b();
        name = "FiArrow";
        craftingResults = 1;
        itemId = 129 + Block.byId.length;
        tip = Item.COAL;
        item = new ItemStack(itemId, 1, 0);
        spriteFile = "/arrows/fiarrow.png";
    }

    public boolean onHit()
    {
        if (tryToPlaceBlock(51))
        {
            die();
        }
        return true;
    }

    public boolean onHitTarget(Entity entity)
    {
        entity.setOnFire(15);
        return true;
    }

    public void tickFlying()
    {
    }
}
