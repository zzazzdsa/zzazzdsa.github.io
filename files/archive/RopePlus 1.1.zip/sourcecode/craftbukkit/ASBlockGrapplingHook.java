package net.minecraft.server;

import java.util.Random;

public class ASBlockGrapplingHook extends Block
{
    private int renderType;

    protected ASBlockGrapplingHook(int i, int j, int k)
    {
        super(i, j, Material.WOOD);
        renderType = k;
        a(0.0F, 0.0F, 0.0F, 1.0F, 0.125F, 1.0F);
    }

    public AxisAlignedBB e(World world, int i, int j, int k)
    {
        return null;
    }

    public boolean a()
    {
        return false;
    }

    public boolean b()
    {
        return false;
    }

    public boolean canPlace(World world, int i, int j, int k)
    {
        int l = world.getTypeId(i, j - 1, k);
        if (l == 0 || !Block.byId[l].a())
        {
            return false;
        }
        else
        {
            return world.getMaterial(i, j - 1, k).isBuildable();
        }
    }

    public void doPhysics(World world, int i, int j, int k, int l)
    {
        func_314_h(world, i, j, k);
    }

    private boolean func_314_h(World world, int i, int j, int k)
    {
        if (!canPlace(world, i, j, k))
        {
            b(world, i, j, k, world.getData(i, j, k), 0);
            world.setTypeId(i, j, k, 0);
            onBlockDestroyed(world, i, j, k);
            return false;
        }
        else
        {
            return true;
        }
    }

    public int getDropType(int i, Random random, int j)
    {
        return mod_ASGrapplingHook.itemGrapplingHook.id;
    }

    public int a(Random random)
    {
        return 1;
    }

    public void postBreak(World world, int i, int j, int k, int l)
    {
        onBlockDestroyed(world, i, j, k);
    }

    public void wasExploded(World world, int i, int j, int k)
    {
        onBlockDestroyed(world, i, j, k);
    }

    private void onBlockDestroyed(World world, int i, int j, int k)
    {
        int ai[][] =
        {
            {
                i - 1, j - 1, k
            }, {
                i + 1, j - 1, k
            }, {
                i, j - 1, k - 1
            }, {
                i, j - 1, k + 1
            }
        };
        for (int l = 0; l < ai.length; l++)
        {
            if (world.getTypeId(ai[l][0], ai[l][1], ai[l][2]) != mod_ASGrapplingHook.blockRope.id)
            {
                continue;
            }
            for (int i1 = ai[l][1]; world.getTypeId(ai[l][0], i1, ai[l][2]) == mod_ASGrapplingHook.blockRope.id; i1--)
            {
                world.setTypeId(ai[l][0], i1, ai[l][2], 0);
            }
        }
    }
}
