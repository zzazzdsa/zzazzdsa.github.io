package net.minecraft.server;

public class EntityArrow303Dirt extends EntityArrow303
{
    public static final int defaultBlockId;

    public void subscreen()
    {
    }

    public void setupConfig()
    {
    }

    public void b()
    {
        super.b();
        name = "DirtArrow";
        craftingResults = 1;
        itemId = 132 + Block.byId.length;
        tip = Block.DIRT;
        item = new ItemStack(itemId, 1, 0);
        spriteFile = "/arrows/dirtarrow.png";
    }

    public EntityArrow303Dirt(World world)
    {
        super(world);
    }

    public EntityArrow303Dirt(World world, EntityLiving entityliving)
    {
        super(world, entityliving);
    }

    public EntityArrow303Dirt(World world, double d, double d1, double d2)
    {
        super(world, d, d1, d2);
    }

    public boolean onHit()
    {
        spawnDirt();
        return true;
    }

    public boolean onHitBlock()
    {
        die();
        return true;
    }

    public void spawnDirt()
    {
        int i = MathHelper.floor(locX);
        int j = MathHelper.floor(locY);
        int k = MathHelper.floor(locZ);
        for (int l = 0; l <= 0; l++)
        {
            label0:
            for (int i1 = 0; i1 <= 0; i1++)
            {
                int j1 = 0;
                do
                {
                    if (j1 > 0)
                    {
                        continue label0;
                    }
                    int k1 = i + l;
                    int l1 = j + j1;
                    int i2 = k + i1;
                    if ((Math.abs(l) == 0 || Math.abs(j1) == 0 || Math.abs(i1) == 0) && world.mayPlace(defaultBlockId, k1, l1, i2, true, Block.DIRT.id))
                    {
                        world.setTypeId(k1, l1, i2, Block.DIRT.id);
                        continue label0;
                    }
                    j1++;
                }
                while (true);
            }
        }
    }

    public void tickFlying()
    {
        super.tickFlying();
    }

    static
    {
        defaultBlockId = Block.DIRT.id;
    }
}
