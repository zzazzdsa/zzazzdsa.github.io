package net.minecraft.server;

import java.io.PrintStream;
import java.util.Random;

public class ASBlockRope extends BlockContainer
{
    public float ascensionSpeed;
    public float descensionSpeed;
    private int renderType;

    protected ASBlockRope(int i, int j, int k)
    {
        super(i, j, Material.REPLACEABLE_PLANT);
        ascensionSpeed = 0.2F;
        descensionSpeed = -0.15F;
        renderType = k;
    }

    public TileEntity a_()
    {
        return null;
    }

    public boolean canPlace(World world, int i, int j, int k, int l)
    {
        switch (l)
        {
            case 1:
                return canBePlacedOn(world.getTypeId(i, j + 1, k));

            case 2:
                return canBePlacedOn(world.getTypeId(i, j, k + 1));

            case 3:
                return canBePlacedOn(world.getTypeId(i, j, k - 1));

            case 4:
                return canBePlacedOn(world.getTypeId(i + 1, j, k));

            case 5:
                return canBePlacedOn(world.getTypeId(i - 1, j, k));
        }
        return false;
    }

    private boolean canBePlacedOn(int i)
    {
        if (i == 0)
        {
            return false;
        }
        else
        {
            Block block = Block.byId[i];
            return block.b() && block.material.isSolid();
        }
    }

    public void a(World world, int i, int j, int k, Entity entity)
    {
        if (entity instanceof EntityLiving)
        {
            entity.fallDistance = 0.0F;
            if (entity.motY < (double)descensionSpeed)
            {
                entity.motY = descensionSpeed;
            }
            if (entity.positionChanged)
            {
                entity.motY = ascensionSpeed;
            }
        }
    }

    public AxisAlignedBB e(World world, int i, int j, int k)
    {
        int l = world.getData(i, j, k);
        float f = 0.125F;
        if (l == 1)
        {
            a(0.0F, 0.0F, 1.0F - f, 1.0F, 1.0F, 1.0F);
        }
        if (l == 4)
        {
            a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, f);
        }
        if (l == 8)
        {
            a(1.0F - f, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
        }
        if (l == 2)
        {
            a(0.0F, 0.0F, 0.0F, f, 1.0F, 1.0F);
        }
        return super.e(world, i, j, k);
    }

    public void f()
    {
        a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
    }

    public boolean a()
    {
        return false;
    }

    public boolean b()
    {
        return false;
    }

    public void updateShape(IBlockAccess iblockaccess, int i, int j, int k)
    {
        int l = iblockaccess.getData(i, j, k);
        float f = 1.0F;
        float f1 = 1.0F;
        float f2 = 1.0F;
        float f3 = 0.0F;
        float f4 = 0.0F;
        float f5 = 0.0F;
        boolean flag = l > 0;
        if ((l & 2) != 0)
        {
            f3 = Math.max(f3, 0.0625F);
            f = 0.0F;
            f1 = 0.0F;
            f4 = 1.0F;
            f2 = 0.0F;
            f5 = 1.0F;
            boolean flag1 = true;
        }
        if ((l & 8) != 0)
        {
            f = Math.min(f, 0.9375F);
            f3 = 1.0F;
            f1 = 0.0F;
            f4 = 1.0F;
            f2 = 0.0F;
            f5 = 1.0F;
            boolean flag2 = true;
        }
        if ((l & 4) != 0)
        {
            f5 = Math.max(f5, 0.0625F);
            f2 = 0.0F;
            f = 0.0F;
            f3 = 1.0F;
            f1 = 0.0F;
            f4 = 1.0F;
            boolean flag3 = true;
        }
        if ((l & 1) != 0)
        {
            f2 = Math.min(f2, 0.9375F);
            f5 = 1.0F;
            f = 0.0F;
            f3 = 1.0F;
            f1 = 0.0F;
            f4 = 1.0F;
            boolean flag4 = true;
        }
        a(f, f1, f2, f3, f4, f5);
    }

    public int c()
    {
        return 20;
    }

    public int a(Random random)
    {
        return 0;
    }

    public void postBreak(World world, int i, int j, int k, int l)
    {
        onBlockDestroyed(world, i, j, k);
    }

    public void wasExploded(World world, int i, int j, int k)
    {
        onBlockDestroyed(world, i, j, k);
    }

    public void onBlockDestroyed(World world, int i, int j, int k)
    {
        if (world.isStatic)
        {
            return;
        }
        int j1 = 1;
        int l;
        do
        {
            if (world.getTypeId(i, j + j1, k) != mod_ASGrapplingHook.blockRope.id)
            {
                l = (j + j1) - 1;
                break;
            }
            j1++;
        }
        while (true);
        j1 = -1;
        int i1;
        do
        {
            if (world.getTypeId(i, j + j1, k) != mod_ASGrapplingHook.blockRope.id)
            {
                i1 = j + j1 + 1;
                break;
            }
            j1--;
        }
        while (true);
        j1 = l - i1;
        System.out.println((new StringBuilder()).append("Rope min: ").append(i1).append(", Rope max: ").append(l).append(", lenght: ").append(j1).toString());
        for (int k1 = 0; k1 <= j1; k1++)
        {
            world.setTypeId(i, l - k1, k, 0);
        }

        int l1 = l;
        int ai[][] =
        {
            {
                i - 1, l1 + 1, k
            }, {
                i, l1 + 1, k - 1
            }, {
                i, l1 + 1, k + 1
            }, {
                i + 1, l1 + 1, k
            }
        };
        boolean flag = false;
        int i2 = 0;
        do
        {
            if (i2 >= ai.length)
            {
                break;
            }
            if (world.getTypeId(ai[i2][0], ai[i2][1], ai[i2][2]) == mod_ASGrapplingHook.blockGrapplingHook.id)
            {
                world.setTypeId(ai[i2][0], ai[i2][1], ai[i2][2], 0);
                EntityItem entityitem1 = new EntityItem(world, i, j, k, new ItemStack(mod_ASGrapplingHook.itemGrapplingHook));
                entityitem1.pickupDelay = 5;
                world.addEntity(entityitem1);
                flag = true;
                break;
            }
            i2++;
        }
        while (true);
        if (!flag)
        {
            EntityItem entityitem = new EntityItem(world, i, j, k, new ItemStack(mod_Arrows303.getArrowItemByTip(mod_Rope.rope)));
            entityitem.pickupDelay = 5;
            world.addEntity(entityitem);
        }
    }
}
