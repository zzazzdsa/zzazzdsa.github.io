package net.minecraft.server;

public class EntityArrow303Grass extends EntityArrow303
{
    public void b()
    {
        super.b();
        name = "GrassArrow";
        craftingResults = 1;
        itemId = 3439 + Block.byId.length;
        tip = Item.SEEDS;
        item = new ItemStack(itemId, 1, 0);
        spriteFile = "/arrows/grassarrow.png";
    }

    public EntityArrow303Grass(World world)
    {
        super(world);
    }

    public EntityArrow303Grass(World world, EntityLiving entityliving)
    {
        super(world, entityliving);
    }

    public EntityArrow303Grass(World world, double d, double d1, double d2)
    {
        super(world, d, d1, d2);
    }

    public boolean onHit()
    {
        int i = MathHelper.floor(locX);
        int j = MathHelper.floor(locY);
        int k = MathHelper.floor(locZ);
        for (int l = i - 1; l <= i + 1; l++)
        {
            for (int i1 = j - 1; i1 <= j + 1; i1++)
            {
                for (int j1 = k - 1; j1 <= k + 1; j1++)
                {
                    int k1 = world.getTypeId(l, i1, j1);
                    if (k1 == 3)
                    {
                        world.setTypeId(l, i1, j1, 2);
                        die();
                        continue;
                    }
                    if (k1 == 4)
                    {
                        world.setTypeId(l, i1, j1, 48);
                        die();
                        continue;
                    }
                    if (k1 == 60 && i1 != 127 && world.getTypeId(l, i1 + 1, j1) == 0)
                    {
                        world.setTypeId(l, i1 + 1, j1, 59);
                        die();
                    }
                }
            }
        }

        return true;
    }

    public void tickFlying()
    {
    }
}
