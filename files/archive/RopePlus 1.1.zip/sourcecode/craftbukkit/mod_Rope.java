package net.minecraft.server;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.server.MinecraftServer;

public class mod_Rope extends BaseModMp
{
    private boolean loaded;
    static List ropeEntArray = new ArrayList();
    static List ropePosArray = new ArrayList();
    public static int idBlock;
    public static Block rope;
    public static int rtex;
    private static long time;

    public mod_Rope()
    {
        loaded = false;
    }

    public void load()
    {
        if (loaded)
        {
            return;
        }
        else
        {
            loaded = true;
            rtex = ModLoader.addOverride("/terrain.png", "/imgz/rope2.png");
            ModLoader.RegisterBlock(rope);
            ModLoader.AddRecipe(new ItemStack(rope, 12), new Object[]
                    {
                        " # ", " # ", " # ", Character.valueOf('#'), Item.STRING
                    });
            time = System.currentTimeMillis();
            ModLoader.SetInGameHook(this, true, false);
            return;
        }
    }

    public void ModsLoaded()
    {
        load();
    }

    public void OnTickInGame(MinecraftServer minecraftserver)
    {
        if (minecraftserver.worlds == null || minecraftserver.worlds.get(0) == null)
        {
            return;
        }
        for (int i = 0; i < ropeEntArray.size(); i++)
        {
            Object obj = ropeEntArray.get(i);
            if (obj instanceof BlockRopePseudoEnt)
            {
                if (((BlockRopePseudoEnt)obj).OnUpdate())
                {
                    ropeEntArray.remove(i);
                }
                continue;
            }
            if ((obj instanceof ASTileEntityRope) && ((ASTileEntityRope)obj).OnUpdate())
            {
                ropeEntArray.remove(i);
            }
        }
    }

    public static void onRopeArrowHit(World world, int i, int j, int k)
    {
        int ai[] = new int[3];
        ai[0] = i;
        ai[1] = j;
        ai[2] = k;
        addCoordsToRopeArray(ai);
        BlockRopePseudoEnt blockropepseudoent = new BlockRopePseudoEnt(world, i, j, k, 31);
        addRopeToArray(blockropepseudoent);
    }

    public static void addRopeToArray(BlockRopePseudoEnt blockropepseudoent)
    {
        ropeEntArray.add(blockropepseudoent);
    }

    public static void addRopeToArray(ASTileEntityRope astileentityrope)
    {
        ropeEntArray.add(astileentityrope);
    }

    public static void addCoordsToRopeArray(int ai[])
    {
        ropePosArray.add(ai);
    }

    public static void removeCoordsFromRopeArray(int ai[])
    {
        ropePosArray.remove(ai);
    }

    public static int[] areCoordsArrowRope(int i, int j, int k)
    {
        for (int l = 0; l < ropePosArray.size(); l++)
        {
            int ai[] = (int[])ropePosArray.get(l);
            if (i == ai[0] && j == ai[1] && k == ai[2])
            {
                return ai;
            }
        }

        return null;
    }

    public String getVersion()
    {
        return "1.1 AS";
    }

    static
    {
        AS_Settings_RopePlus.InitSettings();
        idBlock = AS_Settings_RopePlus.blockIdRopeDJRoslin;
        rope = (new BlockRope(idBlock, rtex)).c(0.3F).a(Block.i).a("rope");
    }
}
