package net.minecraft.server;

public class EntityArrow303Torch extends EntityArrow303
{
    public void b()
    {
        super.b();
        name = "TorchArrow";
        craftingResults = 1;
        itemId = 133 + Block.byId.length;
        tip = Block.TORCH;
        spriteFile = "/arrows/torcharrow.png";
        item = new ItemStack(itemId, 1, 0);
    }

    public EntityArrow303Torch(World world)
    {
        super(world);
    }

    public EntityArrow303Torch(World world, EntityLiving entityliving)
    {
        super(world, entityliving);
    }

    public EntityArrow303Torch(World world, double d, double d1, double d2)
    {
        super(world, d, d1, d2);
    }

    public boolean onHit()
    {
        if (tryToPlaceBlock(50))
        {
            die();
        }
        return true;
    }

    public boolean onHitTarget(Entity entity)
    {
        entity.setOnFire(15);
        return true;
    }
}
