package net.minecraft.server;

public class ItemArrow303 extends Item
{
    public EntityArrow303 arrow;

    public ItemArrow303(int i, EntityArrow303 entityarrow303)
    {
        super(i);
        arrow = entityarrow303;
    }
}
