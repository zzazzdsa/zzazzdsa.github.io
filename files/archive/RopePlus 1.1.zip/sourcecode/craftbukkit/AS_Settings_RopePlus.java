package net.minecraft.server;

import java.io.*;
import java.util.Properties;

public class AS_Settings_RopePlus
{
    public static int blockIdRopeDJRoslin = 242;
    public static int blockIdRope = 243;
    public static int blockIdGrapplingHook = 244;
    public static boolean settingsLoaded = false;
    private static File configfile = new File("mods/RopePlus.txt");

    public AS_Settings_RopePlus()
    {
        InitSettings();
    }

    public static void InitSettings()
    {
        if (settingsLoaded)
        {
            return;
        }
        settingsLoaded = true;
        Properties properties = new Properties();
        if (configfile.exists())
        {
            try
            {
                properties.load(new FileInputStream(configfile));
            }
            catch (IOException ioexception)
            {
                System.out.println((new StringBuilder()).append("RopePlus config exception: ").append(ioexception).toString());
            }
            blockIdRope = Integer.parseInt(properties.getProperty("blockIdRope", new String((new StringBuilder()).append("").append(blockIdRope).toString())));
            blockIdGrapplingHook = Integer.parseInt(properties.getProperty("blockIdGrapplingHook", new String((new StringBuilder()).append("").append(blockIdGrapplingHook).toString())));
            blockIdRopeDJRoslin = Integer.parseInt(properties.getProperty("blockIdRopeDJRoslin", new String((new StringBuilder()).append("").append(blockIdRopeDJRoslin).toString())));
        }
        else
        {
            System.out.println("No RopePlus config found, trying to create...");
            try
            {
                configfile.createNewFile();
                properties.load(new FileInputStream(configfile));
            }
            catch (IOException ioexception1)
            {
                System.out.println((new StringBuilder()).append("RopePlus config exception: ").append(ioexception1).toString());
            }
            properties.setProperty("blockIdRope", new String((new StringBuilder()).append("").append(blockIdRope).toString()));
            properties.setProperty("blockIdGrapplingHook", new String((new StringBuilder()).append("").append(blockIdGrapplingHook).toString()));
            properties.setProperty("blockIdRopeDJRoslin", new String((new StringBuilder()).append("").append(blockIdRopeDJRoslin).toString()));
            try
            {
                FileOutputStream fileoutputstream = new FileOutputStream(configfile);
                properties.store(fileoutputstream, "Here you can customize Block ID's in case of incompatibility. Defaults: 242 - 244; ID may not exceed 255 unless a mod enables that");
            }
            catch (IOException ioexception2)
            {
                System.out.println((new StringBuilder()).append("RopePlus config exception: ").append(ioexception2).toString());
            }
        }
    }
}
