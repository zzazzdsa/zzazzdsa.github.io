package net.minecraft.server;

import java.util.Map;
import java.util.Random;

public class ASItemGrapplingHook extends Item
{
    public ASItemGrapplingHook(int i)
    {
        super(i);
        maxStackSize = 1;
    }

    public boolean isFull3D()
    {
        return true;
    }

    public boolean shouldRotateAroundWhenRendering()
    {
        return true;
    }

    public ItemStack a(ItemStack itemstack, World world, EntityHuman entityhuman)
    {
        if (mod_ASGrapplingHook.grapplingHooks.get(entityhuman) != null)
        {
            int i = ((ASEntityGrapplingHook)mod_ASGrapplingHook.grapplingHooks.get(entityhuman)).recallHook();
            entityhuman.s_();
        }
        else
        {
            world.makeSound(entityhuman, "random.hurt", 1.0F, 1.0F / (c.nextFloat() * 0.1F + 0.95F));
            if (!world.isStatic)
            {
                world.addEntity(new ASEntityGrapplingHook(world, entityhuman));
            }
            entityhuman.s_();
        }
        return itemstack;
    }
}
