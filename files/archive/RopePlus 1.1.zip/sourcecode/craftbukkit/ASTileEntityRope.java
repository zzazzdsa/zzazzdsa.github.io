package net.minecraft.server;

public class ASTileEntityRope
{
    private int delay;
    private World world;
    private int ix;
    private int iy;
    private int iz;
    private int remainrope;

    public ASTileEntityRope(World world1, int i, int j, int k, int l)
    {
        world = world1;
        ix = i;
        iy = j;
        iz = k;
        delay = 20;
        remainrope = l;
    }

    public boolean OnUpdate()
    {
        if (delay < 0)
        {
            return true;
        }
        delay--;
        if (delay == 0)
        {
            if (world.getTypeId(ix, iy - 1, iz) == 0 || world.getTypeId(ix, iy - 1, iz) == Block.SNOW.id)
            {
                remainrope--;
                if (remainrope <= 0)
                {
                    return true;
                }
                world.setTypeId(ix, iy - 1, iz, mod_ASGrapplingHook.blockRope.id);
                world.setData(ix, iy - 1, iz, world.getData(ix, iy, iz));
                ASTileEntityRope astileentityrope = new ASTileEntityRope(world, ix, iy - 1, iz, remainrope);
                mod_Rope.addRopeToArray(astileentityrope);
            }
            return true;
        }
        else
        {
            return false;
        }
    }
}
