package net.minecraft.server;

import java.util.*;

public class EntityArrow303Confusion extends EntityArrow303
{
    public static double radius = 6D;

    public EntityArrow303Confusion(World world)
    {
        super(world);
    }

    public EntityArrow303Confusion(World world, EntityLiving entityliving)
    {
        super(world, entityliving);
    }

    public EntityArrow303Confusion(World world, double d, double d1, double d2)
    {
        super(world, d, d1, d2);
    }

    public void b()
    {
        super.b();
        name = "ConfusionArrow";
        craftingResults = 1;
        itemId = 3543 + Block.byId.length;
        tip = Block.SAND;
        spriteFile = "/arrows/confusionarrow.png";
        item = new ItemStack(itemId, 1, 0);
    }

    public boolean onHitBlock()
    {
        confuse(this);
        return true;
    }

    public boolean onHitTarget(Entity entity)
    {
        confuse(entity);
        return true;
    }

    public void confuse(Entity entity)
    {
        List list = world.getEntities(this, entity.boundingBox.grow(radius, radius, radius));
        ArrayList arraylist = new ArrayList();
        Iterator iterator = list.iterator();
        do
        {
            if (!iterator.hasNext())
            {
                break;
            }
            Entity entity1 = (Entity)iterator.next();
            if ((entity1 instanceof EntityCreature) && entity1 != shooter)
            {
                arraylist.add((EntityCreature)entity1);
            }
        }
        while (true);
        if (arraylist.size() < 2)
        {
            return;
        }
        for (int i = 0; i < arraylist.size(); i++)
        {
            EntityCreature entitycreature = (EntityCreature)arraylist.get(i);
            EntityCreature entitycreature1 = (EntityCreature)arraylist.get(i == 0 ? arraylist.size() - 1 : i - 1);
            entitycreature.damageEntity(DamageSource.mobAttack(entitycreature1), 0);
            entitycreature1.target = entitycreature;
        }

        die();
    }

    public void tickFlying()
    {
    }
}
