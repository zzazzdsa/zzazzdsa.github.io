package net.minecraft.server;

import java.util.*;

public class ASEntityGrapplingHook extends Entity
{
    private int xTile;
    private int yTile;
    private int zTile;
    private int inTile;
    private boolean inGround;
    public EntityHuman owner;
    private Entity plantedHook;
    private int ticksInGround;
    private int ticksInAir;
    private int ticksCatchable;
    private int field_6388_l;
    private double field_6387_m;
    private double field_6386_n;
    private double field_6385_o;
    private double field_6384_p;
    private double field_6383_q;
    private double velocityX;
    private double velocityY;
    private double velocityZ;
    private double startPosX;
    private double startPosZ;

    public ASEntityGrapplingHook(World world)
    {
        super(world);
        xTile = -1;
        yTile = -1;
        zTile = -1;
        inTile = 0;
        inGround = false;
        ticksInAir = 0;
        ticksCatchable = 0;
        b(0.25F, 0.25F);
        cd = true;
        plantedHook = null;
    }

    public ASEntityGrapplingHook(World world, double d, double d1, double d2)
    {
        this(world);
        setPosition(d, d1, d2);
    }

    public ASEntityGrapplingHook(World world, EntityHuman entityhuman)
    {
        this(world);
        owner = entityhuman;
        mod_ASGrapplingHook.grapplingHooks.put(entityhuman, this);
        setPositionRotation(entityhuman.locX, (entityhuman.locY + 1.6200000000000001D) - (double)entityhuman.height, entityhuman.locZ, entityhuman.yaw, entityhuman.pitch);
        locX -= MathHelper.cos((yaw / 180F) * 3.141593F) * 0.16F;
        locY -= 0.10000000149011612D;
        locZ -= MathHelper.sin((yaw / 180F) * 3.141593F) * 0.16F;
        setPosition(locX, locY, locZ);
        height = 0.0F;
        float f = 0.4F;
        motX = -MathHelper.sin((yaw / 180F) * 3.141593F) * MathHelper.cos((pitch / 180F) * 3.141593F) * f;
        motZ = MathHelper.cos((yaw / 180F) * 3.141593F) * MathHelper.cos((pitch / 180F) * 3.141593F) * f;
        motY = -MathHelper.sin((pitch / 180F) * 3.141593F) * f;
        func_4042_a(motX, motY, motZ, 1.5F, 1.0F);
        startPosX = owner.locX;
        startPosZ = owner.locZ;
    }

    protected void b()
    {
    }

    public boolean isInRangeToRenderDist(double d)
    {
        return true;
    }

    public void func_4042_a(double d, double d1, double d2, float f,
            float f1)
    {
        float f2 = MathHelper.sqrt(d * d + d1 * d1 + d2 * d2);
        d /= f2;
        d1 /= f2;
        d2 /= f2;
        d += random.nextGaussian() * 0.0074999998323619366D * (double)f1;
        d1 += random.nextGaussian() * 0.0074999998323619366D * (double)f1;
        d2 += random.nextGaussian() * 0.0074999998323619366D * (double)f1;
        d *= f;
        d1 *= f;
        d2 *= f;
        motX = d;
        motY = d1;
        motZ = d2;
        float f3 = MathHelper.sqrt(d * d + d2 * d2);
        lastYaw = yaw = (float)((Math.atan2(d, d2) * 180D) / 3.1415927410125732D);
        lastPitch = pitch = (float)((Math.atan2(d1, f3) * 180D) / 3.1415927410125732D);
        ticksInGround = 0;
    }

    public void setPositionAndRotation2(double d, double d1, double d2, float f,
            float f1, int i)
    {
        field_6387_m = d;
        field_6386_n = d1;
        field_6385_o = d2;
        field_6384_p = f;
        field_6383_q = f1;
        field_6388_l = i;
        motX = velocityX;
        motY = velocityY;
        motZ = velocityZ;
    }

    public void setVelocity(double d, double d1, double d2)
    {
        velocityX = motX = d;
        velocityY = motY = d1;
        velocityZ = motZ = d2;
    }

    public void y_()
    {
        super.y_();
        if (field_6388_l > 0)
        {
            double d = locX + (field_6387_m - locX) / (double)field_6388_l;
            double d1 = locY + (field_6386_n - locY) / (double)field_6388_l;
            double d2 = locZ + (field_6385_o - locZ) / (double)field_6388_l;
            double d4;
            for (d4 = field_6384_p - (double)yaw; d4 < -180D; d4 += 360D) { }
            for (; d4 >= 180D; d4 -= 360D) { }
            yaw += d4 / (double)field_6388_l;
            pitch += (field_6383_q - (double)pitch) / (double)field_6388_l;
            field_6388_l--;
            setPosition(d, d1, d2);
            c(yaw, pitch);
            return;
        }
        if (!world.isStatic)
        {
            if (owner == null)
            {
                die();
                return;
            }
            ItemStack itemstack = owner.Q();
            if (owner.dead || itemstack == null || itemstack.getItem() != mod_ASGrapplingHook.itemGrapplingHook || i(owner) > 1024D)
            {
                die();
                return;
            }
            if (plantedHook != null)
            {
                if (plantedHook.dead)
                {
                    plantedHook = null;
                }
                else
                {
                    locX = plantedHook.locX;
                    locY = plantedHook.boundingBox.b + (double)plantedHook.length * 0.80000000000000004D;
                    locZ = plantedHook.locZ;
                    return;
                }
            }
        }
        if (inGround)
        {
            int i = world.getTypeId(xTile, yTile, zTile);
            if (i != inTile)
            {
                inGround = false;
                motX *= random.nextFloat() * 0.2F;
                motY *= random.nextFloat() * 0.2F;
                motZ *= random.nextFloat() * 0.2F;
                ticksInGround = 0;
                ticksInAir = 0;
            }
            else
            {
                ticksInGround++;
                if (ticksInGround == 1200)
                {
                    die();
                }
                return;
            }
        }
        else
        {
            ticksInAir++;
        }
        Vec3D vec3d = Vec3D.create(locX, locY, locZ);
        Vec3D vec3d1 = Vec3D.create(locX + motX, locY + motY, locZ + motZ);
        MovingObjectPosition movingobjectposition = world.a(vec3d, vec3d1);
        vec3d = Vec3D.create(locX, locY, locZ);
        vec3d1 = Vec3D.create(locX + motX, locY + motY, locZ + motZ);
        if (movingobjectposition != null)
        {
            vec3d1 = Vec3D.create(movingobjectposition.f.a, movingobjectposition.f.b, movingobjectposition.f.c);
        }
        Entity entity = null;
        List list = world.getEntities(this, boundingBox.a(motX, motY, motZ).grow(1.0D, 1.0D, 1.0D));
        double d3 = 0.0D;
        for (int j = 0; j < list.size(); j++)
        {
            Entity entity1 = (Entity)list.get(j);
            if (!entity1.e_() || entity1 == owner && ticksInAir < 5)
            {
                continue;
            }
            float f2 = 0.3F;
            AxisAlignedBB axisalignedbb = entity1.boundingBox.grow(f2, f2, f2);
            MovingObjectPosition movingobjectposition1 = axisalignedbb.a(vec3d, vec3d1);
            if (movingobjectposition1 == null)
            {
                continue;
            }
            double d8 = vec3d.b(movingobjectposition1.f);
            if (d8 < d3 || d3 == 0.0D)
            {
                entity = entity1;
                d3 = d8;
            }
        }

        if (entity != null)
        {
            movingobjectposition = new MovingObjectPosition(entity);
        }
        if (movingobjectposition != null)
        {
            if (movingobjectposition.entity != null)
            {
                if (movingobjectposition.entity.damageEntity(DamageSource.playerAttack(owner), 0))
                {
                    plantedHook = movingobjectposition.entity;
                }
            }
            else
            {
                double d5 = motX;
                double d6 = motZ;
                xTile = movingobjectposition.b;
                yTile = movingobjectposition.c;
                zTile = movingobjectposition.d;
                inTile = world.getTypeId(xTile, yTile, zTile);
                motX = (float)(movingobjectposition.f.a - locX);
                motY = (float)(movingobjectposition.f.b - locY);
                motZ = (float)(movingobjectposition.f.c - locZ);
                float f3 = MathHelper.sqrt(motX * motX + motY * motY + motZ * motZ);
                locX -= (motX / (double)f3) * 0.05000000074505806D;
                locY -= (motY / (double)f3) * 0.05000000074505806D;
                locZ -= (motZ / (double)f3) * 0.05000000074505806D;
                if (movingobjectposition.f.b - (double)yTile == 1.0D && (world.getTypeId(xTile, yTile + 1, zTile) == 0 || world.getTypeId(xTile, yTile + 1, zTile) == Block.SNOW.id) && yTile + 1 < 128)
                {
                    if (d5 == 0.0D || d6 == 0.0D)
                    {
                        d5 = locX - startPosX;
                        d6 = locZ - startPosZ;
                    }
                    byte byte0 = (byte)(d5 > 0.0D ? 1 : -1);
                    byte byte1 = (byte)(d6 > 0.0D ? 1 : -1);
                    boolean flag = (world.getTypeId(xTile - byte0, yTile, zTile) == 0 || world.getTypeId(xTile - byte0, yTile, zTile) == Block.SNOW.id) && world.getTypeId(xTile - byte0, yTile + 1, zTile) == 0;
                    boolean flag1 = (world.getTypeId(xTile, yTile, zTile - byte1) == 0 || world.getTypeId(xTile, yTile, zTile - byte1) == Block.SNOW.id) && world.getTypeId(xTile, yTile + 1, zTile - byte1) == 0;
                    int k1 = xTile;
                    int l1 = yTile;
                    int i2 = zTile;
                    byte byte2 = 0;
                    boolean flag2 = false;
                    if (flag && !flag1 || flag && flag1 && Math.abs(d5) > Math.abs(d6))
                    {
                        k1 -= byte0;
                        flag2 = true;
                        if (byte0 > 0)
                        {
                            byte2 = 8;
                        }
                        else
                        {
                            byte2 = 2;
                        }
                    }
                    else if (!flag && flag1 || flag && flag1 && Math.abs(d5) <= Math.abs(d6))
                    {
                        i2 -= byte1;
                        flag2 = true;
                        if (byte1 > 0)
                        {
                            byte2 = 1;
                        }
                        else
                        {
                            byte2 = 4;
                        }
                    }
                    if (flag2)
                    {
                        world.setTypeId(xTile, yTile + 1, zTile, mod_ASGrapplingHook.blockGrapplingHook.id);
                        world.setData(xTile, yTile + 1, zTile, byte2);
                        world.setTypeId(k1, l1, i2, mod_ASGrapplingHook.blockRope.id);
                        world.setData(k1, l1, i2, byte2);
                        ASTileEntityRope astileentityrope = new ASTileEntityRope(world, k1, l1, i2, 32);
                        mod_Rope.addRopeToArray(astileentityrope);
                        if (owner != null)
                        {
                            owner.R();
                        }
                        die();
                    }
                    else
                    {
                        inGround = true;
                    }
                }
            }
        }
        if (inGround)
        {
            return;
        }
        move(motX, motY, motZ);
        float f = MathHelper.sqrt(motX * motX + motZ * motZ);
        yaw = (float)((Math.atan2(motX, motZ) * 180D) / 3.1415927410125732D);
        for (pitch = (float)((Math.atan2(motY, f) * 180D) / 3.1415927410125732D); pitch - lastPitch < -180F; lastPitch -= 360F) { }
        for (; pitch - lastPitch >= 180F; lastPitch += 360F) { }
        for (; yaw - lastYaw < -180F; lastYaw -= 360F) { }
        for (; yaw - lastYaw >= 180F; lastYaw += 360F) { }
        pitch = lastPitch + (pitch - lastPitch) * 0.2F;
        yaw = lastYaw + (yaw - lastYaw) * 0.2F;
        float f1 = 0.92F;
        if (onGround || positionChanged)
        {
            f1 = 0.5F;
        }
        int k = 5;
        double d7 = 0.0D;
        for (int l = 0; l < k; l++)
        {
            double d10 = ((boundingBox.b + ((boundingBox.e - boundingBox.b) * (double)(l + 0)) / (double)k) - 0.125D) + 0.125D;
            double d11 = ((boundingBox.b + ((boundingBox.e - boundingBox.b) * (double)(l + 1)) / (double)k) - 0.125D) + 0.125D;
            AxisAlignedBB axisalignedbb1 = AxisAlignedBB.b(boundingBox.a, d10, boundingBox.c, boundingBox.d, d11, boundingBox.f);
        }

        if (d7 > 0.0D)
        {
            if (ticksCatchable > 0)
            {
                ticksCatchable--;
            }
            else if (random.nextInt(500) == 0)
            {
                ticksCatchable = random.nextInt(30) + 10;
                motY -= 0.20000000298023224D;
                world.makeSound(this, "random.splash", 0.25F, 1.0F + (random.nextFloat() - random.nextFloat()) * 0.4F);
                float f4 = MathHelper.floor(boundingBox.b);
                for (int i1 = 0; (float)i1 < 1.0F + width * 20F; i1++)
                {
                    float f5 = (random.nextFloat() * 2.0F - 1.0F) * width;
                    float f7 = (random.nextFloat() * 2.0F - 1.0F) * width;
                    world.a("bubble", locX + (double)f5, f4 + 1.0F, locZ + (double)f7, motX, motY - (double)(random.nextFloat() * 0.2F), motZ);
                }

                for (int j1 = 0; (float)j1 < 1.0F + width * 20F; j1++)
                {
                    float f6 = (random.nextFloat() * 2.0F - 1.0F) * width;
                    float f8 = (random.nextFloat() * 2.0F - 1.0F) * width;
                    world.a("splash", locX + (double)f6, f4 + 1.0F, locZ + (double)f8, motX, motY, motZ);
                }
            }
        }
        if (ticksCatchable > 0)
        {
            motY -= (double)(random.nextFloat() * random.nextFloat() * random.nextFloat()) * 0.20000000000000001D;
        }
        double d9 = d7 * 2D - 1.0D;
        motY += 0.039999999105930328D * d9;
        if (d7 > 0.0D)
        {
            f1 = (float)((double)f1 * 0.90000000000000002D);
            motY *= 0.80000000000000004D;
        }
        motX *= f1;
        motY *= f1;
        motZ *= f1;
        setPosition(locX, locY, locZ);
    }

    public int recallHook()
    {
        byte byte0 = 0;
        if (plantedHook != null)
        {
            double d = owner.locX - locX;
            double d1 = owner.locY - locY;
            double d2 = owner.locZ - locZ;
            double d3 = MathHelper.sqrt(d * d + d1 * d1 + d2 * d2);
            double d4 = 0.10000000000000001D;
            plantedHook.motX += d * d4;
            plantedHook.motY += d1 * d4 + (double)MathHelper.sqrt(d3) * 0.080000000000000002D;
            plantedHook.motZ += d2 * d4;
            byte0 = 3;
        }
        if (inGround)
        {
            byte0 = 2;
        }
        die();
        return byte0;
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        nbttagcompound.setShort("xTile", (short)xTile);
        nbttagcompound.setShort("yTile", (short)yTile);
        nbttagcompound.setShort("zTile", (short)zTile);
        nbttagcompound.setByte("inTile", (byte)inTile);
        nbttagcompound.setByte("inGround", (byte)(inGround ? 1 : 0));
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        xTile = nbttagcompound.getShort("xTile");
        yTile = nbttagcompound.getShort("yTile");
        zTile = nbttagcompound.getShort("zTile");
        inTile = nbttagcompound.getByte("inTile") & 0xff;
        inGround = nbttagcompound.getByte("inGround") == 1;
    }

    public float getShadowSize()
    {
        return 0.0F;
    }

    public void die()
    {
        super.die();
        mod_ASGrapplingHook.grapplingHooks.remove(owner);
        owner = null;
    }
}
