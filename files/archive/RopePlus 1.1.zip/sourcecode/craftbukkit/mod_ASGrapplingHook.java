package net.minecraft.server;

import java.util.HashMap;
import java.util.Map;

public class mod_ASGrapplingHook extends BaseModMp
{
    private boolean loaded;
    public static Block blockRope;
    public static Block blockGrapplingHook;
    public static final Item itemRope = (new Item(2511)).d(ModLoader.addOverride("/gui/items.png", "/imgz/rope.png")).a("itemRope");
    public static final Item itemGrapplingHook = (new ASItemGrapplingHook(2512)).d(ModLoader.addOverride("/gui/items.png", "/imgz/itemGrapplingHook.png")).a("itemGrapplingHook");
    public static Map grapplingHooks = new HashMap();

    public mod_ASGrapplingHook()
    {
        loaded = false;
    }

    public void load()
    {
        if (loaded)
        {
            return;
        }
        else
        {
            loaded = true;
            AS_Settings_RopePlus.InitSettings();
            blockRope = (new ASBlockRope(AS_Settings_RopePlus.blockIdRope, ModLoader.addOverride("/terrain.png", "/imgz/rope.png"), ModLoader.getUniqueBlockModelID(this, false))).c(0.5F).a(Block.k).a("blockRope");
            blockGrapplingHook = (new ASBlockGrapplingHook(AS_Settings_RopePlus.blockIdGrapplingHook, ModLoader.addOverride("/terrain.png", "/imgz/blockGrapplingHook.png"), ModLoader.getUniqueBlockModelID(this, false))).c(0.0F).a(Block.i).a("blockGrapplingHook");
            ModLoader.RegisterEntityID(net.minecraft.server.ASEntityGrapplingHook.class, "GrapplingHook", ModLoader.getUniqueEntityId());
            ModLoader.RegisterTileEntity(net.minecraft.server.ASTileEntityRope.class, "Rope");
            ModLoaderMp.RegisterEntityTrackerEntry(net.minecraft.server.ASEntityGrapplingHook.class, 254);
            ModLoaderMp.RegisterEntityTracker(net.minecraft.server.ASEntityGrapplingHook.class, 160, 5);
            ModLoader.RegisterBlock(blockRope);
            ModLoader.RegisterBlock(blockGrapplingHook);
            ModLoader.AddRecipe(new ItemStack(itemGrapplingHook, 1), new Object[]
                    {
                        " X ", " # ", " # ", Character.valueOf('#'), mod_Rope.rope, Character.valueOf('X'), Item.IRON_INGOT
                    });
            return;
        }
    }

    public void ModsLoaded()
    {
        load();
    }

    public String getVersion()
    {
        return "1.1 AS";
    }
}
