package net.minecraft.server;

public class BlockRopePseudoEnt
{
    private int delay;
    private World world;
    private int ix;
    private int iy;
    private int iz;
    private int remainrope;

    public BlockRopePseudoEnt(World world1, int i, int j, int k, int l)
    {
        world = world1;
        ix = i;
        iy = j;
        iz = k;
        delay = 20;
        remainrope = l;
    }

    public boolean OnUpdate()
    {
        if (delay < 0)
        {
            return true;
        }
        delay--;
        if (delay == 0)
        {
            if (world.getTypeId(ix, iy - 1, iz) == 0 || world.getTypeId(ix, iy - 1, iz) == Block.SNOW.id)
            {
                remainrope--;
                if (remainrope <= 0)
                {
                    return true;
                }
                world.setTypeId(ix, iy - 1, iz, mod_Rope.rope.id);
                BlockRopePseudoEnt blockropepseudoent = new BlockRopePseudoEnt(world, ix, iy - 1, iz, remainrope);
                mod_Rope.addRopeToArray(blockropepseudoent);
                int ai[] = new int[3];
                ai[0] = ix;
                ai[1] = iy - 1;
                ai[2] = iz;
                mod_Rope.addCoordsToRopeArray(ai);
            }
            return true;
        }
        else
        {
            return false;
        }
    }
}
