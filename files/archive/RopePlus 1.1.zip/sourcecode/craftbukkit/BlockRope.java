package net.minecraft.server;

public class BlockRope extends Block
{
    protected BlockRope(int i, int j)
    {
        super(i, Material.REPLACEABLE_PLANT);
        textureId = mod_Rope.rtex;
        float f = 0.1F;
        a(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, 1.0F, 0.5F + f);
    }

    public void onPlace(World world, int i, int j, int k)
    {
        byte byte0 = 0;
        byte byte1 = 0;
        byte byte2 = 0;
        if (world.getTypeId(i - 1, j, k + 0) == id)
        {
            byte0 = -1;
            byte1 = 0;
        }
        else if (world.getTypeId(i + 1, j, k + 0) == id)
        {
            byte0 = 1;
            byte1 = 0;
        }
        else if (world.getTypeId(i, j, k - 1) == id)
        {
            byte0 = 0;
            byte1 = -1;
        }
        else if (world.getTypeId(i, j, k + 1) == id)
        {
            byte0 = 0;
            byte1 = 1;
        }
        if (byte0 != 0 || byte1 != 0)
        {
            for (int l = 1; l <= 32; l++)
            {
                if ((byte2 == 0) & world.o(i + byte0, j - l, k + byte1))
                {
                    byte2 = 2;
                }
                if ((byte2 == 0) & (world.getTypeId(i + byte0, j - l, k + byte1) == 0))
                {
                    byte2 = 1;
                    world.setTypeId(i, j, k, 0);
                    world.setTypeId(i + byte0, j - l, k + byte1, id);
                }
            }
        }
        if ((byte2 == 0 || byte2 == 2) & (world.getTypeId(i, j + 1, k) != id) && !world.o(i, j + 1, k))
        {
            b(world, i, j, k, world.getData(i, j, k), 0);
            world.setTypeId(i, j, k, 0);
        }
    }

    public void doPhysics(World world, int i, int j, int k, int l)
    {
        super.doPhysics(world, i, j, k, l);
        boolean flag = false;
        if (world.getTypeId(i - 1, j, k + 0) == id)
        {
            flag = true;
        }
        if (world.getTypeId(i + 1, j, k + 0) == id)
        {
            flag = true;
        }
        if (world.getTypeId(i, j, k - 1) == id)
        {
            flag = true;
        }
        if (world.getTypeId(i, j, k + 1) == id)
        {
            flag = true;
        }
        if (world.o(i, j + 1, k))
        {
            flag = true;
        }
        if (world.getTypeId(i, j + 1, k) == id)
        {
            flag = true;
        }
        if (!flag)
        {
            b(world, i, j, k, world.getData(i, j, k), 0);
            world.setTypeId(i, j, k, 0);
        }
    }

    public boolean canPlace(World world, int i, int j, int k)
    {
        if (world.getTypeId(i - 1, j, k + 0) == id)
        {
            return true;
        }
        if (world.getTypeId(i + 1, j, k + 0) == id)
        {
            return true;
        }
        if (world.getTypeId(i, j, k - 1) == id)
        {
            return true;
        }
        if (world.getTypeId(i, j, k + 1) == id)
        {
            return true;
        }
        if (world.o(i, j + 1, k))
        {
            return true;
        }
        else
        {
            return world.getTypeId(i, j + 1, k) == id;
        }
    }

    public void postBreak(World world, int i, int j, int k, int l)
    {
        int ai[] = mod_Rope.areCoordsArrowRope(i, j, k);
        if (ai == null)
        {
            return;
        }
        if (world.getTypeId(i, j, k) == id)
        {
            world.setTypeId(i, j, k, 0);
        }
        int k1 = 1;
        int i1;
        do
        {
            if (world.getTypeId(i, j + k1, k) != id)
            {
                i1 = (j + k1) - 1;
                break;
            }
            k1++;
        }
        while (true);
        k1 = 0;
        int j1;
        do
        {
            if (world.getTypeId(i, j + k1, k) != id)
            {
                j1 = j + k1 + 1;
                break;
            }
            k1--;
        }
        while (true);
        k1 = i1 - j1;
        for (int l1 = 0; l1 <= k1; l1++)
        {
            int ai1[] = mod_Rope.areCoordsArrowRope(i, j1 + l1, k);
            world.setTypeId(i, j1 + l1, k, 0);
            if (ai1 != null)
            {
                mod_Rope.removeCoordsFromRopeArray(ai1);
            }
        }

        if (!world.isStatic)
        {
            EntityItem entityitem = new EntityItem(world, i, j, k, new ItemStack(Item.STICK));
            entityitem.pickupDelay = 5;
            world.addEntity(entityitem);
            entityitem = new EntityItem(world, i, j, k, new ItemStack(Item.FEATHER));
            entityitem.pickupDelay = 5;
            world.addEntity(entityitem);
        }
    }

    public boolean a()
    {
        return false;
    }

    public boolean b()
    {
        return false;
    }

    public int c()
    {
        return 1;
    }
}
