package net.minecraft.server;

import java.lang.reflect.Constructor;
import java.util.List;

public class EntityArrow303 extends EntityProjectileBase
{
    public int placeCoords[];
    public String name;
    public int itemId;
    public int craftingResults;
    public Object tip;
    public String spriteFile;
    public Entity target;
    public boolean homing;
    public static final int ticksBeforeCollidable = 2;
    public static int candidates[][] =
    {
        {
            0, 0, 0
        }, {
            0, -1, 0
        }, {
            0, 1, 0
        }, {
            -1, 0, 0
        }, {
            1, 0, 0
        }, {
            0, 0, -1
        }, {
            0, 0, 1
        }, {
            -1, -1, 0
        }, {
            -1, 0, -1
        }, {
            -1, 0, 1
        }, {
            -1, 1, 0
        }, {
            0, -1, -1
        }, {
            0, -1, 1
        }, {
            0, 1, -1
        }, {
            0, 1, 1
        }, {
            1, -1, 0
        }, {
            1, 0, -1
        }, {
            1, 0, 1
        }, {
            1, 1, 0
        }, {
            -1, -1, -1
        }, {
            -1, -1, 1
        }, {
            -1, 1, -1
        }, {
            -1, 1, 1
        }, {
            1, -1, -1
        }, {
            1, -1, 1
        }, {
            1, 1, -1
        }, {
            1, 1, 1
        }
    };

    public void b()
    {
        super.b();
        homing = false;
        name = "Arrow";
        itemId = Item.ARROW.id;
        craftingResults = 4;
        tip = Item.FLINT;
        spriteFile = null;
        curvature = 0.03F;
        slowdown = 0.99F;
        precision = 1.0F;
        speed = 1.5F;
        item = new ItemStack(itemId, 1, 0);
        height = 0.0F;
        b(0.5F, 0.5F);
    }

    public EntityArrow303 newArrow(World world, EntityLiving entityliving)
    {
        try
        {
            return (EntityArrow303)getClass().getConstructor(new Class[]
                    {
                        net.minecraft.server.World.class, net.minecraft.server.EntityLiving.class
                    }).newInstance(new Object[]
                            {
                                world, entityliving
                            });
        }
        catch (Throwable throwable)
        {
            throw new RuntimeException("Could not construct arrow instance", throwable);
        }
    }

    public EntityArrow303 newArrow(World world)
    {
        try
        {
            return (EntityArrow303)getClass().getConstructor(new Class[]
                    {
                        net.minecraft.server.World.class
                    }).newInstance(new Object[]
                            {
                                world
                            });
        }
        catch (Throwable throwable)
        {
            throw new RuntimeException("Could not construct arrow instance", throwable);
        }
    }

    public void setupConfig()
    {
    }

    public EntityArrow303(World world)
    {
        super(world);
        placeCoords = new int[3];
    }

    public EntityArrow303(World world, double d, double d1, double d2)
    {
        super(world, d, d1, d2);
        placeCoords = new int[3];
    }

    public EntityArrow303(World world, EntityLiving entityliving)
    {
        super(world, entityliving);
        placeCoords = new int[3];
        homing = false;
    }

    public boolean attackEntityFrom(Entity entity, int i)
    {
        if (i < 8)
        {
            return false;
        }
        if (!inGround && entity != null)
        {
            Vec3D vec3d = entity.aA();
            if (vec3d != null)
            {
                if (homing)
                {
                    target = shooter;
                    if (entity instanceof EntityLiving)
                    {
                        shooter = (EntityLiving)entity;
                    }
                }
                motX = vec3d.a;
                motY = vec3d.b;
                motZ = vec3d.c;
                return true;
            }
        }
        return false;
    }

    public boolean isInSight(Entity entity)
    {
        return world.a(Vec3D.create(locX, locY + (double)y(), locZ), Vec3D.create(entity.locX, entity.locY + (double)entity.y(), entity.locZ)) == null;
    }

    public void handleMotionUpdate()
    {
        if (!homing)
        {
            float f = slowdown;
            if (i_())
            {
                for (int i = 0; i < 4; i++)
                {
                    float f1 = 0.25F;
                    world.a("bubble", locX - motX * (double)f1, locY - motY * (double)f1, locZ - motZ * (double)f1, motX, motY, motZ);
                }

                f *= 0.8F;
            }
            motX *= f;
            motY *= f;
            motZ *= f;
        }
        if (target == null)
        {
            motY -= curvature;
        }
    }

    public void tickFlying()
    {
        if (ticksFlying > 1 && homing)
        {
            if (target == null || target.dead || (target instanceof EntityLiving) && ((EntityLiving)target).deathTicks != 0)
            {
                if (shooter instanceof EntityCreature)
                {
                    target = ((EntityCreature)shooter).F();
                }
                else
                {
                    target = getTarget(locX, locY, locZ, 16D);
                }
            }
            else if ((shooter instanceof EntityHuman) && !isInSight(target))
            {
                target = getTarget(locX, locY, locZ, 16D);
            }
            if (target != null)
            {
                double d = (target.boundingBox.a + (target.boundingBox.d - target.boundingBox.a) / 2D) - locX;
                double d1 = (target.boundingBox.b + (target.boundingBox.e - target.boundingBox.b) / 2D) - locY;
                double d2 = (target.boundingBox.c + (target.boundingBox.f - target.boundingBox.c) / 2D) - locZ;
                setArrowHeading(d, d1, d2, speed, precision);
            }
        }
    }

    public boolean e_()
    {
        return !dead && !inGround && ticksFlying >= 2;
    }

    public boolean canBeShot(Entity entity)
    {
        return !(entity instanceof EntityArrow303) && super.canBeShot(entity);
    }

    private Entity getTarget(double d, double d1, double d2, double d3)
    {
        float f = -1F;
        Entity entity = null;
        List list = world.getEntities(this, boundingBox.grow(d3, d3, d3));
        for (int i = 0; i < list.size(); i++)
        {
            Entity entity1 = (Entity)list.get(i);
            if (!canTarget(entity1))
            {
                continue;
            }
            float f1 = entity1.h(this);
            if (f == -1F || f1 < f)
            {
                f = f1;
                entity = entity1;
            }
        }

        return entity;
    }

    public boolean canTarget(Entity entity)
    {
        return (entity instanceof EntityLiving) && entity != shooter && isInSight(entity);
    }

    public boolean tryToPlaceBlock(int i)
    {
        int j = MathHelper.floor(locX);
        int k = MathHelper.floor(locY);
        int l = MathHelper.floor(locZ);
        boolean flag = false;
        int ai[][] = candidates;
        int i1 = ai.length;
        int j1 = 0;
        do
        {
            if (j1 >= i1)
            {
                break;
            }
            int ai1[] = ai[j1];
            int l1 = ai1[0];
            int i2 = ai1[1];
            int j2 = ai1[2];
            if (world.mayPlace(i, j + l1, k + i2, l + j2, true, 1))
            {
                j += l1;
                k += i2;
                l += j2;
                flag = true;
                break;
            }
            j1++;
        }
        while (true);
        if (!flag)
        {
            return false;
        }
        else
        {
            int k1 = world.getTypeId(j, k, l);
            world.setTypeId(j, k, l, i);
            world.setData(j, k, l, 0);
            placeCoords[0] = j;
            placeCoords[1] = k;
            placeCoords[2] = l;
            return true;
        }
    }
}
