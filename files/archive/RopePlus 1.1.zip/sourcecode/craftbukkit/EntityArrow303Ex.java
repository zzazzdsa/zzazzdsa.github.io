package net.minecraft.server;

public class EntityArrow303Ex extends EntityArrow303
{
    public void subscreen()
    {
    }

    public void setupConfig()
    {
    }

    public void b()
    {
        super.b();
        name = "ExArrow";
        craftingResults = 1;
        itemId = 128 + Block.byId.length;
        tip = Item.SULPHUR;
        item = new ItemStack(itemId, 1, 0);
        spriteFile = "/arrows/exarrow.png";
    }

    public EntityArrow303Ex(World world)
    {
        super(world);
    }

    public EntityArrow303Ex(World world, EntityLiving entityliving)
    {
        super(world, entityliving);
    }

    public EntityArrow303Ex(World world, double d, double d1, double d2)
    {
        super(world, d, d1, d2);
    }

    public boolean onHit()
    {
        world.a(((Entity) (shooter == null ? ((Entity) (this)) : ((Entity) (shooter)))), locX, locY, locZ, 2.0F);
        die();
        return true;
    }

    public void tickFlying()
    {
    }
}
