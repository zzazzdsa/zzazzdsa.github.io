package net.minecraft.server;

import java.lang.reflect.Constructor;
import java.util.*;
import net.minecraft.server.MinecraftServer;

public class mod_Arrows303 extends BaseModMp
    implements Runnable
{
    private boolean loaded;
    public static mod_Arrows303 inst;
    public static MinecraftServer mc = ModLoader.getMinecraftServerInstance();
    public static List arrows = new ArrayList();
    public static List newArrows = new ArrayList();
    private HashMap selectedArrowMap;
    private HashMap selectedSlotMap;
    private HashMap cycledMap;
    public static final int bow303id;
    public int burstSize;
    public Item bow;
    public Item bow303;
    public Class coreArrowClasses[];
    public EntityHuman prevPlayer;
    public static List arrowItems = new ArrayList();

    public mod_Arrows303()
    {
        loaded = false;
        selectedArrowMap = new HashMap();
        selectedSlotMap = new HashMap();
        cycledMap = new HashMap();
    }

    public void load()
    {
        if (loaded)
        {
            return;
        }
        loaded = true;
        burstSize = 1;
        coreArrowClasses = (new Class[]
                {
                    net.minecraft.server.EntityArrow303Dirt.class, net.minecraft.server.EntityArrow303Ex.class, net.minecraft.server.EntityArrow303Fire.class, net.minecraft.server.EntityArrow303Grass.class, net.minecraft.server.EntityArrow303Ice.class, net.minecraft.server.EntityArrow303Laser.class, net.minecraft.server.EntityArrow303Slime.class, net.minecraft.server.EntityArrow303Torch.class, net.minecraft.server.EntityArrow303Warp.class, net.minecraft.server.EntityArrow303Confusion.class,
                    net.minecraft.server.EntityArrow303Rope.class
                });
        inst = this;
        arrows.add(new EntityArrow303(null));
        Class aclass[] = coreArrowClasses;
        int i = aclass.length;
        for (int j = 0; j < i; j++)
        {
            Class class1 = aclass[j];
            addArrow(makeArrow(class1));
        }

        ModLoaderMp.RegisterEntityTrackerEntry(net.minecraft.server.EntityArrow303Dirt.class, 243);
        ModLoaderMp.RegisterEntityTrackerEntry(net.minecraft.server.EntityArrow303Ex.class, 244);
        ModLoaderMp.RegisterEntityTrackerEntry(net.minecraft.server.EntityArrow303Fire.class, 245);
        ModLoaderMp.RegisterEntityTrackerEntry(net.minecraft.server.EntityArrow303Ice.class, 246);
        ModLoaderMp.RegisterEntityTrackerEntry(net.minecraft.server.EntityArrow303Laser.class, 247);
        ModLoaderMp.RegisterEntityTrackerEntry(net.minecraft.server.EntityArrow303Grass.class, 248);
        ModLoaderMp.RegisterEntityTrackerEntry(net.minecraft.server.EntityArrow303Slime.class, 249);
        ModLoaderMp.RegisterEntityTrackerEntry(net.minecraft.server.EntityArrow303Warp.class, 250);
        ModLoaderMp.RegisterEntityTrackerEntry(net.minecraft.server.EntityArrow303Torch.class, 251);
        ModLoaderMp.RegisterEntityTrackerEntry(net.minecraft.server.EntityArrow303Rope.class, 252);
        ModLoaderMp.RegisterEntityTrackerEntry(net.minecraft.server.EntityArrow303Confusion.class, 253);
        ModLoaderMp.RegisterEntityTrackerEntry(net.minecraft.server.EntityArrow303.class, 255);
        ModLoaderMp.RegisterEntityTracker(net.minecraft.server.EntityArrow303Dirt.class, 243, 5);
        ModLoaderMp.RegisterEntityTracker(net.minecraft.server.EntityArrow303Ex.class, 244, 5);
        ModLoaderMp.RegisterEntityTracker(net.minecraft.server.EntityArrow303Fire.class, 245, 5);
        ModLoaderMp.RegisterEntityTracker(net.minecraft.server.EntityArrow303Ice.class, 246, 5);
        ModLoaderMp.RegisterEntityTracker(net.minecraft.server.EntityArrow303Laser.class, 247, 5);
        ModLoaderMp.RegisterEntityTracker(net.minecraft.server.EntityArrow303Grass.class, 248, 5);
        ModLoaderMp.RegisterEntityTracker(net.minecraft.server.EntityArrow303Slime.class, 249, 5);
        ModLoaderMp.RegisterEntityTracker(net.minecraft.server.EntityArrow303Warp.class, 250, 5);
        ModLoaderMp.RegisterEntityTracker(net.minecraft.server.EntityArrow303Torch.class, 251, 5);
        ModLoaderMp.RegisterEntityTracker(net.minecraft.server.EntityArrow303Rope.class, 252, 5);
        ModLoaderMp.RegisterEntityTracker(net.minecraft.server.EntityArrow303Confusion.class, 253, 5);
        ModLoaderMp.RegisterEntityTracker(net.minecraft.server.EntityArrow303.class, 255, 5);
        setupBow();
    }

    public String getVersion()
    {
        return "1.1 AS";
    }

    public void run()
    {
        setupBow();
        load();
    }

    public void setupBow()
    {
        bow = Item.BOW;
        Item.byId[bow.id] = null;
        bow303 = (new ItemBow303(bow.id - Block.byId.length)).a(5, 1).a("bow");
        Item.byId[bow.id] = bow;
        Item.byId[Item.BOW.id] = Item.BOW = bow303;
    }

    public void selectArrow(World world, EntityHuman entityhuman)
    {
        findNextArrow(world, entityhuman, true);
        if (selectedArrow(entityhuman) == null)
        {
            cycle(world, entityhuman, true);
        }
    }

    public void findNextArrow(World world, EntityHuman entityhuman, boolean flag)
    {
        EntityArrow303 entityarrow303 = selectedArrow(entityhuman);
        int i = selectedSlot(entityhuman);
        findNextArrowBetween(world, entityhuman, entityarrow303, i, 1, entityhuman.inventory.items.length, flag);
        if (selectedArrow(entityhuman) == null)
        {
            findNextArrowBetween(world, entityhuman, entityarrow303, 0, 1, i, flag);
        }
    }

    public void findPrevArrow(World world, EntityHuman entityhuman)
    {
        EntityArrow303 entityarrow303 = selectedArrow(entityhuman);
        int i = selectedSlot(entityhuman);
        findNextArrowBetween(world, entityhuman, entityarrow303, i, -1, -1, false);
        if (selectedArrow(entityhuman) == null)
        {
            findNextArrowBetween(world, entityhuman, entityarrow303, entityhuman.inventory.items.length - 1, -1, i + 1, false);
        }
    }

    public void findNextArrowBetween(World world, EntityHuman entityhuman, EntityArrow303 entityarrow303, int i, int j, int k, boolean flag)
    {
        for (int l = i; j > 0 && l < k || l > k; l += j)
        {
            ItemStack itemstack = entityhuman.inventory.items[l];
            if (itemstack == null)
            {
                continue;
            }
            Item item = itemstack.getItem();
            if (item == null || !(item instanceof ItemArrow303))
            {
                continue;
            }
            ItemArrow303 itemarrow303 = (ItemArrow303)item;
            if (entityarrow303 == null || flag && itemarrow303.arrow == entityarrow303 || !flag && itemarrow303.arrow != entityarrow303)
            {
                setselectedArrow(entityhuman, itemarrow303.arrow);
                setselectedSlot(entityhuman, l);
                return;
            }
        }

        setselectedArrow(entityhuman, null);
        setselectedSlot(entityhuman, 0);
    }

    public void cycle(World world, EntityHuman entityhuman, boolean flag)
    {
        EntityArrow303 entityarrow303 = selectedArrow(entityhuman);
        int i = selectedSlot(entityhuman);
        if (flag)
        {
            findNextArrow(world, entityhuman, false);
        }
        else
        {
            findPrevArrow(world, entityhuman);
        }
        ItemStack itemstack;
        Item item;
        if (selectedArrow(entityhuman) == null && entityarrow303 != null && (itemstack = entityhuman.inventory.items[i]) != null && ((item = itemstack.getItem()) instanceof ItemArrow303) && ((ItemArrow303)item).arrow == entityarrow303)
        {
            setselectedArrow(entityhuman, entityarrow303);
            setselectedSlot(entityhuman, i);
        }
    }

    public void ModsLoaded()
    {
        load();
        EntityArrow303 entityarrow303;
        for (Iterator iterator = arrows.iterator(); iterator.hasNext(); makeItem(entityarrow303))
        {
            entityarrow303 = (EntityArrow303)iterator.next();
        }

        setupBow();
    }

    public boolean DispenseEntity(World world, double d, double d1, double d2,
            int i, int j, ItemStack itemstack)
    {
        for (Iterator iterator = arrows.iterator(); iterator.hasNext();)
        {
            EntityArrow303 entityarrow303 = (EntityArrow303)iterator.next();
            if (entityarrow303.itemId == itemstack.id)
            {
                EntityArrow303 entityarrow303_1 = entityarrow303.newArrow(world);
                entityarrow303_1.setPosition(d, d1, d2);
                entityarrow303_1.setArrowHeading(i, 0.10000000000000001D, j, 1.1F, 6F);
                world.addEntity(entityarrow303_1);
                world.makeSound(d, d1, d2, "random.bow", 1.0F, 1.2F);
                return true;
            }
        }

        return false;
    }

    public EntityArrow303 makeArrow(Class class1)
    {
        try
        {
            return (EntityArrow303)class1.getConstructor(new Class[]
                    {
                        net.minecraft.server.World.class
                    }).newInstance(new Object[]
                            {
                                (World)null
                            });
        }
        catch (Throwable throwable)
        {
            throw new RuntimeException(throwable);
        }
    }

    private void makeItem(EntityArrow303 entityarrow303)
    {
        if (entityarrow303.itemId == Item.ARROW.id)
        {
            Item.byId[Item.ARROW.id] = null;
            Item item = Item.ARROW = (new ItemArrow303(Item.ARROW.id - Block.byId.length, entityarrow303)).d(Item.ARROW.textureId).a(Item.ARROW.getName());
        }
        else
        {
            int i = Item.ARROW.textureId;
            i = ModLoader.addOverride("/gui/items.png", entityarrow303.spriteFile);
            Item item1 = (new ItemArrow303(entityarrow303.itemId - Block.byId.length, entityarrow303)).d(i).a(entityarrow303.name);
            ModLoader.AddRecipe(new ItemStack(entityarrow303.itemId, entityarrow303.craftingResults, 0), new Object[]
                    {
                        "X", "#", "Y", Character.valueOf('X'), entityarrow303.tip, Character.valueOf('#'), Item.STICK, Character.valueOf('Y'), Item.FEATHER
                    });
            arrowItems.add(item1);
        }
    }

    public static void addArrow(EntityArrow303 entityarrow303)
    {
        newArrows.add(entityarrow303);
        arrows.add(entityarrow303);
    }

    public void showToggles()
    {
    }

    public EntityArrow303 selectedArrow(EntityHuman entityhuman)
    {
        return (EntityArrow303)selectedArrowMap.get(entityhuman);
    }

    public void setselectedArrow(EntityHuman entityhuman, EntityArrow303 entityarrow303)
    {
        selectedArrowMap.put(entityhuman, entityarrow303);
    }

    public int selectedSlot(EntityHuman entityhuman)
    {
        if (selectedSlotMap.get(entityhuman) == null)
        {
            return 0;
        }
        else
        {
            return ((Integer)selectedSlotMap.get(entityhuman)).intValue();
        }
    }

    public void setselectedSlot(EntityHuman entityhuman, int i)
    {
        selectedSlotMap.put(entityhuman, Integer.valueOf(i));
    }

    public boolean cycled(EntityHuman entityhuman)
    {
        if (cycledMap.get(entityhuman) == null)
        {
            return false;
        }
        else
        {
            return ((Boolean)cycledMap.get(entityhuman)).booleanValue();
        }
    }

    public void setselectedSlot(EntityHuman entityhuman, boolean flag)
    {
        cycledMap.put(entityhuman, Boolean.valueOf(flag));
    }

    public void HandlePacket(Packet230ModLoader packet230modloader, EntityPlayer entityplayer)
    {
        switch (packet230modloader.packetType)
        {
            case 0:
                setselectedSlot(entityplayer, packet230modloader.dataInt[0]);
                ItemStack itemstack = entityplayer.inventory.items[packet230modloader.dataInt[0]];
                if (itemstack != null)
                {
                    Item item = itemstack.getItem();
                    ItemArrow303 itemarrow303 = (ItemArrow303)item;
                    setselectedArrow(entityplayer, itemarrow303.arrow);
                }
                break;
        }
    }

    public static Item getArrowItemByTip(Object obj)
    {
        for (Iterator iterator = arrowItems.iterator(); iterator.hasNext();)
        {
            ItemArrow303 itemarrow303 = (ItemArrow303)iterator.next();
            if (itemarrow303.arrow.tip == obj)
            {
                return itemarrow303;
            }
        }

        return null;
    }

    static
    {
        bow303id = 3541 + Block.byId.length;
    }
}
