package net.minecraft.server;

import java.util.List;

public class EntityArrow303Ice extends EntityArrow303
{
    public EntityLiving victim;
    public float freezeFactor;
    public int freezeTimer;

    public void subscreen()
    {
    }

    public void setupConfig()
    {
    }

    public void b()
    {
        super.b();
        name = "IceArrow";
        craftingResults = 1;
        itemId = 130 + Block.byId.length;
        tip = Item.SNOW_BALL;
        item = new ItemStack(itemId, 1, 0);
        spriteFile = "/arrows/icearrow.png";
    }

    public EntityArrow303Ice(World world)
    {
        super(world);
    }

    public EntityArrow303Ice(World world, double d, double d1, double d2)
    {
        super(world, d, d1, d2);
    }

    public EntityArrow303Ice(World world, EntityLiving entityliving)
    {
        super(world, entityliving);
    }

    public boolean onHitBlock()
    {
        if (victim == null)
        {
            die();
            return true;
        }
        else
        {
            return false;
        }
    }

    public boolean onHitTarget(Entity entity)
    {
        if (!(entity instanceof EntityLiving) || victim != null)
        {
            return false;
        }
        List list = world.getEntities(this, entity.boundingBox.grow(3D, 3D, 3D));
        for (int i = 0; i < list.size(); i++)
        {
            Entity entity1 = (Entity)list.get(i);
            if (!(entity1 instanceof EntityArrow303Ice))
            {
                continue;
            }
            EntityArrow303Ice entityarrow303ice = (EntityArrow303Ice)entity1;
            if (entityarrow303ice.victim == entity)
            {
                entityarrow303ice.freezeTimer += getFreezeTimer((EntityLiving)entity);
                entityarrow303ice.dead = false;
                entity.damageEntity(DamageSource.playerAttack((EntityHuman)shooter), 4);
                die();
                return false;
            }
        }

        entity.damageEntity(DamageSource.playerAttack((EntityHuman)shooter), 4);
        freezeMob((EntityLiving)entity);
        return false;
    }

    public int getFreezeTimer(EntityLiving entityliving)
    {
        return (entityliving instanceof EntityHuman) ? '\005' : 200;
    }

    public void freezeMob(EntityLiving entityliving)
    {
        victim = entityliving;
        freezeFactor = (entityliving instanceof EntityHuman) ? 0.5F : 0.1F;
        freezeTimer = getFreezeTimer(entityliving);
        motX = motY = motZ = 0.0D;
    }

    public void unfreezeMob()
    {
        victim = null;
    }

    public void die()
    {
        if (victim != null)
        {
            unfreezeMob();
        }
        super.die();
    }

    public void y_()
    {
        super.y_();
        if (victim != null)
        {
            if (victim.dead || victim.deathTicks > 0)
            {
                die();
                return;
            }
            dead = false;
            inGround = false;
            locX = victim.locX;
            locY = victim.boundingBox.b + (double)victim.length * 0.5D;
            locZ = victim.locZ;
            setPosition(locX, locY, locZ);
            victim.motX *= freezeFactor;
            victim.motY *= freezeFactor;
            victim.motZ *= freezeFactor;
            freezeTimer--;
            if (freezeTimer <= 0)
            {
                die();
            }
        }
    }

    public boolean onHit()
    {
        if (victim != null)
        {
            return false;
        }
        int i = MathHelper.floor(locX);
        int j = MathHelper.floor(locY);
        int k = MathHelper.floor(locZ);
        for (int l = i - 1; l <= i + 1; l++)
        {
            for (int i1 = j - 1; i1 <= j + 1; i1++)
            {
                for (int j1 = k - 1; j1 <= k + 1; j1++)
                {
                    if (world.getMaterial(l, i1, j1) == Material.WATER && world.getData(l, i1, j1) == 0)
                    {
                        world.setTypeId(l, i1, j1, 79);
                        continue;
                    }
                    if (world.getMaterial(l, i1, j1) == Material.LAVA && world.getData(l, i1, j1) == 0)
                    {
                        world.setTypeId(l, i1, j1, 49);
                        continue;
                    }
                    if (world.getTypeId(l, i1, j1) == 51)
                    {
                        world.setTypeId(l, i1, j1, 0);
                        continue;
                    }
                    if (world.getTypeId(l, i1, j1) == 50)
                    {
                        Block.byId[50].dropNaturally(world, l, i1, j1, world.getData(l, i1, j1), 1.0F, 0);
                        world.setTypeId(l, i1, j1, 0);
                        Block.byId[50].wasExploded(world, l, i1, j1);
                    }
                }
            }
        }

        return true;
    }

    public void tickFlying()
    {
    }
}
