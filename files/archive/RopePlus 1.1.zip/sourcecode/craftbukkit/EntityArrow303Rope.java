package net.minecraft.server;

public class EntityArrow303Rope extends EntityArrow303
{
    public void b()
    {
        super.b();
        name = "RopeArrow";
        craftingResults = 1;
        itemId = 243 + Block.byId.length;
        tip = mod_Rope.rope;
        spriteFile = "/arrows/ropearrow.png";
        item = new ItemStack(itemId, 1, 0);
    }

    public EntityArrow303Rope(World world)
    {
        super(world);
    }

    public EntityArrow303Rope(World world, EntityLiving entityliving)
    {
        super(world, entityliving);
    }

    public EntityArrow303Rope(World world, double d, double d1, double d2)
    {
        super(world, d, d1, d2);
    }

    public boolean onHit()
    {
        if (tryToPlaceBlock(mod_Rope.rope.id))
        {
            die();
            mod_Rope.onRopeArrowHit(world, placeCoords[0], placeCoords[1], placeCoords[2]);
        }
        else if (tryToPlaceBlock2(mod_ASGrapplingHook.blockRope.id))
        {
            ASTileEntityRope astileentityrope = new ASTileEntityRope(world, placeCoords[0], placeCoords[1], placeCoords[2], 32);
            mod_Rope.addRopeToArray(astileentityrope);
            die();
        }
        return true;
    }

    public boolean tryToPlaceBlock2(int i)
    {
        int j = MathHelper.floor(locX);
        int k = MathHelper.floor(locY);
        int l = MathHelper.floor(locZ);
        boolean flag = false;
        int ai[][] = candidates;
        int i1 = ai.length;
        int j1 = 0;
        double d = motX;
        double d1 = motZ;
        byte byte0 = (byte)(d > 0.0D ? 1 : -1);
        byte byte1 = (byte)(d1 > 0.0D ? 1 : -1);
        byte byte2 = 0;
        byte byte3 = 0;
        boolean flag1 = false;
        if (Math.abs(d) > Math.abs(d1))
        {
            flag1 = true;
            if (byte0 > 0)
            {
                byte3 = 4;
                byte2 = 8;
            }
            else
            {
                byte3 = 5;
                byte2 = 2;
            }
        }
        else if (Math.abs(d) <= Math.abs(d1))
        {
            flag1 = true;
            if (byte1 > 0)
            {
                byte3 = 1;
                byte2 = 1;
            }
            else
            {
                byte3 = 3;
                byte2 = 4;
            }
        }
        do
        {
            if (j1 >= i1)
            {
                break;
            }
            int ai1[] = ai[j1];
            int l1 = ai1[0];
            int j2 = ai1[1];
            int k2 = ai1[2];
            if (world.mayPlace(i, j + l1, k + j2, l + k2, true, byte3))
            {
                j += l1;
                k += j2;
                l += k2;
                flag = true;
                break;
            }
            j1++;
        }
        while (true);
        if (!flag)
        {
            return false;
        }
        int k1 = world.getTypeId(j, k, l);
        if (k1 > 0 && shotByPlayer)
        {
            int i2 = world.getData(j, k, l);
            Block.byId[k1].a(world, (EntityHuman)shooter, j, k, l, i2);
        }
        if (flag1)
        {
            if (!world.isStatic)
            {
                world.setTypeId(j, k, l, i);
                world.setData(j, k, l, byte2);
            }
            placeCoords[0] = j;
            placeCoords[1] = k;
            placeCoords[2] = l;
            return true;
        }
        else
        {
            return false;
        }
    }
}
