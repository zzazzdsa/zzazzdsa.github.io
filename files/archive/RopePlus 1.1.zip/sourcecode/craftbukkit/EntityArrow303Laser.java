package net.minecraft.server;

import java.util.*;

public class EntityArrow303Laser extends EntityArrow303
{
    public boolean pierced;
    public Set piercedMobs;
    public static String sound = "damage.fallbig";

    public void b()
    {
        super.b();
        name = "LaserArrow";
        craftingResults = 1;
        itemId = 2818 + Block.byId.length;
        tip = Item.REDSTONE;
        spriteFile = "/arrows/laserarrow.png";
        curvature = 0.0F;
        slowdown = 1.3F;
        precision = 0.0F;
        speed = 2.0F;
        pierced = false;
        piercedMobs = new HashSet();
        item = new ItemStack(itemId, 1, 0);
    }

    public EntityArrow303Laser(World world)
    {
        super(world);
    }

    public EntityArrow303Laser(World world, double d, double d1, double d2)
    {
        super(world, d, d1, d2);
    }

    public EntityArrow303Laser(World world, EntityLiving entityliving)
    {
        super(world, entityliving);
    }

    public boolean onHitTarget(Entity entity)
    {
        entity.damageEntity(DamageSource.playerAttack((EntityHuman)shooter), 8);
        pierced = true;
        piercedMobs.add(entity);
        target = null;
        world.makeSound(this, sound, 1.0F, ((random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F) / 0.8F);
        return false;
    }

    public boolean isInSight(Entity entity)
    {
        return canSee(this, entity) && canSee(entity, this);
    }

    public boolean canSee(Entity entity, Entity entity1)
    {
        MovingObjectPosition movingobjectposition = world.a(((Vec3D)null).create(entity.locX, entity.locY + (double)entity.y(), entity.locZ), ((Vec3D)null).create(entity1.locX, entity1.locY + (double)entity1.y(), entity1.locZ));
        return movingobjectposition == null || movingobjectposition.type == EnumMovingObjectType.TILE && isTransparent(world.getTypeId(movingobjectposition.b, movingobjectposition.c, movingobjectposition.d));
    }

    public boolean onHitBlock()
    {
        if (!isTransparent(inTile))
        {
            if (pierced)
            {
                die();
            }
            return true;
        }
        else
        {
            return false;
        }
    }

    public boolean isTransparent(int i)
    {
        return Block.lightBlock[i] != 255;
    }

    public void tickFlying()
    {
    }

    public boolean canTarget(Entity entity)
    {
        return !piercedMobs.contains(entity) && super.canTarget(entity);
    }
}
