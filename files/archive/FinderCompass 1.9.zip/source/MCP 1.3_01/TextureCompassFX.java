package net.minecraft.src;
// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;
import net.minecraft.client.Minecraft;
import java.util.*;
import java.io.*;

public class TextureCompassFX extends TextureFX
{
	
	// MODIFY THIS ACCORDING TO TEXTURE PACK!!!! eg 16, 32, 64 ....
	final int texturesetting = 16;

    public TextureCompassFX(Minecraft minecraft)
    {
        super(Item.compass.getIconIndex(null));
        baseSpriteBuffer = new int[looper*looper*16];
        mc = minecraft;
        tileImage = 1;
        try
        {
            BufferedImage bufferedimage = ImageIO.read((net.minecraft.client.Minecraft.class).getResource("/gui/items.png"));
            int i = (iconIndex % 16) * looper*4;
            int j = (iconIndex / 16) * looper*4;
            bufferedimage.getRGB(i, j, looper*4, looper*4, baseSpriteBuffer, 0, looper*4);
        }
        catch(IOException ioexception)
        {
            ioexception.printStackTrace();
        }
    }

    public void onTick()
    {	
        for(int i = 0; i < looper*looper*16; i++) // sprite to animation buffer conversion
        {
            int j = baseSpriteBuffer[i] >> 24 & 0xff;
            int k = baseSpriteBuffer[i] >> 16 & 0xff;
            int l = baseSpriteBuffer[i] >> 8 & 0xff;
            int i1 = baseSpriteBuffer[i] >> 0 & 0xff;
            if(anaglyphEnabled)
            {
                int j1 = (k * 30 + l * 59 + i1 * 11) / 100;
                int k1 = (k * 30 + l * 70) / 100;
                int l1 = (k * 30 + i1 * 70) / 100;
                k = j1;
                l = k1;
                i1 = l1;
            }
            imageData[i * 4 + 0] = (byte)k;
            imageData[i * 4 + 1] = (byte)l;
            imageData[i * 4 + 2] = (byte)i1;
            imageData[i * 4 + 3] = (byte)j;
        }
		
		if(mc.theWorld != null && mc.thePlayer != null)
        {
			if (!areSettingsLoaded)
				this.initializeSettingsFile();
		
			drawNeedle(0, computeNeedleHeading(mc.theWorld.getSpawnPoint()), spawnNeedleColor, true);
			
			boolean updateScan = false;
			if ((int)mc.thePlayer.posX != playerX
			|| (int)mc.thePlayer.posY != playerY
			|| (int)mc.thePlayer.posZ != playerZ)
			{
				playerX = (int)mc.thePlayer.posX;
				playerY = (int)mc.thePlayer.posY;
				playerZ = (int)mc.thePlayer.posZ;
				updateScan = true;
				//mc.ingameGUI.addChatMessage("Update Scan requested! Pos["+playerX+","+playerY+","+playerZ+"]");
			}
			
			/*
			// DEBUG TEST START
			if (updateScan)
			{
				MovingObjectPosition objectMouseOver = mc.objectMouseOver;
				
				if (objectMouseOver != null && objectMouseOver.typeOfHit == EnumMovingObjectType.TILE)
				{
					int j = objectMouseOver.blockX;
					int k = objectMouseOver.blockY;
					int l = objectMouseOver.blockZ;
					
					//System.out.println("Looking at Block ID: " + mc.theWorld.getBlockId(j, k, l));
					mc.ingameGUI.addChatMessage("Looking at Block ID: " + mc.theWorld.getBlockId(j, k, l));
				}
			}
			//DEBUG TEST END
			*/
			
			if (playerY <= 16 && updateScan)
			{
				//mc.ingameGUI.addChatMessage("Running Diamond Search...");
				DiamondOre = findNearestBlockChunkOfIDInRange(Block.oreDiamond.blockID, playerX, playerY, playerZ, scanrangediamond, 1); //Block.oreDiamond.blockID
			}
			
			if (!DiamondOre.equals(NullChunk))
				drawNeedle(1, computeNeedleHeading(DiamondOre), diamondNeedleColor, false);
			
			if (playerY <= 60 && updateScan)
			{
				ChunkCoordinates currentBlock = new ChunkCoordinates(playerX, playerY, playerZ);
				
				if(GetDistanceBetweenChunks(lastScanBlock, currentBlock) > scanrangespawners)
				{
					lastScanBlock = currentBlock;
					MobSpawner = findNearestBlockChunkOfIDInRange(Block.mobSpawner.blockID, playerX, playerY, playerZ, scanrangespawners, scanrangespawners);
				}
			}
			
			if (!MobSpawner.equals(NullChunk))
			{
				if(Math.abs(playerX - MobSpawner.x) < 2 && Math.abs(playerZ - MobSpawner.z) < 2)
				{
					if(playerY > MobSpawner.y)
					{
						drawNeedle(2, HEADING_DOWN, spawnerNeedleColor, false);
					}
					else
					{
						drawNeedle(2, HEADING_UP, spawnerNeedleColor, false);
					}
				}
				else
				{
					drawNeedle(2, computeNeedleHeading(MobSpawner), spawnerNeedleColor, false);
				}
			}
			
			if(updateScan)
			{
				for (Map.Entry<Integer, int[]> entry : customNeedles.entrySet())
				{
					int ID = entry.getKey();
					int color[] = entry.getValue();
					
					ChunkCoordinates iC = findNearestBlockChunkOfIDInRange(ID, playerX, playerY, playerZ, scanrangediamond, 1);
					
					if (!iC.equals(NullChunk))
					{
						if (customNeedleTargets.containsKey(color))
						{
							customNeedleTargets.remove(color);
						}
						customNeedleTargets.put(color, iC);
					}
					else
					{
						customNeedleTargets.remove(color);
					}
				}
			}
			
			int iterator = 2;
			
			for (Map.Entry<int[], ChunkCoordinates> entry2 : customNeedleTargets.entrySet())
			{
				int color2[] = entry2.getKey();
				ChunkCoordinates target = entry2.getValue();
				iterator++;
				
				drawNeedle(iterator, computeNeedleHeading(target), color2, false);
			}
		}
    }
	
	public double computeNeedleHeading(ChunkCoordinates chunkcoordinates)
	{
		double d = 0.0D;
		
        if(mc.theWorld != null && mc.thePlayer != null)
        {
            double d2 = (double)chunkcoordinates.x - mc.thePlayer.posX;
            double d4 = (double)chunkcoordinates.z - mc.thePlayer.posZ;
            d = ((double)(mc.thePlayer.rotationYaw - 90F) * 3.1415926535897931D) / 180D - Math.atan2(d4, d2);
            if(mc.theWorld.worldProvider.field_4220_c)
            {
                d = Math.random() * 3.1415927410125732D * 2D;
            }
        }
		
		return d;
	}
	
	public void drawNeedle(int needleIterator, double d, int[] color, boolean drawCenter)
	{
        double d1;
        for(d1 = d - i[needleIterator]; d1 < -3.1415926535897931D; d1 += 6.2831853071795862D) { }
        for(; d1 >= 3.1415926535897931D; d1 -= 6.2831853071795862D) { }
        if(d1 < -1D)
        {
            d1 = -1D;
        }
        if(d1 > 1.0D)
        {
            d1 = 1.0D;
        }
        this.j[needleIterator] += d1 * 0.10000000000000001D;
        this.j[needleIterator] *= 0.80000000000000004D;
        this.i[needleIterator] += this.j[needleIterator];
        double d3 = Math.sin(i[needleIterator]);
        double d5 = Math.cos(i[needleIterator]);
		
		if (drawCenter)
		{
			for(int i2 = -looper; i2 <= looper; i2++)
			{
				int k2 = (int)(looper*2+0.5D + d5 * (double)i2 * 0.29999999999999999D);
				int i3 = (int)(looper*2-0.5D - d3 * (double)i2 * 0.29999999999999999D * 0.5D);
				int k3 = i3 * looper*4 + k2;
				int i4 = 100;
				int k4 = 100;
				int i5 = 100;
				char c = '\377';
				if(anaglyphEnabled)
				{
					int k5 = (i4 * 30 + k4 * 59 + i5 * 11) / 100;
					int i6 = (i4 * 30 + k4 * 70) / 100;
					int k6 = (i4 * 30 + i5 * 70) / 100;
					i4 = k5;
					k4 = i6;
					i5 = k6;
				}
				imageData[k3 * 4 + 0] = (byte)i4;
				imageData[k3 * 4 + 1] = (byte)k4;
				imageData[k3 * 4 + 2] = (byte)i5;
				imageData[k3 * 4 + 3] = (byte)c;
			}
		}
		
        for(int j2 = -(looper*2); j2 <= (looper*4); j2++)
        {
            int l2 = (int)(looper*2+0.5D + d3 * (double)j2 * 0.29999999999999999D);
            int j3 = (int)(looper*2-0.5D + d5 * (double)j2 * 0.29999999999999999D * 0.5D);
            int l3 = j3 * looper*4 + l2;
            int j4 = j2 < 0 ? 100 : color[0];
            int l4 = j2 < 0 ? 100 : color[1];
            int j5 = j2 < 0 ? 100 : color[2];
            char c1 = '\377';
            if(anaglyphEnabled)
            {
                int l5 = (j4 * 30 + l4 * 59 + j5 * 11) / 100;
                int j6 = (j4 * 30 + l4 * 70) / 100;
                int l6 = (j4 * 30 + j5 * 70) / 100;
                j4 = l5;
                l4 = j6;
                j5 = l6;
            }
            imageData[l3 * 4 + 0] = (byte)j4;
            imageData[l3 * 4 + 1] = (byte)l4;
            imageData[l3 * 4 + 2] = (byte)j5;
            imageData[l3 * 4 + 3] = (byte)c1;
        }
	}
	
	void initializeSettingsFile()
	{
		settingsFile = new File(Minecraft.getAppDir("minecraft"), "findercompass.cfg");
		System.out.println("initializeSettingsFile() running");
		
		try
		{
			if(settingsFile.exists())
			{
				System.out.println(".minecraft/findercompass.cfg found and opened");
			
				BufferedReader in = new BufferedReader(new FileReader(settingsFile));
				String sCurrentLine;
				
				while ((sCurrentLine = in.readLine()) != null)
				{
					if(sCurrentLine.startsWith("SearchDistance"))
					{
						String[] distLine = sCurrentLine.split(":");
						scanrangediamond = Integer.parseInt(distLine[1]);
						scanrangespawners = scanrangediamond*4;
					}
					else if(!sCurrentLine.startsWith("//"))
					{
						String[] curLine = sCurrentLine.split(":");
						
						int ID = Integer.parseInt(curLine[0]);
						
						int color[] = new int[3];
						color[0] = Integer.parseInt(curLine[1]);
						color[1] = Integer.parseInt(curLine[2]);
						color[2] = Integer.parseInt(curLine[3]);
						
						customNeedles.put(ID, color);
						mc.ingameGUI.addChatMessage("Finder Compass: loaded custom needle of id " +ID+ ", color ["+color[0]+","+color[1]+","+color[2]);
						System.out.println("Finder Compass: loaded custom needle of id " +ID+ ", color ["+color[0]+","+color[1]+","+color[2]);
					}
				}
				in.close();
			}
			else
			{
				mc.ingameGUI.addChatMessage(".minecraft/findercompass.cfg not found, using defaults");
			}
		}
		catch (Exception fuckdammit)
		{
			System.out.println("EXCEPTION BufferedReader");
		}
		
		areSettingsLoaded = true;
	}

    private Minecraft mc;
    private int baseSpriteBuffer[];
	private double[] i = new double[10];
	private double[] j = new double[10];
	
	private int[] spawnNeedleColor = { 255, 20, 20 };
	private int[] spawnerNeedleColor = { 26, 255, 26 };
	private int[] diamondNeedleColor = { 51, 255, 204 };
	
	private static Map<Integer, int[]> customNeedles = new HashMap<Integer, int[]>();
	private static Map<int[], ChunkCoordinates> customNeedleTargets = new HashMap<int[], ChunkCoordinates>();
	private static boolean areSettingsLoaded = false;
	static File settingsFile;
	
	final double HEADING_DOWN = 0.0D;
	final double HEADING_UP = 135.0D;
	
	private int playerX;
	private int playerY;
	private int playerZ;
	
	private ChunkCoordinates DiamondOre = new ChunkCoordinates(0,0,0);
	private ChunkCoordinates MobSpawner = new ChunkCoordinates(0,0,0);
	private ChunkCoordinates lastScanBlock = new ChunkCoordinates(0,0,0);
	private ChunkCoordinates NullChunk = new ChunkCoordinates(0,0,0);
	
	static int scanrangediamond = 7;
	static int scanrangespawners = scanrangediamond*4;
	final int looper = texturesetting/4;
	

	List findBlocksOfIDInRange(int ID, int xpos, int ypos, int zpos, int flatrange, int depthrange)
	{
		List returnList = new ArrayList();
		
		for(int y = ypos - depthrange - 1; y <= ypos + depthrange; y++)
		{
			if (y > 60 || y < 1) continue;
			
			for(int z = zpos - flatrange; z <= zpos + flatrange; z++)
			{
				for(int x = xpos - flatrange; x <= xpos + flatrange; x++)
				{
					if(mc.theWorld.getBlockId(x, y, z) == ID)
					{
						ChunkCoordinates addObj = new ChunkCoordinates(x, y, z);
						returnList.add(addObj);
					}
				}
			}
		}
		
		return returnList;
	}
	
	ChunkCoordinates findNearestBlockChunkOfIDInRange(int ID, int xpos, int ypos, int zpos, int flatrange, int depthrange)
	{
		List blocklist = findBlocksOfIDInRange(ID, xpos, ypos, zpos, flatrange, depthrange);
		
		ChunkCoordinates origin = new ChunkCoordinates(xpos, ypos, zpos);
		ChunkCoordinates returnblock = new ChunkCoordinates(0, 0, 0);
		double mindistance = 9999.0F;
		double checkdistance;
		
		for(int x = 0; x < blocklist.size(); x++)
        {
			ChunkCoordinates loopagainst = (ChunkCoordinates)blocklist.get(x);
			checkdistance = GetDistanceBetweenChunks(origin, loopagainst);
			
			if (checkdistance < mindistance)
			{
				returnblock = loopagainst;
				mindistance = checkdistance;
			}
		}
		
		ChunkCoordinates returnchunkcoords = new ChunkCoordinates(returnblock.x, returnblock.y, returnblock.z);
		return returnchunkcoords;
	}
	
	double GetDistanceBetweenChunks(ChunkCoordinates BlockA, ChunkCoordinates BlockB)
	{
		int xDiff = Math.abs(BlockA.x - BlockB.x);
		int yDiff = Math.abs(BlockA.y - BlockB.y);
		int zDiff = Math.abs(BlockA.z - BlockB.z);
		
		return Math.sqrt(Math.pow(xDiff, 2) + Math.pow(yDiff, 2) + Math.pow(zDiff, 2));
	}
}
