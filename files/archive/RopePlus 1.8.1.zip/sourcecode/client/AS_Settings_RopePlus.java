package net.minecraft.src;

import java.io.*;
import java.util.*;
import net.minecraft.client.Minecraft;

public class AS_Settings_RopePlus
{
	public AS_Settings_RopePlus()
	{
		InitSettings();
	}
	
	public static int blockIdRopeDJRoslin = 242;
	public static int blockIdRope = 115;
	public static int blockIdGrapplingHook = 116;
	public static boolean settingsLoaded = false;

	private static File configfile = new File(Minecraft.getMinecraftDir(), "mods/RopePlus.txt");
	
	public static void InitSettings()
	{
		if (settingsLoaded) return;
		settingsLoaded = true;
		
		Properties properties = new Properties();
		
		if (configfile.exists())
		{
			try
			{
				properties.load(new FileInputStream(configfile));
			}
			catch (IOException localIOException)
			{
				System.out.println("RopePlus config exception: "+localIOException);
			}
			
			blockIdRope = Integer.parseInt(properties.getProperty("blockIdRope", "115"));
			blockIdGrapplingHook = Integer.parseInt(properties.getProperty("blockIdGrapplingHook", "116"));
			blockIdRopeDJRoslin = Integer.parseInt(properties.getProperty("blockIdRopeDJRoslin", "242"));
		}
		else
		{
			System.out.println("No RopePlus config found, trying to create...");
		
			try
			{
				configfile.createNewFile();
				properties.load(new FileInputStream(configfile));
			}
			catch (IOException localIOException)
			{
				System.out.println("RopePlus config exception: "+localIOException);
			}
			
			properties.setProperty("blockIdRope", "115");
			properties.setProperty("blockIdGrapplingHook", "116");
			properties.setProperty("blockIdRopeDJRoslin", "242");
			
			try
			{
				FileOutputStream fostream = new FileOutputStream(configfile);
				properties.store(fostream, "Here you can customize Block ID's in case of incompatibility. Defaults: 115, 116 and 242; ID may not exceed 255 unless a mod enables that");
			}
			catch (IOException localIOException)
			{
				System.out.println("RopePlus config exception: "+localIOException);
			}
		}
	}
}
