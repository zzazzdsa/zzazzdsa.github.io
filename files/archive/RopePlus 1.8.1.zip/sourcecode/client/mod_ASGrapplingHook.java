package net.minecraft.src;

import java.io.*;
import java.net.*;
import java.security.*;
import java.util.*;

public class mod_ASGrapplingHook extends BaseModMp
{

    public mod_ASGrapplingHook()
    {
		AS_Settings_RopePlus.InitSettings();
		
		ropeTexture = ModLoader.addOverride("/terrain.png", "/imgz/rope.png");
        blockRope = (new ASBlockRope(AS_Settings_RopePlus.blockIdRope, ropeTexture, ModLoader.getUniqueBlockModelID(this, false))).setHardness(0.5F).setStepSound(Block.soundClothFootstep).setBlockName("blockRope");
        blockGrapplingHook = (new ASBlockGrapplingHook(AS_Settings_RopePlus.blockIdGrapplingHook, ModLoader.addOverride("/terrain.png", "/imgz/blockGrapplingHook.png"), ModLoader.getUniqueBlockModelID(this, false))).setHardness(0.0F).setStepSound(Block.soundMetalFootstep).setBlockName("blockGrapplingHook");
			
        ModLoader.AddName(blockRope, "GrHk Rope");
        ModLoader.AddName(blockGrapplingHook, "Grappling Hook");
        ModLoader.AddName(itemRope, "GrHk Rope");
        ModLoader.AddName(itemGrapplingHook, "Grappling Hook");	
		
        ModLoader.RegisterEntityID(ASEntityGrapplingHook.class, "GrapplingHook", ModLoader.getUniqueEntityId());
        ModLoaderMp.RegisterNetClientHandlerEntity(ASEntityGrapplingHook.class, true, 133);
		
		ModLoader.RegisterBlock(blockRope);
        ModLoader.RegisterBlock(blockGrapplingHook);
        ModLoader.AddRecipe(new ItemStack(itemGrapplingHook, 1), new Object[] {
            " X ", " # ", " # ", Character.valueOf('#'), mod_Rope.rope, Character.valueOf('X'), Item.ingotIron
        });
    }

    public String Version()
    {
        return "1.8.1 AS";
    }

    public void AddRenderer(Map map)
    {
        map.put(ASEntityGrapplingHook.class, new ASRenderGrapplingHook());
    }

    public boolean RenderWorldBlock(RenderBlocks renderblocks, IBlockAccess iblockaccess, int i, int j, int k, Block block, int l)
    {
        try
        {
            if(l == blockRope.getRenderType())
            {
                return renderRope(renderblocks, block, i, j, k, iblockaccess);
            }
            else if(l == blockGrapplingHook.getRenderType())
            {
                return renderGrapplingHook(renderblocks, block, i, j, k, iblockaccess);
            }
        }
        catch(Exception exception)
        {
            ModLoader.getLogger().throwing("mod_ASGrapplingHook", "RenderWorldBlock", exception);
            return false;
        }
        return false;
    }
    
    public static boolean renderRope(RenderBlocks renderblocks, Block block, int i, int j, int k, IBlockAccess iblockaccess)
    {
        Tessellator tessellator = Tessellator.instance;
        int l = block.getBlockTextureFromSide(0);
        float f = block.getMixedBrightnessForBlock(iblockaccess, i, j, k);
        tessellator.setColorOpaque_F(f, f, f);
        int i1 = (l & 0xf) << 4;
        int j1 = l & 0xf0;
        double d = (float)i1 / 256F;
        double d1 = ((float)i1 + 15.99F) / 256F;
        double d2 = (float)j1 / 256F;
        double d3 = ((float)j1 + 15.99F) / 256F;
        int k1 = iblockaccess.getBlockMetadata(i, j, k);
        float f1 = 0.0F;
        float f2 = 0.05F;
        if(k1 == 5)
        {
            tessellator.addVertexWithUV((float)i + f2, (float)(j + 1) + f1, (float)(k + 1) + f1, d, d2);
            tessellator.addVertexWithUV((float)i + f2, (float)(j + 0) - f1, (float)(k + 1) + f1, d, d3);
            tessellator.addVertexWithUV((float)i + f2, (float)(j + 0) - f1, (float)(k + 0) - f1, d1, d3);
            tessellator.addVertexWithUV((float)i + f2, (float)(j + 1) + f1, (float)(k + 0) - f1, d1, d2);
            tessellator.addVertexWithUV((float)i + f2, (float)(j + 0) - f1, (float)(k + 1) + f1, d1, d3);
            tessellator.addVertexWithUV((float)i + f2, (float)(j + 1) + f1, (float)(k + 1) + f1, d1, d2);
            tessellator.addVertexWithUV((float)i + f2, (float)(j + 1) + f1, (float)(k + 0) - f1, d, d2);
            tessellator.addVertexWithUV((float)i + f2, (float)(j + 0) - f1, (float)(k + 0) - f1, d, d3);
        }
        if(k1 == 4)
        {
            tessellator.addVertexWithUV((float)(i + 1) - f2, (float)(j + 1) + f1, (float)(k + 1) + f1, d, d2);
            tessellator.addVertexWithUV((float)(i + 1) - f2, (float)(j + 0) - f1, (float)(k + 1) + f1, d, d3);
            tessellator.addVertexWithUV((float)(i + 1) - f2, (float)(j + 0) - f1, (float)(k + 0) - f1, d1, d3);
            tessellator.addVertexWithUV((float)(i + 1) - f2, (float)(j + 1) + f1, (float)(k + 0) - f1, d1, d2);
            tessellator.addVertexWithUV((float)(i + 1) - f2, (float)(j + 0) - f1, (float)(k + 1) + f1, d1, d3);
            tessellator.addVertexWithUV((float)(i + 1) - f2, (float)(j + 1) + f1, (float)(k + 1) + f1, d1, d2);
            tessellator.addVertexWithUV((float)(i + 1) - f2, (float)(j + 1) + f1, (float)(k + 0) - f1, d, d2);
            tessellator.addVertexWithUV((float)(i + 1) - f2, (float)(j + 0) - f1, (float)(k + 0) - f1, d, d3);
        }
        if(k1 == 3)
        {
            tessellator.addVertexWithUV((float)(i + 1) + f1, (float)(j + 0) - f1, (float)k + f2, d1, d3);
            tessellator.addVertexWithUV((float)(i + 1) + f1, (float)(j + 1) + f1, (float)k + f2, d1, d2);
            tessellator.addVertexWithUV((float)(i + 0) - f1, (float)(j + 1) + f1, (float)k + f2, d, d2);
            tessellator.addVertexWithUV((float)(i + 0) - f1, (float)(j + 0) - f1, (float)k + f2, d, d3);
            tessellator.addVertexWithUV((float)(i + 1) + f1, (float)(j + 1) + f1, (float)k + f2, d, d2);
            tessellator.addVertexWithUV((float)(i + 1) + f1, (float)(j + 0) - f1, (float)k + f2, d, d3);
            tessellator.addVertexWithUV((float)(i + 0) - f1, (float)(j + 0) - f1, (float)k + f2, d1, d3);
            tessellator.addVertexWithUV((float)(i + 0) - f1, (float)(j + 1) + f1, (float)k + f2, d1, d2);
        }
        if(k1 == 2)
        {
            tessellator.addVertexWithUV((float)(i + 1) + f1, (float)(j + 0) - f1, (float)(k + 1) - f2, d1, d3);
            tessellator.addVertexWithUV((float)(i + 1) + f1, (float)(j + 1) + f1, (float)(k + 1) - f2, d1, d2);
            tessellator.addVertexWithUV((float)(i + 0) - f1, (float)(j + 1) + f1, (float)(k + 1) - f2, d, d2);
            tessellator.addVertexWithUV((float)(i + 0) - f1, (float)(j + 0) - f1, (float)(k + 1) - f2, d, d3);
            tessellator.addVertexWithUV((float)(i + 1) + f1, (float)(j + 1) + f1, (float)(k + 1) - f2, d, d2);
            tessellator.addVertexWithUV((float)(i + 1) + f1, (float)(j + 0) - f1, (float)(k + 1) - f2, d, d3);
            tessellator.addVertexWithUV((float)(i + 0) - f1, (float)(j + 0) - f1, (float)(k + 1) - f2, d1, d3);
            tessellator.addVertexWithUV((float)(i + 0) - f1, (float)(j + 1) + f1, (float)(k + 1) - f2, d1, d2);
        }
        return true;
    }
    
    public static boolean renderGrapplingHook(RenderBlocks renderblocks, Block block, int i, int j, int k, IBlockAccess iblockaccess)
    {
        int l = block.colorMultiplier(iblockaccess, i, j, k);
        float f = (float)(l >> 16 & 0xff) / 255F;
        float f1 = (float)(l >> 8 & 0xff) / 255F;
        float f2 = (float)(l & 0xff) / 255F;
        return renderGrapplingHook2(renderblocks, block, i, j, k, f, f1, f2, iblockaccess);
    }

    public static boolean renderGrapplingHook2(RenderBlocks renderblocks, Block block, int i, int j, int k, float f, float f1, float f2, 
            IBlockAccess iblockaccess)
    {
        Tessellator tessellator = Tessellator.instance;
        boolean flag = false;
        float f3 = 1.0F;
        float f4 = f3 * f;
        float f5 = f3 * f1;
        float f6 = f3 * f2;
        if(block == Block.grass)
        {
            f = f1 = f2 = 1.0F;
        }
        float f7 = block.getMixedBrightnessForBlock(iblockaccess, i, j, k);
        int l = iblockaccess.getBlockMetadata(i, j, k);
        if(block.shouldSideBeRendered(iblockaccess, i, j + 1, k, 1))
        {
            float f8 = block.getMixedBrightnessForBlock(iblockaccess, i, j + 1, k);
            if(block.maxY != 1.0D && !block.blockMaterial.getIsLiquid())
            {
                f8 = f7;
            }
            tessellator.setColorOpaque_F(f4 * f8, f5 * f8, f6 * f8);
            
            tessellator.setBrightness(block.getMixedBrightnessForBlock(iblockaccess, i, j, k));
            tessellator.setColorOpaque_F(1.0F, 1.0F, 1.0F);
            
            int i1 = block.getBlockTexture(iblockaccess, i, j, k, 1);
            renderGrapplingHook3(block, i, j, k, i1, l);
            flag = true;
        }
        return flag;
    }

    public static void renderGrapplingHook3(Block block, double d, double d1, double d2, int i, 
            int j)
    {
        Tessellator tessellator = Tessellator.instance;
        int k = (i & 0xf) << 4;
        int l = i & 0xf0;
        double d3 = ((double)k + block.minX * 16D) / 256D;
        double d4 = (((double)k + block.maxX * 16D) - 0.01D) / 256D;
        double d5 = ((double)l + block.minZ * 16D) / 256D;
        double d6 = (((double)l + block.maxZ * 16D) - 0.01D) / 256D;
        if(block.minX < 0.0D || block.maxX > 1.0D)
        {
            d3 = ((float)k + 0.0F) / 256F;
            d4 = ((float)k + 15.99F) / 256F;
        }
        if(block.minZ < 0.0D || block.maxZ > 1.0D)
        {
            d5 = ((float)l + 0.0F) / 256F;
            d6 = ((float)l + 15.99F) / 256F;
        }
        double d7 = d + block.minX;
        double d8 = d + block.maxX;
        double d9 = d1 + block.maxY;
        double d10 = d2 + block.minZ;
        double d11 = d2 + block.maxZ;
        switch(j)
        {
        case 2: // '\002'
            double d12 = d5;
            d5 = d6;
            d6 = d12;
            d12 = d3;
            d3 = d4;
            d4 = d12;
            break;

        case 4: // '\004'
            double d13 = d5;
            d5 = d6;
            d6 = d13;
            break;

        case 5: // '\005'
            double d14 = d3;
            d3 = d4;
            d4 = d14;
            break;
        }
        tessellator.addVertexWithUV(d8, d9, d11, d4, d6);
        tessellator.addVertexWithUV(d8, d9, d10, d4, d5);
        tessellator.addVertexWithUV(d7, d9, d10, d3, d5);
        tessellator.addVertexWithUV(d7, d9, d11, d3, d6);
    }

    public static Block blockRope;
    public static Block blockGrapplingHook;
    public static int ropeTexture;
    public static final Item itemRope = (new Item(2511)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/imgz/rope.png")).setItemName("itemRope");
    public static final Item itemGrapplingHook = (new ASItemGrapplingHook(2512)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/imgz/itemGrapplingHook.png")).setItemName("itemGrapplingHook");
	
    public static Map grapplingHooks = new HashMap();
}
