package net.minecraft.src;

import java.util.*;


public class ASBlockRope extends BlockContainer
{

    protected ASBlockRope(int i, int j, int k)
    {
        super(i, j, Material.circuits);
        ascensionSpeed = 0.2F;
        descensionSpeed = -0.15F;
        renderType = k;
    }

	/*
    public void onEntityCollidedWithBlock(World world, int i, int j, int k, Entity entity)
    {
        if(entity instanceof EntityLiving)
        {
            entity.fallDistance = 0.0F;
            if(entity.motionY < (double)descensionSpeed)
            {
                entity.motionY = descensionSpeed;
            }
            if(entity.isCollidedHorizontally)
            {
                entity.motionY = ascensionSpeed;
            }
			if(entity.isSneaking())
			{
				entity.motionY = 0.0D;
			}
        }
    }
	*/
    
    public int getBlockTexture(IBlockAccess iblockaccess, int i, int j, int k, int l)
    {
        return mod_ASGrapplingHook.ropeTexture;
    }

    public int getBlockTextureFromSide(int i)
    {
    	return mod_ASGrapplingHook.ropeTexture;
    }

    public TileEntity getBlockEntity()
    {
    	return null;
    }

    public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int i, int j, int k)
    {
        int l = world.getBlockMetadata(i, j, k);
        float f = 0.125F;
        if(l == 2)
        {
            setBlockBounds(0.0F, 0.0F, 1.0F - f, 1.0F, 1.0F, 1.0F);
        }
        if(l == 3)
        {
            setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, f);
        }
        if(l == 4)
        {
            setBlockBounds(1.0F - f, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
        }
        if(l == 5)
        {
            setBlockBounds(0.0F, 0.0F, 0.0F, f, 1.0F, 1.0F);
        }
        return super.getCollisionBoundingBoxFromPool(world, i, j, k);
    }

    public AxisAlignedBB getSelectedBoundingBoxFromPool(World world, int i, int j, int k)
    {
        int l = world.getBlockMetadata(i, j, k);
        float f = 0.125F;
        if(l == 2)
        {
            setBlockBounds(0.0F, 0.0F, 1.0F - f, 1.0F, 1.0F, 1.0F);
        }
        if(l == 3)
        {
            setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, f);
        }
        if(l == 4)
        {
            setBlockBounds(1.0F - f, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
        }
        if(l == 5)
        {
            setBlockBounds(0.0F, 0.0F, 0.0F, f, 1.0F, 1.0F);
        }
        return super.getSelectedBoundingBoxFromPool(world, i, j, k);
    }

    public boolean isOpaqueCube()
    {
        return false;
    }

    public boolean renderAsNormalBlock()
    {
        return false;
    }

    public int getRenderType()
    {
        return 8;
    }

    public int quantityDropped(Random random)
    {
        return 0;
    }
    
    public void onBlockDestroyedByPlayer(World world, int i, int j, int k, int l)
    {
        onBlockDestroyed(world, i, j, k);
    }

    public void onBlockDestroyedByExplosion(World world, int i, int j, int k)
    {
        onBlockDestroyed(world, i, j, k);
    }
	
    public void onBlockDestroyed(World world, int a, int b, int c)
    {
		if(world.multiplayerWorld)
        {
            return;
        }
		
		int rope_max_y;
		int rope_min_y;
		
		for(int x = 1;; x++)
		{
			if (world.getBlockId(a, b+x, c) != mod_ASGrapplingHook.blockRope.blockID)
			{
				rope_max_y = (b+x)-1;
				break;
			}
		}
		
		for(int x = -1;; x--)
		{
			if (world.getBlockId(a, b+x, c) != mod_ASGrapplingHook.blockRope.blockID)
			{
				rope_min_y = (b+x)+1;
				break;
			}
		}
		
		int ropelenght = rope_max_y-rope_min_y;
		
		System.out.println("Rope min: "+rope_min_y+", Rope max: "+rope_max_y+", lenght: "+ropelenght);
		
		for(int x = 0; x <= ropelenght; x++)
		{
			world.setBlockWithNotify(a, rope_max_y-x, c, 0);
		}
		
		//ModLoader.getMinecraftInstance().ingameGUI.addChatMessage("Rope height of ["+(h-b)+"] removed");
		
		int h = rope_max_y;
		
		int candidates[][] = {
			{a-1, h+1, c},
			{a, h+1, c-1},
			{a, h+1, c+1},
			{a+1, h+1, c}
        };
		
		boolean IsHook = false;
		for(int y = 0; y < candidates.length; y++)
		{
			if(world.getBlockId(candidates[y][0], candidates[y][1], candidates[y][2]) == mod_ASGrapplingHook.blockGrapplingHook.blockID)
			{
				world.setBlockWithNotify(candidates[y][0], candidates[y][1], candidates[y][2], 0);
				
				EntityItem entityitem = new EntityItem(world, a, b, c, new ItemStack(mod_ASGrapplingHook.itemGrapplingHook));
				entityitem.delayBeforeCanPickup = 5;
				world.entityJoinedWorld(entityitem);
				
				IsHook = true;
				break;
			}
		}
		
		if (!IsHook)
		{
			EntityItem entityitem = new EntityItem(world, a, b, c, new ItemStack(mod_Arrows303.getArrowItemByTip(mod_Rope.rope)));
			entityitem.delayBeforeCanPickup = 5;
			world.entityJoinedWorld(entityitem);
		}
	}

    public float ascensionSpeed;
    public float descensionSpeed;
    private int renderType;
}
