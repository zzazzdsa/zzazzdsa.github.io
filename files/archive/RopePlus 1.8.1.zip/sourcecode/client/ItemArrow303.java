// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;


// Referenced classes of package net.minecraft.src:
//            Item, EntityArrow303

public class ItemArrow303 extends Item
{

    public ItemArrow303(int i, EntityArrow303 entityarrow303)
    {
        super(i);
        arrow = entityarrow303;
    }

    public EntityArrow303 arrow;
}
