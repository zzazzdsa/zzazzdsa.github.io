// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import java.lang.reflect.Constructor;
import java.util.*;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;

// Referenced classes of package net.minecraft.src:
//            BaseMod, EntityArrow303Dirt, EntityArrow303Egg, EntityArrow303Ex, 
//            EntityArrow303Fire, EntityArrow303Grass, EntityArrow303Ice, EntityArrow303Laser, 
//            EntityArrow303Mob, EntityArrow303Slime, EntityArrow303Torch, EntityArrow303Warp, 
//            EntityArrow303Confusion, ModLoader, ModSettings, ModSettingScreen, 
//            WidgetSimplewindow, ModAction, SettingKey, WidgetKeybinding, 
//            SettingFloat, WidgetFloat, SettingBoolean, WidgetBoolean, 
//            EntityArrow303, Item, ItemBow303, Block, 
//            EntityPlayerSP, InventoryPlayer, ItemStack, ItemArrow303, 
//            WidgetClassicTwocolumn, World, FontRenderer, GuiModScreen, 
//            EntityPlayer, GuiScreen

public class mod_Arrows303 extends BaseModMp
    implements Runnable
{

    public mod_Arrows303()
    {
        toggleMap = new HashMap();
        cycled = false;
        burstSize = 1;
        coreArrowClasses = (new Class[] {
            net.minecraft.src.EntityArrow303Dirt.class, net.minecraft.src.EntityArrow303Ex.class, net.minecraft.src.EntityArrow303Fire.class, net.minecraft.src.EntityArrow303Grass.class, net.minecraft.src.EntityArrow303Ice.class, net.minecraft.src.EntityArrow303Laser.class, net.minecraft.src.EntityArrow303Slime.class, net.minecraft.src.EntityArrow303Torch.class, 
            net.minecraft.src.EntityArrow303Warp.class, net.minecraft.src.EntityArrow303Confusion.class, net.minecraft.src.EntityArrow303Rope.class
        });
        inst = this;
        ModLoader.SetInGameHook(this, true, false);
		
		/*
        homingPlayer = false;
        homingMob = false;
        particles = true;
        replaceBow = true;
		*/
		
        arrows.add(new EntityArrow303(null));
        Class aclass[] = coreArrowClasses;
        int i = aclass.length;
        for(int j = 0; j < i; j++)
        {
            Class class1 = aclass[j];
            addArrow(makeArrow(class1));
        }
		
		ModLoaderMp.RegisterNetClientHandlerEntity(net.minecraft.src.EntityArrow303Dirt.class, 241);
		ModLoaderMp.RegisterNetClientHandlerEntity(net.minecraft.src.EntityArrow303Ex.class, 242);
		ModLoaderMp.RegisterNetClientHandlerEntity(net.minecraft.src.EntityArrow303Fire.class, 243);
		ModLoaderMp.RegisterNetClientHandlerEntity(net.minecraft.src.EntityArrow303Ice.class, 244);
		ModLoaderMp.RegisterNetClientHandlerEntity(net.minecraft.src.EntityArrow303Laser.class, 245);
		ModLoaderMp.RegisterNetClientHandlerEntity(net.minecraft.src.EntityArrow303Grass.class, 246);
		ModLoaderMp.RegisterNetClientHandlerEntity(net.minecraft.src.EntityArrow303Slime.class, 247);
		ModLoaderMp.RegisterNetClientHandlerEntity(net.minecraft.src.EntityArrow303Warp.class, 248);
		ModLoaderMp.RegisterNetClientHandlerEntity(net.minecraft.src.EntityArrow303Torch.class, 249);
		ModLoaderMp.RegisterNetClientHandlerEntity(net.minecraft.src.EntityArrow303Rope.class, 250);
		ModLoaderMp.RegisterNetClientHandlerEntity(net.minecraft.src.EntityArrow303Confusion.class, 251);

        bow = Item.bow;
        Item.itemsList[bow.shiftedIndex] = null;
        bow303 = (new ItemBow303(bow.shiftedIndex - Block.blocksList.length)).setIconCoord(5, 1).setItemName("bow");
        Item.itemsList[bow.shiftedIndex] = bow;
    }

    public void run()
    {
        setupBow();
    }

    public void setupBow()
    {
        Item.itemsList[Item.bow.shiftedIndex] = Item.bow = bow303;
    }

    public void selectArrow()
    {
        if(mc.thePlayer == null)
        {
            selectedArrow = null;
            selectedSlot = 0;
        }
        findNextArrow(true);
        if(selectedArrow == null)
        {
            cycle(true);
        }
    }

    public void findNextArrow(boolean flag)
    {
        EntityArrow303 entityarrow303 = selectedArrow;
        int i = selectedSlot;
        findNextArrowBetween(entityarrow303, i, 1, mc.thePlayer.inventory.mainInventory.length, flag);
        if(selectedArrow == null)
        {
            findNextArrowBetween(entityarrow303, 0, 1, i, flag);
        }
    }

    public void findPrevArrow()
    {
        EntityArrow303 entityarrow303 = selectedArrow;
        int i = selectedSlot;
        findNextArrowBetween(entityarrow303, i, -1, -1, false);
        if(selectedArrow == null)
        {
            findNextArrowBetween(entityarrow303, mc.thePlayer.inventory.mainInventory.length - 1, -1, i + 1, false);
        }
    }

    public void findNextArrowBetween(EntityArrow303 entityarrow303, int i, int j, int k, boolean flag)
    {
        for(int l = i; j > 0 && l < k || l > k; l += j)
        {
            ItemStack itemstack = mc.thePlayer.inventory.mainInventory[l];
            if(itemstack == null)
            {
                continue;
            }
            Item item = itemstack.getItem();
            if(item == null || !(item instanceof ItemArrow303))
            {
                continue;
            }
            ItemArrow303 itemarrow303 = (ItemArrow303)item;
            if(entityarrow303 == null || flag && itemarrow303.arrow == entityarrow303 || !flag && itemarrow303.arrow != entityarrow303)
            {
                selectedArrow = itemarrow303.arrow;
                selectedSlot = l;
				SendPacketToUpdateArrowChoice();
                return;
            }
        }

        selectedArrow = null;
        selectedSlot = 0;
    }
	
	public void SendPacketToUpdateArrowChoice()
	{
		int[] dataInt = new int[1];
		dataInt[0] = selectedSlot;
		
		Packet230ModLoader packet = new Packet230ModLoader();
		packet.packetType = 0;
		packet.dataInt = dataInt;
		
		ModLoaderMp.SendPacket(this, packet);
	}

    public void cycle(boolean flag)
    {
        EntityArrow303 entityarrow303 = selectedArrow;
        int i = selectedSlot;
        if(flag)
        {
            findNextArrow(false);
        } else
        {
            findPrevArrow();
        }
        ItemStack itemstack;
        Item item;
        if(selectedArrow == null && entityarrow303 != null && (itemstack = mc.thePlayer.inventory.mainInventory[i]) != null && ((item = itemstack.getItem()) instanceof ItemArrow303) && ((ItemArrow303)item).arrow == entityarrow303)
        {
            selectedArrow = entityarrow303;
            selectedSlot = i;
			SendPacketToUpdateArrowChoice();
        }
    }

    public void ModsLoaded()
    {
        EntityArrow303 entityarrow303;

        EntityArrow303 entityarrow303_1;
        for(Iterator iterator1 = arrows.iterator(); iterator1.hasNext(); ModLoader.RegisterEntityID(entityarrow303_1.getClass(), (new StringBuilder()).append(entityarrow303_1.name).append("303").toString(), ModLoader.getUniqueEntityId()))
        {
            entityarrow303_1 = (EntityArrow303)iterator1.next();
            makeItem(entityarrow303_1);
        }
		
        setupBow();
    }

    public boolean DispenseEntity(World world, double d, double d1, double d2, 
            int i, int j, ItemStack itemstack)
    {
        for(Iterator iterator = arrows.iterator(); iterator.hasNext();)
        {
            EntityArrow303 entityarrow303 = (EntityArrow303)iterator.next();
            if(entityarrow303.itemId == itemstack.itemID)
            {
                EntityArrow303 entityarrow303_1 = entityarrow303.newArrow(world);
                entityarrow303_1.setPosition(d, d1, d2);
                entityarrow303_1.setArrowHeading(i, 0.10000000000000001D, j, 1.1F, 6F);
                world.entityJoinedWorld(entityarrow303_1);
                world.playSoundEffect(d, d1, d2, "random.bow", 1.0F, 1.2F);
                return true;
            }
        }

        return false;
    }

    public EntityArrow303 makeArrow(Class class1)
    {
        try
        {
            return (EntityArrow303)class1.getConstructor(new Class[] {
                net.minecraft.src.World.class
            }).newInstance(new Object[] {
                (World)null
            });
        }
        catch(Throwable throwable)
        {
            throw new RuntimeException(throwable);
        }
    }

    public boolean OnTickInGame(Minecraft minecraft)
    {
        if(prevPlayer != minecraft.thePlayer || prevScreen != minecraft.currentScreen)
        {
            prevPlayer = minecraft.thePlayer;
            prevScreen = minecraft.currentScreen;
            selectArrow();
        }
        if(minecraft.currentScreen != null)
        {
            return true;
        }
        ItemStack itemstack = minecraft.thePlayer.getCurrentEquippedItem();
        if(itemstack == null || itemstack.itemID != Item.bow.shiftedIndex)
        {
            return true;
        }		
        boolean flag = Keyboard.isKeyDown(keyforward);
        boolean flag1 = Keyboard.isKeyDown(keyback);
        if(cycled)
        {
            if(!flag && !flag1)
            {
                cycled = false;
            }
        }
		else
        {
            cycled = true;
            if(flag)
            {
                cycle(false);
            }
			else if(flag1)
            {
                cycle(true);
            }
			else
            {
                cycled = false;
            }
        }
        if(selectedArrow == null)
        {
            return true;
        }

        String s = selectedArrow.name;
        if(burstSize > 0)
        {
            s = (new StringBuilder()).append(s).append("x").append(burstSize).toString();
        }
        minecraft.fontRenderer.drawStringWithShadow(s, 2, 12, 0xffffff);
		
		return true;
    }

    public int countArrows(EntityArrow303 entityarrow303)
    {
        int i = 0;
        InventoryPlayer inventoryplayer = mc.thePlayer.inventory;
        ItemStack aitemstack[] = inventoryplayer.mainInventory;
        int j = aitemstack.length;
        for(int k = 0; k < j; k++)
        {
            ItemStack itemstack = aitemstack[k];
            if(itemstack != null && itemstack.itemID == entityarrow303.itemId)
            {
                i += itemstack.stackSize;
            }
        }

        return i;
    }

    private void makeItem(EntityArrow303 entityarrow303)
    {
        Item item = null;
        if(entityarrow303.itemId == Item.arrow.shiftedIndex)
        {
            Item.itemsList[Item.arrow.shiftedIndex] = null;
            item = Item.arrow = (new ItemArrow303(Item.arrow.shiftedIndex - Block.blocksList.length, entityarrow303)).setIconIndex(Item.arrow.iconIndex).setItemName(Item.arrow.getItemName());
        }
		else if (Item.arrow != null)
        {
            int i = Item.arrow.iconIndex;
            i = ModLoader.addOverride("/gui/items.png", entityarrow303.spriteFile);
            item = (new ItemArrow303(entityarrow303.itemId - Block.blocksList.length, entityarrow303)).setIconIndex(i).setItemName(entityarrow303.name);
            ModLoader.AddRecipe(new ItemStack(entityarrow303.itemId, entityarrow303.craftingResults, 0), new Object[] {
                "X", "#", "Y", Character.valueOf('X'), entityarrow303.tip, Character.valueOf('#'), Item.stick, Character.valueOf('Y'), Item.feather
            });
			
			arrowItems.add(item);
        }
        ModLoader.AddName(item, entityarrow303.name);
    }

    public static void addArrow(EntityArrow303 entityarrow303)
    {
        newArrows.add(entityarrow303);
        arrows.add(entityarrow303);
    }

    public void showToggles()
    {
    }

    public void AddRenderer(Map map)
    {
        EntityArrow303 entityarrow303;
        for(Iterator iterator = arrows.iterator(); iterator.hasNext(); map.put(entityarrow303.getClass(), entityarrow303.renderer))
        {
            entityarrow303 = (EntityArrow303)iterator.next();
        }

    }

    public String Version()
    {
        return "1.8.1 AS";
    }

    public static mod_Arrows303 inst;
    public static Minecraft mc = ModLoader.getMinecraftInstance();
	
    public static List arrows = new ArrayList();
    public static List newArrows = new ArrayList();
    public Map toggleMap;
    public EntityArrow303 selectedArrow;
    public int selectedSlot;
    public boolean cycled;
    public static final int bow303id;
    public int burstSize;
    public boolean loading;
    public Item bow;
    public Item bow303;
	
    public Class coreArrowClasses[];
    public EntityPlayer prevPlayer;
    public GuiScreen prevScreen;
	
	final int keyforward = Keyboard.getKeyIndex("COMMA");
	final int keyback = Keyboard.getKeyIndex("PERIOD");

    static 
    {
        bow303id = 3541 + Block.blocksList.length;
    }
	
	public static List arrowItems = new ArrayList();
	
	public static Item getArrowItemByTip(Object desiredtip)
	{
		for(Iterator iterator = arrowItems.iterator(); iterator.hasNext();)
		{
			ItemArrow303 itemarrow303 = (ItemArrow303)iterator.next();
			if(itemarrow303.arrow.tip == desiredtip)
			{
				return (Item)itemarrow303;
			}
		}
		
		return null;
	}
}
