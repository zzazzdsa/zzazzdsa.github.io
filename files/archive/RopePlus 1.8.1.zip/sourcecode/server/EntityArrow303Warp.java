// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;



// Referenced classes of package net.minecraft.src:
//            EntityArrow303, Block, ItemStack, World, 
//            mod_Arrows303, SettingBoolean, EntityPortalFX, EffectRenderer, 
//            MathHelper, EntityLiving

public class EntityArrow303Warp extends EntityArrow303
{

    public void entityInit()
    {
        super.entityInit();
        name = "WarpArrow";
        craftingResults = 4;
        itemId = 258 + Block.blocksList.length;
        tip = Block.obsidian;
        item = new ItemStack(itemId, 1, 0);
        spriteFile = "/arrows/warparrow.png";
    }

    public EntityArrow303Warp(World world)
    {
        super(world);
    }

    public EntityArrow303Warp(World world, EntityLiving entityliving)
    {
        super(world, entityliving);
        world.playSoundAtEntity(this, "portal.trigger", 1.0F, 1.0F);
    }

    public EntityArrow303Warp(World world, double d, double d1, double d2)
    {
        super(world, d, d1, d2);
    }

    public void tickFlying()
    {
    }

    public boolean onHit()
    {
        if(teleport(posX, posY, posZ))
        {
            setEntityDead();
        }
        return true;
    }

    private boolean isSolid(double d, double d1, double d2)
    {
        return isSolid(MathHelper.floor_double(d), MathHelper.floor_double(d1), MathHelper.floor_double(d2));
    }

    public boolean teleport(double d, double d1, double d2)
    {
        if(shooter == null)
        {
            return false;
        }
        float f = shooter.height;
        double d3 = 0.10000000000000001D;
        double d4 = Math.ceil(d1) - d1;
        double d5 = d1 - Math.floor(d1);
        for(int i = 1; i < 3 && !isSolid(d, d1 + (double)i, d2); i++)
        {
            d4++;
        }

        for(int j = 1; j < 3 && !isSolid(d, d1 - (double)j, d2); j++)
        {
            d5++;
        }

        if(d4 + d5 < (double)f + d3)
        {
            return false;
        }
        if(d5 < (double)f)
        {
            d1 += (double)f - d5;
        }
        if(d4 < d3)
        {
            d1 -= d3;
        }
        shooter.setPosition(Math.floor(d) + 0.5D, d1, Math.floor(d2) + 0.5D);
        shooter.fallDistance = 0.0F;
        return true;
    }
}
