package net.minecraft.src;

import java.io.*;
import java.net.*;
import java.security.*;
import java.util.*;

public class mod_ASGrapplingHook extends BaseModMp
{

    public mod_ASGrapplingHook()
    {
		AS_Settings_RopePlus.InitSettings();
		
        blockRope = (new ASBlockRope(AS_Settings_RopePlus.blockIdRope, ModLoader.addOverride("/terrain.png", "/imgz/rope.png"), ModLoader.getUniqueBlockModelID(this, false))).setHardness(0.5F).setStepSound(Block.soundClothFootstep).setBlockName("blockRope");
        blockGrapplingHook = (new ASBlockGrapplingHook(AS_Settings_RopePlus.blockIdGrapplingHook, ModLoader.addOverride("/terrain.png", "/imgz/blockGrapplingHook.png"), ModLoader.getUniqueBlockModelID(this, false))).setHardness(0.0F).setStepSound(Block.soundMetalFootstep).setBlockName("blockGrapplingHook");
		
        ModLoader.RegisterEntityID(ASEntityGrapplingHook.class, "GrapplingHook", ModLoader.getUniqueEntityId());
        ModLoader.RegisterTileEntity(ASTileEntityRope.class, "Rope");
		ModLoaderMp.RegisterEntityTrackerEntry(ASEntityGrapplingHook.class, 133);
		ModLoaderMp.RegisterEntityTracker(ASEntityGrapplingHook.class, 160, 5);
		
		ModLoader.RegisterBlock(blockRope);
        ModLoader.RegisterBlock(blockGrapplingHook);
        ModLoader.AddRecipe(new ItemStack(itemGrapplingHook, 1), new Object[] {
            " X ", " # ", " # ", Character.valueOf('#'), mod_Rope.rope, Character.valueOf('X'), Item.ingotIron
        });
    }


    public String Version()
    {
        return "1.8.1 AS";
    }

    public static Block blockRope;
    public static Block blockGrapplingHook;
    public static final Item itemRope = (new Item(2511)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/imgz/rope.png")).setItemName("itemRope");
    public static final Item itemGrapplingHook = (new ASItemGrapplingHook(2512)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/imgz/itemGrapplingHook.png")).setItemName("itemGrapplingHook");
	
    public static Map grapplingHooks = new HashMap();
}
