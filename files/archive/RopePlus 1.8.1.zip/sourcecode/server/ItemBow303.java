package net.minecraft.src;

import java.util.Random;


public class ItemBow303 extends Item
{

    public ItemBow303(int i)
    {
        super(i);
        maxStackSize = 1;
    }

    public void func_35408_a(ItemStack var1, World world, EntityPlayer entityplayer, int var4) {
    	
        mod_Arrows303.inst.selectArrow(world, entityplayer);
        EntityArrow303 entityarrow303 = mod_Arrows303.inst.selectedArrow(entityplayer);
        if(entityarrow303 == null)
        {
            return;
        }
        	
           int var5 = this.func_35404_c(var1) - var4;
           float bowCharge = (float)var5 / 20.0F;
           bowCharge = (bowCharge * bowCharge + bowCharge * 2.0F) / 3.0F;
           if((double)bowCharge < 0.1D) {
              return;
           }

           if(bowCharge > 1.0F) {
              bowCharge = 1.0F;
           }
           
           EntityArrow var7 = new EntityArrow(world, entityplayer, bowCharge * 2.0F);
           if(bowCharge == 1.0F) {
              var7.field_9077_F = true;
           }           
           
           int i = mod_Arrows303.inst.burstSize;
           do
           {
               if(--entityplayer.inventory.mainInventory[mod_Arrows303.inst.selectedSlot(entityplayer)].stackSize <= 0)
               {
                   entityplayer.inventory.mainInventory[mod_Arrows303.inst.selectedSlot(entityplayer)] = null;
                   mod_Arrows303.inst.selectArrow(world, entityplayer);
               }
               world.playSoundAtEntity(entityplayer, "random.bow", 1.0F, 1.0F / (itemRand.nextFloat() * 0.4F + 1.2F) + bowCharge * 0.5F);
               EntityArrow303 entityarrow303_1 = entityarrow303.newArrow(world, entityplayer);
               setPrecision(entityarrow303_1, mod_Arrows303.inst.burstSize);
               
               if(!world.singleplayerWorld)
               {
            	   world.entityJoinedWorld(entityarrow303_1);
            	   
                   if(bowCharge == 1.0F) {
                	   entityarrow303_1.arrowCritical = true;
                    }
               }
               
               if(entityarrow303 != mod_Arrows303.inst.selectedArrow(entityplayer))
               {
                   break;
               }
               i--;
           }
   			while(i > 0);
   		
           mod_Arrows303.inst.burstSize = 1;
     }
     
     public ItemStack func_35405_b(ItemStack var1, World var2, EntityPlayer var3) {
         return var1;
      }

      public int func_35404_c(ItemStack var1) {
         return 72000;
      }

      public EnumAction func_35406_b(ItemStack var1) {
         return EnumAction.bow;
      }
     
     public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer)
     {
         entityplayer.func_35201_a(itemstack, this.func_35404_c(itemstack));
         return itemstack;
     }

    public void setPrecision(EntityArrow303 entityarrow303, int i)
    {
        if(i == 1)
        {
            return;
        } else
        {
            float f = (float)i * precisionBase;
            float f1 = entityarrow303.speed * (float)Math.pow(0.97000002861022949D, i);
            entityarrow303.setArrowHeading(entityarrow303.motionX, entityarrow303.motionY, entityarrow303.motionZ, f1, f);
            return;
        }
    }

    public static float precisionBase = 1.5F;

}
