package net.minecraft.src;

import java.util.Map;
import java.util.Random;


public class ASItemGrapplingHook extends Item
{

    public ASItemGrapplingHook(int i)
    {
        super(i);
        maxStackSize = 1;
    }

    public boolean isFull3D()
    {
        return true;
    }

    public boolean shouldRotateAroundWhenRendering()
    {
        return true;
    }

    public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer)
    {
        if(mod_ASGrapplingHook.grapplingHooks.get(entityplayer) != null)
        {
            int i = ((ASEntityGrapplingHook)mod_ASGrapplingHook.grapplingHooks.get(entityplayer)).recallHook();
            entityplayer.swingItem();
        }
		else
        {
            world.playSoundAtEntity(entityplayer, "random.hurt", 1.0F, 1.0F / (itemRand.nextFloat() * 0.1F + 0.95F));
            if(!world.singleplayerWorld)
            {
                world.entityJoinedWorld(new ASEntityGrapplingHook(world, entityplayer));
            }
            entityplayer.swingItem();
        }
        return itemstack;
    }
}
