// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import java.util.List;
import net.minecraft.client.Minecraft;

// Referenced classes of package net.minecraft.src:
//            EntityArrow303, GuiModScreen, ModAction, mod_Arrows303, 
//            ModSettingScreen, WidgetClassicTwocolumn, SettingInt, ModSettings, 
//            WidgetInt, SettingFloat, WidgetFloat, WidgetSimplewindow, 
//            Block, Item, ItemStack, EntityLiving, 
//            Entity, AxisAlignedBB, World, EntityPlayer, 
//            MathHelper, Material, SettingBoolean, EntitySlimeFX, 
//            EffectRenderer

public class EntityArrow303Ice extends EntityArrow303
{

    public void subscreen()
    {
    }

    public void setupConfig()
    {
    }

    public void entityInit()
    {
        super.entityInit();
        name = "IceArrow";
        craftingResults = 1;
        itemId = 130 + Block.blocksList.length;
        tip = Item.snowball;
        item = new ItemStack(itemId, 1, 0);
        spriteFile = "/arrows/icearrow.png";
    }

    public EntityArrow303Ice(World world)
    {
        super(world);
    }

    public EntityArrow303Ice(World world, double d, double d1, double d2)
    {
        super(world, d, d1, d2);
    }

    public EntityArrow303Ice(World world, EntityLiving entityliving)
    {
        super(world, entityliving);
    }

    public boolean onHitBlock()
    {
        if(victim == null)
        {
            setEntityDead();
            return true;
        } else
        {
            return false;
        }
    }

    public boolean onHitTarget(Entity entity)
    {
        if(!(entity instanceof EntityLiving) || victim != null)
        {
            return false;
        }
        List list = worldObj.getEntitiesWithinAABBExcludingEntity(this, entity.boundingBox.expand(3D, 3D, 3D));
        for(int i = 0; i < list.size(); i++)
        {
            Entity entity1 = (Entity)list.get(i);
            if(!(entity1 instanceof EntityArrow303Ice))
            {
                continue;
            }
            EntityArrow303Ice entityarrow303ice = (EntityArrow303Ice)entity1;
            if(entityarrow303ice.victim == entity)
            {
                entityarrow303ice.freezeTimer += getFreezeTimer((EntityLiving)entity);
                entityarrow303ice.isDead = false;
                entity.attackEntityFrom(DamageSource.causePlayerDamage((EntityPlayer)shooter), 4);
                setEntityDead();
                return false;
            }
        }

        entity.attackEntityFrom(DamageSource.causePlayerDamage((EntityPlayer)shooter), 4);
        freezeMob((EntityLiving)entity);
        return false;
    }

    public int getFreezeTimer(EntityLiving entityliving)
    {
        return ((entityliving instanceof EntityPlayer) ? 5 : 10 * 20);
    }

    public void freezeMob(EntityLiving entityliving)
    {
        victim = entityliving;
        freezeFactor = ((entityliving instanceof EntityPlayer) ? 0.5F : 0.1F);
        freezeTimer = getFreezeTimer(entityliving);
        motionX = motionY = motionZ = 0.0D;
    }

    public void unfreezeMob()
    {
        victim = null;
    }

    public void setEntityDead()
    {
        if(victim != null)
        {
            unfreezeMob();
        }
        super.setEntityDead();
    }

    public void onUpdate()
    {
        super.onUpdate();
        if(victim != null)
        {
            if(victim.isDead || victim.deathTime > 0)
            {
                setEntityDead();
                return;
            }
            isDead = false;
            inGround = false;
            posX = victim.posX;
            posY = victim.boundingBox.minY + (double)victim.height * 0.5D;
            posZ = victim.posZ;
            setPosition(posX, posY, posZ);
            victim.motionX *= freezeFactor;
            victim.motionY *= freezeFactor;
            victim.motionZ *= freezeFactor;
            freezeTimer--;
            if(freezeTimer <= 0)
            {
                setEntityDead();
            }
        }
    }

    public boolean onHit()
    {
        if(victim != null)
        {
            return false;
        }
        int i = MathHelper.floor_double(posX);
        int j = MathHelper.floor_double(posY);
        int k = MathHelper.floor_double(posZ);
        for(int l = i - 1; l <= i + 1; l++)
        {
            for(int i1 = j - 1; i1 <= j + 1; i1++)
            {
                for(int j1 = k - 1; j1 <= k + 1; j1++)
                {
                    if(worldObj.getBlockMaterial(l, i1, j1) == Material.water && worldObj.getBlockMetadata(l, i1, j1) == 0)
                    {
                        worldObj.setBlockWithNotify(l, i1, j1, 79);
                        continue;
                    }
                    if(worldObj.getBlockMaterial(l, i1, j1) == Material.lava && worldObj.getBlockMetadata(l, i1, j1) == 0)
                    {
                        worldObj.setBlockWithNotify(l, i1, j1, 49);
                        continue;
                    }
                    if(worldObj.getBlockId(l, i1, j1) == 51)
                    {
                        worldObj.setBlockWithNotify(l, i1, j1, 0);
                        continue;
                    }
                    if(worldObj.getBlockId(l, i1, j1) == 50)
                    {
                        Block.blocksList[50].dropBlockAsItemWithChance(worldObj, l, i1, j1, worldObj.getBlockMetadata(l, i1, j1), 1.0F, 0);
                        worldObj.setBlockWithNotify(l, i1, j1, 0);
                        Block.blocksList[50].onBlockDestroyedByExplosion(worldObj, l, i1, j1);
                    }
                }

            }

        }

        return true;
    }

    public void tickFlying()
    {
        super.tickFlying();
        if(true)
        {
            EntitySpellParticleFX entityslimefx = new EntitySpellParticleFX(worldObj, posX, posY, posZ, 0, 0, 0);
            entityslimefx.motionX = entityslimefx.motionZ = entityslimefx.motionY = 0.01D;
            entityslimefx.renderDistanceWeight = 10D;
            mod_Arrows303.mc.effectRenderer.addEffect(entityslimefx);
        }
    }

    public EntityLiving victim;
    public float freezeFactor;
    public int freezeTimer;
}
