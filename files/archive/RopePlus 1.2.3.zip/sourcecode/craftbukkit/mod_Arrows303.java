package net.minecraft.server;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import net.minecraft.server.MinecraftServer;

public class mod_Arrows303 extends BaseModMp implements Runnable
{
    private boolean loaded = false;
    public static mod_Arrows303 inst;
    public static MinecraftServer mc = ModLoader.getMinecraftServerInstance();
    public static List arrows = new ArrayList();
    public static List newArrows = new ArrayList();
    private HashMap selectedArrowMap = new HashMap();
    private HashMap selectedSlotMap = new HashMap();
    private HashMap cycledMap = new HashMap();
    public static final int bow303id = 3541 + Block.byId.length;
    public int burstSize;
    public Item bow;
    public Item bow303;
    public Class[] coreArrowClasses;
    public EntityHuman prevPlayer;
    public static List arrowItems = new ArrayList();
	
    public String getPriorities()
    {
    	return "after:mod_Rope";
    }		

    public void load()
    {
        if (!this.loaded)
        {
            this.loaded = true;
            this.burstSize = 1;
            this.coreArrowClasses = new Class[] {EntityArrow303Dirt.class, EntityArrow303Ex.class, EntityArrow303Fire.class, EntityArrow303Grass.class, EntityArrow303Ice.class, EntityArrow303Laser.class, EntityArrow303Slime.class, EntityArrow303Torch.class, EntityArrow303Warp.class, EntityArrow303Confusion.class, EntityArrow303Rope.class};
            inst = this;
            arrows.add(new EntityArrow303((World)null));
            Class[] var1 = this.coreArrowClasses;
            int var2 = var1.length;

            for (int var3 = 0; var3 < var2; ++var3)
            {
                Class var4 = var1[var3];
                addArrow(this.makeArrow(var4));
            }

            ModLoaderMp.registerEntityTrackerEntry(EntityArrow303Dirt.class, 243);
            ModLoaderMp.registerEntityTrackerEntry(EntityArrow303Ex.class, 244);
            ModLoaderMp.registerEntityTrackerEntry(EntityArrow303Fire.class, 245);
            ModLoaderMp.registerEntityTrackerEntry(EntityArrow303Ice.class, 246);
            ModLoaderMp.registerEntityTrackerEntry(EntityArrow303Laser.class, 247);
            ModLoaderMp.registerEntityTrackerEntry(EntityArrow303Grass.class, 248);
            ModLoaderMp.registerEntityTrackerEntry(EntityArrow303Slime.class, 249);
            ModLoaderMp.registerEntityTrackerEntry(EntityArrow303Warp.class, 250);
            ModLoaderMp.registerEntityTrackerEntry(EntityArrow303Torch.class, 251);
            ModLoaderMp.registerEntityTrackerEntry(EntityArrow303Rope.class, 252);
            ModLoaderMp.registerEntityTrackerEntry(EntityArrow303Confusion.class, 253);
            ModLoaderMp.registerEntityTrackerEntry(EntityArrow303.class, 255);
            ModLoaderMp.registerEntityTracker(EntityArrow303Dirt.class, 243, 5);
            ModLoaderMp.registerEntityTracker(EntityArrow303Ex.class, 244, 5);
            ModLoaderMp.registerEntityTracker(EntityArrow303Fire.class, 245, 5);
            ModLoaderMp.registerEntityTracker(EntityArrow303Ice.class, 246, 5);
            ModLoaderMp.registerEntityTracker(EntityArrow303Laser.class, 247, 5);
            ModLoaderMp.registerEntityTracker(EntityArrow303Grass.class, 248, 5);
            ModLoaderMp.registerEntityTracker(EntityArrow303Slime.class, 249, 5);
            ModLoaderMp.registerEntityTracker(EntityArrow303Warp.class, 250, 5);
            ModLoaderMp.registerEntityTracker(EntityArrow303Torch.class, 251, 5);
            ModLoaderMp.registerEntityTracker(EntityArrow303Rope.class, 252, 5);
            ModLoaderMp.registerEntityTracker(EntityArrow303Confusion.class, 253, 5);
            ModLoaderMp.registerEntityTracker(EntityArrow303.class, 255, 5);
            this.setupBow();
        }
    }

    public String getVersion()
    {
        return "1.2.3 AS";
    }

    public void run()
    {
        this.setupBow();
        this.load();
    }

    public void setupBow()
    {
        this.bow = Item.BOW;
        Item.byId[this.bow.id] = null;
        this.bow303 = (new ItemBow303(this.bow.id - 256)).a(5, 1).a("bow");
        Item.byId[this.bow.id] = this.bow;
        Item.byId[Item.BOW.id] = Item.BOW = this.bow303;
    }

    public void selectArrow(World var1, EntityHuman var2)
    {
        this.findNextArrow(var1, var2, true);

        if (this.selectedArrow(var2) == null)
        {
            this.cycle(var1, var2, true);
        }
    }

    public void findNextArrow(World var1, EntityHuman var2, boolean var3)
    {
        EntityArrow303 var4 = this.selectedArrow(var2);
        int var5 = this.selectedSlot(var2);
        this.findNextArrowBetween(var1, var2, var4, var5, 1, var2.inventory.items.length, var3);

        if (this.selectedArrow(var2) == null)
        {
            this.findNextArrowBetween(var1, var2, var4, 0, 1, var5, var3);
        }
    }

    public void findPrevArrow(World var1, EntityHuman var2)
    {
        EntityArrow303 var3 = this.selectedArrow(var2);
        int var4 = this.selectedSlot(var2);
        this.findNextArrowBetween(var1, var2, var3, var4, -1, -1, false);

        if (this.selectedArrow(var2) == null)
        {
            this.findNextArrowBetween(var1, var2, var3, var2.inventory.items.length - 1, -1, var4 + 1, false);
        }
    }

    public void findNextArrowBetween(World var1, EntityHuman var2, EntityArrow303 var3, int var4, int var5, int var6, boolean var7)
    {
        for (int var8 = var4; var5 > 0 && var8 < var6 || var8 > var6; var8 += var5)
        {
            ItemStack var9 = var2.inventory.items[var8];

            if (var9 != null)
            {
                Item var10 = var9.getItem();

                if (var10 != null && var10 instanceof ItemArrow303)
                {
                    ItemArrow303 var11 = (ItemArrow303)var10;

                    if (var3 == null || var7 && var11.arrow == var3 || !var7 && var11.arrow != var3)
                    {
                        this.setselectedArrow(var2, var11.arrow);
                        this.setselectedSlot(var2, var8);
                        return;
                    }
                }
            }
        }

        this.setselectedArrow(var2, (EntityArrow303)null);
        this.setselectedSlot(var2, 0);
    }

    public void cycle(World var1, EntityHuman var2, boolean var3)
    {
        EntityArrow303 var4 = this.selectedArrow(var2);
        int var5 = this.selectedSlot(var2);

        if (var3)
        {
            this.findNextArrow(var1, var2, false);
        }
        else
        {
            this.findPrevArrow(var1, var2);
        }

        ItemStack var6;
        Item var7;

        if (this.selectedArrow(var2) == null && var4 != null && (var6 = var2.inventory.items[var5]) != null && (var7 = var6.getItem()) instanceof ItemArrow303 && ((ItemArrow303)var7).arrow == var4)
        {
            this.setselectedArrow(var2, var4);
            this.setselectedSlot(var2, var5);
        }
    }

    public void modsLoaded()
    {
        this.load();
        System.out.println("ModsLoaded in mod_Arrows303");
        Iterator var2 = arrows.iterator();

        while (var2.hasNext())
        {
            EntityArrow303 var1 = (EntityArrow303)var2.next();
            System.out.println("about to call makeItem for arrow " + var1);
            this.makeItem(var1);
        }

        this.setupBow();
    }

    public boolean dispenseEntity(World var1, double var2, double var4, double var6, int var8, int var9, ItemStack var10)
    {
        Iterator var11 = arrows.iterator();
        EntityArrow303 var12;

        do
        {
            if (!var11.hasNext())
            {
                return false;
            }

            var12 = (EntityArrow303)var11.next();
        }
        while (var12.itemId != var10.id);

        EntityArrow303 var13 = var12.newArrow(var1);
        var13.setPosition(var2, var4, var6);
        var13.setArrowHeading((double)var8, 0.1D, (double)var9, 1.1F, 6.0F);
        var1.addEntity(var13);
        var1.makeSound(var2, var4, var6, "random.bow", 1.0F, 1.2F);
        return true;
    }

    public EntityArrow303 makeArrow(Class var1)
    {
        try
        {
            return (EntityArrow303)var1.getConstructor(new Class[] {World.class}).newInstance(new Object[] {(World)null});
        }
        catch (Throwable var3)
        {
            throw new RuntimeException(var3);
        }
    }

    private void makeItem(EntityArrow303 var1)
    {
        if (var1.itemId == Item.ARROW.id)
        {
            Item.byId[Item.ARROW.id] = null;
            Item.ARROW = (new ItemArrow303(Item.ARROW.id - 256, var1)).d(Item.ARROW.textureId).a(Item.ARROW.getName());
        }
        else
        {
            int var3 = Item.ARROW.textureId;
            var3 = ModLoader.addOverride("/gui/items.png", var1.spriteFile);
            Item var2 = (new ItemArrow303(var1.itemId - 256, var1)).d(var3).a(var1.name);
            ModLoader.addRecipe(new ItemStack(var1.itemId, var1.craftingResults, 0), new Object[] {"X", "#", "Y", 'X', var1.tip, '#', Item.STICK, 'Y', Item.FEATHER});
            arrowItems.add(var2);
        }
    }

    public static void addArrow(EntityArrow303 var0)
    {
        newArrows.add(var0);
        arrows.add(var0);
    }

    public void showToggles() {}

    public EntityArrow303 selectedArrow(EntityHuman var1)
    {
        return (EntityArrow303)this.selectedArrowMap.get(var1);
    }

    public void setselectedArrow(EntityHuman var1, EntityArrow303 var2)
    {
        this.selectedArrowMap.put(var1, var2);
    }

    public int selectedSlot(EntityHuman var1)
    {
        return this.selectedSlotMap.get(var1) == null ? 0 : ((Integer)this.selectedSlotMap.get(var1)).intValue();
    }

    public void setselectedSlot(EntityHuman var1, int var2)
    {
        this.selectedSlotMap.put(var1, Integer.valueOf(var2));
    }

    public boolean cycled(EntityHuman var1)
    {
        return this.cycledMap.get(var1) == null ? false : ((Boolean)this.cycledMap.get(var1)).booleanValue();
    }

    public void setselectedSlot(EntityHuman var1, boolean var2)
    {
        this.cycledMap.put(var1, Boolean.valueOf(var2));
    }

    public void handlePacket(Packet230ModLoader var1, EntityPlayer var2)
    {
        switch (var1.packetType)
        {
            case 0:
                this.setselectedSlot(var2, var1.dataInt[0]);
                ItemStack var3 = var2.inventory.items[var1.dataInt[0]];

                if (var3 != null)
                {
                    Item var4 = var3.getItem();
                    ItemArrow303 var5 = (ItemArrow303)var4;
                    this.setselectedArrow(var2, var5.arrow);
                }

            default:
        }
    }

    public static Item getArrowItemByTip(Object var0)
    {
        Iterator var1 = arrowItems.iterator();
        ItemArrow303 var2;

        do
        {
            if (!var1.hasNext())
            {
                return null;
            }

            var2 = (ItemArrow303)var1.next();
        }
        while (var2.arrow.tip != var0);

        return var2;
    }
}
