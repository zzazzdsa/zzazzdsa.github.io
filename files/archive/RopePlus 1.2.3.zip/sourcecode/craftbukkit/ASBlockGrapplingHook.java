package net.minecraft.server;

import java.util.Random;

public class ASBlockGrapplingHook extends Block
{
    private int renderType;

    protected ASBlockGrapplingHook(int var1, int var2, int var3)
    {
        super(var1, var2, Material.WOOD);
        this.renderType = var3;
        this.a(0.0F, 0.0F, 0.0F, 1.0F, 0.125F, 1.0F);
    }

    /**
     * Returns a bounding box from the pool of bounding boxes (this means this box can change after the pool has been
     * cleared to be reused)
     */
    public AxisAlignedBB e(World var1, int var2, int var3, int var4)
    {
        return null;
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean a()
    {
        return false;
    }

    /**
     * If this block doesn't render as an ordinary block it will return false (examples: signs, buttons, stairs, etc)
     */
    public boolean b()
    {
        return false;
    }

    /**
     * Checks to see if its valid to put this block at the specified coordinates. Args: world, x, y, z
     */
    public boolean canPlace(World var1, int var2, int var3, int var4)
    {
        int var5 = var1.getTypeId(var2, var3 - 1, var4);
        return var5 != 0 && Block.byId[var5].a() ? var1.getMaterial(var2, var3 - 1, var4).isBuildable() : false;
    }

    /**
     * Lets the block know when one of its neighbor changes. Doesn't know which neighbor changed (coordinates passed are
     * their own) Args: x, y, z, blockID
     */
    public void doPhysics(World var1, int var2, int var3, int var4, int var5)
    {
        this.func_314_h(var1, var2, var3, var4);
    }

    private boolean func_314_h(World var1, int var2, int var3, int var4)
    {
        if (!this.canPlace(var1, var2, var3, var4))
        {
            this.b(var1, var2, var3, var4, var1.getData(var2, var3, var4), 0);
            var1.setTypeId(var2, var3, var4, 0);
            this.onBlockDestroyed(var1, var2, var3, var4);
            return false;
        }
        else
        {
            return true;
        }
    }

    /**
     * Returns the ID of the items to drop on destruction.
     */
    public int getDropType(int var1, Random var2, int var3)
    {
        return mod_ASGrapplingHook.itemGrapplingHook.id;
    }

    /**
     * Returns the quantity of items to drop on block destruction.
     */
    public int a(Random var1)
    {
        return 1;
    }

    /**
     * Called right before the block is destroyed by a player.  Args: world, x, y, z, metaData
     */
    public void postBreak(World var1, int var2, int var3, int var4, int var5)
    {
        this.onBlockDestroyed(var1, var2, var3, var4);
    }

    /**
     * Called upon the block being destroyed by an explosion
     */
    public void wasExploded(World var1, int var2, int var3, int var4)
    {
        this.onBlockDestroyed(var1, var2, var3, var4);
    }

    private void onBlockDestroyed(World var1, int var2, int var3, int var4)
    {
        int[][] var5 = new int[][] {{var2 - 1, var3 - 1, var4}, {var2 + 1, var3 - 1, var4}, {var2, var3 - 1, var4 - 1}, {var2, var3 - 1, var4 + 1}};

        for (int var6 = 0; var6 < var5.length; ++var6)
        {
            if (var1.getTypeId(var5[var6][0], var5[var6][1], var5[var6][2]) == mod_ASGrapplingHook.blockRope.id)
            {
                for (int var7 = var5[var6][1]; var1.getTypeId(var5[var6][0], var7, var5[var6][2]) == mod_ASGrapplingHook.blockRope.id; --var7)
                {
                    var1.setTypeId(var5[var6][0], var7, var5[var6][2], 0);
                }
            }
        }
    }
}
