package net.minecraft.server;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.server.MinecraftServer;

public class mod_Rope extends BaseModMp
{
    private boolean loaded = false;
    static List ropeEntArray = new ArrayList();
    static List ropePosArray = new ArrayList();
    public static int idBlock;
    public static Block rope;
    public static int rtex;
    private static long time;

    public String getVersion()
    {
        return "1.2.3 AS";
    }

    public void load()
    {
        if (!this.loaded)
        {
            this.loaded = true;
            rtex = ModLoader.addOverride("/terrain.png", "/imgz/rope2.png");
            ModLoader.registerBlock(rope);
            ModLoader.addRecipe(new ItemStack(rope, 12), new Object[] {" # ", " # ", " # ", '#', Item.STRING});
            time = System.currentTimeMillis();
            ModLoader.setInGameHook(this, true, false);
        }
    }

    public void modsLoaded()
    {
        this.load();
    }

    public void onTickInGame(MinecraftServer var1)
    {
        if (var1.worlds != null && var1.worlds.get(0) != null)
        {
            for (int var2 = 0; var2 < ropeEntArray.size(); ++var2)
            {
                Object var3 = ropeEntArray.get(var2);

                if (var3 instanceof BlockRopePseudoEnt)
                {
                    if (((BlockRopePseudoEnt)var3).OnUpdate())
                    {
                        ropeEntArray.remove(var2);
                    }
                }
                else if (var3 instanceof ASTileEntityRope && ((ASTileEntityRope)var3).OnUpdate())
                {
                    ropeEntArray.remove(var2);
                }
            }
        }
    }

    public static void onRopeArrowHit(World var0, int var1, int var2, int var3)
    {
        int[] var4 = new int[] {var1, var2, var3};
        addCoordsToRopeArray(var4);
        BlockRopePseudoEnt var5 = new BlockRopePseudoEnt(var0, var1, var2, var3, 31);
        addRopeToArray(var5);
    }

    public static void addRopeToArray(BlockRopePseudoEnt var0)
    {
        ropeEntArray.add(var0);
    }

    public static void addRopeToArray(ASTileEntityRope var0)
    {
        ropeEntArray.add(var0);
    }

    public static void addCoordsToRopeArray(int[] var0)
    {
        ropePosArray.add(var0);
    }

    public static void removeCoordsFromRopeArray(int[] var0)
    {
        ropePosArray.remove(var0);
    }

    public static int[] areCoordsArrowRope(int var0, int var1, int var2)
    {
        for (int var3 = 0; var3 < ropePosArray.size(); ++var3)
        {
            int[] var4 = (int[])((int[])ropePosArray.get(var3));

            if (var0 == var4[0] && var1 == var4[1] && var2 == var4[2])
            {
                return var4;
            }
        }

        return null;
    }

    static
    {
        AS_Settings_RopePlus.InitSettings();
        idBlock = AS_Settings_RopePlus.blockIdRopeDJRoslin;
        rope = (new BlockRope(idBlock, rtex)).c(0.3F).a(Block.i).a("rope");
    }
}
