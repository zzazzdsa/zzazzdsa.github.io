package net.minecraft.server;

import java.util.List;

public class EntityArrow303 extends EntityProjectileBase
{
    public int[] placeCoords = new int[3];
    public String name;
    public int itemId;
    public int craftingResults;
    public Object tip;
    public String spriteFile;
    public Entity target;
    public boolean homing;
    public static final int ticksBeforeCollidable = 2;
    public static int[][] candidates = new int[][] {{0, 0, 0}, {0, -1, 0}, {0, 1, 0}, { -1, 0, 0}, {1, 0, 0}, {0, 0, -1}, {0, 0, 1}, { -1, -1, 0}, { -1, 0, -1}, { -1, 0, 1}, { -1, 1, 0}, {0, -1, -1}, {0, -1, 1}, {0, 1, -1}, {0, 1, 1}, {1, -1, 0}, {1, 0, -1}, {1, 0, 1}, {1, 1, 0}, { -1, -1, -1}, { -1, -1, 1}, { -1, 1, -1}, { -1, 1, 1}, {1, -1, -1}, {1, -1, 1}, {1, 1, -1}, {1, 1, 1}};

    public void b()
    {
        super.b();
        this.homing = false;
        this.name = "Arrow";
        this.itemId = Item.ARROW.id;
        this.craftingResults = 4;
        this.tip = Item.FLINT;
        this.spriteFile = null;
        this.curvature = 0.03F;
        this.slowdown = 0.99F;
        this.precision = 1.0F;
        this.speed = 1.5F;
        this.item = new ItemStack(this.itemId, 1, 0);
        this.height = 0.0F;
        this.b(0.5F, 0.5F);
    }

    public EntityArrow303 newArrow(World var1, EntityLiving var2)
    {
        try
        {
            return (EntityArrow303)this.getClass().getConstructor(new Class[] {World.class, EntityLiving.class}).newInstance(new Object[] {var1, var2});
        }
        catch (Throwable var4)
        {
            throw new RuntimeException("Could not construct arrow instance", var4);
        }
    }

    public EntityArrow303 newArrow(World var1)
    {
        try
        {
            return (EntityArrow303)this.getClass().getConstructor(new Class[] {World.class}).newInstance(new Object[] {var1});
        }
        catch (Throwable var3)
        {
            throw new RuntimeException("Could not construct arrow instance", var3);
        }
    }

    public void setupConfig() {}

    public EntityArrow303(World var1)
    {
        super(var1);
    }

    public EntityArrow303(World var1, double var2, double var4, double var6)
    {
        super(var1, var2, var4, var6);
    }

    public EntityArrow303(World var1, EntityLiving var2)
    {
        super(var1, var2);
        this.homing = false;
    }

    public boolean attackEntityFrom(Entity var1, int var2)
    {
        if (var2 < 8)
        {
            return false;
        }
        else
        {
            if (!this.inGround && var1 != null)
            {
                Vec3D var3 = var1.aI();

                if (var3 != null)
                {
                    if (this.homing)
                    {
                        this.target = this.shooter;

                        if (var1 instanceof EntityLiving)
                        {
                            this.shooter = (EntityLiving)var1;
                        }
                    }

                    this.motX = var3.a;
                    this.motY = var3.b;
                    this.motZ = var3.c;
                    return true;
                }
            }

            return false;
        }
    }

    public boolean isInSight(Entity var1)
    {
        return this.world.a(Vec3D.create(this.locX, this.locY + (double)this.getHeadHeight(), this.locZ), Vec3D.create(var1.locX, var1.locY + (double)var1.getHeadHeight(), var1.locZ)) == null;
    }

    public void handleMotionUpdate()
    {
        if (!this.homing)
        {
            float var1 = this.slowdown;

            if (this.h_())
            {
                for (int var2 = 0; var2 < 4; ++var2)
                {
                    float var3 = 0.25F;
                    this.world.a("bubble", this.locX - this.motX * (double)var3, this.locY - this.motY * (double)var3, this.locZ - this.motZ * (double)var3, this.motX, this.motY, this.motZ);
                }

                var1 *= 0.8F;
            }

            this.motX *= (double)var1;
            this.motY *= (double)var1;
            this.motZ *= (double)var1;
        }

        if (this.target == null)
        {
            this.motY -= (double)this.curvature;
        }
    }

    public void tickFlying()
    {
        if (this.ticksFlying > 1 && this.homing)
        {
            if (this.target != null && !this.target.dead && (!(this.target instanceof EntityLiving) || ((EntityLiving)this.target).deathTicks == 0))
            {
                if (this.shooter instanceof EntityHuman && !this.isInSight(this.target))
                {
                    this.target = this.getTarget(this.locX, this.locY, this.locZ, 16.0D);
                }
            }
            else if (this.shooter instanceof EntityCreature)
            {
                this.target = ((EntityCreature)this.shooter).H();
            }
            else
            {
                this.target = this.getTarget(this.locX, this.locY, this.locZ, 16.0D);
            }

            if (this.target != null)
            {
                double var1 = this.target.boundingBox.a + (this.target.boundingBox.d - this.target.boundingBox.a) / 2.0D - this.locX;
                double var3 = this.target.boundingBox.b + (this.target.boundingBox.e - this.target.boundingBox.b) / 2.0D - this.locY;
                double var5 = this.target.boundingBox.c + (this.target.boundingBox.f - this.target.boundingBox.c) / 2.0D - this.locZ;
                this.setArrowHeading(var1, var3, var5, this.speed, this.precision);
            }
        }
    }

    public boolean o_()
    {
        return !this.dead && !this.inGround && this.ticksFlying >= 2;
    }

    public boolean canBeShot(Entity var1)
    {
        return !(var1 instanceof EntityArrow303) && super.canBeShot(var1);
    }

    private Entity getTarget(double var1, double var3, double var5, double var7)
    {
        float var9 = -1.0F;
        Entity var10 = null;
        List var11 = this.world.getEntities(this, this.boundingBox.grow(var7, var7, var7));

        for (int var12 = 0; var12 < var11.size(); ++var12)
        {
            Entity var13 = (Entity)var11.get(var12);

            if (this.canTarget(var13))
            {
                float var14 = var13.i(this);

                if (var9 == -1.0F || var14 < var9)
                {
                    var9 = var14;
                    var10 = var13;
                }
            }
        }

        return var10;
    }

    public boolean canTarget(Entity var1)
    {
        return var1 instanceof EntityLiving && var1 != this.shooter && this.isInSight(var1);
    }

    public boolean tryToPlaceBlock(int var1)
    {
        int var2 = MathHelper.floor(this.locX);
        int var3 = MathHelper.floor(this.locY);
        int var4 = MathHelper.floor(this.locZ);
        boolean var5 = false;
        int[][] var6 = candidates;
        int var7 = var6.length;

        for (int var8 = 0; var8 < var7; ++var8)
        {
            int[] var9 = var6[var8];
            int var10 = var9[0];
            int var11 = var9[1];
            int var12 = var9[2];

            if (this.world.mayPlace(var1, var2 + var10, var3 + var11, var4 + var12, true, 1))
            {
                var2 += var10;
                var3 += var11;
                var4 += var12;
                var5 = true;
                break;
            }
        }

        if (!var5)
        {
            return false;
        }
        else
        {
            this.world.getTypeId(var2, var3, var4);
            this.world.setTypeId(var2, var3, var4, var1);
            this.world.setData(var2, var3, var4, 0);
            this.placeCoords[0] = var2;
            this.placeCoords[1] = var3;
            this.placeCoords[2] = var4;
            return true;
        }
    }
}
