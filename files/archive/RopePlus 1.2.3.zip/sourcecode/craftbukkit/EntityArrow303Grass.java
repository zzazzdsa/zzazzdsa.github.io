package net.minecraft.server;

public class EntityArrow303Grass extends EntityArrow303
{
    public void b()
    {
        super.b();
        this.name = "GrassArrow";
        this.craftingResults = 1;
        this.itemId = 3439 + Block.byId.length;
        this.tip = Item.SEEDS;
        this.item = new ItemStack(this.itemId, 1, 0);
        this.spriteFile = "/arrows/grassarrow.png";
    }

    public EntityArrow303Grass(World var1)
    {
        super(var1);
    }

    public EntityArrow303Grass(World var1, EntityLiving var2)
    {
        super(var1, var2);
    }

    public EntityArrow303Grass(World var1, double var2, double var4, double var6)
    {
        super(var1, var2, var4, var6);
    }

    public boolean onHit()
    {
        int var1 = MathHelper.floor(this.locX);
        int var2 = MathHelper.floor(this.locY);
        int var3 = MathHelper.floor(this.locZ);

        for (int var4 = var1 - 1; var4 <= var1 + 1; ++var4)
        {
            for (int var5 = var2 - 1; var5 <= var2 + 1; ++var5)
            {
                for (int var6 = var3 - 1; var6 <= var3 + 1; ++var6)
                {
                    int var7 = this.world.getTypeId(var4, var5, var6);

                    if (var7 == 3)
                    {
                        this.world.setTypeId(var4, var5, var6, 2);
                        this.die();
                    }
                    else if (var7 == 4)
                    {
                        this.world.setTypeId(var4, var5, var6, 48);
                        this.die();
                    }
                    else if (var7 == 60 && var5 != 127 && this.world.getTypeId(var4, var5 + 1, var6) == 0)
                    {
                        this.world.setTypeId(var4, var5 + 1, var6, 59);
                        this.die();
                    }
                }
            }
        }

        return true;
    }

    public void tickFlying() {}
}
