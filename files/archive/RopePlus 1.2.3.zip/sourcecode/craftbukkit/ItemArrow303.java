package net.minecraft.server;

public class ItemArrow303 extends Item
{
    public EntityArrow303 arrow;

    public ItemArrow303(int var1, EntityArrow303 var2)
    {
        super(var1);
        this.arrow = var2;
    }
}
