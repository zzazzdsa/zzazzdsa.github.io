package net.minecraft.server;

public class EntityArrow303Warp extends EntityArrow303
{
    public void b()
    {
        super.b();
        this.name = "WarpArrow";
        this.craftingResults = 4;
        this.itemId = 258 + Block.byId.length;
        this.tip = Block.OBSIDIAN;
        this.item = new ItemStack(this.itemId, 1, 0);
        this.spriteFile = "/arrows/warparrow.png";
    }

    public EntityArrow303Warp(World var1)
    {
        super(var1);
    }

    public EntityArrow303Warp(World var1, EntityLiving var2)
    {
        super(var1, var2);
        var1.makeSound(this, "portal.trigger", 1.0F, 1.0F);
    }

    public EntityArrow303Warp(World var1, double var2, double var4, double var6)
    {
        super(var1, var2, var4, var6);
    }

    public void tickFlying() {}

    public boolean onHit()
    {
        if (this.teleport(this.locX, this.locY, this.locZ))
        {
            this.die();
        }

        return true;
    }

    private boolean isSolid(int var1, int var2, int var3)
    {
        int var4 = this.world.getTypeId(var1, var2, var3);
        return var4 != 0 && Block.byId[var4].c() == 0;
    }

    private boolean isSolid(double var1, double var3, double var5)
    {
        return this.isSolid(MathHelper.floor(var1), MathHelper.floor(var3), MathHelper.floor(var5));
    }

    public boolean teleport(double var1, double var3, double var5)
    {
        if (this.shooter == null)
        {
            return false;
        }
        else
        {
            float var7 = this.shooter.length;
            double var8 = 0.1D;
            double var10 = Math.ceil(var3) - var3;
            double var12 = var3 - Math.floor(var3);
            int var14;

            for (var14 = 1; var14 < 3 && !this.isSolid(var1, var3 + (double)var14, var5); ++var14)
            {
                ++var10;
            }

            for (var14 = 1; var14 < 3 && !this.isSolid(var1, var3 - (double)var14, var5); ++var14)
            {
                ++var12;
            }

            if (var10 + var12 < (double)var7 + var8)
            {
                return false;
            }
            else
            {
                if (var12 < (double)var7)
                {
                    var3 += (double)var7 - var12;
                }

                if (var10 < var8)
                {
                    var3 -= var8;
                }

                this.shooter.enderTeleportTo(Math.floor(var1) + 0.5D, var3, Math.floor(var5) + 0.5D);
                this.shooter.fallDistance = 0.0F;
                this.shooter.damageEntity(DamageSource.FALL, 5);
                return true;
            }
        }
    }
}
