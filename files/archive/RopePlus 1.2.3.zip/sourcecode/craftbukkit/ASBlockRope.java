package net.minecraft.server;

import java.util.Random;

public class ASBlockRope extends BlockContainer
{
    public float ascensionSpeed = 0.2F;
    public float descensionSpeed = -0.15F;
    private int renderType;

    protected ASBlockRope(int var1, int var2, int var3)
    {
        super(var1, var2, Material.REPLACEABLE_PLANT);
        this.renderType = var3;
    }

    /**
     * Returns the TileEntity used by this block.
     */
    public TileEntity a_()
    {
        return null;
    }

    /**
     * checks to see if you can place this block can be placed on that side of a block: BlockLever overrides
     */
    public boolean canPlace(World var1, int var2, int var3, int var4, int var5)
    {
        switch (var5)
        {
            case 1:
                return this.canBePlacedOn(var1.getTypeId(var2, var3, var4 + 1));

            case 2:
                return this.canBePlacedOn(var1.getTypeId(var2, var3, var4 + 1));

            case 3:
                return this.canBePlacedOn(var1.getTypeId(var2, var3, var4 - 1));

            case 4:
                return this.canBePlacedOn(var1.getTypeId(var2 + 1, var3, var4));

            case 5:
                return this.canBePlacedOn(var1.getTypeId(var2 - 1, var3, var4));

            default:
                return false;
        }
    }

    private boolean canBePlacedOn(int var1)
    {
        System.out.println("canBePlaced on ID: " + var1);

        if (var1 == 0)
        {
            return false;
        }
        else
        {
            Block var2 = Block.byId[var1];
            return var2.b() && var2.material.isSolid();
        }
    }

    /**
     * Triggered whenever an entity collides with this block (enters into the block). Args: world, x, y, z, entity
     */
    public void a(World var1, int var2, int var3, int var4, Entity var5)
    {
        if (var5 instanceof EntityLiving)
        {
            var5.fallDistance = 0.0F;

            if (var5.motY < (double)this.descensionSpeed)
            {
                var5.motY = (double)this.descensionSpeed;
            }

            if (var5.positionChanged)
            {
                var5.motY = (double)this.ascensionSpeed;
            }
        }
    }

    /**
     * Returns a bounding box from the pool of bounding boxes (this means this box can change after the pool has been
     * cleared to be reused)
     */
    public AxisAlignedBB e(World var1, int var2, int var3, int var4)
    {
        int var5 = var1.getData(var2, var3, var4);
        float var6 = 0.125F;

        if (var5 == 1)
        {
            this.a(0.0F, 0.0F, 1.0F - var6, 1.0F, 1.0F, 1.0F);
        }

        if (var5 == 4)
        {
            this.a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, var6);
        }

        if (var5 == 8)
        {
            this.a(1.0F - var6, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
        }

        if (var5 == 2)
        {
            this.a(0.0F, 0.0F, 0.0F, var6, 1.0F, 1.0F);
        }

        return super.e(var1, var2, var3, var4);
    }

    /**
     * Sets the block's bounds for rendering it as an item
     */
    public void f()
    {
        this.a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean a()
    {
        return false;
    }

    /**
     * If this block doesn't render as an ordinary block it will return false (examples: signs, buttons, stairs, etc)
     */
    public boolean b()
    {
        return false;
    }

    /**
     * Updates the blocks bounds based on its current state. Args: world, x, y, z
     */
    public void updateShape(IBlockAccess var1, int var2, int var3, int var4)
    {
        int var5 = var1.getData(var2, var3, var4);
        float var6 = 1.0F;
        float var7 = 1.0F;
        float var8 = 1.0F;
        float var9 = 0.0F;
        float var10 = 0.0F;
        float var11 = 0.0F;
        boolean var12 = var5 > 0;

        if ((var5 & 2) != 0)
        {
            var9 = Math.max(var9, 0.0625F);
            var6 = 0.0F;
            var7 = 0.0F;
            var10 = 1.0F;
            var8 = 0.0F;
            var11 = 1.0F;
            var12 = true;
        }

        if ((var5 & 8) != 0)
        {
            var6 = Math.min(var6, 0.9375F);
            var9 = 1.0F;
            var7 = 0.0F;
            var10 = 1.0F;
            var8 = 0.0F;
            var11 = 1.0F;
            var12 = true;
        }

        if ((var5 & 4) != 0)
        {
            var11 = Math.max(var11, 0.0625F);
            var8 = 0.0F;
            var6 = 0.0F;
            var9 = 1.0F;
            var7 = 0.0F;
            var10 = 1.0F;
            var12 = true;
        }

        if ((var5 & 1) != 0)
        {
            var8 = Math.min(var8, 0.9375F);
            var11 = 1.0F;
            var6 = 0.0F;
            var9 = 1.0F;
            var7 = 0.0F;
            var10 = 1.0F;
            var12 = true;
        }

        this.a(var6, var7, var8, var9, var10, var11);
    }

    /**
     * The type of render function that is called for this block
     */
    public int c()
    {
        return 20;
    }

    /**
     * Returns the quantity of items to drop on block destruction.
     */
    public int a(Random var1)
    {
        return 0;
    }

    /**
     * Called right before the block is destroyed by a player.  Args: world, x, y, z, metaData
     */
    public void postBreak(World var1, int var2, int var3, int var4, int var5)
    {
        this.onBlockDestroyed(var1, var2, var3, var4);
    }

    /**
     * Called upon the block being destroyed by an explosion
     */
    public void wasExploded(World var1, int var2, int var3, int var4)
    {
        this.onBlockDestroyed(var1, var2, var3, var4);
    }

    public void onBlockDestroyed(World var1, int var2, int var3, int var4)
    {
        if (!var1.isStatic)
        {
            int var7;

            for (var7 = 1; var1.getTypeId(var2, var3 + var7, var4) == mod_ASGrapplingHook.blockRope.id; ++var7)
            {
                ;
            }

            int var5 = var3 + var7 - 1;

            for (var7 = -1; var1.getTypeId(var2, var3 + var7, var4) == mod_ASGrapplingHook.blockRope.id; --var7)
            {
                ;
            }

            int var6 = var3 + var7 + 1;
            var7 = var5 - var6;
            System.out.println("Rope min: " + var6 + ", Rope max: " + var5 + ", lenght: " + var7);

            for (int var8 = 0; var8 <= var7; ++var8)
            {
                var1.setTypeId(var2, var5 - var8, var4, 0);
            }

            int[][] var9 = new int[][] {{var2 - 1, var5 + 1, var4}, {var2, var5 + 1, var4 - 1}, {var2, var5 + 1, var4 + 1}, {var2 + 1, var5 + 1, var4}};
            boolean var10 = false;

            for (int var11 = 0; var11 < var9.length; ++var11)
            {
                if (var1.getTypeId(var9[var11][0], var9[var11][1], var9[var11][2]) == mod_ASGrapplingHook.blockGrapplingHook.id)
                {
                    var1.setTypeId(var9[var11][0], var9[var11][1], var9[var11][2], 0);
                    EntityItem var12 = new EntityItem(var1, (double)var2, (double)var3, (double)var4, new ItemStack(mod_ASGrapplingHook.itemGrapplingHook));
                    var12.pickupDelay = 5;
                    var1.addEntity(var12);
                    var10 = true;
                    break;
                }
            }

            if (!var10)
            {
                EntityItem var13 = new EntityItem(var1, (double)var2, (double)var3, (double)var4, new ItemStack(mod_Arrows303.getArrowItemByTip(mod_Rope.rope)));
                var13.pickupDelay = 5;
                var1.addEntity(var13);
            }
        }
    }
}
