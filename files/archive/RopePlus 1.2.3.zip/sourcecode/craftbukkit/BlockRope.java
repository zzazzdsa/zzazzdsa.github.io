package net.minecraft.server;

public class BlockRope extends Block
{
    protected BlockRope(int var1, int var2)
    {
        super(var1, Material.REPLACEABLE_PLANT);
        this.textureId = mod_Rope.rtex;
        float var3 = 0.1F;
        this.a(0.5F - var3, 0.0F, 0.5F - var3, 0.5F + var3, 1.0F, 0.5F + var3);
    }

    /**
     * Called whenever the block is added into the world. Args: world, x, y, z
     */
    public void onPlace(World var1, int var2, int var3, int var4)
    {
        byte var5 = 0;
        byte var6 = 0;
        byte var7 = 0;

        if (var1.getTypeId(var2 - 1, var3, var4 + 0) == this.id)
        {
            var5 = -1;
            var6 = 0;
        }
        else if (var1.getTypeId(var2 + 1, var3, var4 + 0) == this.id)
        {
            var5 = 1;
            var6 = 0;
        }
        else if (var1.getTypeId(var2, var3, var4 - 1) == this.id)
        {
            var5 = 0;
            var6 = -1;
        }
        else if (var1.getTypeId(var2, var3, var4 + 1) == this.id)
        {
            var5 = 0;
            var6 = 1;
        }

        if (var5 != 0 || var6 != 0)
        {
            for (int var8 = 1; var8 <= 32; ++var8)
            {
                if (var7 == 0 & var1.r(var2 + var5, var3 - var8, var4 + var6))
                {
                    var7 = 2;
                }

                if (var7 == 0 & var1.getTypeId(var2 + var5, var3 - var8, var4 + var6) == 0)
                {
                    var7 = 1;
                    var1.setTypeId(var2, var3, var4, 0);
                    var1.setTypeId(var2 + var5, var3 - var8, var4 + var6, this.id);
                }
            }
        }

        if ((var7 == 0 || var7 == 2) & var1.getTypeId(var2, var3 + 1, var4) != this.id && !var1.r(var2, var3 + 1, var4))
        {
            this.b(var1, var2, var3, var4, var1.getData(var2, var3, var4), 0);
            var1.setTypeId(var2, var3, var4, 0);
        }
    }

    /**
     * Lets the block know when one of its neighbor changes. Doesn't know which neighbor changed (coordinates passed are
     * their own) Args: x, y, z, blockID
     */
    public void doPhysics(World var1, int var2, int var3, int var4, int var5)
    {
        super.doPhysics(var1, var2, var3, var4, var5);
        boolean var6 = false;

        if (var1.getTypeId(var2 - 1, var3, var4 + 0) == this.id)
        {
            var6 = true;
        }

        if (var1.getTypeId(var2 + 1, var3, var4 + 0) == this.id)
        {
            var6 = true;
        }

        if (var1.getTypeId(var2, var3, var4 - 1) == this.id)
        {
            var6 = true;
        }

        if (var1.getTypeId(var2, var3, var4 + 1) == this.id)
        {
            var6 = true;
        }

        if (var1.r(var2, var3 + 1, var4))
        {
            var6 = true;
        }

        if (var1.getTypeId(var2, var3 + 1, var4) == this.id)
        {
            var6 = true;
        }

        if (!var6)
        {
            this.b(var1, var2, var3, var4, var1.getData(var2, var3, var4), 0);
            var1.setTypeId(var2, var3, var4, 0);
        }
    }

    /**
     * Checks to see if its valid to put this block at the specified coordinates. Args: world, x, y, z
     */
    public boolean canPlace(World var1, int var2, int var3, int var4)
    {
        return var1.getTypeId(var2 - 1, var3, var4 + 0) == this.id ? true : (var1.getTypeId(var2 + 1, var3, var4 + 0) == this.id ? true : (var1.getTypeId(var2, var3, var4 - 1) == this.id ? true : (var1.getTypeId(var2, var3, var4 + 1) == this.id ? true : (var1.r(var2, var3 + 1, var4) ? true : var1.getTypeId(var2, var3 + 1, var4) == this.id))));
    }

    /**
     * Called right before the block is destroyed by a player.  Args: world, x, y, z, metaData
     */
    public void postBreak(World var1, int var2, int var3, int var4, int var5)
    {
        int[] var6 = mod_Rope.areCoordsArrowRope(var2, var3, var4);

        if (var6 != null)
        {
            if (var1.getTypeId(var2, var3, var4) == this.id)
            {
                var1.setTypeId(var2, var3, var4, 0);
            }

            int var9;

            for (var9 = 1; var1.getTypeId(var2, var3 + var9, var4) == this.id; ++var9)
            {
                ;
            }

            int var7 = var3 + var9 - 1;

            for (var9 = 0; var1.getTypeId(var2, var3 + var9, var4) == this.id; --var9)
            {
                ;
            }

            int var8 = var3 + var9 + 1;
            var9 = var7 - var8;

            for (int var10 = 0; var10 <= var9; ++var10)
            {
                var6 = mod_Rope.areCoordsArrowRope(var2, var8 + var10, var4);
                var1.setTypeId(var2, var8 + var10, var4, 0);

                if (var6 != null)
                {
                    mod_Rope.removeCoordsFromRopeArray(var6);
                }
            }

            if (!var1.isStatic)
            {
                EntityItem var11 = new EntityItem(var1, (double)var2, (double)var3, (double)var4, new ItemStack(Item.STICK));
                var11.pickupDelay = 5;
                var1.addEntity(var11);
                var11 = new EntityItem(var1, (double)var2, (double)var3, (double)var4, new ItemStack(Item.FEATHER));
                var11.pickupDelay = 5;
                var1.addEntity(var11);
            }
        }
    }

    /**
     * Is this block (a) opaque and (b) a full 1m cube?  This determines whether or not to render the shared face of two
     * adjacent blocks and also whether the player can attach torches, redstone wire, etc to this block.
     */
    public boolean a()
    {
        return false;
    }

    /**
     * If this block doesn't render as an ordinary block it will return false (examples: signs, buttons, stairs, etc)
     */
    public boolean b()
    {
        return false;
    }

    /**
     * The type of render function that is called for this block
     */
    public int c()
    {
        return 1;
    }
}
