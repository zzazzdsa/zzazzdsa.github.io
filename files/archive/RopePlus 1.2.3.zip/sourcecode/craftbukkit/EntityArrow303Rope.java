package net.minecraft.server;

public class EntityArrow303Rope extends EntityArrow303
{
    public void b()
    {
        super.b();
        this.name = "RopeArrow";
        this.craftingResults = 1;
        this.itemId = 243 + Block.byId.length;
        this.tip = mod_Rope.rope;
        this.spriteFile = "/arrows/ropearrow.png";
        this.item = new ItemStack(this.itemId, 1, 0);
    }

    public EntityArrow303Rope(World var1)
    {
        super(var1);
    }

    public EntityArrow303Rope(World var1, EntityLiving var2)
    {
        super(var1, var2);
    }

    public EntityArrow303Rope(World var1, double var2, double var4, double var6)
    {
        super(var1, var2, var4, var6);
    }

    public boolean onHit()
    {
        if (this.tryToPlaceBlock(mod_Rope.rope.id))
        {
            this.die();
            mod_Rope.onRopeArrowHit(this.world, this.placeCoords[0], this.placeCoords[1], this.placeCoords[2]);
        }
        else if (this.tryToPlaceBlock2(mod_ASGrapplingHook.blockRope.id))
        {
            ASTileEntityRope var1 = new ASTileEntityRope(this.world, this.placeCoords[0], this.placeCoords[1], this.placeCoords[2], 32);
            mod_Rope.addRopeToArray(var1);
            this.die();
        }

        return true;
    }

    public boolean tryToPlaceBlock2(int var1)
    {
        int var2 = MathHelper.floor(this.locX);
        int var3 = MathHelper.floor(this.locY);
        int var4 = MathHelper.floor(this.locZ);
        boolean var5 = false;
        int[][] var6 = candidates;
        int var7 = var6.length;
        int var8 = 0;
        double var9 = this.motX;
        double var11 = this.motZ;
        byte var13 = (byte)(var9 <= 0.0D ? -1 : 1);
        byte var14 = (byte)(var11 <= 0.0D ? -1 : 1);
        byte var15 = 0;
        byte var16 = 0;
        boolean var17 = false;

        if (Math.abs(var9) > Math.abs(var11))
        {
            var17 = true;

            if (var13 > 0)
            {
                var16 = 4;
                var15 = 8;
            }
            else
            {
                var16 = 5;
                var15 = 2;
            }
        }
        else if (Math.abs(var9) <= Math.abs(var11))
        {
            var17 = true;

            if (var14 > 0)
            {
                var16 = 1;
                var15 = 1;
            }
            else
            {
                var16 = 3;
                var15 = 4;
            }
        }

        int var19;

        while (var8 < var7)
        {
            int[] var18 = var6[var8];
            var19 = var18[0];
            int var20 = var18[1];
            int var21 = var18[2];

            if (this.world.mayPlace(var1, var2 + var19, var3 + var20, var4 + var21, true, var16))
            {
                var2 += var19;
                var3 += var20;
                var4 += var21;
                var5 = true;
                break;
            }

            System.out.println("server could not put rope at: [" + (var2 + var19) + "|" + (var3 + var20) + "|" + (var4 + var21) + "], blockside " + var16);
            ++var8;
        }

        if (!var5)
        {
            return false;
        }
        else
        {
            int var22 = this.world.getTypeId(var2, var3, var4);

            if (var22 > 0 && this.shotByPlayer)
            {
                var19 = this.world.getData(var2, var3, var4);
                Block.byId[var22].a(this.world, (EntityHuman)this.shooter, var2, var3, var4, var19);
            }

            if (var17)
            {
                if (!this.world.isStatic)
                {
                    this.world.setTypeId(var2, var3, var4, var1);
                    this.world.setData(var2, var3, var4, var15);
                }

                this.placeCoords[0] = var2;
                this.placeCoords[1] = var3;
                this.placeCoords[2] = var4;
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
