package net.minecraft.server;

import java.util.HashMap;
import java.util.Map;

public class mod_ASGrapplingHook extends BaseModMp
{
    private boolean loaded = false;
    public static Block blockRope;
    public static Block blockGrapplingHook;
    public static final Item itemRope = (new Item(2511)).d(ModLoader.addOverride("/gui/items.png", "/imgz/rope.png")).a("itemRope");
    public static final Item itemGrapplingHook = (new ASItemGrapplingHook(2512)).d(ModLoader.addOverride("/gui/items.png", "/imgz/itemGrapplingHook.png")).a("itemGrapplingHook");
    public static Map grapplingHooks = new HashMap();

    public String getPriorities()
    {
    	return "after:mod_Rope";
    }		
	
    public void load()
    {
        if (!this.loaded)
        {
            this.loaded = true;
            AS_Settings_RopePlus.InitSettings();
            blockRope = (new ASBlockRope(AS_Settings_RopePlus.blockIdRope, ModLoader.addOverride("/terrain.png", "/imgz/rope.png"), ModLoader.getUniqueBlockModelID(this, false))).c(0.5F).a(Block.k).a("blockRope");
            blockGrapplingHook = (new ASBlockGrapplingHook(AS_Settings_RopePlus.blockIdGrapplingHook, ModLoader.addOverride("/terrain.png", "/imgz/blockGrapplingHook.png"), ModLoader.getUniqueBlockModelID(this, false))).c(0.0F).a(Block.i).a("blockGrapplingHook");
            ModLoader.registerEntityID(ASEntityGrapplingHook.class, "GrapplingHook", ModLoader.getUniqueEntityId());
            ModLoader.registerTileEntity(ASTileEntityRope.class, "Rope");
            ModLoaderMp.registerEntityTrackerEntry(ASEntityGrapplingHook.class, 254);
            ModLoaderMp.registerEntityTracker(ASEntityGrapplingHook.class, 160, 5);
            ModLoader.registerBlock(blockRope);
            ModLoader.registerBlock(blockGrapplingHook);
            ModLoader.addRecipe(new ItemStack(itemGrapplingHook, 1), new Object[] {" X ", " # ", " # ", '#', mod_Rope.rope, 'X', Item.IRON_INGOT});
        }
    }

    public void modsLoaded()
    {
        this.load();
    }

    public String getVersion()
    {
        return "1.2.3 AS";
    }
}
