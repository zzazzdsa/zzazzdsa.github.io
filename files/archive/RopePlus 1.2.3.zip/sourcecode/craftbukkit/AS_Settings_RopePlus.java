package net.minecraft.server;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class AS_Settings_RopePlus
{
    public static int blockIdRopeDJRoslin = 242;
    public static int blockIdRope = 243;
    public static int blockIdGrapplingHook = 244;
    public static boolean settingsLoaded = false;
    private static File configfile = new File("mods/RopePlus.txt");

    public AS_Settings_RopePlus()
    {
        InitSettings();
    }

    public static void InitSettings()
    {
        if (!settingsLoaded)
        {
            settingsLoaded = true;
            Properties var0 = new Properties();

            if (configfile.exists())
            {
                try
                {
                    var0.load(new FileInputStream(configfile));
                }
                catch (IOException var4)
                {
                    System.out.println("RopePlus config exception: " + var4);
                }

                blockIdRope = Integer.parseInt(var0.getProperty("blockIdRope", new String("" + blockIdRope)));
                blockIdGrapplingHook = Integer.parseInt(var0.getProperty("blockIdGrapplingHook", new String("" + blockIdGrapplingHook)));
                blockIdRopeDJRoslin = Integer.parseInt(var0.getProperty("blockIdRopeDJRoslin", new String("" + blockIdRopeDJRoslin)));
            }
            else
            {
                System.out.println("No RopePlus config found, trying to create...");

                try
                {
                    configfile.createNewFile();
                    var0.load(new FileInputStream(configfile));
                }
                catch (IOException var3)
                {
                    System.out.println("RopePlus config exception: " + var3);
                }

                var0.setProperty("blockIdRope", new String("" + blockIdRope));
                var0.setProperty("blockIdGrapplingHook", new String("" + blockIdGrapplingHook));
                var0.setProperty("blockIdRopeDJRoslin", new String("" + blockIdRopeDJRoslin));

                try
                {
                    FileOutputStream var1 = new FileOutputStream(configfile);
                    var0.store(var1, "Here you can customize Block ID\'s in case of incompatibility. Defaults: 242 - 244; ID may not exceed 255 unless a mod enables that");
                }
                catch (IOException var2)
                {
                    System.out.println("RopePlus config exception: " + var2);
                }
            }
        }
    }
}
