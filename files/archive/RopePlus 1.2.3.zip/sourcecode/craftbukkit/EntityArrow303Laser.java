package net.minecraft.server;

import java.util.HashSet;
import java.util.Set;

public class EntityArrow303Laser extends EntityArrow303
{
    public boolean pierced;
    public Set piercedMobs;
    public static String sound = "damage.fallbig";

    public void b()
    {
        super.b();
        this.name = "LaserArrow";
        this.craftingResults = 1;
        this.itemId = 2818 + Block.byId.length;
        this.tip = Item.REDSTONE;
        this.spriteFile = "/arrows/laserarrow.png";
        this.curvature = 0.0F;
        this.slowdown = 1.3F;
        this.precision = 0.0F;
        this.speed = 2.0F;
        this.pierced = false;
        this.piercedMobs = new HashSet();
        this.item = new ItemStack(this.itemId, 1, 0);
    }

    public EntityArrow303Laser(World var1)
    {
        super(var1);
    }

    public EntityArrow303Laser(World var1, double var2, double var4, double var6)
    {
        super(var1, var2, var4, var6);
    }

    public EntityArrow303Laser(World var1, EntityLiving var2)
    {
        super(var1, var2);
    }

    public boolean onHitTarget(Entity var1)
    {
        var1.damageEntity(DamageSource.playerAttack((EntityHuman)this.shooter), 8);
        this.pierced = true;
        this.piercedMobs.add(var1);
        this.target = null;
        this.world.makeSound(this, sound, 1.0F, ((this.random.nextFloat() - this.random.nextFloat()) * 0.2F + 1.0F) / 0.8F);
        return false;
    }

    public boolean isInSight(Entity var1)
    {
        return this.canSee(this, var1) && this.canSee(var1, this);
    }

    public boolean canSee(Entity var1, Entity var2)
    {
        World var10000 = this.world;
        Vec3D var10001 = (Vec3D)null;
        var10001 = Vec3D.create(var1.locX, var1.locY + (double)var1.getHeadHeight(), var1.locZ);
        Vec3D var10002 = (Vec3D)null;
        MovingObjectPosition var3 = var10000.a(var10001, Vec3D.create(var2.locX, var2.locY + (double)var2.getHeadHeight(), var2.locZ));
        return var3 == null || var3.type == EnumMovingObjectType.TILE && this.isTransparent(this.world.getTypeId(var3.b, var3.c, var3.d));
    }

    public boolean onHitBlock()
    {
        if (!this.isTransparent(this.inTile))
        {
            if (this.pierced)
            {
                this.die();
            }

            return true;
        }
        else
        {
            return false;
        }
    }

    public boolean isTransparent(int var1)
    {
        return Block.lightBlock[var1] != 255;
    }

    public void tickFlying() {}

    public boolean canTarget(Entity var1)
    {
        return !this.piercedMobs.contains(var1) && super.canTarget(var1);
    }
}
