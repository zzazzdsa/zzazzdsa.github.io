package net.minecraft.server;

public class EntityArrow303Dirt extends EntityArrow303
{
    public static final int defaultBlockId = Block.DIRT.id;

    public void subscreen() {}

    public void setupConfig() {}

    public void b()
    {
        super.b();
        this.name = "DirtArrow";
        this.craftingResults = 1;
        this.itemId = 132 + Block.byId.length;
        this.tip = Block.DIRT;
        this.item = new ItemStack(this.itemId, 1, 0);
        this.spriteFile = "/arrows/dirtarrow.png";
    }

    public EntityArrow303Dirt(World var1)
    {
        super(var1);
    }

    public EntityArrow303Dirt(World var1, EntityLiving var2)
    {
        super(var1, var2);
    }

    public EntityArrow303Dirt(World var1, double var2, double var4, double var6)
    {
        super(var1, var2, var4, var6);
    }

    public boolean onHit()
    {
        this.spawnDirt();
        return true;
    }

    public boolean onHitBlock()
    {
        this.die();
        return true;
    }

    public void spawnDirt()
    {
        int var1 = MathHelper.floor(this.locX);
        int var2 = MathHelper.floor(this.locY);
        int var3 = MathHelper.floor(this.locZ);

        for (int var4 = 0; var4 <= 0; ++var4)
        {
            int var5 = 0;

            while (var5 <= 0)
            {
                int var6 = 0;

                while (true)
                {
                    if (var6 <= 0)
                    {
                        int var7 = var1 + var4;
                        int var8 = var2 + var6;
                        int var9 = var3 + var5;

                        if (Math.abs(var4) != 0 && Math.abs(var6) != 0 && Math.abs(var5) != 0 || !this.world.mayPlace(defaultBlockId, var7, var8, var9, true, Block.DIRT.id))
                        {
                            ++var6;
                            continue;
                        }

                        this.world.setTypeId(var7, var8, var9, Block.DIRT.id);
                    }

                    ++var5;
                    break;
                }
            }
        }
    }

    public void tickFlying()
    {
        super.tickFlying();
    }
}
