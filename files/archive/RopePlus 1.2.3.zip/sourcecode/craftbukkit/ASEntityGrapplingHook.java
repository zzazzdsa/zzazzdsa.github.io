package net.minecraft.server;

import java.util.List;

public class ASEntityGrapplingHook extends Entity
{
    private int xTile;
    private int yTile;
    private int zTile;
    private int inTile;
    private boolean inGround;
    public EntityHuman owner;
    private Entity plantedHook;
    private int ticksInGround;
    private int ticksInAir;
    private int ticksCatchable;
    private int field_6388_l;
    private double field_6387_m;
    private double field_6386_n;
    private double field_6385_o;
    private double field_6384_p;
    private double field_6383_q;
    private double velocityX;
    private double velocityY;
    private double velocityZ;
    private double startPosX;
    private double startPosZ;

    public ASEntityGrapplingHook(World var1)
    {
        super(var1);
        this.xTile = -1;
        this.yTile = -1;
        this.zTile = -1;
        this.inTile = 0;
        this.inGround = false;
        this.ticksInAir = 0;
        this.ticksCatchable = 0;
        this.b(0.25F, 0.25F);
        this.cd = true;
        this.plantedHook = null;
    }

    public ASEntityGrapplingHook(World var1, double var2, double var4, double var6)
    {
        this(var1);
        this.setPosition(var2, var4, var6);
    }

    public ASEntityGrapplingHook(World var1, EntityHuman var2)
    {
        this(var1);
        this.owner = var2;
        mod_ASGrapplingHook.grapplingHooks.put(var2, this);
        this.setPositionRotation(var2.locX, var2.locY + 1.62D - (double)var2.height, var2.locZ, var2.yaw, var2.pitch);
        this.locX -= (double)(MathHelper.cos(this.yaw / 180.0F * (float)Math.PI) * 0.16F);
        this.locY -= 0.10000000149011612D;
        this.locZ -= (double)(MathHelper.sin(this.yaw / 180.0F * (float)Math.PI) * 0.16F);
        this.setPosition(this.locX, this.locY, this.locZ);
        this.height = 0.0F;
        float var3 = 0.4F;
        this.motX = (double)(-MathHelper.sin(this.yaw / 180.0F * (float)Math.PI) * MathHelper.cos(this.pitch / 180.0F * (float)Math.PI) * var3);
        this.motZ = (double)(MathHelper.cos(this.yaw / 180.0F * (float)Math.PI) * MathHelper.cos(this.pitch / 180.0F * (float)Math.PI) * var3);
        this.motY = (double)(-MathHelper.sin(this.pitch / 180.0F * (float)Math.PI) * var3);
        this.func_4042_a(this.motX, this.motY, this.motZ, 1.5F, 1.0F);
        this.startPosX = this.owner.locX;
        this.startPosZ = this.owner.locZ;
    }

    protected void b() {}

    public boolean isInRangeToRenderDist(double var1)
    {
        return true;
    }

    public void func_4042_a(double var1, double var3, double var5, float var7, float var8)
    {
        float var9 = MathHelper.sqrt(var1 * var1 + var3 * var3 + var5 * var5);
        var1 /= (double)var9;
        var3 /= (double)var9;
        var5 /= (double)var9;
        var1 += this.random.nextGaussian() * 0.007499999832361937D * (double)var8;
        var3 += this.random.nextGaussian() * 0.007499999832361937D * (double)var8;
        var5 += this.random.nextGaussian() * 0.007499999832361937D * (double)var8;
        var1 *= (double)var7;
        var3 *= (double)var7;
        var5 *= (double)var7;
        this.motX = var1;
        this.motY = var3;
        this.motZ = var5;
        float var10 = MathHelper.sqrt(var1 * var1 + var5 * var5);
        this.lastYaw = this.yaw = (float)(Math.atan2(var1, var5) * 180.0D / Math.PI);
        this.lastPitch = this.pitch = (float)(Math.atan2(var3, (double)var10) * 180.0D / Math.PI);
        this.ticksInGround = 0;
    }

    public void setPositionAndRotation2(double var1, double var3, double var5, float var7, float var8, int var9)
    {
        this.field_6387_m = var1;
        this.field_6386_n = var3;
        this.field_6385_o = var5;
        this.field_6384_p = (double)var7;
        this.field_6383_q = (double)var8;
        this.field_6388_l = var9;
        this.motX = this.velocityX;
        this.motY = this.velocityY;
        this.motZ = this.velocityZ;
    }

    public void setVelocity(double var1, double var3, double var5)
    {
        this.velocityX = this.motX = var1;
        this.velocityY = this.motY = var3;
        this.velocityZ = this.motZ = var5;
    }

    /**
     * Called to update the entity's position/logic.
     */
    public void G_()
    {
        super.G_();

        if (this.field_6388_l > 0)
        {
            double var25 = this.locX + (this.field_6387_m - this.locX) / (double)this.field_6388_l;
            double var26 = this.locY + (this.field_6386_n - this.locY) / (double)this.field_6388_l;
            double var27 = this.locZ + (this.field_6385_o - this.locZ) / (double)this.field_6388_l;
            double var7;

            for (var7 = this.field_6384_p - (double)this.yaw; var7 < -180.0D; var7 += 360.0D)
            {
                ;
            }

            while (var7 >= 180.0D)
            {
                var7 -= 360.0D;
            }

            this.yaw = (float)((double)this.yaw + var7 / (double)this.field_6388_l);
            this.pitch = (float)((double)this.pitch + (this.field_6383_q - (double)this.pitch) / (double)this.field_6388_l);
            --this.field_6388_l;
            this.setPosition(var25, var26, var27);
            this.c(this.yaw, this.pitch);
        }
        else
        {
            if (!this.world.isStatic)
            {
                if (this.owner == null)
                {
                    this.die();
                    return;
                }

                ItemStack var1 = this.owner.T();

                if (this.owner.dead || var1 == null || var1.getItem() != mod_ASGrapplingHook.itemGrapplingHook || this.j(this.owner) > 1024.0D)
                {
                    this.die();
                    return;
                }

                if (this.plantedHook != null)
                {
                    if (!this.plantedHook.dead)
                    {
                        this.locX = this.plantedHook.locX;
                        this.locY = this.plantedHook.boundingBox.b + (double)this.plantedHook.length * 0.8D;
                        this.locZ = this.plantedHook.locZ;
                        return;
                    }

                    this.plantedHook = null;
                }
            }

            if (this.inGround)
            {
                int var23 = this.world.getTypeId(this.xTile, this.yTile, this.zTile);

                if (var23 == this.inTile)
                {
                    ++this.ticksInGround;

                    if (this.ticksInGround == 1200)
                    {
                        this.die();
                    }

                    return;
                }

                this.inGround = false;
                this.motX *= (double)(this.random.nextFloat() * 0.2F);
                this.motY *= (double)(this.random.nextFloat() * 0.2F);
                this.motZ *= (double)(this.random.nextFloat() * 0.2F);
                this.ticksInGround = 0;
                this.ticksInAir = 0;
            }
            else
            {
                ++this.ticksInAir;
            }

            Vec3D var24 = Vec3D.create(this.locX, this.locY, this.locZ);
            Vec3D var2 = Vec3D.create(this.locX + this.motX, this.locY + this.motY, this.locZ + this.motZ);
            MovingObjectPosition var3 = this.world.a(var24, var2);
            var24 = Vec3D.create(this.locX, this.locY, this.locZ);
            var2 = Vec3D.create(this.locX + this.motX, this.locY + this.motY, this.locZ + this.motZ);

            if (var3 != null)
            {
                var2 = Vec3D.create(var3.pos.a, var3.pos.b, var3.pos.c);
            }

            Entity var4 = null;
            List var5 = this.world.getEntities(this, this.boundingBox.a(this.motX, this.motY, this.motZ).grow(1.0D, 1.0D, 1.0D));
            double var6 = 0.0D;
            double var13;

            for (int var8 = 0; var8 < var5.size(); ++var8)
            {
                Entity var9 = (Entity)var5.get(var8);

                if (var9.o_() && (var9 != this.owner || this.ticksInAir >= 5))
                {
                    float var10 = 0.3F;
                    AxisAlignedBB var11 = var9.boundingBox.grow((double)var10, (double)var10, (double)var10);
                    MovingObjectPosition var12 = var11.a(var24, var2);

                    if (var12 != null)
                    {
                        var13 = var24.b(var12.pos);

                        if (var13 < var6 || var6 == 0.0D)
                        {
                            var4 = var9;
                            var6 = var13;
                        }
                    }
                }
            }

            if (var4 != null)
            {
                var3 = new MovingObjectPosition(var4);
            }

            if (var3 != null)
            {
                if (var3.entity != null)
                {
                    if (var3.entity.damageEntity(DamageSource.playerAttack(this.owner), 0))
                    {
                        this.plantedHook = var3.entity;
                    }
                }
                else
                {
                    double var28 = this.motX;
                    double var33 = this.motZ;
                    this.xTile = var3.b;
                    this.yTile = var3.c;
                    this.zTile = var3.d;
                    this.inTile = this.world.getTypeId(this.xTile, this.yTile, this.zTile);
                    this.motX = (double)((float)(var3.pos.a - this.locX));
                    this.motY = (double)((float)(var3.pos.b - this.locY));
                    this.motZ = (double)((float)(var3.pos.c - this.locZ));
                    float var34 = MathHelper.sqrt(this.motX * this.motX + this.motY * this.motY + this.motZ * this.motZ);
                    this.locX -= this.motX / (double)var34 * 0.05000000074505806D;
                    this.locY -= this.motY / (double)var34 * 0.05000000074505806D;
                    this.locZ -= this.motZ / (double)var34 * 0.05000000074505806D;

                    if (var3.pos.b - (double)this.yTile == 1.0D && (this.world.getTypeId(this.xTile, this.yTile + 1, this.zTile) == 0 || this.world.getTypeId(this.xTile, this.yTile + 1, this.zTile) == Block.SNOW.id) && this.yTile + 1 < 128)
                    {
                        if (var28 == 0.0D || var33 == 0.0D)
                        {
                            var28 = this.locX - this.startPosX;
                            var33 = this.locZ - this.startPosZ;
                        }

                        byte var36 = (byte)(var28 <= 0.0D ? -1 : 1);
                        byte var14 = (byte)(var33 <= 0.0D ? -1 : 1);
                        boolean var15 = this.world.getTypeId(this.xTile - var36, this.yTile, this.zTile) == 0 || this.world.getTypeId(this.xTile - var36, this.yTile, this.zTile) == Block.SNOW.id && this.world.getTypeId(this.xTile - var36, this.yTile + 1, this.zTile) == 0;
                        boolean var16 = this.world.getTypeId(this.xTile, this.yTile, this.zTile - var14) == 0 || this.world.getTypeId(this.xTile, this.yTile, this.zTile - var14) == Block.SNOW.id && this.world.getTypeId(this.xTile, this.yTile + 1, this.zTile - var14) == 0;
                        int var17 = this.xTile;
                        int var18 = this.yTile;
                        int var19 = this.zTile;
                        byte var20 = 0;
                        boolean var21 = false;

                        if ((!var15 || var16) && (!var15 || !var16 || Math.abs(var28) <= Math.abs(var33)))
                        {
                            if (!var15 && var16 || var15 && var16 && Math.abs(var28) <= Math.abs(var33))
                            {
                                var19 -= var14;
                                var21 = true;

                                if (var14 > 0)
                                {
                                    var20 = 1;
                                }
                                else
                                {
                                    var20 = 4;
                                }
                            }
                        }
                        else
                        {
                            var17 -= var36;
                            var21 = true;

                            if (var36 > 0)
                            {
                                var20 = 8;
                            }
                            else
                            {
                                var20 = 2;
                            }
                        }

                        if (var21)
                        {
                            this.world.setTypeId(this.xTile, this.yTile + 1, this.zTile, mod_ASGrapplingHook.blockGrapplingHook.id);
                            this.world.setData(this.xTile, this.yTile + 1, this.zTile, var20);
                            this.world.setTypeId(var17, var18, var19, mod_ASGrapplingHook.blockRope.id);
                            this.world.setData(var17, var18, var19, var20);
                            ASTileEntityRope var22 = new ASTileEntityRope(this.world, var17, var18, var19, 32);
                            mod_Rope.addRopeToArray(var22);

                            if (this.owner != null)
                            {
                                this.owner.U();
                            }

                            this.die();
                        }
                        else
                        {
                            this.inGround = true;
                        }
                    }
                }
            }

            if (!this.inGround)
            {
                this.move(this.motX, this.motY, this.motZ);
                float var30 = MathHelper.sqrt(this.motX * this.motX + this.motZ * this.motZ);
                this.yaw = (float)(Math.atan2(this.motX, this.motZ) * 180.0D / Math.PI);

                for (this.pitch = (float)(Math.atan2(this.motY, (double)var30) * 180.0D / Math.PI); this.pitch - this.lastPitch < -180.0F; this.lastPitch -= 360.0F)
                {
                    ;
                }

                while (this.pitch - this.lastPitch >= 180.0F)
                {
                    this.lastPitch += 360.0F;
                }

                while (this.yaw - this.lastYaw < -180.0F)
                {
                    this.lastYaw -= 360.0F;
                }

                while (this.yaw - this.lastYaw >= 180.0F)
                {
                    this.lastYaw += 360.0F;
                }

                this.pitch = this.lastPitch + (this.pitch - this.lastPitch) * 0.2F;
                this.yaw = this.lastYaw + (this.yaw - this.lastYaw) * 0.2F;
                float var29 = 0.92F;

                if (this.onGround || this.positionChanged)
                {
                    var29 = 0.5F;
                }

                byte var31 = 5;
                double var32 = 0.0D;

                for (int var35 = 0; var35 < var31; ++var35)
                {
                    double var38 = this.boundingBox.b + (this.boundingBox.e - this.boundingBox.b) * (double)(var35 + 0) / (double)var31 - 0.125D + 0.125D;
                    double var42 = this.boundingBox.b + (this.boundingBox.e - this.boundingBox.b) * (double)(var35 + 1) / (double)var31 - 0.125D + 0.125D;
                    AxisAlignedBB.b(this.boundingBox.a, var38, this.boundingBox.c, this.boundingBox.d, var42, this.boundingBox.f);
                }

                if (var32 > 0.0D)
                {
                    if (this.ticksCatchable > 0)
                    {
                        --this.ticksCatchable;
                    }
                    else if (this.random.nextInt(500) == 0)
                    {
                        this.ticksCatchable = this.random.nextInt(30) + 10;
                        this.motY -= 0.20000000298023224D;
                        this.world.makeSound(this, "random.splash", 0.25F, 1.0F + (this.random.nextFloat() - this.random.nextFloat()) * 0.4F);
                        float var39 = (float)MathHelper.floor(this.boundingBox.b);
                        float var37;
                        int var40;
                        float var41;

                        for (var40 = 0; (float)var40 < 1.0F + this.width * 20.0F; ++var40)
                        {
                            var37 = (this.random.nextFloat() * 2.0F - 1.0F) * this.width;
                            var41 = (this.random.nextFloat() * 2.0F - 1.0F) * this.width;
                            this.world.a("bubble", this.locX + (double)var37, (double)(var39 + 1.0F), this.locZ + (double)var41, this.motX, this.motY - (double)(this.random.nextFloat() * 0.2F), this.motZ);
                        }

                        for (var40 = 0; (float)var40 < 1.0F + this.width * 20.0F; ++var40)
                        {
                            var37 = (this.random.nextFloat() * 2.0F - 1.0F) * this.width;
                            var41 = (this.random.nextFloat() * 2.0F - 1.0F) * this.width;
                            this.world.a("splash", this.locX + (double)var37, (double)(var39 + 1.0F), this.locZ + (double)var41, this.motX, this.motY, this.motZ);
                        }
                    }
                }

                if (this.ticksCatchable > 0)
                {
                    this.motY -= (double)(this.random.nextFloat() * this.random.nextFloat() * this.random.nextFloat()) * 0.2D;
                }

                var13 = var32 * 2.0D - 1.0D;
                this.motY += 0.03999999910593033D * var13;

                if (var32 > 0.0D)
                {
                    var29 = (float)((double)var29 * 0.9D);
                    this.motY *= 0.8D;
                }

                this.motX *= (double)var29;
                this.motY *= (double)var29;
                this.motZ *= (double)var29;
                this.setPosition(this.locX, this.locY, this.locZ);
            }
        }
    }

    public int recallHook()
    {
        byte var1 = 0;

        if (this.plantedHook != null)
        {
            double var2 = this.owner.locX - this.locX;
            double var4 = this.owner.locY - this.locY;
            double var6 = this.owner.locZ - this.locZ;
            double var8 = (double)MathHelper.sqrt(var2 * var2 + var4 * var4 + var6 * var6);
            double var10 = 0.1D;
            this.plantedHook.motX += var2 * var10;
            this.plantedHook.motY += var4 * var10 + (double)MathHelper.sqrt(var8) * 0.08D;
            this.plantedHook.motZ += var6 * var10;
            var1 = 3;
        }

        if (this.inGround)
        {
            var1 = 2;
        }

        this.die();
        return var1;
    }

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void b(NBTTagCompound var1)
    {
        var1.setShort("xTile", (short)this.xTile);
        var1.setShort("yTile", (short)this.yTile);
        var1.setShort("zTile", (short)this.zTile);
        var1.setByte("inTile", (byte)this.inTile);
        var1.setByte("inGround", (byte)(this.inGround ? 1 : 0));
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void a(NBTTagCompound var1)
    {
        this.xTile = var1.getShort("xTile");
        this.yTile = var1.getShort("yTile");
        this.zTile = var1.getShort("zTile");
        this.inTile = var1.getByte("inTile") & 255;
        this.inGround = var1.getByte("inGround") == 1;
    }

    public float getShadowSize()
    {
        return 0.0F;
    }

    /**
     * Will get destroyed next tick
     */
    public void die()
    {
        super.die();
        mod_ASGrapplingHook.grapplingHooks.remove(this.owner);
        this.owner = null;
    }
}
