package net.minecraft.server;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class EntityArrow303Confusion extends EntityArrow303
{
    public static double radius = 6.0D;

    public EntityArrow303Confusion(World var1)
    {
        super(var1);
    }

    public EntityArrow303Confusion(World var1, EntityLiving var2)
    {
        super(var1, var2);
    }

    public EntityArrow303Confusion(World var1, double var2, double var4, double var6)
    {
        super(var1, var2, var4, var6);
    }

    public void b()
    {
        super.b();
        this.name = "ConfusionArrow";
        this.craftingResults = 1;
        this.itemId = 3543 + Block.byId.length;
        this.tip = Block.SAND;
        this.spriteFile = "/arrows/confusionarrow.png";
        this.item = new ItemStack(this.itemId, 1, 0);
    }

    public boolean onHitBlock()
    {
        this.confuse(this);
        return true;
    }

    public boolean onHitTarget(Entity var1)
    {
        this.confuse(var1);
        return true;
    }

    public void confuse(Entity var1)
    {
        List var2 = this.world.getEntities(this, var1.boundingBox.grow(radius, radius, radius));
        ArrayList var3 = new ArrayList();
        Iterator var4 = var2.iterator();

        while (var4.hasNext())
        {
            Entity var5 = (Entity)var4.next();

            if (var5 instanceof EntityCreature && var5 != this.shooter)
            {
                var3.add((EntityCreature)var5);
            }
        }

        if (var3.size() >= 2)
        {
            for (int var8 = 0; var8 < var3.size(); ++var8)
            {
                EntityCreature var6 = (EntityCreature)var3.get(var8);
                EntityCreature var7 = (EntityCreature)var3.get(var8 != 0 ? var8 - 1 : var3.size() - 1);
                var6.damageEntity(DamageSource.mobAttack(var7), 0);
                var7.target = var6;
            }

            this.die();
        }
    }

    public void tickFlying() {}
}
