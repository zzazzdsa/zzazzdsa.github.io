package net.minecraft.server;

public class EntityArrow303Slime extends EntityArrow303
{
    public void b()
    {
        super.b();
        this.name = "SlimeArrow";
        this.craftingResults = 1;
        this.itemId = 134 + Block.byId.length;
        this.tip = Item.SLIME_BALL;
        this.spriteFile = "/arrows/slimearrow.png";
        this.item = new ItemStack(this.itemId, 1, 0);
    }

    public EntityArrow303Slime(World var1)
    {
        super(var1);
    }

    public EntityArrow303Slime(World var1, EntityLiving var2)
    {
        super(var1, var2);
    }

    public EntityArrow303Slime(World var1, double var2, double var4, double var6)
    {
        super(var1, var2, var4, var6);
    }

    public EntityLiving makeMob()
    {
        EntitySlime var1 = new EntitySlime(this.world);
        var1.heal(1 << this.random.nextInt(4));
        return var1;
    }

    public boolean onHitBlock()
    {
        EntityLiving var1 = this.makeMob();
        var1.setPositionRotation(this.locX, this.locY, this.locZ, this.yaw, this.pitch);

        if (this.world.addEntity(var1))
        {
            var1.aB();
            this.die();
        }

        return true;
    }

    public boolean onHitTarget(Entity var1)
    {
        EntityLiving var2 = this.makeMob();
        var2.setPositionRotation(var1.locX, var1.locY, var1.locZ, var1.yaw, var1.pitch);

        if (this.world.addEntity(var2))
        {
            var2.aB();

            if (!(var1 instanceof EntityHuman))
            {
                var1.die();
            }
        }

        return true;
    }

    public void tickFlying() {}
}
