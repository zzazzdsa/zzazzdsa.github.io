package net.minecraft.server;

public class ItemBow303 extends Item
{
    public static float precisionBase = 1.5F;

    public ItemBow303(int var1)
    {
        super(var1);
        this.maxStackSize = 1;
    }

    public void a(ItemStack var1, World var2, EntityHuman var3, int var4)
    {
        mod_Arrows303.inst.selectArrow(var2, var3);
        EntityArrow303 var5 = mod_Arrows303.inst.selectedArrow(var3);

        if (var5 != null)
        {
            int var6 = this.c(var1) - var4;
            float var7 = (float)var6 / 20.0F;
            var7 = (var7 * var7 + var7 * 2.0F) / 3.0F;

            if ((double)var7 >= 0.1D)
            {
                if (var7 > 1.0F)
                {
                    var7 = 1.0F;
                }

                EntityArrow var8 = new EntityArrow(var2, var3, var7 * 2.0F);

                if (var7 == 1.0F)
                {
                    var8.d = true;
                }

                int var9 = mod_Arrows303.inst.burstSize;

                do
                {
                    if (--var3.inventory.items[mod_Arrows303.inst.selectedSlot(var3)].count <= 0)
                    {
                        var3.inventory.items[mod_Arrows303.inst.selectedSlot(var3)] = null;
                        mod_Arrows303.inst.selectArrow(var2, var3);
                    }

                    var2.makeSound(var3, "random.bow", 1.0F, 1.0F / (c.nextFloat() * 0.4F + 1.2F) + var7 * 0.5F);
                    EntityArrow303 var10 = var5.newArrow(var2, var3);
                    this.setPrecision(var10, mod_Arrows303.inst.burstSize, var7 * 1.5F);

                    if (!var2.isStatic)
                    {
                        var2.addEntity(var10);

                        if (var7 == 1.0F)
                        {
                            var10.arrowCritical = true;
                        }
                    }

                    if (var5 != mod_Arrows303.inst.selectedArrow(var3))
                    {
                        break;
                    }

                    --var9;
                }
                while (var9 > 0);

                mod_Arrows303.inst.burstSize = 1;
            }
        }
    }

    public ItemStack b(ItemStack var1, World var2, EntityHuman var3)
    {
        return var1;
    }

    /**
     * How long it takes to use or consume an item
     */
    public int c(ItemStack var1)
    {
        return 72000;
    }

    /**
     * returns the action that specifies what animation to play when the items is being used
     */
    public EnumAnimation d(ItemStack var1)
    {
        return EnumAnimation.d;
    }

    /**
     * Called whenever this item is equipped and the right mouse button is pressed. Args: itemStack, world, entityPlayer
     */
    public ItemStack a(ItemStack var1, World var2, EntityHuman var3)
    {
        var3.a(var1, this.c(var1));
        return var1;
    }

    public void setPrecision(EntityArrow303 var1, int var2, float var3)
    {
        float var4 = (float)var2 * precisionBase;
        float var5 = var1.speed * var3;
        var1.setArrowHeading(var1.motX, var1.motY, var1.motZ, var5, var4);
    }
}
