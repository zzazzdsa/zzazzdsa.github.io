package net.minecraft.server;

public class ASItemGrapplingHook extends Item
{
    public ASItemGrapplingHook(int var1)
    {
        super(var1);
        this.maxStackSize = 1;
    }

    public boolean isFull3D()
    {
        return true;
    }

    public boolean shouldRotateAroundWhenRendering()
    {
        return true;
    }

    /**
     * Called whenever this item is equipped and the right mouse button is pressed. Args: itemStack, world, entityPlayer
     */
    public ItemStack a(ItemStack var1, World var2, EntityHuman var3)
    {
        if (mod_ASGrapplingHook.grapplingHooks.get(var3) != null)
        {
            int var4 = ((ASEntityGrapplingHook)mod_ASGrapplingHook.grapplingHooks.get(var3)).recallHook();
            var3.D();
        }
        else
        {
            var2.makeSound(var3, "random.hurt", 1.0F, 1.0F / (c.nextFloat() * 0.1F + 0.95F));

            if (!var2.isStatic)
            {
                var2.addEntity(new ASEntityGrapplingHook(var2, var3));
            }

            var3.D();
        }

        return var1;
    }
}
