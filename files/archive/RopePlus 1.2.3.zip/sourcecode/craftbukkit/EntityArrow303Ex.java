package net.minecraft.server;

public class EntityArrow303Ex extends EntityArrow303
{
    public void subscreen() {}

    public void setupConfig() {}

    public void b()
    {
        super.b();
        this.name = "ExArrow";
        this.craftingResults = 1;
        this.itemId = 128 + Block.byId.length;
        this.tip = Item.SULPHUR;
        this.item = new ItemStack(this.itemId, 1, 0);
        this.spriteFile = "/arrows/exarrow.png";
    }

    public EntityArrow303Ex(World var1)
    {
        super(var1);
    }

    public EntityArrow303Ex(World var1, EntityLiving var2)
    {
        super(var1, var2);
    }

    public EntityArrow303Ex(World var1, double var2, double var4, double var6)
    {
        super(var1, var2, var4, var6);
    }

    public boolean onHit()
    {
        this.world.explode((Entity)(this.shooter != null ? this.shooter : this), this.locX, this.locY, this.locZ, 2.0F);
        this.die();
        return true;
    }

    public void tickFlying() {}
}
