package net.minecraft.server;

import java.util.List;

public class EntityArrow303Ice extends EntityArrow303
{
    public EntityLiving victim;
    public float freezeFactor;
    public int freezeTimer;

    public void subscreen() {}

    public void setupConfig() {}

    public void b()
    {
        super.b();
        this.name = "IceArrow";
        this.craftingResults = 1;
        this.itemId = 130 + Block.byId.length;
        this.tip = Item.SNOW_BALL;
        this.item = new ItemStack(this.itemId, 1, 0);
        this.spriteFile = "/arrows/icearrow.png";
    }

    public EntityArrow303Ice(World var1)
    {
        super(var1);
    }

    public EntityArrow303Ice(World var1, double var2, double var4, double var6)
    {
        super(var1, var2, var4, var6);
    }

    public EntityArrow303Ice(World var1, EntityLiving var2)
    {
        super(var1, var2);
    }

    public boolean onHitBlock()
    {
        if (this.victim == null)
        {
            this.die();
            return true;
        }
        else
        {
            return false;
        }
    }

    public boolean onHitTarget(Entity var1)
    {
        if (var1 instanceof EntityLiving && this.victim == null)
        {
            List var2 = this.world.getEntities(this, var1.boundingBox.grow(3.0D, 3.0D, 3.0D));

            for (int var3 = 0; var3 < var2.size(); ++var3)
            {
                Entity var4 = (Entity)var2.get(var3);

                if (var4 instanceof EntityArrow303Ice)
                {
                    EntityArrow303Ice var5 = (EntityArrow303Ice)var4;

                    if (var5.victim == var1)
                    {
                        var5.freezeTimer += this.getFreezeTimer((EntityLiving)var1);
                        var5.dead = false;
                        var1.damageEntity(DamageSource.playerAttack((EntityHuman)this.shooter), 4);
                        this.die();
                        return false;
                    }
                }
            }

            var1.damageEntity(DamageSource.playerAttack((EntityHuman)this.shooter), 4);
            this.freezeMob((EntityLiving)var1);
            return false;
        }
        else
        {
            return false;
        }
    }

    public int getFreezeTimer(EntityLiving var1)
    {
        return var1 instanceof EntityHuman ? 5 : 200;
    }

    public void freezeMob(EntityLiving var1)
    {
        this.victim = var1;
        this.freezeFactor = var1 instanceof EntityHuman ? 0.5F : 0.1F;
        this.freezeTimer = this.getFreezeTimer(var1);
        this.motX = this.motY = this.motZ = 0.0D;
    }

    public void unfreezeMob()
    {
        this.victim = null;
    }

    /**
     * Will get destroyed next tick
     */
    public void die()
    {
        if (this.victim != null)
        {
            this.unfreezeMob();
        }

        super.die();
    }

    /**
     * Called to update the entity's position/logic.
     */
    public void G_()
    {
        super.G_();

        if (this.victim != null)
        {
            if (this.victim.dead || this.victim.deathTicks > 0)
            {
                this.die();
                return;
            }

            this.dead = false;
            this.inGround = false;
            this.locX = this.victim.locX;
            this.locY = this.victim.boundingBox.b + (double)this.victim.length * 0.5D;
            this.locZ = this.victim.locZ;
            this.setPosition(this.locX, this.locY, this.locZ);
            this.victim.motX *= (double)this.freezeFactor;
            this.victim.motY *= (double)this.freezeFactor;
            this.victim.motZ *= (double)this.freezeFactor;
            --this.freezeTimer;

            if (this.freezeTimer <= 0)
            {
                this.die();
            }
        }
    }

    public boolean onHit()
    {
        if (this.victim != null)
        {
            return false;
        }
        else
        {
            int var1 = MathHelper.floor(this.locX);
            int var2 = MathHelper.floor(this.locY);
            int var3 = MathHelper.floor(this.locZ);

            for (int var4 = var1 - 1; var4 <= var1 + 1; ++var4)
            {
                for (int var5 = var2 - 1; var5 <= var2 + 1; ++var5)
                {
                    for (int var6 = var3 - 1; var6 <= var3 + 1; ++var6)
                    {
                        if (this.world.getMaterial(var4, var5, var6) == Material.WATER && this.world.getData(var4, var5, var6) == 0)
                        {
                            this.world.setTypeId(var4, var5, var6, 79);
                        }
                        else if (this.world.getMaterial(var4, var5, var6) == Material.LAVA && this.world.getData(var4, var5, var6) == 0)
                        {
                            this.world.setTypeId(var4, var5, var6, 49);
                        }
                        else if (this.world.getTypeId(var4, var5, var6) == 51)
                        {
                            this.world.setTypeId(var4, var5, var6, 0);
                        }
                        else if (this.world.getTypeId(var4, var5, var6) == 50)
                        {
                            Block.byId[50].dropNaturally(this.world, var4, var5, var6, this.world.getData(var4, var5, var6), 1.0F, 0);
                            this.world.setTypeId(var4, var5, var6, 0);
                            Block.byId[50].wasExploded(this.world, var4, var5, var6);
                        }
                    }
                }
            }

            return true;
        }
    }

    public void tickFlying() {}
}
