package net.minecraft.server;

public class ASTileEntityRope
{
    private int delay;
    private World world;
    private int ix;
    private int iy;
    private int iz;
    private int remainrope;

    public ASTileEntityRope(World var1, int var2, int var3, int var4, int var5)
    {
        this.world = var1;
        this.ix = var2;
        this.iy = var3;
        this.iz = var4;
        this.delay = 20;
        this.remainrope = var5;
    }

    public boolean OnUpdate()
    {
        if (this.delay < 0)
        {
            return true;
        }
        else
        {
            --this.delay;

            if (this.delay != 0)
            {
                return false;
            }
            else
            {
                if (this.world.getTypeId(this.ix, this.iy - 1, this.iz) == 0 || this.world.getTypeId(this.ix, this.iy - 1, this.iz) == Block.SNOW.id)
                {
                    --this.remainrope;

                    if (this.remainrope <= 0)
                    {
                        return true;
                    }

                    this.world.setTypeId(this.ix, this.iy - 1, this.iz, mod_ASGrapplingHook.blockRope.id);
                    this.world.setData(this.ix, this.iy - 1, this.iz, this.world.getData(this.ix, this.iy, this.iz));
                    ASTileEntityRope var1 = new ASTileEntityRope(this.world, this.ix, this.iy - 1, this.iz, this.remainrope);
                    mod_Rope.addRopeToArray(var1);
                }

                return true;
            }
        }
    }
}
