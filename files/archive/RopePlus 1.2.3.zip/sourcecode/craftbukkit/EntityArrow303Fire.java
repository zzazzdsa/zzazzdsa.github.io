package net.minecraft.server;

public class EntityArrow303Fire extends EntityArrow303
{
    public EntityArrow303Fire(World var1)
    {
        super(var1);
    }

    public EntityArrow303Fire(World var1, EntityLiving var2)
    {
        super(var1, var2);
    }

    public EntityArrow303Fire(World var1, double var2, double var4, double var6)
    {
        super(var1, var2, var4, var6);
    }

    public void b()
    {
        super.b();
        this.name = "FiArrow";
        this.craftingResults = 1;
        this.itemId = 129 + Block.byId.length;
        this.tip = Item.COAL;
        this.item = new ItemStack(this.itemId, 1, 0);
        this.spriteFile = "/arrows/fiarrow.png";
    }

    public boolean onHit()
    {
        if (this.tryToPlaceBlock(51))
        {
            this.die();
        }

        return true;
    }

    public boolean onHitTarget(Entity var1)
    {
        var1.setOnFire(15);
        return true;
    }

    public void tickFlying() {}
}
