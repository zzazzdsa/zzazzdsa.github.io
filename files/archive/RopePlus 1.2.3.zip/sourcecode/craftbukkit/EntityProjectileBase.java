package net.minecraft.server;

import java.util.List;

public abstract class EntityProjectileBase extends Entity
{
    public float speed;
    public float slowdown;
    public float curvature;
    public float precision;
    public float hitBox;
    public int dmg;
    public ItemStack item;
    public int ttlInGround;
    public int xTile;
    public int yTile;
    public int zTile;
    public int inTile;
    public int inData;
    public boolean inGround;
    public int arrowShake;
    public EntityLiving shooter;
    public int ticksInGround;
    public int ticksFlying;
    public boolean shotByPlayer;
    public boolean arrowCritical;

    public EntityProjectileBase(World var1)
    {
        super(var1);
        this.arrowCritical = false;
    }

    public EntityProjectileBase(World var1, double var2, double var4, double var6)
    {
        this(var1);
        this.setPosition(var2, var4, var6);
    }

    public EntityProjectileBase(World var1, EntityLiving var2)
    {
        this(var1);
        this.shooter = var2;
        this.shotByPlayer = var2 instanceof EntityHuman;
        this.setPositionRotation(var2.locX, var2.locY + (double)var2.getHeadHeight(), var2.locZ, var2.yaw, var2.pitch);
        this.locX -= (double)(MathHelper.cos(this.yaw / 180.0F * (float)Math.PI) * 0.16F);
        this.locY -= 0.10000000149011612D;
        this.locZ -= (double)(MathHelper.sin(this.yaw / 180.0F * (float)Math.PI) * 0.16F);
        this.setPosition(this.locX, this.locY, this.locZ);
        this.motX = (double)(-MathHelper.sin(this.yaw / 180.0F * (float)Math.PI) * MathHelper.cos(this.pitch / 180.0F * (float)Math.PI));
        this.motZ = (double)(MathHelper.cos(this.yaw / 180.0F * (float)Math.PI) * MathHelper.cos(this.pitch / 180.0F * (float)Math.PI));
        this.motY = (double)(-MathHelper.sin(this.pitch / 180.0F * (float)Math.PI));
        this.setArrowHeading(this.motX, this.motY, this.motZ, this.speed, this.precision);
    }

    protected void b()
    {
        this.xTile = -1;
        this.yTile = -1;
        this.zTile = -1;
        this.inTile = 0;
        this.inGround = false;
        this.arrowShake = 0;
        this.ticksFlying = 0;
        this.b(0.5F, 0.5F);
        this.height = 0.0F;
        this.hitBox = 0.3F;
        this.speed = 1.0F;
        this.slowdown = 0.99F;
        this.curvature = 0.03F;
        this.dmg = 4;
        this.precision = 1.0F;
        this.ttlInGround = 1200;
        this.item = null;
    }

    /**
     * Will get destroyed next tick
     */
    public void die()
    {
        this.shooter = null;
        super.die();
    }

    public void setArrowHeading(double var1, double var3, double var5, float var7, float var8)
    {
        float var9 = MathHelper.sqrt(var1 * var1 + var3 * var3 + var5 * var5);
        var1 /= (double)var9;
        var3 /= (double)var9;
        var5 /= (double)var9;
        var1 += this.random.nextGaussian() * 0.007499999832361937D * (double)var8;
        var3 += this.random.nextGaussian() * 0.007499999832361937D * (double)var8;
        var5 += this.random.nextGaussian() * 0.007499999832361937D * (double)var8;
        var1 *= (double)var7;
        var3 *= (double)var7;
        var5 *= (double)var7;
        this.motX = var1;
        this.motY = var3;
        this.motZ = var5;
        float var10 = MathHelper.sqrt(var1 * var1 + var5 * var5);
        this.lastYaw = this.yaw = (float)(Math.atan2(var1, var5) * 180.0D / Math.PI);
        this.lastPitch = this.pitch = (float)(Math.atan2(var3, (double)var10) * 180.0D / Math.PI);
        this.ticksInGround = 0;
    }

    public void setVelocity(double var1, double var3, double var5)
    {
        this.motX = var1;
        this.motY = var3;
        this.motZ = var5;

        if (this.lastPitch == 0.0F && this.lastYaw == 0.0F)
        {
            float var7 = MathHelper.sqrt(var1 * var1 + var5 * var5);
            this.lastYaw = this.yaw = (float)(Math.atan2(var1, var5) * 180.0D / Math.PI);
            this.lastPitch = this.pitch = (float)(Math.atan2(var3, (double)var7) * 180.0D / Math.PI);
        }
    }

    /**
     * Called to update the entity's position/logic.
     */
    public void G_()
    {
        super.G_();

        if (this.lastPitch == 0.0F && this.lastYaw == 0.0F)
        {
            float var1 = MathHelper.sqrt(this.motX * this.motX + this.motZ * this.motZ);
            this.lastYaw = this.yaw = (float)(Math.atan2(this.motX, this.motZ) * 180.0D / Math.PI);
            this.lastPitch = this.pitch = (float)(Math.atan2(this.motY, (double)var1) * 180.0D / Math.PI);
        }

        if (this.arrowShake > 0)
        {
            --this.arrowShake;
        }

        if (this.inGround)
        {
            int var15 = this.world.getTypeId(this.xTile, this.yTile, this.zTile);
            int var2 = this.world.getData(this.xTile, this.yTile, this.zTile);

            if (var15 == this.inTile && var2 == this.inData)
            {
                ++this.ticksInGround;
                this.tickInGround();

                if (this.ticksInGround == this.ttlInGround)
                {
                    this.die();
                }

                return;
            }

            this.inGround = false;
            this.motX *= (double)(this.random.nextFloat() * 0.2F);
            this.motY *= (double)(this.random.nextFloat() * 0.2F);
            this.motZ *= (double)(this.random.nextFloat() * 0.2F);
            this.ticksInGround = 0;
            this.ticksFlying = 0;
        }
        else
        {
            ++this.ticksFlying;
        }

        this.tickFlying();
        Vec3D var16 = Vec3D.create(this.locX, this.locY, this.locZ);
        Vec3D var17 = Vec3D.create(this.locX + this.motX, this.locY + this.motY, this.locZ + this.motZ);
        MovingObjectPosition var3 = this.world.a(var16, var17);
        var16 = Vec3D.create(this.locX, this.locY, this.locZ);
        var17 = Vec3D.create(this.locX + this.motX, this.locY + this.motY, this.locZ + this.motZ);

        if (var3 != null)
        {
            var17 = Vec3D.create(var3.pos.a, var3.pos.b, var3.pos.c);
        }

        Entity var4 = null;
        List var5 = this.world.getEntities(this, this.boundingBox.a(this.motX, this.motY, this.motZ).grow(1.0D, 1.0D, 1.0D));
        double var6 = 0.0D;
        int var8;

        for (var8 = 0; var8 < var5.size(); ++var8)
        {
            Entity var9 = (Entity)var5.get(var8);

            if (this.canBeShot(var9))
            {
                float var10 = this.hitBox;
                AxisAlignedBB var11 = var9.boundingBox.grow((double)var10, (double)var10, (double)var10);
                MovingObjectPosition var12 = var11.a(var16, var17);

                if (var12 != null)
                {
                    double var13 = var16.b(var12.pos);

                    if (var13 < var6 || var6 == 0.0D)
                    {
                        var4 = var9;
                        var6 = var13;
                    }
                }
            }
        }

        if (var4 != null)
        {
            var3 = new MovingObjectPosition(var4);
        }

        if (var3 != null && this.ticksFlying > 2 && this.onHit())
        {
            Entity var18 = var3.entity;

            if (var18 != null)
            {
                if (this.onHitTarget(var18))
                {
                    if (var18 instanceof EntityLiving && !(var18 instanceof EntityHuman))
                    {
                        ++((EntityLiving)var18).lastDamageByPlayerTime;
                    }

                    var18.damageEntity(DamageSource.playerAttack((EntityHuman)this.shooter), this.arrowCritical ? this.dmg * 2 : this.dmg);
                    this.die();
                }
            }
            else
            {
                this.xTile = var3.b;
                this.yTile = var3.c;
                this.zTile = var3.d;
                this.inTile = this.world.getTypeId(this.xTile, this.yTile, this.zTile);
                this.inData = this.world.getData(this.xTile, this.yTile, this.zTile);

                if (this.onHitBlock(var3))
                {
                    this.motX = (double)((float)(var3.pos.a - this.locX));
                    this.motY = (double)((float)(var3.pos.b - this.locY));
                    this.motZ = (double)((float)(var3.pos.c - this.locZ));
                    float var19 = MathHelper.sqrt(this.motX * this.motX + this.motY * this.motY + this.motZ * this.motZ);
                    this.locX -= this.motX / (double)var19 * 0.05000000074505806D;
                    this.locY -= this.motY / (double)var19 * 0.05000000074505806D;
                    this.locZ -= this.motZ / (double)var19 * 0.05000000074505806D;
                    this.inGround = true;
                    this.arrowShake = 7;
                    this.arrowCritical = false;
                }
                else
                {
                    this.inTile = 0;
                    this.inData = 0;
                }
            }
        }

        if (this.arrowCritical)
        {
            for (var8 = 0; var8 < 4; ++var8)
            {
                this.world.a("crit", this.locX + this.motX * (double)var8 / 4.0D, this.locY + this.motY * (double)var8 / 4.0D, this.locZ + this.motZ * (double)var8 / 4.0D, -this.motX, -this.motY + 0.2D, -this.motZ);
            }
        }

        this.locX += this.motX;
        this.locY += this.motY;
        this.locZ += this.motZ;
        this.handleMotionUpdate();
        float var20 = MathHelper.sqrt(this.motX * this.motX + this.motZ * this.motZ);
        this.yaw = (float)(Math.atan2(this.motX, this.motZ) * 180.0D / Math.PI);

        for (this.pitch = (float)(Math.atan2(this.motY, (double)var20) * 180.0D / Math.PI); this.pitch - this.lastPitch < -180.0F; this.lastPitch -= 360.0F)
        {
            ;
        }

        while (this.pitch - this.lastPitch >= 180.0F)
        {
            this.lastPitch += 360.0F;
        }

        while (this.yaw - this.lastYaw < -180.0F)
        {
            this.lastYaw -= 360.0F;
        }

        while (this.yaw - this.lastYaw >= 180.0F)
        {
            this.lastYaw += 360.0F;
        }

        this.pitch = this.lastPitch + (this.pitch - this.lastPitch) * 0.2F;
        this.yaw = this.lastYaw + (this.yaw - this.lastYaw) * 0.2F;
        this.setPosition(this.locX, this.locY, this.locZ);
    }

    public void handleMotionUpdate()
    {
        float var1 = this.slowdown;

        if (this.h_())
        {
            for (int var2 = 0; var2 < 4; ++var2)
            {
                float var3 = 0.25F;
                this.world.a("bubble", this.locX - this.motX * (double)var3, this.locY - this.motY * (double)var3, this.locZ - this.motZ * (double)var3, this.motX, this.motY, this.motZ);
            }

            var1 *= 0.8F;
        }

        this.motX *= (double)var1;
        this.motY *= (double)var1;
        this.motZ *= (double)var1;
        this.motY -= (double)this.curvature;
    }

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void b(NBTTagCompound var1)
    {
        var1.setShort("xTile", (short)this.xTile);
        var1.setShort("yTile", (short)this.yTile);
        var1.setShort("zTile", (short)this.zTile);
        var1.setByte("inTile", (byte)this.inTile);
        var1.setByte("inData", (byte)this.inData);
        var1.setByte("shake", (byte)this.arrowShake);
        var1.setByte("inGround", (byte)(this.inGround ? 1 : 0));
        var1.setBoolean("player", this.shotByPlayer);
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void a(NBTTagCompound var1)
    {
        this.xTile = var1.getShort("xTile");
        this.yTile = var1.getShort("yTile");
        this.zTile = var1.getShort("zTile");
        this.inTile = var1.getByte("inTile") & 255;
        this.inData = var1.getByte("inData") & 255;
        this.arrowShake = var1.getByte("shake") & 255;
        this.inGround = var1.getByte("inGround") == 1;
        this.shotByPlayer = var1.getBoolean("player");
    }

    /**
     * Called by a player entity when they collide with an entity
     */
    public void a_(EntityHuman var1)
    {
        if (this.item != null)
        {
            if (!this.world.isStatic)
            {
                if (this.inGround && this.shotByPlayer && this.arrowShake <= 0 && var1.inventory.pickup(this.item.cloneItemStack()))
                {
                    this.world.makeSound(this, "random.pop", 0.2F, ((this.random.nextFloat() - this.random.nextFloat()) * 0.7F + 1.0F) * 2.0F);
                    var1.receive(this, 1);
                    this.die();
                }
            }
        }
    }

    public boolean canBeShot(Entity var1)
    {
        return var1.o_() && (var1 != this.shooter || this.ticksFlying >= 2) && (!(var1 instanceof EntityLiving) || ((EntityLiving)var1).deathTicks <= 0);
    }

    public boolean onHit()
    {
        return true;
    }

    public boolean onHitTarget(Entity var1)
    {
        this.world.makeSound(this, "random.drr", 1.0F, 1.2F / (this.random.nextFloat() * 0.2F + 0.9F));
        return true;
    }

    public void tickFlying() {}

    public void tickInGround() {}

    public boolean onHitBlock(MovingObjectPosition var1)
    {
        return this.onHitBlock();
    }

    public boolean onHitBlock()
    {
        this.world.makeSound(this, "random.drr", 1.0F, 1.2F / (this.random.nextFloat() * 0.2F + 0.9F));
        return true;
    }

    public float getShadowSize()
    {
        return 0.0F;
    }
}
