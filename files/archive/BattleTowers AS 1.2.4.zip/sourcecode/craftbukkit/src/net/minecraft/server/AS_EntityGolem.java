package net.minecraft.server;

public class AS_EntityGolem extends EntityMonster
{
    private int rageCounter;
    private int explosionAttack;
    private int drops;
    private float golemMoveSpeed = 0.05F;
    private int attackCounter;
    private ChunkCoordinates towerTopCoord = null;

    public AS_EntityGolem(World var1, int var2)
    {
        super(var1);
        this.texture = "/mob/golemdormant.png";
        this.bb = this.golemMoveSpeed;
        this.damage = 6;
        this.health = 150 + 50 * var2;
        this.b(1.6F, 3.4F);
        this.yaw = 0.0F;
        this.rageCounter = 0;
        this.explosionAttack = 0;
        this.fireProof = true;
        this.drops = 5 + var2;
        this.setPositionRotation(this.locX, this.locY, this.locZ, 0.0F, 0.0F);
        this.attackCounter = 0;
    }

    public AS_EntityGolem(World var1)
    {
        super(var1);
        this.texture = "/mob/golem.png";
        this.bb = this.golemMoveSpeed;
        this.damage = 6;
        this.health = 300;
        this.b(1.6F, 3.4F);
        this.yaw = 0.0F;
        this.rageCounter = 0;
        this.explosionAttack = 0;
        this.fireProof = true;
        this.drops = 1;
        this.setPositionRotation(this.locX, this.locY, this.locZ, 0.0F, 0.0F);
        this.attackCounter = 0;
    }

    protected void b()
    {
        super.b();
        this.datawatcher.a(16, new Integer(Integer.valueOf(1).intValue()));
    }

    private void setDormant()
    {
        this.datawatcher.watch(16, new Integer(Integer.valueOf(1).intValue()));
    }

    private void setAwake()
    {
        this.datawatcher.watch(16, new Integer(Integer.valueOf(0).intValue()));
    }

    private boolean getIsDormant()
    {
        return this.datawatcher.getInt(16) != 0;
    }

    public int getMaxHealth()
    {
        return 150 + 50 * (this.drops - 5);
    }

    /**
     * Will get destroyed next tick
     */
    public void die()
    {
        super.die();
    }

    /**
     * Called when the mob's health reaches 0.
     */
    public void die(DamageSource var1)
    {
        super.die(var1);
        Entity var2 = var1.getEntity();

        if (this.aj > 0 && var2 != null)
        {
            var2.b(this, this.aj);
        }

        if (!this.world.isStatic)
        {
            int var3 = this.drops;
            int var4;

            for (var4 = 0; var4 < var3; ++var4)
            {
                this.b(Item.DIAMOND.id, 1);
                this.b(Item.REDSTONE.id, 1);
            }

            var3 = this.random.nextInt(4) + 8;

            for (var4 = 0; var4 < var3; ++var4)
            {
                this.b(Block.CLAY.id, 1);
            }

            if (this.towerTopCoord != null && this.target != null && mod_AS_BattleTowers.towerDestroyerEnabled != 0)
            {
                ModLoaderMp.sendChatToAll("A Tower Guardian has fallen! Without it\'s energy, the tower will collapse...");
                mod_AS_BattleTowers.registerTowerDestroyer(new AS_TowerDestroyer(this.world, this.towerTopCoord, System.currentTimeMillis(), this.target));
            }
        }

        this.world.broadcastEntityEffect(this, (byte)3);
    }

    /**
     * knocks back this entity
     */
    public void a(Entity var1, int var2, double var3, double var5)
    {
        if (this.random.nextInt(5) == 0)
        {
            this.motX *= 1.5D;
            this.motZ *= 1.5D;
            this.motY += 0.6000000238418579D;
        }
    }

    protected void look()
    {
        if (this.getIsDormant())
        {
            EntityHuman var1 = this.world.findNearbyPlayer(this, 6.0D);

            if (var1 != null && this.h(var1))
            {
                this.setAwake();

                if ((int)this.locY > 90)
                {
                    this.towerTopCoord = new ChunkCoordinates((int)this.locX, (int)this.locY, (int)this.locZ);
                }

                this.world.makeSound(this.locX, this.locY, this.locZ, "ambient.cave.cave", 0.7F, 1.0F);
                this.world.makeSound(this, "golemawaken", this.p() * 2.0F, ((this.random.nextFloat() - this.random.nextFloat()) * 0.2F + 1.0F) * 1.8F);
                this.texture = "/mob/golem.png";
                this.rageCounter = 175;
            }
        }
        else if (this.target != null)
        {
            if (this.towerTopCoord == null)
            {
                this.towerTopCoord = new ChunkCoordinates((int)this.locX, (int)this.locY, (int)this.locZ);
            }

            boolean var10 = this.target.j(this) < 36.0D;

            if (var10 && this.explosionAttack != 1 && (!var10 || this.locY - this.target.locY <= 0.3D))
            {
                this.rageCounter = 175;
            }
            else
            {
                this.rageCounter -= 2;
            }

            double var2 = this.target.locX - this.locX;
            double var4 = this.target.boundingBox.b + (double)(this.target.length / 2.0F) - (this.locY + (double)this.length * 0.8D);
            double var6 = this.target.locZ - this.locZ;
            this.V = this.yaw = -((float)Math.atan2(var2, var6)) * 180.0F / (float)Math.PI;

            if (this.h(this.target))
            {
                if (this.attackCounter == 10)
                {
                    this.world.makeSound(this, "golemcharge", this.p(), (this.random.nextFloat() - this.random.nextFloat()) * 0.2F + 1.0F);
                }

                ++this.attackCounter;

                if (this.attackCounter == 20)
                {
                    this.world.makeSound(this, "mob.ghast.fireball", this.p(), (this.random.nextFloat() - this.random.nextFloat()) * 0.2F + 1.0F);

                    if (!this.world.isStatic)
                    {
                        AS_EntityGolemFireball var8 = new AS_EntityGolemFireball(this.world, this, var2, var4, var6);
                        Vec3D var9 = this.f(1.0F);
                        var8.locX = this.locX + var9.a * 2.0D;
                        var8.locY = this.locY + (double)this.length * 0.8D;
                        var8.locZ = this.locZ + var9.c * 2.0D;
                        this.world.addEntity(var8);
                    }

                    this.attackCounter = -40;
                }
            }
            else if (this.attackCounter > 0)
            {
                --this.attackCounter;
            }
        }
        else
        {
            this.V = this.yaw = -((float)Math.atan2(this.motX, this.motZ)) * 180.0F / (float)Math.PI;

            if (this.attackCounter > 0)
            {
                --this.attackCounter;
            }
        }
    }

    /**
     * Determines if an entity can be despawned, used on idle far away entities
     */
    protected boolean n()
    {
        return this.dead;
    }

    /**
     * Called to update the entity's position/logic.
     */
    public void G_()
    {
        if (!this.getIsDormant())
        {
            this.motX *= 0.7D;
            this.motZ *= 0.7D;

            if (this.rageCounter <= 0 && this.explosionAttack == 0)
            {
                if (this.explosionAttack == 0 && this.target instanceof EntityHuman && this.world.findNearbyPlayer(this, 24.0D) == null)
                {
                    this.target = null;
                }
                else
                {
                    this.world.makeSound(this, "golemspecial", this.p() * 2.0F, ((this.random.nextFloat() - this.random.nextFloat()) * 0.2F + 1.0F) * 1.8F);
                    this.motY += 0.9D;
                    this.explosionAttack = 1;
                    this.bb = 1.0F;
                }
            }
            else if (this.target == null)
            {
                this.health = 300;
                this.rageCounter = 125;
                this.explosionAttack = 0;

                if (this.towerTopCoord != null)
                {
                    this.enderTeleportTo((double)this.towerTopCoord.x, (double)this.towerTopCoord.y, (double)this.towerTopCoord.z);
                    this.setDormant();
                    this.texture = "/mob/golemdormant.png";
                }
            }
            else if ((this.rageCounter <= -30 || this.onGround) && this.explosionAttack == 1)
            {
                if (this.health <= 100)
                {
                    this.health += 15;
                }

                if (!this.world.isStatic && this.locY - this.target.locY > 0.3D)
                {
                    this.world.explode(this, this.locX, this.locY - 0.3D, this.locZ, 4.0F);
                }

                this.rageCounter = 125;
                this.explosionAttack = 0;
                this.bb = this.golemMoveSpeed;
            }

            super.G_();
        }

        this.look();
    }

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void b(NBTTagCompound var1)
    {
        super.b(var1);
        var1.setByte("isDormant", (byte)(this.getIsDormant() ? 1 : 0));
        var1.setByte("hasexplosionAttacked", (byte)this.explosionAttack);
        var1.setByte("rageCounter", (byte)this.rageCounter);
        var1.setByte("Drops", (byte)this.drops);
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void a(NBTTagCompound var1)
    {
        super.a(var1);

        if ((var1.getByte("isDormant") & 255) == 1)
        {
            this.setDormant();
        }
        else
        {
            this.setAwake();
        }

        this.explosionAttack = var1.getByte("hasexplosionAttacked") & 255;
        this.rageCounter = var1.getByte("rageCounter") & 255;
        this.drops = var1.getByte("Drops") & 255;
        this.bb = this.golemMoveSpeed;
        this.texture = this.getIsDormant() ? "/mob/golemdormant.png" : "/mob/golem.png";
        this.damage = 8;
    }

    /**
     * Basic mob attack. Default to touch of death in EntityCreature. Overridden by each mob to define their attack.
     */
    protected void a(Entity var1, float var2)
    {
        if ((double)var2 < 3.0D && var1.boundingBox.e > this.boundingBox.b && var1.boundingBox.b < this.boundingBox.e)
        {
            var1.damageEntity(DamageSource.mobAttack(this), this.damage);
        }

        if (this.onGround)
        {
            double var3 = var1.locX - this.locX;
            double var5 = var1.locZ - this.locZ;
            float var7 = MathHelper.sqrt(var3 * var3 + var5 * var5);
            this.motX = var3 / (double)var7 * 0.5D * 0.20000000192092895D + this.motX * 0.20000000098023224D;
            this.motZ = var5 / (double)var7 * 0.5D * 0.10000000192092896D + this.motZ * 0.20000000098023224D;
        }
        else
        {
            super.a(var1, var2);
        }
    }

    /**
     * Returns the sound this mob makes while it's alive.
     */
    protected String i()
    {
        return !this.getIsDormant() ? "golem" : null;
    }

    /**
     * Returns the sound this mob makes when it is hurt.
     */
    protected String j()
    {
        return "golemhurt";
    }

    /**
     * Returns the sound this mob makes on death.
     */
    protected String k()
    {
        return "golemdeath";
    }

    /**
     * Returns the item ID for the item the mob drops on death.
     */
    protected int getLootId()
    {
        return Item.CLAY_BRICK.id;
    }
}
