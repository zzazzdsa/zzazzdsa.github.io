package net.minecraft.server;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import net.minecraft.server.MinecraftServer;

public class mod_AS_BattleTowers extends BaseModMp
{
    static boolean isWorking = false;
    private List TowerPositions;
    private static List TowerDestroyers;
    private int raritycounter = 400;
    private int spawncounter;
    private static int rarity;
    private double minDistanceBetweenTowers;
    public static int towerDestroyerEnabled;
    public static String configpath;
    private long time;
    static BaseModMp instance;
    private boolean hasinit = false;

    public mod_AS_BattleTowers()
    {
        if (!this.hasinit)
        {
            this.init();
        }
    }

    public void load()
    {
        if (!this.hasinit)
        {
            this.init();
        }
    }

    private void init()
    {
        this.hasinit = true;
        ModLoader.registerEntityID(AS_EntityGolem.class, "Golem", 27);
        ModLoaderMp.registerEntityTrackerEntry(AS_EntityGolemFireball.class, 27);
        ModLoaderMp.registerEntityTracker(AS_EntityGolemFireball.class, 160, 5);
        this.spawncounter = 200;

        try
        {
            Properties var1 = new Properties();
            String var2 = mod_AS_BattleTowers.class.getProtectionDomain().getCodeSource().getLocation().toURI().getPath();
            var2 = var2.substring(0, var2.lastIndexOf(47));
            var2 = var2.substring(0, var2.lastIndexOf(47));
            var2 = var2 + "/mods/BattleTowers.txt";
            File var3 = new File(var2);
            configpath = var2;
            var1.load(new InputStreamReader(new FileInputStream(var3)));
            rarity = Integer.valueOf(var1.getProperty("rarity")).intValue();
            this.minDistanceBetweenTowers = Double.valueOf(var1.getProperty("minDistanceBetweenTowers")).doubleValue();
            towerDestroyerEnabled = Integer.valueOf(var1.getProperty("towerDestroyerEnabled")).intValue();
        }
        catch (URISyntaxException var4)
        {
            System.err.println("BattleTowers URISyntaxException: " + var4);
            this.UseDefaults();
        }
        catch (FileNotFoundException var5)
        {
            System.err.println("BattleTowers properties file not found, using default values: " + var5);
            this.UseDefaults();
        }
        catch (IOException var6)
        {
            System.err.println("Error reading BattleTowers properties file, using default values: " + var6);
            this.UseDefaults();
        }
        catch (NumberFormatException var7)
        {
            System.err.println("Incorrect value property, using default value. " + var7);
            this.UseDefaults();
        }

        if (rarity < 1)
        {
            rarity = 1;
        }

        this.raritycounter = rarity * 100;
        this.TowerPositions = new ArrayList();
        TowerDestroyers = new ArrayList();
        this.time = System.currentTimeMillis();
        ModLoader.setInGameHook(this, true, true);
        instance = this;
    }

    public void onTickInGame(MinecraftServer var1)
    {
        if (System.currentTimeMillis() > this.time + 1000L)
        {
            for (int var2 = 0; var2 < TowerDestroyers.size(); ++var2)
            {
                AS_TowerDestroyer var3 = (AS_TowerDestroyer)TowerDestroyers.get(var2);
                var3.Update();
            }
        }
    }

    public static void registerTowerDestroyer(AS_TowerDestroyer var0)
    {
        forceAllClientsDestroyerSetting();

        if (towerDestroyerEnabled != 0)
        {
            TowerDestroyers.add(var0);
        }
    }

    private static void forceAllClientsDestroyerSetting()
    {
        int[] var0 = new int[] {towerDestroyerEnabled};
        Packet230ModLoader var1 = new Packet230ModLoader();
        var1.packetType = 0;
        var1.dataInt = var0;
        ModLoaderMp.sendPacketToAll(instance, var1);
    }

    public static void unRegisterTowerDestroyer(AS_TowerDestroyer var0)
    {
        TowerDestroyers.remove(var0);
    }

    public void UseDefaults()
    {
        rarity = 3;
        this.minDistanceBetweenTowers = 64.0D;
        towerDestroyerEnabled = 1;
    }

    public void modsLoaded()
    {
        System.err.println("BATTLE TOWERS CONFIG");
        System.err.println("Tower Rarity " + String.valueOf(rarity));
        System.err.println("Min Tower Distance " + String.valueOf(this.minDistanceBetweenTowers));
        System.err.println("MINECRAFT PROPERTIES " + configpath);
    }

    public void generateSurface(World var1, Random var2, int var3, int var4)
    {
        if (!this.hasinit)
        {
            this.init();
        }

        if (!isWorking)
        {
            isWorking = true;

            if (this.spawncounter > this.raritycounter)
            {
                boolean var5 = true;
                double var8 = 100.0D;

                for (int var10 = 0; var10 < this.TowerPositions.size(); ++var10)
                {
                    ChunkCoordinates var11 = (ChunkCoordinates)this.TowerPositions.get(var10);
                    double var6 = var11.b(var3, 64, var4);

                    if (var6 < var8)
                    {
                        var8 = var6;
                    }

                    if (var6 < this.minDistanceBetweenTowers)
                    {
                        var5 = false;
                        break;
                    }
                }

                if (var5 && this.AttemptToSpawnTower(var1, var2, var3, var4))
                {
                    if (this.TowerPositions.size() > 30)
                    {
                        this.TowerPositions.remove(0);
                    }

                    ChunkCoordinates var12 = new ChunkCoordinates(var3, 64, var4);
                    this.TowerPositions.add(var12);
                    this.spawncounter = 0;
                }
            }
            else
            {
                ++this.spawncounter;
            }

            isWorking = false;
        }
    }

    private boolean AttemptToSpawnTower(World var1, Random var2, int var3, int var4)
    {
        int var5 = this.GetSurfaceBlockHeight(var1, var3, var4);
        return var5 == 49 ? false : (new AS_WorldGenTower()).a(var1, var2, var3, var5, var4);
    }

    private int GetSurfaceBlockHeight(World var1, int var2, int var3)
    {
        int var4 = 50;

        do
        {
            ++var4;
        }
        while (var1.getTypeId(var2, var4, var3) != 0);

        return var4 - 1;
    }

    public String getVersion()
    {
        return "1.2.3";
    }
}
