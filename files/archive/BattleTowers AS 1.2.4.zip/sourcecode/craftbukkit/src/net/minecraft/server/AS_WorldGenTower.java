package net.minecraft.server;

import java.util.Arrays;
import java.util.Random;

public class AS_WorldGenTower extends WorldGenerator
{
    private int floor;
    private int floorIterator;
    private boolean topFloor;
    private int[][] candidates = new int[][] {{4, -5}, {4, 0}, {4, 5}, {0, -5}, {0, 0}, {0, 5}, { -4, -5}, { -4, 0}, { -4, 5}};
    private int candidatecount;
    final int maxHoleDepthInBase;
    private AS_WorldGenTower.towerTypes towerChosen;

    public AS_WorldGenTower()
    {
        this.candidatecount = this.candidates.length;
        this.maxHoleDepthInBase = 22;
    }

    public boolean a(World var1, Random var2, int var3, int var4, int var5)
    {
        int var6 = var4;
        int var7 = 0;
        int var8 = 0;
        int var9 = 0;
        int var10 = 0;
        int var13;
        int var14;
        int var15;

        for (int var11 = 0; var11 < this.candidatecount; ++var11)
        {
            int[] var12 = this.candidates[var11];
            var13 = this.GetSurfaceBlockHeight(var1, var3 + var12[0], var5 + var12[1]);
            var14 = var1.getTypeId(var3 + var12[0], var13, var5 + var12[1]);

            if (var1.getTypeId(var3 + var12[0], var13 + 1, var5 + var12[1]) != Block.SNOW.id && var14 != Block.ICE.id)
            {
                if (var14 != Block.SAND.id && var14 != Block.SANDSTONE.id)
                {
                    if (var14 == Block.STATIONARY_WATER.id)
                    {
                        ++var7;
                    }
                    else
                    {
                        ++var10;
                    }
                }
                else
                {
                    ++var8;
                }
            }
            else
            {
                ++var9;
            }

            if (Math.abs(var13 - var6) > 22)
            {
                return false;
            }

            for (var15 = 1; var15 <= 3; ++var15)
            {
                var14 = var1.getTypeId(var3 + var12[0], var13 + var15, var5 + var12[1]);

                if (this.IsBannedBlockID(var14))
                {
                    return false;
                }
            }

            for (var15 = 1; var15 <= 5; ++var15)
            {
                var14 = var1.getTypeId(var3 + var12[0], var13 - var15, var5 + var12[1]);

                if (var14 == 0 || this.IsBannedBlockID(var14))
                {
                    return false;
                }
            }
        }

        int[] var25 = new int[] {var7, var9, var8, var10};
        Arrays.sort(var25);
        int var24 = var25[var25.length - 1];

        if (var8 == var24)
        {
            this.towerChosen = AS_WorldGenTower.towerTypes.SandStone;
        }
        else if (var9 == var24)
        {
            this.towerChosen = AS_WorldGenTower.towerTypes.Ice;
        }
        else if (var7 == var24)
        {
            this.towerChosen = AS_WorldGenTower.towerTypes.CobbleStoneMossy;
        }
        else if (var2.nextInt(10) == 0)
        {
            this.towerChosen = AS_WorldGenTower.towerTypes.Netherrack;
        }
        else
        {
            this.towerChosen = var2.nextInt(5) == 0 ? AS_WorldGenTower.towerTypes.SmoothStone : AS_WorldGenTower.towerTypes.CobbleStone;
        }

        var13 = this.towerChosen.GetWallBlockID();
        var14 = this.towerChosen.GetLightBlockID();
        var15 = this.towerChosen.GetFloorBlockID();
        this.floor = 1;
        this.topFloor = false;

        for (int var16 = var4 - 6; var16 < 120; var16 += 7)
        {
            if (var16 + 7 >= 120)
            {
                this.topFloor = true;
            }

            int var17;
            int var19;
            int var18;
            int var20;

            for (this.floorIterator = 0; this.floorIterator < 7; ++this.floorIterator)
            {
                if (this.floor == 1 && this.floorIterator < 4)
                {
                    this.floorIterator = 4;
                }

                for (var17 = -7; var17 < 7; ++var17)
                {
                    for (var18 = -7; var18 < 7; ++var18)
                    {
                        var19 = var17 + var3;
                        var20 = this.floorIterator + var16;
                        int var21 = var18 + var5;

                        if (var18 == -7)
                        {
                            if (var17 > -5 && var17 < 4)
                            {
                                this.BuildWallPiece(var1, var19, var20, var21, var13);
                            }
                        }
                        else if (var18 != -6 && var18 != -5)
                        {
                            if (var18 != -4 && var18 != -3 && var18 != 2 && var18 != 3)
                            {
                                if (var18 > -3 && var18 < 2)
                                {
                                    if (var17 != -7 && var17 != 6)
                                    {
                                        if (var17 > -7 && var17 < 6)
                                        {
                                            if (this.floorIterator == 5)
                                            {
                                                this.BuildFloorPiece(var1, var19, var20, var21, var15);
                                            }
                                            else
                                            {
                                                var1.setRawTypeId(var19, var20, var21, 0);
                                            }
                                        }
                                    }
                                    else if (this.floorIterator >= 0 && this.floorIterator <= 3 && (var17 == -7 || var17 == 6) && (var18 == -1 || var18 == 0))
                                    {
                                        var1.setRawTypeId(var19, var20, var21, 0);
                                    }
                                    else
                                    {
                                        this.BuildWallPiece(var1, var19, var20, var21, var13);
                                    }
                                }
                                else if (var18 == 4)
                                {
                                    if (var17 != -5 && var17 != 4)
                                    {
                                        if (var17 > -5 && var17 < 4)
                                        {
                                            if (this.floorIterator == 5)
                                            {
                                                this.BuildFloorPiece(var1, var19, var20, var21, var15);
                                            }
                                            else
                                            {
                                                var1.setRawTypeId(var19, var20, var21, 0);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        this.BuildWallPiece(var1, var19, var20, var21, var13);
                                    }
                                }
                                else if (var18 == 5)
                                {
                                    if (var17 != -4 && var17 != -3 && var17 != 2 && var17 != 3)
                                    {
                                        if (var17 > -3 && var17 < 2)
                                        {
                                            if (this.floorIterator == 5)
                                            {
                                                this.BuildFloorPiece(var1, var19, var20, var21, var15);
                                            }
                                            else
                                            {
                                                this.BuildWallPiece(var1, var19, var20, var21, var13);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        this.BuildWallPiece(var1, var19, var20, var21, var13);
                                    }
                                }
                                else if (var18 == 6 && var17 > -3 && var17 < 2)
                                {
                                    if (this.floorIterator >= 0 && this.floorIterator <= 3 && (var17 == -1 || var17 == 0))
                                    {
                                        this.BuildWallPiece(var1, var19, var20, var21, var13);
                                    }
                                    else
                                    {
                                        this.BuildWallPiece(var1, var19, var20, var21, var13);
                                    }
                                }
                            }
                            else if (var17 != -6 && var17 != 5)
                            {
                                if (var17 > -6 && var17 < 5)
                                {
                                    if (this.floorIterator == 5)
                                    {
                                        this.BuildFloorPiece(var1, var19, var20, var21, var15);
                                    }
                                    else if (var1.getTypeId(var19, var20, var21) != Block.CHEST.id)
                                    {
                                        var1.setRawTypeId(var19, var20, var21, 0);
                                    }
                                }
                            }
                            else
                            {
                                this.BuildWallPiece(var1, var19, var20, var21, var13);
                            }
                        }
                        else if (var17 != -5 && var17 != 4)
                        {
                            if (var18 == -6)
                            {
                                if (var17 == (this.floorIterator + 1) % 7 - 3)
                                {
                                    var1.setRawTypeId(var19, var20, var21, this.towerChosen.GetStairBlockID());

                                    if (this.floorIterator == 5)
                                    {
                                        var1.setRawTypeId(var19 - 7, var20, var21, var15);
                                    }

                                    if (this.floorIterator == 6 && this.topFloor)
                                    {
                                        this.BuildWallPiece(var1, var19, var20, var21, var13);
                                    }
                                }
                                else if (var17 < 4 && var17 > -5)
                                {
                                    var1.setRawTypeId(var19, var20, var21, 0);
                                }
                            }
                            else if (var18 == -5 && var17 > -5 && var17 < 5)
                            {
                                if ((this.floorIterator == 0 || this.floorIterator == 6) && (var17 == -4 || var17 == 3))
                                {
                                    var1.setRawTypeId(var19, var20, var21, 0);
                                }
                                else if (this.floorIterator == 5 && (var17 == 3 || var17 == -4))
                                {
                                    this.BuildFloorPiece(var1, var19, var20, var21, var15);
                                }
                                else
                                {
                                    this.BuildWallPiece(var1, var19, var20, var21, var13);
                                }
                            }
                        }
                        else
                        {
                            this.BuildWallPiece(var1, var19, var20, var21, var13);
                        }
                    }
                }
            }

            if (this.floor == 2)
            {
                var1.setRawTypeId(var3 + 3, var16, var5 - 5, var13);
                var1.setRawTypeId(var3 + 3, var16 - 1, var5 - 5, var13);
            }

            if (this.topFloor)
            {
                double var27 = (double)var3;
                double var28 = (double)(var16 + 6);
                double var32 = (double)var5 + 0.5D;
                AS_EntityGolem var23 = new AS_EntityGolem(var1, this.towerChosen.ordinal());
                var23.setPositionRotation(var27, var28, var32, var1.random.nextFloat() * 360.0F, 0.0F);
                var23.setPosition(var27, var28, var32);
                var1.addEntity(var23);
            }
            else
            {
                var1.setTypeId(var3 + 2, var16 + 6, var5 + 2, Block.MOB_SPAWNER.id);
                TileEntityMobSpawner var26 = (TileEntityMobSpawner)var1.getTileEntity(var3 + 2, var16 + 6, var5 + 2);
                var26.a(this.getMobType(var2));
                var1.setTypeId(var3 - 3, var16 + 6, var5 + 2, Block.MOB_SPAWNER.id);
                TileEntityMobSpawner var30 = (TileEntityMobSpawner)var1.getTileEntity(var3 - 3, var16 + 6, var5 + 2);
                var30.a(this.getMobType(var2));
            }

            var1.setRawTypeId(var3, var16 + 6, var5 + 3, var15);
            var1.setRawTypeId(var3 - 1, var16 + 6, var5 + 3, var15);

            if (var16 + 56 >= 120 && this.floor == 1)
            {
                this.floor = 2;
            }

            for (var17 = 0; var17 < 2; ++var17)
            {
                var1.setRawTypeId(var3 - var17, var16 + 7, var5 + 3, Block.CHEST.id);
                var1.setRawData(var3 - var17, var16 + 7, var5 + 3, 2);
                TileEntityChest var29 = new TileEntityChest();
                var1.setTileEntity(var3 - var17, var16 + 7, var5 + 3, var29);

                for (var19 = 0; var19 < 3; ++var19)
                {
                    ItemStack var31 = this.getChestRewardItem(this.floor, var2);

                    if (var31 != null)
                    {
                        var29.setItem(var2.nextInt(var29.getSize()), var31);
                    }
                }
            }

            if (var14 != 0 && Block.byId[var14].a())
            {
                var16 += 2;
            }

            var1.setRawTypeId(var3 + 3, var16, var5 - 6, var14);
            var1.setRawTypeId(var3 - 4, var16, var5 - 6, var14);
            var1.setRawTypeId(var3 + 1, var16, var5 - 4, var14);
            var1.setRawTypeId(var3 - 2, var16, var5 - 4, var14);

            if (var14 != 0 && Block.byId[var14].a())
            {
                var16 -= 2;
            }

            for (var17 = 0; var17 < this.floor * 4 + this.towerChosen.ordinal() - 8 && !this.topFloor; ++var17)
            {
                var18 = 5 - var2.nextInt(12);
                var19 = var16 + 5;
                var20 = 5 - var2.nextInt(10);

                if (var20 >= -2 || var18 >= 4 || var18 <= -5 || var18 == 1 || var18 == -2)
                {
                    var18 += var3;
                    var20 += var5;

                    if (var1.getTypeId(var18, var19, var20) == var15 && var1.getTypeId(var18, var19 + 1, var20) != Block.MOB_SPAWNER.id)
                    {
                        var1.setRawTypeId(var18, var19, var20, 0);
                    }
                }
            }

            ++this.floor;
        }

        return true;
    }

    private void BuildFloorPiece(World var1, int var2, int var3, int var4, int var5)
    {
        var1.setRawTypeId(var2, var3, var4, var5);

        if (this.towerChosen.GetFloorBlockMetaData() != 0)
        {
            var1.setData(var2, var3, var4, this.towerChosen.GetFloorBlockMetaData());
        }
    }

    private void BuildWallPiece(World var1, int var2, int var3, int var4, int var5)
    {
        var1.setRawTypeId(var2, var3, var4, var5);

        if (this.floor == 1 && this.floorIterator == 4)
        {
            this.FillTowerBaseToGround(var1, var2, var3, var4, var5);
        }
    }

    private void FillTowerBaseToGround(World var1, int var2, int var3, int var4, int var5)
    {
        int var6 = var3 - 1;

        do
        {
            var1.setRawTypeId(var2, var6, var4, var5);
            --var6;
        }
        while (!this.IsBuildableBlockID(var1.getTypeId(var2, var6, var4)));
    }

    private int GetSurfaceBlockHeight(World var1, int var2, int var3)
    {
        int var4 = 50;

        do
        {
            ++var4;
        }
        while (var1.getTypeId(var2, var4, var3) != 0 && !this.IsFoliageBlockID(var1.getTypeId(var2, var4, var3)));

        return var4 - 1;
    }

    private boolean IsFoliageBlockID(int var1)
    {
        return var1 == Block.SNOW.id || var1 == Block.LONG_GRASS.id || var1 == Block.DEAD_BUSH.id || var1 == Block.LOG.id || var1 == Block.LEAVES.id;
    }

    private boolean IsBuildableBlockID(int var1)
    {
        return var1 == Block.STONE.id || var1 == Block.GRASS.id || var1 == Block.SAND.id || var1 == Block.SANDSTONE.id || var1 == Block.GRAVEL.id || var1 == Block.DIRT.id;
    }

    private boolean IsBannedBlockID(int var1)
    {
        return var1 == Block.YELLOW_FLOWER.id || var1 == Block.RED_ROSE.id || var1 == Block.BROWN_MUSHROOM.id || var1 == Block.RED_MUSHROOM.id || var1 == Block.CACTUS.id || var1 == Block.PUMPKIN.id || var1 == Block.LAVA.id || var1 == Block.STATIONARY_LAVA.id;
    }

    private ItemStack getChestRewardItem(int var1, Random var2)
    {
        int var3 = var2.nextInt(4);

        if (this.topFloor)
        {
            switch (var3)
            {
                case 0:
                    return new ItemStack(Item.REDSTONE, var2.nextInt(8));

                case 1:
                    return new ItemStack(Item.IRON_INGOT, var2.nextInt(8));

                case 2:
                    return new ItemStack(Item.DIAMOND, var2.nextInt(6));

                case 3:
                    return new ItemStack(Item.GOLD_INGOT, var2.nextInt(8));
            }
        }

        switch (var1)
        {
            case 1:
                switch (var3)
                {
                    case 0:
                        return new ItemStack(Item.STICK, var2.nextInt(5) + 6);

                    case 1:
                        return new ItemStack(Item.SEEDS, var2.nextInt(5) + 6);

                    case 2:
                        return new ItemStack(Block.WOOD, var2.nextInt(5) + 7);

                    case 3:
                        return new ItemStack(Item.COAL, var2.nextInt(5) + 6);
                }

            case 2:
                switch (var3)
                {
                    case 0:
                        return new ItemStack(Item.COAL, var2.nextInt(3) + 6);

                    case 1:
                        return new ItemStack(Item.WOOD_PICKAXE, 1);

                    case 2:
                        return new ItemStack(Block.WOOD, var2.nextInt(3) + 6);

                    case 3:
                        return new ItemStack(Block.WOOL, var2.nextInt(3) + 6);
                }

            case 3:
                switch (var3)
                {
                    case 0:
                        return new ItemStack(Item.FEATHER, var2.nextInt(3) + 6);

                    case 1:
                        return new ItemStack(Item.BREAD, 1);

                    case 2:
                        return new ItemStack(Block.GLASS, var2.nextInt(3) + 6);

                    case 3:
                        return new ItemStack(Block.RED_MUSHROOM, 1);
                }

            case 4:
                switch (var3)
                {
                    case 0:
                        return new ItemStack(Item.STRING, var2.nextInt(3) + 4);

                    case 1:
                        return new ItemStack(Item.IRON_SWORD, 1);

                    case 2:
                        return new ItemStack(Block.TORCH, var2.nextInt(3) + 8);

                    case 3:
                        return new ItemStack(Block.RED_ROSE, var2.nextInt(3) + 3);
                }

            case 5:
                switch (var3)
                {
                    case 0:
                        return new ItemStack(Item.SIGN, 1);

                    case 1:
                        return new ItemStack(Item.BOW, 1);

                    case 2:
                        return new ItemStack(Block.BRICK, var2.nextInt(3) + 5);

                    case 3:
                        return new ItemStack(Item.CHAINMAIL_BOOTS, 1);
                }

            case 6:
                switch (var3)
                {
                    case 0:
                        return new ItemStack(Block.LADDER, var2.nextInt(3) + 9);

                    case 1:
                        return new ItemStack(Item.FLINT_AND_STEEL, 1);

                    case 2:
                        return new ItemStack(Block.GLOWSTONE, var2.nextInt(3) + 5);

                    case 3:
                        return new ItemStack(Item.CHAINMAIL_HELMET, 1);
                }

            case 7:
                switch (var3)
                {
                    case 0:
                        return new ItemStack(Block.TNT, var2.nextInt(3) + 6);

                    case 1:
                        return new ItemStack(Item.DIAMOND_HOE, 1);

                    case 2:
                        return new ItemStack(Block.OBSIDIAN, var2.nextInt(3) + 2);

                    case 3:
                        return new ItemStack(Item.CHAINMAIL_CHESTPLATE, 1);
                }

            case 8:
                switch (var3)
                {
                    case 0:
                        return new ItemStack(Item.DIAMOND_SWORD, 1);

                    case 1:
                        return new ItemStack(Item.DIAMOND_PICKAXE, 1);

                    case 2:
                        return new ItemStack(Item.DIAMOND_AXE, 1);

                    case 3:
                        return new ItemStack(Item.DIAMOND_SPADE, 1);
                }

            default:
                return null;
        }
    }

    private String getMobType(Random var1)
    {
        switch (var1.nextInt(4))
        {
            case 0:
                if (ModLoader.isModLoaded("mod_prefixskeletons"))
                {
                    return "PrefixSkeleton";
                }

                return "Skeleton";

            case 1:
                if (ModLoader.isModLoaded("mod_MoreCreepsAndWeirdos"))
                {
                    return "Mummy";
                }

                return "Zombie";

            case 2:
                return "Zombie";

            case 3:
                return "Spider";

            case 4:
                return "";

            default:
                return "";
        }
    }

    public static enum towerTypes
    {
        CobbleStone("CobbleStone", 0, Block.COBBLESTONE.id, Block.TORCH.id, Block.DOUBLE_STEP.id, 0, Block.COBBLESTONE_STAIRS.id),
        CobbleStoneMossy("CobbleStoneMossy", 1, Block.MOSSY_COBBLESTONE.id, Block.TORCH.id, Block.DOUBLE_STEP.id, 0, Block.COBBLESTONE_STAIRS.id),
        SandStone("SandStone", 2, Block.SANDSTONE.id, Block.TORCH.id, Block.DOUBLE_STEP.id, 1, Block.COBBLESTONE_STAIRS.id),
        Ice("Ice", 3, Block.ICE.id, 0, Block.CLAY.id, 2, Block.WOOD_STAIRS.id),
        SmoothStone("SmoothStone", 4, Block.STONE.id, Block.TORCH.id, Block.DOUBLE_STEP.id, 3, Block.COBBLESTONE_STAIRS.id),
        Netherrack("Netherrack", 5, Block.NETHERRACK.id, Block.GLOWSTONE.id, Block.SOUL_SAND.id, 0, Block.COBBLESTONE_STAIRS.id);
        private int wallBlockID;
        private int lightBlockID;
        private int floorBlockID;
        private int floorBlockMetaData;
        private int stairBlockID;

        private static final AS_WorldGenTower.towerTypes[] $VALUES = new AS_WorldGenTower.towerTypes[]{CobbleStone, CobbleStoneMossy, SandStone, Ice, SmoothStone, Netherrack};

        private towerTypes(String var1, int var2, int var3, int var4, int var5, int var6, int var7)
        {
            this.wallBlockID = var3;
            this.lightBlockID = var4;
            this.floorBlockID = var5;
            this.floorBlockMetaData = var6;
            this.stairBlockID = var7;
        }

        int GetWallBlockID()
        {
            return this.wallBlockID;
        }

        int GetLightBlockID()
        {
            return this.lightBlockID;
        }

        int GetFloorBlockID()
        {
            return this.floorBlockID;
        }

        int GetFloorBlockMetaData()
        {
            return this.floorBlockMetaData;
        }

        int GetStairBlockID()
        {
            return this.stairBlockID;
        }
    }
}
