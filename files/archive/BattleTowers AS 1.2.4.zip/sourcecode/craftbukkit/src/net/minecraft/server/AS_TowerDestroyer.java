package net.minecraft.server;

public class AS_TowerDestroyer
{
    private int x;
    private int y;
    private int z;
    private World world;
    private Entity player;
    private long triggerTime;
    private long lastExplosionSoundTime;
    private final int maxfloor = 6;
    private int floor = 6;
    private final int floorDistance = 7;
    private final float explosionPower = 10.0F;

    public AS_TowerDestroyer(World var1, ChunkCoordinates var2, long var3, Entity var5)
    {
        this.world = var1;
        this.player = var5;
        this.x = var2.x;
        this.y = var2.y;
        this.z = var2.z;
        this.triggerTime = var3;
        this.lastExplosionSoundTime = var3;
    }

    public void Update()
    {
        if (this.floor == 6 && System.currentTimeMillis() > this.triggerTime + 30000L)
        {
            this.triggerTime = System.currentTimeMillis();

            if (!this.world.isStatic)
            {
                this.world.explode(this.player, (double)this.x, this.yCoord(), (double)this.z, 10.0F);
                this.cleanUpStragglerBlocks();
            }

            --this.floor;
        }
        else if (this.floor < 6 && System.currentTimeMillis() > this.triggerTime + 10000L)
        {
            if (this.floor < 1)
            {
                mod_AS_BattleTowers.unRegisterTowerDestroyer(this);
                return;
            }

            this.triggerTime = System.currentTimeMillis();

            if (!this.world.isStatic)
            {
                this.world.explode(this.player, (double)this.x, this.yCoord(), (double)this.z, 10.0F);
                this.cleanUpStragglerBlocks();
            }

            --this.floor;
        }
    }

    private double yCoord()
    {
        return (double)(this.y - 7 * Math.abs(6 - this.floor));
    }

    private int randomTowerCoord(int var1)
    {
        return var1 - 7 + this.world.random.nextInt(15);
    }

    private void cleanUpStragglerBlocks()
    {
        int var1 = (int)this.yCoord();

        for (int var2 = -8; var2 < 8; ++var2)
        {
            for (int var3 = -8; var3 < 8; ++var3)
            {
                for (int var4 = 1; var4 < 9; ++var4)
                {
                    if (this.world.getTypeId(this.x + var2, var1 + var4, this.z + var3) != 0)
                    {
                        this.world.setRawTypeId(this.x + var2, var1 + var4, this.z + var3, 0);
                    }
                }
            }
        }
    }
}
