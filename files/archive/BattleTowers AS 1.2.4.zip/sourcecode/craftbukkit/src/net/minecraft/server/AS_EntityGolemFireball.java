package net.minecraft.server;

import java.util.List;

public class AS_EntityGolemFireball extends Entity
{
    private int xTile = -1;
    private int yTile = -1;
    private int zTile = -1;
    private int inTile = 0;
    private boolean wasDeflected;
    private boolean inGround = false;
    public int shake = 0;
    public EntityLiving shooterEntity;
    public double accelerationX;
    public double accelerationY;
    public double accelerationZ;

    public AS_EntityGolemFireball(World var1)
    {
        super(var1);
        this.b(0.3F, 0.3F);
        this.wasDeflected = false;
    }

    protected void b() {}

    public AS_EntityGolemFireball(World var1, EntityLiving var2, double var3, double var5, double var7)
    {
        super(var1);
        this.shooterEntity = var2;
        this.b(0.3F, 0.3F);
        this.setPosition(this.locX, this.locY, this.locZ);
        this.height = 0.0F;
        this.motX = this.motY = this.motZ = 0.0D;
        var3 += this.random.nextGaussian() * 0.4D;
        var5 += this.random.nextGaussian() * 0.4D;
        var7 += this.random.nextGaussian() * 0.4D;
        double var9 = (double)MathHelper.sqrt(var3 * var3 + var5 * var5 + var7 * var7);
        this.accelerationX = var3 / var9 * 0.1D;
        this.accelerationY = var5 / var9 * 0.1D;
        this.accelerationZ = var7 / var9 * 0.1D;
        this.wasDeflected = false;
    }

    /**
     * Called to update the entity's position/logic.
     */
    public void G_()
    {
        super.G_();
        this.setOnFire(1);

        if (this.shake > 0)
        {
            --this.shake;
        }

        if (this.inGround)
        {
            int var1 = this.world.getTypeId(this.xTile, this.yTile, this.zTile);

            if (var1 == this.inTile)
            {
                if (this.ticksLived >= 1200)
                {
                    this.die();
                }

                return;
            }

            this.inGround = false;
            this.motX *= (double)(this.random.nextFloat() * 0.2F);
            this.motY *= (double)(this.random.nextFloat() * 0.2F);
            this.motZ *= (double)(this.random.nextFloat() * 0.2F);
        }

        Vec3D var15 = Vec3D.create(this.locX, this.locY, this.locZ);
        Vec3D var2 = Vec3D.create(this.locX + this.motX, this.locY + this.motY, this.locZ + this.motZ);
        MovingObjectPosition var3 = this.world.a(var15, var2);
        var15 = Vec3D.create(this.locX, this.locY, this.locZ);
        var2 = Vec3D.create(this.locX + this.motX, this.locY + this.motY, this.locZ + this.motZ);

        if (var3 != null)
        {
            var2 = Vec3D.create(var3.pos.a, var3.pos.b, var3.pos.c);
        }

        Entity var4 = null;
        List var5 = this.world.getEntities(this, this.boundingBox.a(this.motX, this.motY, this.motZ).grow(1.0D, 1.0D, 1.0D));
        double var6 = 0.0D;

        for (int var8 = 0; var8 < var5.size(); ++var8)
        {
            Entity var9 = (Entity)var5.get(var8);

            if (var9.o_() && (var9 != this.shooterEntity || this.ticksLived >= 25 || this.wasDeflected))
            {
                float var10 = 0.3F;
                AxisAlignedBB var11 = var9.boundingBox.grow((double)var10, (double)var10, (double)var10);
                MovingObjectPosition var12 = var11.a(var15, var2);

                if (var12 != null)
                {
                    double var13 = var15.b(var12.pos);

                    if (var13 < var6 || var6 == 0.0D)
                    {
                        var4 = var9;
                        var6 = var13;
                    }
                }
            }
        }

        if (var4 != null)
        {
            var3 = new MovingObjectPosition(var4);
        }

        if (var3 != null)
        {
            if (!this.world.isStatic)
            {
                if (var3.entity != null && !var3.entity.damageEntity(DamageSource.mobAttack(this.shooterEntity), 0))
                {
                    ;
                }

                this.world.createExplosion((Entity)null, this.locX, this.locY, this.locZ, 1.0F, true);
            }

            this.die();
        }

        this.locX += this.motX;
        this.locY += this.motY;
        this.locZ += this.motZ;
        float var16 = MathHelper.sqrt(this.motX * this.motX + this.motZ * this.motZ);
        this.yaw = (float)(Math.atan2(this.motX, this.motZ) * 180.0D / Math.PI);

        for (this.pitch = (float)(Math.atan2(this.motY, (double)var16) * 180.0D / Math.PI); this.pitch - this.lastPitch < -180.0F; this.lastPitch -= 360.0F)
        {
            ;
        }

        while (this.pitch - this.lastPitch >= 180.0F)
        {
            this.lastPitch += 360.0F;
        }

        while (this.yaw - this.lastYaw < -180.0F)
        {
            this.lastYaw -= 360.0F;
        }

        while (this.yaw - this.lastYaw >= 180.0F)
        {
            this.lastYaw += 360.0F;
        }

        this.pitch = this.lastPitch + (this.pitch - this.lastPitch) * 0.2F;
        this.yaw = this.lastYaw + (this.yaw - this.lastYaw) * 0.2F;
        float var17 = 0.95F;

        if (this.aT())
        {
            for (int var19 = 0; var19 < 4; ++var19)
            {
                float var18 = 0.25F;
                this.world.a("bubble", this.locX - this.motX * (double)var18, this.locY - this.motY * (double)var18, this.locZ - this.motZ * (double)var18, this.motX, this.motY, this.motZ);
            }

            var17 = 0.8F;
        }

        this.motX += this.accelerationX;
        this.motY += this.accelerationY;
        this.motZ += this.accelerationZ;
        this.motX *= (double)var17;
        this.motY *= (double)var17;
        this.motZ *= (double)var17;
        this.world.a("smoke", this.locX, this.locY + 0.5D, this.locZ, 0.0D, 0.0D, 0.0D);
        this.setPosition(this.locX, this.locY, this.locZ);
    }

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void b(NBTTagCompound var1)
    {
        var1.setShort("xTile", (short)this.xTile);
        var1.setShort("yTile", (short)this.yTile);
        var1.setShort("zTile", (short)this.zTile);
        var1.setByte("inTile", (byte)this.inTile);
        var1.setByte("shake", (byte)this.shake);
        var1.setByte("inGround", (byte)(this.inGround ? 1 : 0));
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void a(NBTTagCompound var1)
    {
        this.xTile = var1.getShort("xTile");
        this.yTile = var1.getShort("yTile");
        this.zTile = var1.getShort("zTile");
        this.inTile = var1.getByte("inTile") & 255;
        this.shake = var1.getByte("shake") & 255;
        this.inGround = var1.getByte("inGround") == 1;
    }

    public boolean o_()
    {
        return true;
    }

    public float j_()
    {
        return 1.0F;
    }

    /**
     * Called when the entity is attacked.
     */
    public boolean damageEntity(DamageSource var1, int var2)
    {
        this.aV();
        Entity var3 = var1.getEntity();

        if (var3 != null)
        {
            Vec3D var4 = var3.aI();

            if (var4 != null)
            {
                this.motX = var4.a;
                this.motY = var4.b;
                this.motZ = var4.c;
                this.accelerationX = this.motX * 0.1D;
                this.accelerationY = this.motY * 0.1D;
                this.accelerationZ = this.motZ * 0.1D;
                this.wasDeflected = true;
            }

            return true;
        }
        else
        {
            return false;
        }
    }

    public float getShadowSize()
    {
        return 0.0F;
    }
}
