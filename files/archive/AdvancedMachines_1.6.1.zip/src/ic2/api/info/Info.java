package ic2.api.info;

public class Info {
	public static IEnergyValueProvider itemEnergy;
	public static IFuelValueProvider itemFuel;
}
