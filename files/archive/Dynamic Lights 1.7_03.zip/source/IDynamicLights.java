
package net.minecraft.src;


public interface IDynamicLights
{

    public abstract java.util.List getListOfDynamicLights();
	// get the pointer to the current (Ticks) List of Dynamic Lights, active and inactive
	
	public abstract PlayerTorch getDynamicLightForEntity(Entity entity);
	// Dynamic Lights are always attached to an Entity.

	public abstract Entity getEntityForDynamicLight(PlayerTorch light);
	// The same, from the Lights POV
	
	public abstract float[] getDynamicLightPosition(PlayerTorch light);
	// gives you {x, y, z}, should be equal to their entity's position
	
	public abstract int getItemBrightnessValue(int itemID);
	// gives you the configured Item Brightness value by item ID
	
	public abstract int getItemLightRangeValue(int itemID);
	
	public abstract int getItemDeathAgeTicksValue(int itemID);
	
	public abstract boolean getItemWorksUnderWaterValue(int itemID);
	
	public abstract void toggleDynamicLightsOnOff();
	// a simple flip. Takes effect on next Tick
	
	public abstract boolean getAreAnyLightsActive();
	
	public abstract void registerDynamicLight(PlayerTorch light);
	// custom Dynamic Lights can be added here
	
	public abstract void removeDynamicLight(PlayerTorch light);
	// and killed here
	
}
