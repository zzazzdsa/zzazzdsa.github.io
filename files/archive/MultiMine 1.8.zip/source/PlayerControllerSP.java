// this file only tells you what to change in the source file

public class PlayerControllerSP extends PlayerController
{
	// new global
	private Object curObject;

    public boolean sendBlockRemoved(int i, int j, int k, int l)
    {
		// add these 2 lines before the return		
		AS_BlockWithDamage current = new AS_BlockWithDamage(i, j, k, 0, null);
		mod_MultiMine.partiallyMinedBlocksList.remove(current);
		
        return flag;
    }

    public void resetBlockRemoving()
    {
		// add this on top of the function
		saveCurrentDamagedBlock();

        curBlockDamage = 0.0F;
        blockHitWait = 0;
    }

    public void sendBlockRemoving(int i, int j, int k, int l)
    {
		//...
        if(i == curBlockX && j == curBlockY && k == curBlockZ)
        {
            int i1 = mc.theWorld.getBlockId(i, j, k);
            if(i1 == 0)
            {
                return;
            }
			
			// add this below the if - return
			AS_BlockWithDamage newb = new AS_BlockWithDamage(i, j, k, 0, null);
			if (mod_MultiMine.partiallyMinedBlocksList.contains(newb))
			{
				int index = mod_MultiMine.partiallyMinedBlocksList.indexOf(newb);
				newb = (AS_BlockWithDamage)mod_MultiMine.partiallyMinedBlocksList.get(index);
				if(newb.getDamage() > curBlockDamage)
				{
					curBlockDamage = newb.getDamage();
					
					mod_MultiMine.DebugPrint("Already damaged Block being mined again, damage: " + curBlockDamage);
				}
			}
			
			// replace this line with the below: curBlockDamage += block.blockStrength(mc.thePlayer);
			if (!AS_Settings_MultiMine.mineSpeedChanged)
			{
				curBlockDamage += block.blockStrength(mc.thePlayer);
			}
			else
			{
				curBlockDamage += (block.blockStrength(mc.thePlayer) * AS_Settings_MultiMine.mineSpeed);
			}
			
			
			//....
        }
		else
        {
			// add on top of the else
			saveCurrentDamagedBlock();
			curObject = mc.objectMouseOver;
			
			AS_BlockWithDamage newb = new AS_BlockWithDamage(i, j, k, 0, null);
			if (mod_MultiMine.partiallyMinedBlocksList.contains(newb))
			{
				int index = mod_MultiMine.partiallyMinedBlocksList.indexOf(newb);
				newb = (AS_BlockWithDamage)mod_MultiMine.partiallyMinedBlocksList.get(index);
				curBlockDamage = newb.getDamage();
				mod_MultiMine.DebugPrint("Already damaged Block being mined again, damage: " + curBlockDamage);
			}
			else curBlockDamage = 0.0F;
			// replace "curBlockDamage = 0.0F;" with the above line
			
            prevBlockDamage = 0.0F;
			//....
        }
    }
	
	// new function
	private void saveCurrentDamagedBlock()
	{
		if (curBlockDamage == 0.0) return;
		
		mod_MultiMine.DebugPrint("Saving current Damaged Block, damage: " + curBlockDamage);
	
		if (mod_MultiMine.partiallyMinedBlocksList.size() > AS_Settings_MultiMine.maxDamagedBlocks)
		{
			mod_MultiMine.partiallyMinedBlocksList.remove(0);
		}
		
		AS_BlockWithDamage current = new AS_BlockWithDamage(curBlockX, curBlockY, curBlockZ, curBlockDamage, curObject);
		mod_MultiMine.partiallyMinedBlocksList.remove(current); // if its present before with different damage
		
		if (curObject != null)
		{
			mod_MultiMine.partiallyMinedBlocksList.add(current);
			mod_MultiMine.DebugPrint("Added to Array!");
		}
	}
}
