package net.minecraft.src;

import java.util.Map;
import org.lwjgl.input.*;
import net.minecraft.client.Minecraft;
import java.util.*;
import org.lwjgl.opengl.GL11;

public class mod_MultiMine extends BaseMod
{
    public static World lastworld = null;
    public static AS_RenderEntityLahwran entity;
	public static ArrayList partiallyMinedBlocksList;
	public static final boolean DEBUGMODE = false;
	private static Minecraft minecraft;

    public mod_MultiMine()
	{
		partiallyMinedBlocksList = new ArrayList();
        ModLoader.SetInGameHook(this, true, true);
    }
	
    public boolean OnTickInGame(Minecraft mc)
	{
        if (mc.theWorld != lastworld)
		{
            spawn(mc);
            lastworld = mc.theWorld;
        }
		
        if(lastworld != null
		&& mc.objectMouseOver != null
		&& mc.objectMouseOver.typeOfHit == EnumMovingObjectType.TILE
		&& Mouse.getEventButton() == 1
		&& Mouse.getEventButtonState())
        {
            int j = mc.objectMouseOver.blockX;
            int k = mc.objectMouseOver.blockY;
            int l = mc.objectMouseOver.blockZ;
			
			AS_BlockWithDamage dummy = new AS_BlockWithDamage(j, k, l, 0, null); //just the three ints describe the block object, hence this equals any present block in the list
			partiallyMinedBlocksList.remove(dummy);
		}
		
        return true;
    }

    public String Version()
	{
        return "1.7.3";
    }

    public static void spawn(Minecraft mc)
	{
		AS_Settings_MultiMine.InitSettings();
        entity = new AS_RenderEntityLahwran(mc, mc.theWorld);
        //entity.setPosition(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ); //huh?
        mc.theWorld.addWeatherEffect((Entity) entity);
        entity.setPosition(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ);
    }
	
    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Override
    public void AddRenderer(Map map)
	{
        map.put(AS_RenderEntityLahwran.class, new AS_RenderHooks());
    }
	
	public static void DebugPrint(String s)
	{
		if(DEBUGMODE)
		{
			minecraft.ingameGUI.addChatMessage(s);
		}
	}
}
