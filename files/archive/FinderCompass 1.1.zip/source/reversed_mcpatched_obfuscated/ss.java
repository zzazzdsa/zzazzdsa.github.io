import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import javax.imageio.ImageIO;
import net.minecraft.client.Minecraft;

public class ss extends sr {

   private Minecraft mc;
   private int[] tsize;
   private double[] i = new double[30];
   private double[] j = new double[30];
   private int[] spawnNeedlecolor = new int[]{255, 20, 20};
   private int[] strongholdNeedlecolor = new int[]{175, 220, 0};
   private static Map customNeedles = new HashMap();
   private static Map customNeedleTargets = new HashMap();
   private static boolean areSettingsLoaded = false;
   static File settingsFile;
   final double HEADING_DOWN = 0.0D;
   final double HEADING_UP = 135.0D;
   private int x;
   private int y;
   private int z;
   private final td NullChunk = new td(0, 0, 0);
   private long lastTime;
   private int seccounter = 0;
   private boolean updateScan = false;
   private td nextStronghold = new td(0, 0, 0);
   public int modState = -1;
   public int tilesize_intsize = 16;
   public int tilesize_numpixels = 256;
   public BufferedImage texture;
   public int tileSize_int_compassCrossMin = -4;
   public int tileSize_int_compassCrossMax = 4;
   public double tileSize_double_compassCenterMin;
   public double tileSize_double_compassCenterMax;
   public int tileSize_int_compassNeedleMin;
   public int tileSize_int_compassNeedleMax;
   private boolean noDefaultNeedle = false;
   private boolean noEnderEyeNeedle = false;
   public static boolean isHackedIn = false;
   public boolean optifineHack = false;


   public ss(Minecraft var1) {
      super(ww.aQ.b(0));
      this.tileSize_double_compassCenterMin = (double)(this.tilesize_intsize / 2) - 0.5D;
      this.tileSize_double_compassCenterMax = (double)(this.tilesize_intsize / 2) + 0.5D;
      this.tileSize_int_compassNeedleMin = -8;
      this.tileSize_int_compassNeedleMax = 16;
      this.checkModState();
      this.tsize = new int[this.tilesize_numpixels];
      this.mc = var1;
      this.k = 1;
      BufferedImage var2 = this.texture;
      int var3 = this.g % 16 * this.tilesize_intsize;
      int var4 = this.g / 16 * this.tilesize_intsize;
      var2.getRGB(var3, var4, this.tilesize_intsize, this.tilesize_intsize, this.tsize, 0, this.tilesize_intsize);
   }

   public ss(Minecraft var1, boolean optiHackbool) {
      super(ww.aQ.b(0));
      this.mc = var1;
      this.tileSize_double_compassCenterMin = (double)(this.tilesize_intsize / 2) - 0.5D;
      this.tileSize_double_compassCenterMax = (double)(this.tilesize_intsize / 2) + 0.5D;
      this.tileSize_int_compassNeedleMin = -8;
      this.tileSize_int_compassNeedleMax = 16;
      this.optifineHack = true;
      this.checkModState();
      this.tsize = new int[this.tilesize_numpixels];
      this.k = 1;
      BufferedImage var2 = this.texture;
      int var3 = this.g % 16 * this.tilesize_intsize;
      int var4 = this.g / 16 * this.tilesize_intsize;
      var2.getRGB(var3, var4, this.tilesize_intsize, this.tilesize_intsize, this.tsize, 0, this.tilesize_intsize);
   }

   private void checkModState() {
      try {
         this.texture = ImageIO.read(Minecraft.class.getResource("/gui/items.png"));
      } catch (IOException var13) {
         var13.printStackTrace();
      }

      Class var1 = null;

      try {
         var1 = Class.forName("com.pclewis.mcpatcher.mod.TileSize");
      } catch (ClassNotFoundException var12) {
         System.out.println("Finder Compass: Did not detect mcpatcher HD Textures");
      }

      if(var1 != null) {
         System.out.println("Finder Compass: mcpatcher HD Textures detected, setting up...");
         this.modState = 1;

         try {
            this.tilesize_intsize = ((Integer)var1.getField("int_size").get((Object)null)).intValue();
            this.tilesize_numpixels = ((Integer)var1.getField("int_numPixels").get((Object)null)).intValue();
            this.tileSize_int_compassCrossMin = ((Integer)var1.getField("int_compassCrossMin").get((Object)null)).intValue();
            this.tileSize_int_compassCrossMax = ((Integer)var1.getField("int_compassCrossMax").get((Object)null)).intValue();
            this.tileSize_int_compassNeedleMin = ((Integer)var1.getField("int_compassNeedleMin").get((Object)null)).intValue();
            this.tileSize_int_compassNeedleMax = ((Integer)var1.getField("int_compassNeedleMax").get((Object)null)).intValue();
            this.tileSize_double_compassCenterMin = ((Double)var1.getField("double_compassCenterMin").get((Object)null)).doubleValue();
            this.tileSize_double_compassCenterMax = ((Double)var1.getField("double_compassCenterMax").get((Object)null)).doubleValue();
            var1 = Class.forName("com.pclewis.mcpatcher.mod.TextureUtils");
            Method[] targetHDCompassobj = var1.getMethods();

            for(int var15 = 0; var15 < targetHDCompassobj.length; ++var15) {
               Method tilewidth = targetHDCompassobj[var15];
               if(tilewidth.getName().equals("getResourceAsBufferedImage") && tilewidth.getParameterTypes().length == 1) {
                  Object[] var22 = new Object[]{new String("/gui/items.png")};
                  this.texture = (BufferedImage)tilewidth.invoke((Object)null, var22);
               }
            }
         } catch (IllegalArgumentException var20) {
            var20.printStackTrace();
         } catch (SecurityException var21) {
            var21.printStackTrace();
         } catch (IllegalAccessException var221) {
            var221.printStackTrace();
         } catch (NoSuchFieldException var23) {
            var23.printStackTrace();
         } catch (InvocationTargetException var24) {
            var24.printStackTrace();
         } catch (ClassNotFoundException var25) {
            var25.printStackTrace();
         }
      } else {
         try {
            var1 = Class.forName("TextureHDCompassFX");
         } catch (ClassNotFoundException var11) {
            System.out.println("Finder Compass: Did not detect Optifine HD Textures");
         }

         if(var1 != null) {
            System.out.println("Finder Compass: Optifine HD Textures detected, setting up...");
            this.modState = 2;
            if(!this.optifineHack) {
               System.out.println("Awaiting Optifine setup to hack into later");
               return;
            }

            Object var26 = null;

            try {
               Field[] var27 = this.mc.p.getClass().getDeclaredFields();

               for(int var28 = 0; var28 < var27.length; ++var28) {
                  var27[var28].setAccessible(true);
                  Object var29 = var27[var28].get(this.mc.p);
                  if(var29 instanceof List) {
                     System.out.println("Found List in RenderEngine...");
                     Iterator texturePackBase = ((List)var29).iterator();

                     while(texturePackBase.hasNext()) {
                        Object texpackMethodArray = texturePackBase.next();
                        if(texpackMethodArray.getClass().equals(var1)) {
                           System.out.println("Found Object in RenderEngine List: " + texpackMethodArray.getClass());
                           var26 = texpackMethodArray;
                        }
                     }
                  }
               }

               Field var30 = var1.getDeclaredField("tileWidth");
               var30.setAccessible(true);
               this.tilesize_intsize = ((Integer)var30.get(var26)).intValue();
               this.tilesize_numpixels = this.tilesize_intsize * this.tilesize_intsize;
               this.tileSize_double_compassCenterMin = (double)(this.tilesize_intsize / 2) - 0.5D;
               this.tileSize_double_compassCenterMax = (double)(this.tilesize_intsize / 2) + 0.5D;
               System.out.println("tilesize_intsize = " + this.tilesize_intsize + "; tilesize_numpixels = " + this.tilesize_numpixels + ";");
               Field var31 = var1.getDeclaredField("texturePackBase");
               var31.setAccessible(true);
               Object var32 = var31.get(var26);
               if(var32 != null) {
                  Method[] var33 = var32.getClass().getDeclaredMethods();

                  for(int method_i = var33.length - 1; method_i != 0; --method_i) {
                     Method tempMethod = var33[method_i];
                     if(tempMethod.getName().equals("a") && tempMethod.getParameterTypes().length == 1 && tempMethod.getReturnType() != Void.TYPE) {
                        System.out.println("texturePackBase method found, returntype: " + tempMethod.getReturnType());
                        InputStream stream = (InputStream)tempMethod.invoke(var32, new Object[]{"/gui/items.png"});
                        if(stream != null) {
                           this.texture = ImageIO.read(stream);
                           System.out.println("Successfully read texture, texture = null: " + (this.texture == null));
                           this.f = new byte[this.tilesize_numpixels * 4];
                        } else {
                           System.out.println("texturePackBase invoke failed, stream == null");
                        }
                     }
                  }
               }
            } catch (IllegalArgumentException var14) {
               var14.printStackTrace();
            } catch (SecurityException var151) {
               var151.printStackTrace();
            } catch (IllegalAccessException var16) {
               var16.printStackTrace();
            } catch (NoSuchFieldException var17) {
               var17.printStackTrace();
            } catch (InvocationTargetException var18) {
               var18.printStackTrace();
            } catch (IOException var19) {
               var19.printStackTrace();
            }
         } else {
            System.out.println("Finder Compass: Did not detect any HD Textures, going with vanilla");
            this.modState = 0;
         }
      }

      isHackedIn = true;
   }

   td getStrongholdChunk() {
      pr var1 = this.getStrongholdPos();
      return var1 != null?new td(var1.a, var1.b, var1.c):this.NullChunk;
   }

   pr getStrongholdPos() {
      return this.mc.f.b("Stronghold", this.x, this.y, this.z);
   }

   public void a() {
      int var1;
      int var2;
      for(int var9 = 0; var9 < this.tilesize_numpixels; ++var9) {
         int var10 = this.tsize[var9] >> 24 & 255;
         var1 = this.tsize[var9] >> 16 & 255;
         int var11 = this.tsize[var9] >> 8 & 255;
         var2 = this.tsize[var9] >> 0 & 255;
         if(this.h) {
            int var12 = (var1 * 30 + var11 * 59 + var2 * 11) / 100;
            int var13 = (var1 * 30 + var11 * 70) / 100;
            int var14 = (var1 * 30 + var2 * 70) / 100;
            var1 = var12;
            var11 = var13;
            var2 = var14;
         }

         this.f[var9 * 4 + 0] = (byte)var1;
         this.f[var9 * 4 + 1] = (byte)var11;
         this.f[var9 * 4 + 2] = (byte)var2;
         this.f[var9 * 4 + 3] = (byte)var10;
      }

      if(this.mc.f != null && this.mc.h != null) {
         if(!areSettingsLoaded) {
            this.lastTime = System.currentTimeMillis();
            this.initializeSettingsFile();
         }

         boolean var91 = false;
         boolean var101 = false;
         if(System.currentTimeMillis() > this.lastTime + 1000L) {
            var91 = true;
            ++this.seccounter;
            this.lastTime = System.currentTimeMillis();
         }

         if(!this.noDefaultNeedle) {
            this.drawNeedle(0, this.computeNeedleHeading(this.mc.f.v()), this.spawnNeedlecolor, true);
         }

         if(!this.noEnderEyeNeedle) {
            this.drawNeedle(1, this.computeNeedleHeading(this.nextStronghold), this.strongholdNeedlecolor, false);
         }

         if((int)this.mc.h.o != this.x || (int)this.mc.h.p != this.y || (int)this.mc.h.q != this.z) {
            this.x = (int)this.mc.h.o;
            this.y = (int)this.mc.h.p;
            this.z = (int)this.mc.h.q;
            this.updateScan = true;
         }

         if(this.updateScan && var91 && this.seccounter > 14) {
            this.seccounter = 0;
            var101 = true;
            this.nextStronghold = this.getStrongholdChunk();
         }

         int[] var111;
         td var121;
         Iterator var131;
         Entry var141;
         if(this.updateScan && var91) {
            this.updateScan = false;
            var131 = customNeedles.entrySet().iterator();

            while(var131.hasNext()) {
               var141 = (Entry)var131.next();
               var2 = ((Integer)var141.getKey()).intValue();
               var111 = (int[])((int[])((int[])((int[])((int[])((int[])((int[])var141.getValue()))))));
               if(var101 || var111[7] == 0) {
                  var121 = this.findNearestBlockChunkOfIDInRange(var2, this.x, this.y, this.z, var111[3], var111[4], var111[5], var111[6]);
                  if(!var121.equals(this.NullChunk)) {
                     if(customNeedleTargets.containsKey(var111)) {
                        customNeedleTargets.remove(var111);
                     }

                     customNeedleTargets.put(var111, var121);
                  } else {
                     customNeedleTargets.remove(var111);
                  }
               }
            }
         }

         var1 = 3;
         var131 = customNeedleTargets.entrySet().iterator();

         while(var131.hasNext()) {
            var141 = (Entry)var131.next();
            var111 = (int[])((int[])((int[])((int[])((int[])((int[])((int[])var141.getKey()))))));
            var121 = (td)var141.getValue();
            ++var1;
            this.drawNeedle(var1, this.computeNeedleHeading(var121), var111, false);
         }
      }

   }

   public double computeNeedleHeading(td var1) {
      double var2 = 0.0D;
      if(this.mc.f != null && this.mc.h != null) {
         double var4 = (double)var1.a - this.mc.h.o;
         double var6 = (double)var1.c - this.mc.h.q;
         var2 = (double)(this.mc.h.u - 90.0F) * 3.141592653589793D / 180.0D - Math.atan2(var6, var4);
         if(this.mc.f.y.d) {
            var2 = Math.random() * 3.1415927410125732D * 2.0D;
         }
      }

      return var2;
   }

   public void drawNeedle(int var1, double var2, int[] var4, boolean var5) {
      double needleLength = this.modState == 2?0.3D * (double)(this.tilesize_intsize / 16):0.3D;

      double var6;
      for(var6 = var2 - this.i[var1]; var6 < -3.141592653589793D; var6 += 6.283185307179586D) {
         ;
      }

      while(var6 >= 3.141592653589793D) {
         var6 -= 6.283185307179586D;
      }

      if(var6 < -1.0D) {
         var6 = -1.0D;
      }

      if(var6 > 1.0D) {
         var6 = 1.0D;
      }

      this.i[var1] += var6 * 0.1D;
      this.j[var1] *= 0.8D;
      this.j[var1] += this.i[var1];
      double var8 = Math.sin(this.i[var1]);
      double var10 = Math.cos(this.i[var1]);
      int var12;
      int var13;
      int var15;
      int var14;
      int var16;
      int var17;
      int var18;
      short var19;
      int var20;
      int var21;
      int var22;
      if(var5) {
         for(var12 = this.tileSize_int_compassCrossMin; var12 <= this.tileSize_int_compassCrossMax; ++var12) {
            var13 = (int)(this.tileSize_double_compassCenterMax + var10 * (double)var12 * needleLength);
            var14 = (int)(this.tileSize_double_compassCenterMin - var8 * (double)var12 * needleLength * 0.5D);
            var15 = var14 * this.tilesize_intsize + var13;
            var16 = 100;
            var17 = 100;
            var18 = 100;
            var19 = 255;
            if(this.h) {
               var20 = (var16 * 30 + var17 * 59 + var18 * 11) / 100;
               var21 = (var16 * 30 + var17 * 70) / 100;
               var22 = (var16 * 30 + var18 * 70) / 100;
               var16 = var20;
               var17 = var21;
               var18 = var22;
            }

            this.f[var15 * 4 + 0] = (byte)var16;
            this.f[var15 * 4 + 1] = (byte)var17;
            this.f[var15 * 4 + 2] = (byte)var18;
            this.f[var15 * 4 + 3] = (byte)var19;
         }
      }

      for(var12 = this.tileSize_int_compassNeedleMin; var12 <= this.tileSize_int_compassNeedleMax; ++var12) {
         var13 = (int)(this.tileSize_double_compassCenterMax + var8 * (double)var12 * needleLength);
         var14 = (int)(this.tileSize_double_compassCenterMin + var10 * (double)var12 * needleLength * 0.5D);
         var15 = var14 * this.tilesize_intsize + var13;
         var16 = var12 < 0?100:var4[0];
         var17 = var12 < 0?100:var4[1];
         var18 = var12 < 0?100:var4[2];
         var19 = 255;
         if(this.h) {
            var20 = (var16 * 30 + var17 * 59 + var18 * 11) / 100;
            var21 = (var16 * 30 + var17 * 70) / 100;
            var22 = (var16 * 30 + var18 * 70) / 100;
            var16 = var20;
            var17 = var21;
            var18 = var22;
         }

         this.f[var15 * 4 + 0] = (byte)var16;
         this.f[var15 * 4 + 1] = (byte)var17;
         this.f[var15 * 4 + 2] = (byte)var18;
         this.f[var15 * 4 + 3] = (byte)var19;
      }

   }

   void initializeSettingsFile() {
      settingsFile = new File(Minecraft.a("minecraft"), "findercompass.cfg");
      System.out.println("initializeSettingsFile() running");

      try {
         if(settingsFile.exists()) {
            System.out.println(".minecraft/findercompass.cfg found and opened");
            BufferedReader var6 = new BufferedReader(new FileReader(settingsFile));

            String var2;
            while((var2 = var6.readLine()) != null) {
               if(!var2.startsWith("//")) {
                  if(var2.contentEquals("NoDefaultNeedle")) {
                     this.noDefaultNeedle = true;
                     System.out.println("Disabling Default Needle as per config file");
                  } else if(var2.contentEquals("NoEnderEyeNeedle")) {
                     this.noEnderEyeNeedle = true;
                     System.out.println("Disabling Ender Eye Needle as per config file");
                  } else {
                     String[] var3 = var2.split(":");
                     int var4 = Integer.parseInt(var3[0]);
                     int[] var5 = new int[8];
                     var5[0] = Integer.parseInt(var3[1]);
                     var5[1] = Integer.parseInt(var3[2]);
                     var5[2] = Integer.parseInt(var3[3]);
                     System.out.println("Finder Compass: loaded custom needle of id " + var4 + ", color [" + var5[0] + "," + var5[1] + "," + var5[2]);
                     var5[3] = Integer.parseInt(var3[4]);
                     var5[4] = Integer.parseInt(var3[5]);
                     var5[5] = Integer.parseInt(var3[6]);
                     var5[6] = Integer.parseInt(var3[7]);
                     var5[7] = Integer.parseInt(var3[8]);
                     System.out.println("Full readout: " + var5[0] + ":" + var5[1] + ":" + var5[2] + ":" + var5[3] + ":" + var5[4] + ":" + var5[5] + ":" + var5[6] + ":" + var5[7]);
                     customNeedles.put(Integer.valueOf(var4), var5);
                  }
               }
            }

            var6.close();
         } else {
            this.mc.w.a(".minecraft/findercompass.cfg not found, Finder Compass NOT ACTIVE");
         }
      } catch (Exception var61) {
         System.out.println("EXCEPTION BufferedReader: " + var61);
      }

      this.mc.w.a("Finder Compass config loaded; " + customNeedles.size() + " custom needles loaded");
      System.out.println("config file reading finished");
      areSettingsLoaded = true;
   }

   td findNearestBlockChunkOfIDInRange(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      List var9 = this.findBlocksOfIDInRange(var1, var2, var3, var4, var5, var6, var7, var8);
      td var10 = new td(var2, var3, var4);
      td var11 = new td(0, 0, 0);
      double var12 = 9999.0D;

      for(int var18 = 0; var18 < var9.size(); ++var18) {
         td var15 = (td)var9.get(var18);
         double var16 = this.GetDistanceBetweenChunks(var10, var15);
         if(var16 < var12) {
            var11 = var15;
            var12 = var16;
         }
      }

      td var181 = new td(var11.a, var11.b, var11.c);
      return var181;
   }

   List findBlocksOfIDInRange(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      ArrayList var9 = new ArrayList();

      for(int var10 = var3 - var6 - 1; var10 <= var3 + var6; ++var10) {
         if(var10 >= var7 && var10 <= var8) {
            for(int var11 = var4 - var5; var11 <= var4 + var5; ++var11) {
               for(int var12 = var2 - var5; var12 <= var2 + var5; ++var12) {
                  if(this.mc.f.a(var12, var10, var11) == var1) {
                     td var13 = new td(var12, var10, var11);
                     var9.add(var13);
                  }
               }
            }
         }
      }

      return var9;
   }

   double GetDistanceBetweenChunks(td var1, td var2) {
      int var3 = Math.abs(var1.a - var2.a);
      int var4 = Math.abs(var1.b - var2.b);
      int var5 = Math.abs(var1.c - var2.c);
      return Math.sqrt(Math.pow((double)var3, 2.0D) + Math.pow((double)var4, 2.0D) + Math.pow((double)var5, 2.0D));
   }

}
