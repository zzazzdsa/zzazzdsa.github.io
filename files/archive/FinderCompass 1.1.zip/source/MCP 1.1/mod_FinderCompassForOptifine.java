package net.minecraft.src;

import java.util.Map;
import org.lwjgl.input.*;
import net.minecraft.client.Minecraft;
import java.util.*;

public class mod_FinderCompassForOptifine extends BaseMod
{
	private long time = 0;
	
	@Override
	public void load()
	{
        ModLoader.SetInGameHook(this, true, false);
	}
	
    public String getVersion()
	{
        return "1.1";
    }

    public boolean OnTickInGame(float renderTick, Minecraft mc)
	{
    	if (mc.theWorld != null
    	&& mc.thePlayer != null
    	&& !TextureCompassFX.isHackedIn)
    	{
    		if (time == 0)
    		{
    			time = System.currentTimeMillis();
    		}
    		else if (System.currentTimeMillis() > time+5000L)
    		{
	    		TextureCompassFX replacement = new TextureCompassFX(mc, true);
	    		
	    		if (TextureCompassFX.isHackedIn)
	    		{
	    			mc.renderEngine.registerTextureFX(replacement);
	    		}
    		}
    	}
        
        return true;
    }
}
