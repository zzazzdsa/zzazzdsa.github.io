package net.minecraft.src;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import javax.imageio.ImageIO;
import net.minecraft.client.Minecraft;
import net.minecraft.src.ChunkCoordinates;
import net.minecraft.src.ChunkPosition;
import net.minecraft.src.Item;
import net.minecraft.src.TextureFX;

public class TextureCompassFX extends TextureFX
{
    private Minecraft mc;
    private int[] tsize;
    private double[] textureId = new double[30];
    private double[] tileSize = new double[30];
    private int[] spawnNeedlecolor = new int[] {255, 20, 20};
    private int[] strongholdNeedlecolor = new int[] {175, 220, 0};
    private static Map customNeedles = new HashMap();
    private static Map customNeedleTargets = new HashMap();
    private static boolean areSettingsLoaded = false;
    static File settingsFile;
    final double HEADING_DOWN = 0.0D;
    final double HEADING_UP = 135.0D;
    private int x;
    private int y;
    private int z;
    private final ChunkCoordinates NullChunk = new ChunkCoordinates(0, 0, 0);
    private long lastTime;
    private int seccounter = 0;
    private boolean updateScan = false;
    private ChunkCoordinates nextStronghold = new ChunkCoordinates(0, 0, 0);
    public int modState = -1;
    public int tilesize_intsize = 16;
    public int tilesize_numpixels = 256;
    public BufferedImage texture;
    public int tileSize_int_compassCrossMin = -4;
    public int tileSize_int_compassCrossMax = 4;
    public double tileSize_double_compassCenterMin;
    public double tileSize_double_compassCenterMax;
    public int tileSize_int_compassNeedleMin;
    public int tileSize_int_compassNeedleMax;
    private boolean noDefaultNeedle = false;
    private boolean noEnderEyeNeedle = false;
    public static boolean isHackedIn = false;
    public boolean optifineHack = false;

    public TextureCompassFX(Minecraft var1)
    {
        super(Item.compass.getIconFromDamage(0));
        this.tileSize_double_compassCenterMin = (double)(this.tilesize_intsize / 2) - 0.5D;
        this.tileSize_double_compassCenterMax = (double)(this.tilesize_intsize / 2) + 0.5D;
        this.tileSize_int_compassNeedleMin = -8;
        this.tileSize_int_compassNeedleMax = 16;
        this.checkModState();
        this.tsize = new int[this.tilesize_numpixels];
        this.mc = var1;
        this.tileImage = 1;
        BufferedImage var2 = this.texture;
        int var3 = this.iconIndex % 16 * this.tilesize_intsize;
        int var4 = this.iconIndex / 16 * this.tilesize_intsize;
        var2.getRGB(var3, var4, this.tilesize_intsize, this.tilesize_intsize, this.tsize, 0, this.tilesize_intsize);
    }
    
    public TextureCompassFX(Minecraft var1, boolean optiHackbool)
    {
        super(Item.compass.getIconFromDamage(0));
        this.mc = var1;
        this.tileSize_double_compassCenterMin = (double)(this.tilesize_intsize / 2) - 0.5D;
        this.tileSize_double_compassCenterMax = (double)(this.tilesize_intsize / 2) + 0.5D;
        this.tileSize_int_compassNeedleMin = -8;
        this.tileSize_int_compassNeedleMax = 16;
        optifineHack = true;
        this.checkModState();
        this.tsize = new int[this.tilesize_numpixels];
        this.tileImage = 1;
        BufferedImage var2 = this.texture;
        int var3 = this.iconIndex % 16 * this.tilesize_intsize;
        int var4 = this.iconIndex / 16 * this.tilesize_intsize;
        var2.getRGB(var3, var4, this.tilesize_intsize, this.tilesize_intsize, this.tsize, 0, this.tilesize_intsize);
    }

    private void checkModState()
    {
        try
        {
            this.texture = ImageIO.read(Minecraft.class.getResource("/gui/items.png"));
        }
        catch (IOException var9)
        {
            var9.printStackTrace();
        }

        Class var1 = null;

        try
        {
            var1 = Class.forName("com.pclewis.mcpatcher.mod.TileSize");
        }
        catch (ClassNotFoundException var8)
        {
            System.out.println("Finder Compass: Did not detect mcpatcher HD Textures");
        }

        if (var1 != null)
        {
            System.out.println("Finder Compass: mcpatcher HD Textures detected, setting up...");
            this.modState = 1;

            try
            {
                this.tilesize_intsize = ((Integer)var1.getField("int_size").get((Object)null)).intValue();
                this.tilesize_numpixels = ((Integer)var1.getField("int_numPixels").get((Object)null)).intValue();
                this.tileSize_int_compassCrossMin = ((Integer)var1.getField("int_compassCrossMin").get((Object)null)).intValue();
                this.tileSize_int_compassCrossMax = ((Integer)var1.getField("int_compassCrossMax").get((Object)null)).intValue();
                this.tileSize_int_compassNeedleMin = ((Integer)var1.getField("int_compassNeedleMin").get((Object)null)).intValue();
                this.tileSize_int_compassNeedleMax = ((Integer)var1.getField("int_compassNeedleMax").get((Object)null)).intValue();
                this.tileSize_double_compassCenterMin = ((Double)var1.getField("double_compassCenterMin").get((Object)null)).doubleValue();
                this.tileSize_double_compassCenterMax = ((Double)var1.getField("double_compassCenterMax").get((Object)null)).doubleValue();
                var1 = Class.forName("com.pclewis.mcpatcher.mod.TextureUtils");
                Method[] var2 = var1.getMethods();

                for (int var3 = 0; var3 < var2.length; ++var3)
                {
                    Method var4 = var2[var3];
                    if (var4.getName().equals("getResourceAsBufferedImage") && var4.getParameterTypes().length == 1)
                    {
                        Object[] var5 = new Object[] {new String("/gui/items.png")};
                        this.texture = (BufferedImage)var4.invoke((Object)null, var5);
                    }
                }
            }
            catch (IllegalArgumentException var16)
            {
                var16.printStackTrace();
            }
            catch (SecurityException var17)
            {
                var17.printStackTrace();
            }
            catch (IllegalAccessException var18)
            {
                var18.printStackTrace();
            }
            catch (NoSuchFieldException var19)
            {
                var19.printStackTrace();
            }
            catch (InvocationTargetException var20)
            {
                var20.printStackTrace();
            }
            catch (ClassNotFoundException var21)
            {
                var21.printStackTrace();
            }
        }
        else
        {
            try
            {
                var1 = Class.forName("TextureHDCompassFX");
            }
            catch (ClassNotFoundException var7)
            {
                System.out.println("Finder Compass: Did not detect Optifine HD Textures");
            }

            if (var1 != null)
            {
                System.out.println("Finder Compass: Optifine HD Textures detected, setting up...");
                this.modState = 2;
                
                if (!optifineHack)
                {
                	System.out.println("Awaiting Optifine setup to hack into later");
                	return;
                }
                
                Object targetHDCompassobj = null;

                try
                {
                	Field[] fieldarray = mc.renderEngine.getClass().getDeclaredFields();
        			for(int i = 0; i < fieldarray.length; i++)
        			{
        				fieldarray[i].setAccessible(true);
        				Object data = fieldarray[i].get(mc.renderEngine);
        				
        				if (data instanceof List)
        				{
        					System.out.println("Found List in RenderEngine...");
        					Iterator itr = ((List) data).iterator();
        					while (itr.hasNext())
        					{
        						Object temp = itr.next();
        						if (temp.getClass().equals(var1))
        						{
        							System.out.println("Found Object in RenderEngine List: "+temp.getClass());
        							targetHDCompassobj = temp;
        						}
        					}
        				}
        			}
                	
        			Field tilewidth = var1.getDeclaredField("tileWidth");
        			tilewidth.setAccessible(true);                    
                    this.tilesize_intsize = ((Integer)tilewidth.get(targetHDCompassobj)).intValue();
                    this.tilesize_numpixels = this.tilesize_intsize * this.tilesize_intsize;
                    this.tileSize_double_compassCenterMin = (double)(this.tilesize_intsize / 2) - 0.5D;
                    this.tileSize_double_compassCenterMax = (double)(this.tilesize_intsize / 2) + 0.5D;
                    
                    System.out.println("tilesize_intsize = "+tilesize_intsize+"; tilesize_numpixels = "+tilesize_numpixels+";");
                    
                    Field var22 = var1.getDeclaredField("texturePackBase");
                    var22.setAccessible(true);
                    Object texturePackBase = var22.get(targetHDCompassobj);
                    if (texturePackBase != null)
                    {
                        Method[] texpackMethodArray = texturePackBase.getClass().getDeclaredMethods();
                        
                        for (int method_i = texpackMethodArray.length-1; method_i != 0; --method_i)
                        {
                            Method tempMethod = texpackMethodArray[method_i];
                            
                            if (tempMethod.getName().equals("a") && tempMethod.getParameterTypes().length == 1 && tempMethod.getReturnType() != java.lang.Void.TYPE)
                            {
                            	System.out.println("texturePackBase method found, returntype: "+tempMethod.getReturnType());
                            	InputStream stream = (InputStream)tempMethod.invoke(texturePackBase, new Object[] {"/gui/items.png"});
                            	if (stream != null)
                            	{
                            		this.texture = ImageIO.read(stream);
                            		System.out.println("Successfully read texture, texture = null: "+(this.texture == null));
                            		
                            		this.imageData = new byte[tilesize_numpixels*4];
                            	}
                            	else
                            	{
                            		System.out.println("texturePackBase invoke failed, stream == null");
                            	}
                            }
                        }
                    }
                }
                catch (IllegalArgumentException var10)
                {
                    var10.printStackTrace();
                }
                catch (SecurityException var11)
                {
                    var11.printStackTrace();
                }
                catch (IllegalAccessException var12)
                {
                    var12.printStackTrace();
                }
                catch (NoSuchFieldException var13)
                {
                    var13.printStackTrace();
                }
                catch (InvocationTargetException var14)
                {
                    var14.printStackTrace();
                }
                catch (IOException var15)
                {
                    var15.printStackTrace();
                }
            }
            else
            {
                System.out.println("Finder Compass: Did not detect any HD Textures, going with vanilla");
                this.modState = 0;
            }
        }
        
        isHackedIn = true;
    }

    ChunkCoordinates getStrongholdChunk()
    {
        ChunkPosition var1 = this.getStrongholdPos();
        return var1 != null ? new ChunkCoordinates(var1.x, var1.y, var1.z) : this.NullChunk;
    }

    ChunkPosition getStrongholdPos()
    {
        return this.mc.theWorld.func_40477_b("Stronghold", this.x, this.y, this.z);
    }

    public void onTick()
    {
        int var1;
        int var2;
        for (int var3 = 0; var3 < this.tilesize_numpixels; ++var3)
        {
            int var4 = this.tsize[var3] >> 24 & 255;
            var1 = this.tsize[var3] >> 16 & 255;
            int var5 = this.tsize[var3] >> 8 & 255;
            var2 = this.tsize[var3] >> 0 & 255;
            if (this.anaglyphEnabled)
            {
                int var6 = (var1 * 30 + var5 * 59 + var2 * 11) / 100;
                int var7 = (var1 * 30 + var5 * 70) / 100;
                int var8 = (var1 * 30 + var2 * 70) / 100;
                var1 = var6;
                var5 = var7;
                var2 = var8;
            }

            this.imageData[var3 * 4 + 0] = (byte)var1;
            this.imageData[var3 * 4 + 1] = (byte)var5;
            this.imageData[var3 * 4 + 2] = (byte)var2;
            this.imageData[var3 * 4 + 3] = (byte)var4;
        }

        if (this.mc.theWorld != null && this.mc.thePlayer != null)
        {
            if (!areSettingsLoaded)
            {
                this.lastTime = System.currentTimeMillis();
                this.initializeSettingsFile();
            }

            boolean var9 = false;
            boolean var10 = false;
            if (System.currentTimeMillis() > this.lastTime + 1000L)
            {
                var9 = true;
                ++this.seccounter;
                this.lastTime = System.currentTimeMillis();
            }

            if (!this.noDefaultNeedle)
            {
                this.drawNeedle(0, this.computeNeedleHeading(this.mc.theWorld.getSpawnPoint()), this.spawnNeedlecolor, true);
            }

            if (!this.noEnderEyeNeedle)
            {
                this.drawNeedle(1, this.computeNeedleHeading(this.nextStronghold), this.strongholdNeedlecolor, false);
            }

            if ((int)this.mc.thePlayer.posX != this.x || (int)this.mc.thePlayer.posY != this.y || (int)this.mc.thePlayer.posZ != this.z)
            {
                this.x = (int)this.mc.thePlayer.posX;
                this.y = (int)this.mc.thePlayer.posY;
                this.z = (int)this.mc.thePlayer.posZ;
                this.updateScan = true;
            }

            if (this.updateScan && var9 && this.seccounter > 14)
            {
                this.seccounter = 0;
                var10 = true;
                this.nextStronghold = this.getStrongholdChunk();
            }

            int[] var11;
            ChunkCoordinates var12;
            Iterator var13;
            Entry var14;
            if (this.updateScan && var9)
            {
                this.updateScan = false;
                var13 = customNeedles.entrySet().iterator();

                while (var13.hasNext())
                {
                    var14 = (Entry)var13.next();
                    var2 = ((Integer)var14.getKey()).intValue();
                    var11 = (int[])((int[])((int[])((int[])((int[])((int[])var14.getValue())))));
                    if (var10 || var11[7] == 0)
                    {
                        var12 = this.findNearestBlockChunkOfIDInRange(var2, this.x, this.y, this.z, var11[3], var11[4], var11[5], var11[6]);
                        if (!var12.equals(this.NullChunk))
                        {
                            if (customNeedleTargets.containsKey(var11))
                            {
                                customNeedleTargets.remove(var11);
                            }

                            customNeedleTargets.put(var11, var12);
                        }
                        else
                        {
                            customNeedleTargets.remove(var11);
                        }
                    }
                }
            }

            var1 = 3;
            var13 = customNeedleTargets.entrySet().iterator();

            while (var13.hasNext())
            {
                var14 = (Entry)var13.next();
                var11 = (int[])((int[])((int[])((int[])((int[])((int[])var14.getKey())))));
                var12 = (ChunkCoordinates)var14.getValue();
                ++var1;
                this.drawNeedle(var1, this.computeNeedleHeading(var12), var11, false);
            }
        }
    }

    public double computeNeedleHeading(ChunkCoordinates var1)
    {
        double var2 = 0.0D;
        if (this.mc.theWorld != null && this.mc.thePlayer != null)
        {
            double var4 = (double)var1.posX - this.mc.thePlayer.posX;
            double var6 = (double)var1.posZ - this.mc.thePlayer.posZ;
            var2 = (double)(this.mc.thePlayer.rotationYaw - 90.0F) * 3.141592653589793D / 180.0D - Math.atan2(var6, var4);
            if (this.mc.theWorld.worldProvider.isAlternateDimension)
            {
                var2 = Math.random() * 3.1415927410125732D * 2.0D;
            }
        }

        return var2;
    }

    public void drawNeedle(int var1, double var2, int[] var4, boolean var5)
    {
    	double needleLength = modState == 2 ? 0.3D * (this.tilesize_intsize / 16) : 0.3D;
    	
        double var6;
        for (var6 = var2 - this.textureId[var1]; var6 < -3.141592653589793D; var6 += 6.283185307179586D)
        {
            ;
        }

        while (var6 >= 3.141592653589793D)
        {
            var6 -= 6.283185307179586D;
        }

        if (var6 < -1.0D)
        {
            var6 = -1.0D;
        }

        if (var6 > 1.0D)
        {
            var6 = 1.0D;
        }

        this.textureId[var1] += var6 * 0.1D;
        this.tileSize[var1] *= 0.8D;
        this.tileSize[var1] += this.textureId[var1];
        double var8 = Math.sin(this.textureId[var1]);
        double var10 = Math.cos(this.textureId[var1]);
        int var12;
        int var13;
        int var14;
        int var15;
        int var17;
        int var16;
        short var19;
        int var18;
        int var21;
        int var20;
        int var22;
        if (var5)
        {
            for (var12 = this.tileSize_int_compassCrossMin; var12 <= this.tileSize_int_compassCrossMax; ++var12)
            {
                var13 = (int)(this.tileSize_double_compassCenterMax + var10 * (double)var12 * needleLength);
                var14 = (int)(this.tileSize_double_compassCenterMin - var8 * (double)var12 * needleLength * 0.5D);
                var15 = var14 * this.tilesize_intsize + var13;
                var16 = 100;
                var17 = 100;
                var18 = 100;
                var19 = 255;
                if (this.anaglyphEnabled)
                {
                    var20 = (var16 * 30 + var17 * 59 + var18 * 11) / 100;
                    var21 = (var16 * 30 + var17 * 70) / 100;
                    var22 = (var16 * 30 + var18 * 70) / 100;
                    var16 = var20;
                    var17 = var21;
                    var18 = var22;
                }

                this.imageData[var15 * 4 + 0] = (byte)var16;
                this.imageData[var15 * 4 + 1] = (byte)var17;
                this.imageData[var15 * 4 + 2] = (byte)var18;
                this.imageData[var15 * 4 + 3] = (byte)var19;
            }
        }

        for (var12 = this.tileSize_int_compassNeedleMin; var12 <= this.tileSize_int_compassNeedleMax; ++var12)
        {
            var13 = (int)(this.tileSize_double_compassCenterMax + var8 * (double)var12 * needleLength);
            var14 = (int)(this.tileSize_double_compassCenterMin + var10 * (double)var12 * needleLength * 0.5D);
            var15 = var14 * this.tilesize_intsize + var13;
            var16 = var12 < 0 ? 100 : var4[0];
            var17 = var12 < 0 ? 100 : var4[1];
            var18 = var12 < 0 ? 100 : var4[2];
            var19 = 255;
            if (this.anaglyphEnabled)
            {
                var20 = (var16 * 30 + var17 * 59 + var18 * 11) / 100;
                var21 = (var16 * 30 + var17 * 70) / 100;
                var22 = (var16 * 30 + var18 * 70) / 100;
                var16 = var20;
                var17 = var21;
                var18 = var22;
            }

            this.imageData[var15 * 4 + 0] = (byte)var16;
            this.imageData[var15 * 4 + 1] = (byte)var17;
            this.imageData[var15 * 4 + 2] = (byte)var18;
            this.imageData[var15 * 4 + 3] = (byte)var19;
        }
    }

    void initializeSettingsFile()
    {
        settingsFile = new File(Minecraft.getAppDir("minecraft"), "findercompass.cfg");
        System.out.println("initializeSettingsFile() running");

        try
        {
            if (settingsFile.exists())
            {
                System.out.println(".minecraft/findercompass.cfg found and opened");
                BufferedReader var1 = new BufferedReader(new FileReader(settingsFile));

                String var2;
                while ((var2 = var1.readLine()) != null)
                {
                    if (!var2.startsWith("//"))
                    {
                        if (var2.contentEquals("NoDefaultNeedle"))
                        {
                            this.noDefaultNeedle = true;
                            System.out.println("Disabling Default Needle as per config file");
                        }
                        else if (var2.contentEquals("NoEnderEyeNeedle"))
                        {
                            this.noEnderEyeNeedle = true;
                            System.out.println("Disabling Ender Eye Needle as per config file");
                        }
                        else
                        {
                            String[] var3 = var2.split(":");
                            int var4 = Integer.parseInt(var3[0]);
                            int[] var5 = new int[8];
                            var5[0] = Integer.parseInt(var3[1]);
                            var5[1] = Integer.parseInt(var3[2]);
                            var5[2] = Integer.parseInt(var3[3]);
                            System.out.println("Finder Compass: loaded custom needle of id " + var4 + ", color [" + var5[0] + "," + var5[1] + "," + var5[2]);
                            var5[3] = Integer.parseInt(var3[4]);
                            var5[4] = Integer.parseInt(var3[5]);
                            var5[5] = Integer.parseInt(var3[6]);
                            var5[6] = Integer.parseInt(var3[7]);
                            var5[7] = Integer.parseInt(var3[8]);
                            System.out.println("Full readout: " + var5[0] + ":" + var5[1] + ":" + var5[2] + ":" + var5[3] + ":" + var5[4] + ":" + var5[5] + ":" + var5[6] + ":" + var5[7]);
                            customNeedles.put(Integer.valueOf(var4), var5);
                        }
                    }
                }

                var1.close();
            }
            else
            {
                this.mc.ingameGUI.addChatMessage(".minecraft/findercompass.cfg not found, Finder Compass NOT ACTIVE");
            }
        }
        catch (Exception var6)
        {
            System.out.println("EXCEPTION BufferedReader: " + var6);
        }

        this.mc.ingameGUI.addChatMessage("Finder Compass config loaded; " + customNeedles.size() + " custom needles loaded");
        System.out.println("config file reading finished");
        areSettingsLoaded = true;
    }

    ChunkCoordinates findNearestBlockChunkOfIDInRange(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8)
    {
        List var9 = this.findBlocksOfIDInRange(var1, var2, var3, var4, var5, var6, var7, var8);
        ChunkCoordinates var10 = new ChunkCoordinates(var2, var3, var4);
        ChunkCoordinates var11 = new ChunkCoordinates(0, 0, 0);
        double var12 = 9999.0D;

        for (int var14 = 0; var14 < var9.size(); ++var14)
        {
            ChunkCoordinates var15 = (ChunkCoordinates)var9.get(var14);
            double var16 = this.GetDistanceBetweenChunks(var10, var15);
            if (var16 < var12)
            {
                var11 = var15;
                var12 = var16;
            }
        }

        ChunkCoordinates var18 = new ChunkCoordinates(var11.posX, var11.posY, var11.posZ);
        return var18;
    }

    List findBlocksOfIDInRange(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8)
    {
        ArrayList var9 = new ArrayList();

        for (int var10 = var3 - var6 - 1; var10 <= var3 + var6; ++var10)
        {
            if (var10 >= var7 && var10 <= var8)
            {
                for (int var11 = var4 - var5; var11 <= var4 + var5; ++var11)
                {
                    for (int var12 = var2 - var5; var12 <= var2 + var5; ++var12)
                    {
                        if (this.mc.theWorld.getBlockId(var12, var10, var11) == var1)
                        {
                            ChunkCoordinates var13 = new ChunkCoordinates(var12, var10, var11);
                            var9.add(var13);
                        }
                    }
                }
            }
        }

        return var9;
    }

    double GetDistanceBetweenChunks(ChunkCoordinates var1, ChunkCoordinates var2)
    {
        int var3 = Math.abs(var1.posX - var2.posX);
        int var4 = Math.abs(var1.posY - var2.posY);
        int var5 = Math.abs(var1.posZ - var2.posZ);
        return Math.sqrt(Math.pow((double)var3, 2.0D) + Math.pow((double)var4, 2.0D) + Math.pow((double)var5, 2.0D));
    }
}
