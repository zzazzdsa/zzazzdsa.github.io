// This file ONLY tells you what and where this mod specifically adds to the minecraft sourcecode.


public class ChunkCache
    implements IBlockAccess
{

	public int getSkyBlockTypeBrightness(EnumSkyBlock var1, int var2, int var3, int var4)
	{
		//replace:
				return this.chunkArray[var5][var6].getSavedLightValue(var1, var2 & 15, var3, var4 & 15);
		
		//with:
	       		int retVal = this.chunkArray[var5][var6].getSavedLightValue(var1, var2 & 15, var3, var4 & 15);
	    		
	    		if (var1 == EnumSkyBlock.Sky)
	    		{
	    			return retVal;
	    		}
	    		else
	    		{
	    			int cached = LightCache.cache.getLightValue(var2, var3, var4);
	    			if (cached > retVal) return cached;
	
	    			int torchLight = (int)java.lang.Math.round(PlayerTorchArray.getLightBrightness(worldObj, var2, var3, var4));
	    			if(retVal < torchLight)
	    			{
	    				return torchLight;
	    			}
	    		}
	    		
	    		LightCache.cache.setLightValue(var2, var3, var4, retVal);
	    		return retVal;

	}
	
}
