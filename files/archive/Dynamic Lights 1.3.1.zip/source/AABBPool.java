// This file ONLY tells you what and where this mod specifically adds to the minecraft sourcecode.

// hooking AxisAlignedBB.clearBoundingBoxPool was a backdoor into Minecraft.run(), no longer applicable as of 1.3.1
// but the same method is now found at AABBPool
// clearPool() is not called for the integrated server, thankfully

public class AABBPool
{	
    public static void clearPool()
    {
        this.nextPoolIndex = 0;
        this.listAABB.clear();
		
		// ADD THESE IN HERE
		prevFrameTimeForAvg = System.nanoTime();
		tFrameTimes[nextFrameTime] = prevFrameTimeForAvg;
		nextFrameTime = ((nextFrameTime + 1) % 60);
    }
	
	// new global objects
	private static int nextFrameTime;
	private static long prevFrameTimeForAvg;
	private static long[] tFrameTimes = new long[60];
	
	// add this function
	public static long getAvgFrameTime()
	{
		if (tFrameTimes[nextFrameTime] != 0L)
		{
			return (prevFrameTimeForAvg - tFrameTimes[nextFrameTime]) / 60L;
		}
		return 23333333L;
	}

}
