// This file ONLY tells you what and where this mod specifically adds to the minecraft sourcecode.

// this was a requested feature, Creepers light up when they try and explode

public class EntityCreeper extends EntityMob
{
	// global field
	private PlayerTorch creeperLight;
	
	// into constructor
    public EntityCreeper(World par1World)
    {
		//...
        creeperLight = new PlayerTorch(this);
    	PlayerTorchArray.registerDynamicLight(creeperLight);
    	creeperLight.setTorchState(worldObj, false);
    }
	
    public void onUpdate()
    {
		//...
                // after: this.worldObj.playSoundAtEntity(this, "random.fuse", 1.0F, 0.5F);
                if (worldObj.isRemote) // this makes sure it only runs on client
                {
                	creeperLight.setTorchState(worldObj, true);
                }
		
		// somewhere in onUpdate, var1 is the this.getCreeperState() local var
		if (worldObj.isRemote && var1 == -1)
        {
            creeperLight.setTorchState(worldObj, false);
        }
	}
}
