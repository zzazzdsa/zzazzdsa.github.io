package net.minecraft.src.atomicstryker.ropesplus;

import net.minecraft.src.Item;
import net.minecraft.src.forge.ITextureProvider;

public class ItemRope extends Item implements ITextureProvider
{
    public ItemRope(int i)
    {
        super(i);
    }

	@Override
	public String getTextureFile()
	{
		return "/atomicstryker/ropesplus/ropesPlusItems.png";
	}
}
