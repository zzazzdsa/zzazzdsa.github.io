package net.minecraft.src;

import java.io.*;
import java.net.*;
import java.security.*;
import java.util.*;

import org.lwjgl.input.Keyboard;

import net.minecraft.client.Minecraft;
import net.minecraft.src.*;
import net.minecraft.src.atomicstryker.ForgePacketWrapper;
import net.minecraft.src.atomicstryker.ropesplus.*;
import net.minecraft.src.forge.*;

public class mod_RopesPlus extends NetworkMod implements IConnectionHandler, IPacketHandler
{
	public static RopesPlusCore core;
	
	// Rope mod part
	public static int idRopeBlock;
	public static Block ropeBlock;
	public static List ropeEntArray = new ArrayList();
	public static List ropePosArray = new ArrayList();
	
	// Grappling Hook mod part
	public static Block blockRope;
	public static Block blockGrapplingHook;
	public static Item itemRope;
	public static Item itemGrapplingHook;
	public static Map grapplingHooks = new HashMap();
	
	// 303 Arrows part
	public static mod_RopesPlus inst;
	public static Minecraft mc = ModLoader.getMinecraftInstance();
	
	public Map toggleMap;
	public EntityArrow303 selectedArrow;
	public static int arrowCount;
	public int selectedSlot;
	public boolean cycled;
	public boolean loading;
	public EntityPlayer prevPlayer;
	public GuiScreen prevScreen;
	
	private String keyNameForward;
	private String keyNameBackward;
	
	@Override
	public void load()
	{
		AS_Settings_RopePlus.InitSettings();
		
		keyNameForward = Keyboard.getKeyName(AS_Settings_RopePlus.keyforward);
		keyNameBackward = Keyboard.getKeyName(AS_Settings_RopePlus.keyback);
		
        MinecraftForgeClient.preloadTexture("/atomicstryker/ropesplus/ropesPlusItems.png");
        MinecraftForgeClient.preloadTexture("/atomicstryker/ropesplus/ropesPlusBlocks.png");
		
		// Rope mod part
		itemRope = new ItemRope(AS_Settings_RopePlus.itemIdRope).setIconIndex(16).setItemName("itemRope");
		idRopeBlock = AS_Settings_RopePlus.blockIdRopeDJRoslin;
		ropeBlock = (new BlockRope(idRopeBlock, 1)).setHardness(0.3F).setStepSound(Block.soundMetalFootstep).setBlockName("rope");
		ModLoader.addName(ropeBlock, "Rope");

		// Grappling Hook mod part
		itemGrapplingHook = new ASItemGrapplingHook(AS_Settings_RopePlus.itemIdGrapplingHook).setIconIndex(13).setItemName("itemGrapplingHook");
		blockRope = (new ASBlockRope(AS_Settings_RopePlus.blockIdRope, 1, ModLoader.getUniqueBlockModelID(this, false))).setHardness(0.5F).setStepSound(Block.soundClothFootstep).setBlockName("blockRope");
		blockGrapplingHook = (new ASBlockGrapplingHook(AS_Settings_RopePlus.blockIdGrapplingHook, 0, ModLoader.getUniqueBlockModelID(this, false))).setHardness(0.0F).setStepSound(Block.soundMetalFootstep).setBlockName("blockGrapplingHook");
		ModLoader.addName(blockRope, "GrHk Rope");
		ModLoader.addName(blockGrapplingHook, "Grappling Hook");
		ModLoader.addName(itemRope, "GrHk Rope");
		ModLoader.addName(itemGrapplingHook, "Grappling Hook");

		// 303 Arrows part
		toggleMap = new HashMap();
		cycled = false;
		inst = this;
		
		core = new RopesPlusCore();
		RopesPlusCore.load(this);
		
		ModLoader.setInGameHook(this, true, false);
	}

	@Override
	public boolean onTickInGame(float derp, net.minecraft.client.Minecraft mc)
	{
		for(int x = 0; x < ropeEntArray.size(); x++)
		{
			Object temp = ropeEntArray.get(x);
			if (temp instanceof BlockRopePseudoEnt)
			{
				if (((BlockRopePseudoEnt) temp).OnUpdate())
				{
					ropeEntArray.remove(x);
				}
			}
			else if (temp instanceof ASTileEntityRope)
			{
				if (((ASTileEntityRope) temp).OnUpdate())
				{
					ropeEntArray.remove(x);
				}
			}
		}

		if(prevPlayer != mc.thePlayer || prevScreen != mc.currentScreen)
		{
			prevPlayer = mc.thePlayer;
			prevScreen = mc.currentScreen;
			selectArrow();
		}
		if(mc.currentScreen == null)
		{
			ItemStack itemstack = mc.thePlayer.getCurrentEquippedItem();
			if(itemstack != null && (itemstack.itemID == Item.bow.shiftedIndex || itemstack.itemID == RopesPlusCore.bowRopesPlus.shiftedIndex))
			{
				boolean pressingForward = Keyboard.isKeyDown(AS_Settings_RopePlus.keyforward);
				boolean pressingBackward = Keyboard.isKeyDown(AS_Settings_RopePlus.keyback);
				if(cycled)
				{
					if(!pressingForward && !pressingBackward)
					{
						cycled = false;
					}
				}
				else
				{
					cycled = true;
					if(pressingForward)
					{
						cycle(false);
					}
					else if(pressingBackward)
					{
						cycle(true);
					}
					else
					{
						cycled = false;
					}
				}
				if(selectedArrow == null)
				{
					return true;
				}
				
				String s = selectedArrow.name;
				if (arrowCount == -1)
				{
					arrowCount = countArrows(selectedArrow);
				}
				s = (new StringBuilder()).append(s).append("x").append(arrowCount).toString();
				mc.fontRenderer.drawStringWithShadow(s, 2, 10, 0x2F96EB);
				mc.fontRenderer.drawStringWithShadow("Swap arrows with "+keyNameForward+", "+keyNameBackward, 2, 20, 0xffffff);
			}
		}

		return true;
	}

	@Override
	public String getVersion()
	{
		return RopesPlusCore.getVersion();
	}

	@Override
	public void addRenderer(Map map)
	{
		map.put(ASEntityGrapplingHook.class, new ASRenderGrapplingHook());

		EntityArrow303 entityarrow303;
		for(Iterator iterator = RopesPlusCore.arrows.iterator(); iterator.hasNext(); map.put(entityarrow303.getClass(), entityarrow303.renderer))
		{
			entityarrow303 = (EntityArrow303)iterator.next();
		}
	}

	@Override
	public void modsLoaded()
	{
		RopesPlusCore.modsLoaded();
	}

	@Override
	public boolean dispenseEntity(World world, double d, double d1, double d2, 
			int i, int j, ItemStack itemstack)
	{
		return RopesPlusCore.dispenseEntity(world, d, d1, d2, i, j, itemstack);
	}

	public void selectArrow()
	{
		if(mc.thePlayer == null)
		{
			selectedArrow = null;
			selectedSlot = 0;
		}
		findNextArrow(true);
		if(selectedArrow == null)
		{
			cycle(true);
		}
	}

	public void findNextArrow(boolean flag)
	{
		EntityArrow303 entityarrow303 = selectedArrow;
		int i = selectedSlot;
		findNextArrowBetween(entityarrow303, i, 1, mc.thePlayer.inventory.mainInventory.length, flag);
		if(selectedArrow == null)
		{
			findNextArrowBetween(entityarrow303, 0, 1, i, flag);
		}
	}

	public void findPrevArrow()
	{
		EntityArrow303 entityarrow303 = selectedArrow;
		int i = selectedSlot;
		findNextArrowBetween(entityarrow303, i, -1, -1, false);
		if(selectedArrow == null)
		{
			findNextArrowBetween(entityarrow303, mc.thePlayer.inventory.mainInventory.length - 1, -1, i + 1, false);
		}
	}

	public void findNextArrowBetween(EntityArrow303 previousarrow303, int i, int j, int k, boolean dontKeepArrowType)
	{
		for(int l = i; j > 0 && l < k || l > k; l += j)
		{
			ItemStack itemstack = mc.thePlayer.inventory.mainInventory[l];
			if(itemstack == null)
			{
				continue;
			}
			Item item = itemstack.getItem();
			
			if(item == null)
			{
				continue;
			}
			
			if (!(item instanceof ItemArrow303) && !(item.shiftedIndex == Item.arrow.shiftedIndex))
			{				
				continue;
			}
			
			if (item.shiftedIndex == Item.arrow.shiftedIndex)
			{
				EntityArrow303 itemarrow303 = new EntityArrow303(mc.theWorld);
				if(previousarrow303 == null || previousarrow303.tip != itemarrow303.tip)
				{
					selectedArrow = itemarrow303;
					selectedSlot = l;
					SendPacketToUpdateArrowChoice();
					return;
				}
				continue;
			}
			
			ItemArrow303 itemarrow303 = (ItemArrow303)item;
			if(previousarrow303 == null || dontKeepArrowType && itemarrow303.arrow == previousarrow303 || !dontKeepArrowType && itemarrow303.arrow != previousarrow303)
			{
				selectedArrow = itemarrow303.arrow;
				selectedSlot = l;
				SendPacketToUpdateArrowChoice();
				return;
			}
		}
		selectedArrow = null;
		selectedSlot = 0;
	}

	public int countArrows(EntityArrow303 entityarrow303)
	{
		int i = 0;
		InventoryPlayer inventoryplayer = mc.thePlayer.inventory;
		ItemStack aitemstack[] = inventoryplayer.mainInventory;
		int j = aitemstack.length;
		for(int k = 0; k < j; k++)
		{
			ItemStack itemstack = aitemstack[k];
			if(itemstack != null && itemstack.itemID == entityarrow303.itemId)
			{
				i += itemstack.stackSize;
			}
		}

		return i;
	}

	public void SendPacketToUpdateArrowChoice() // TODO vanilla arrow?
	{
		arrowCount = -1;
		Object[] toSend = {selectedSlot};
		ModLoader.sendPacket(ForgePacketWrapper.createPacket(RopesPlusCore.getPacketChannel(), 1, toSend));
	}

	public void cycle(boolean directionForward)
	{
		EntityArrow303 previousarrow303 = selectedArrow;
		int i = selectedSlot;
		if(directionForward)
		{
			findNextArrow(false);
		}
		else
		{
			findPrevArrow();
		}
		
		ItemStack itemstack;
		Item item;
		
		if(selectedArrow == null
		&& previousarrow303 != null
		&& (itemstack = mc.thePlayer.inventory.mainInventory[i]) != null
		&& ((item = itemstack.getItem()) instanceof ItemArrow303)
		&& ((ItemArrow303)item).arrow == previousarrow303)
		{
			selectedArrow = previousarrow303;
			selectedSlot = i;
			System.out.println("client cycle");
			SendPacketToUpdateArrowChoice();
		}
	}

	@Override
	public boolean renderWorldBlock(RenderBlocks renderblocks, IBlockAccess iblockaccess, int i, int j, int k, Block block, int l)
	{
		try
		{
			if(l == blockGrapplingHook.getRenderType())
			{
				return renderGrapplingHook(renderblocks, block, i, j, k, iblockaccess);
			}
			else if (l == blockRope.getRenderType())
			{
				return renderBlockWallRope(renderblocks, block, i, j, k, iblockaccess);
			}
		}
		catch(Exception exception)
		{
			ModLoader.getLogger().throwing("mod_ASGrapplingHook", "RenderWorldBlock", exception);
			return false;
		}
		return false;
	}

	public static boolean renderGrapplingHook(RenderBlocks renderblocks, Block block, int i, int j, int k, IBlockAccess iblockaccess)
	{
		int l = block.colorMultiplier(iblockaccess, i, j, k);
		float f = (float)(l >> 16 & 0xff) / 255F;
		float f1 = (float)(l >> 8 & 0xff) / 255F;
		float f2 = (float)(l & 0xff) / 255F;
		return renderGrapplingHook2(renderblocks, block, i, j, k, f, f1, f2, iblockaccess);
	}

	public static boolean renderGrapplingHook2(RenderBlocks renderblocks, Block block, int i, int j, int k, float f, float f1, float f2, 
			IBlockAccess iblockaccess)
	{
		Tessellator tessellator = Tessellator.instance;
		boolean flag = false;
		float f3 = 1.0F;
		float f4 = f3 * f;
		float f5 = f3 * f1;
		float f6 = f3 * f2;
		if(block == Block.grass)
		{
			f = f1 = f2 = 1.0F;
		}
		float f7 = block.getMixedBrightnessForBlock(iblockaccess, i, j, k);
		int l = iblockaccess.getBlockMetadata(i, j, k);
		if(block.shouldSideBeRendered(iblockaccess, i, j + 1, k, 1))
		{
			float f8 = block.getMixedBrightnessForBlock(iblockaccess, i, j + 1, k);
			if(block.maxY != 1.0D && !block.blockMaterial.isLiquid())
			{
				f8 = f7;
			}
			tessellator.setColorOpaque_F(f4 * f8, f5 * f8, f6 * f8);

			tessellator.setBrightness(block.getMixedBrightnessForBlock(iblockaccess, i, j, k));
			tessellator.setColorOpaque_F(1.0F, 1.0F, 1.0F);

			int i1 = block.getBlockTexture(iblockaccess, i, j, k, 1);
			renderGrapplingHook3(block, i, j, k, i1, l);
			flag = true;
		}
		return flag;
	}

	public static void renderGrapplingHook3(Block block, double d, double d1, double d2, int i, 
			int blockMeta)
	{
		Tessellator tessellator = Tessellator.instance;
		int k = (i & 0xf) << 4;
		int l = i & 0xf0;
		double d3 = ((double)k + block.minX * 16D) / 256D;
		double d4 = (((double)k + block.maxX * 16D) - 0.01D) / 256D;
		double d5 = ((double)l + block.minZ * 16D) / 256D;
		double d6 = (((double)l + block.maxZ * 16D) - 0.01D) / 256D;
		if(block.minX < 0.0D || block.maxX > 1.0D)
		{
			d3 = ((float)k + 0.0F) / 256F;
			d4 = ((float)k + 15.99F) / 256F;
		}
		if(block.minZ < 0.0D || block.maxZ > 1.0D)
		{
			d5 = ((float)l + 0.0F) / 256F;
			d6 = ((float)l + 15.99F) / 256F;
		}
		double d7 = d + block.minX;
		double d8 = d + block.maxX;
		double d9 = d1 + block.maxY;
		double d10 = d2 + block.minZ;
		double d11 = d2 + block.maxZ;

		switch(blockMeta)
		{
		case 1:
			double d13 = d5;
			d5 = d6;
			d6 = d13;
			break;

		case 2: // '\002'
			double d12 = d5;
			d5 = d6;
			d6 = d12;
			d12 = d3;
			d3 = d4;
			d4 = d12;
			break;

		case 5: // '\005'
			double d14 = d3;
			d3 = d4;
			d4 = d14;
			break;
		}
		tessellator.addVertexWithUV(d8, d9, d11, d4, d6);
		tessellator.addVertexWithUV(d8, d9, d10, d4, d5);
		tessellator.addVertexWithUV(d7, d9, d10, d3, d5);
		tessellator.addVertexWithUV(d7, d9, d11, d3, d6);
	}
	
    public boolean renderBlockWallRope(RenderBlocks renderblocks, Block block, int i, int j, int k, IBlockAccess iblockaccess)
    {
        Tessellator var5 = Tessellator.instance;
        int var6 = block.getBlockTextureFromSide(0);

        /*
        if (this.overrideBlockTexture >= 0)
        {
            var6 = this.overrideBlockTexture;
        }
        */

        float var7 = 1.0F;
        var5.setBrightness(block.getMixedBrightnessForBlock(iblockaccess, i, j, k));
        int var8 = block.colorMultiplier(iblockaccess, i, j, k);
        float var9 = (float)(var8 >> 16 & 255) / 255.0F;
        float var10 = (float)(var8 >> 8 & 255) / 255.0F;
        float var11 = (float)(var8 & 255) / 255.0F;
        var5.setColorOpaque_F(var7 * var9, var7 * var10, var7 * var11);
        var8 = (var6 & 15) << 4;
        int var21 = var6 & 240;
        double var22 = (double)((float)var8 / 256.0F);
        double var12 = (double)(((float)var8 + 15.99F) / 256.0F);
        double var14 = (double)((float)var21 / 256.0F);
        double var16 = (double)(((float)var21 + 15.99F) / 256.0F);
        double var18 = 0.05000000074505806D;
        int var20 = iblockaccess.getBlockMetadata(i, j, k);

        if ((var20 & 2) != 0)
        {
            var5.addVertexWithUV((double)i + var18, (double)(j + 1), (double)(k + 1), var22, var14);
            var5.addVertexWithUV((double)i + var18, (double)(j + 0), (double)(k + 1), var22, var16);
            var5.addVertexWithUV((double)i + var18, (double)(j + 0), (double)(k + 0), var12, var16);
            var5.addVertexWithUV((double)i + var18, (double)(j + 1), (double)(k + 0), var12, var14);
            var5.addVertexWithUV((double)i + var18, (double)(j + 1), (double)(k + 0), var12, var14);
            var5.addVertexWithUV((double)i + var18, (double)(j + 0), (double)(k + 0), var12, var16);
            var5.addVertexWithUV((double)i + var18, (double)(j + 0), (double)(k + 1), var22, var16);
            var5.addVertexWithUV((double)i + var18, (double)(j + 1), (double)(k + 1), var22, var14);
        }

        if ((var20 & 8) != 0)
        {
            var5.addVertexWithUV((double)(i + 1) - var18, (double)(j + 0), (double)(k + 1), var12, var16);
            var5.addVertexWithUV((double)(i + 1) - var18, (double)(j + 1), (double)(k + 1), var12, var14);
            var5.addVertexWithUV((double)(i + 1) - var18, (double)(j + 1), (double)(k + 0), var22, var14);
            var5.addVertexWithUV((double)(i + 1) - var18, (double)(j + 0), (double)(k + 0), var22, var16);
            var5.addVertexWithUV((double)(i + 1) - var18, (double)(j + 0), (double)(k + 0), var22, var16);
            var5.addVertexWithUV((double)(i + 1) - var18, (double)(j + 1), (double)(k + 0), var22, var14);
            var5.addVertexWithUV((double)(i + 1) - var18, (double)(j + 1), (double)(k + 1), var12, var14);
            var5.addVertexWithUV((double)(i + 1) - var18, (double)(j + 0), (double)(k + 1), var12, var16);
        }

        if ((var20 & 4) != 0)
        {
            var5.addVertexWithUV((double)(i + 1), (double)(j + 0), (double)k + var18, var12, var16);
            var5.addVertexWithUV((double)(i + 1), (double)(j + 1), (double)k + var18, var12, var14);
            var5.addVertexWithUV((double)(i + 0), (double)(j + 1), (double)k + var18, var22, var14);
            var5.addVertexWithUV((double)(i + 0), (double)(j + 0), (double)k + var18, var22, var16);
            var5.addVertexWithUV((double)(i + 0), (double)(j + 0), (double)k + var18, var22, var16);
            var5.addVertexWithUV((double)(i + 0), (double)(j + 1), (double)k + var18, var22, var14);
            var5.addVertexWithUV((double)(i + 1), (double)(j + 1), (double)k + var18, var12, var14);
            var5.addVertexWithUV((double)(i + 1), (double)(j + 0), (double)k + var18, var12, var16);
        }

        if ((var20 & 1) != 0)
        {
            var5.addVertexWithUV((double)(i + 1), (double)(j + 1), (double)(k + 1) - var18, var22, var14);
            var5.addVertexWithUV((double)(i + 1), (double)(j + 0), (double)(k + 1) - var18, var22, var16);
            var5.addVertexWithUV((double)(i + 0), (double)(j + 0), (double)(k + 1) - var18, var12, var16);
            var5.addVertexWithUV((double)(i + 0), (double)(j + 1), (double)(k + 1) - var18, var12, var14);
            var5.addVertexWithUV((double)(i + 0), (double)(j + 1), (double)(k + 1) - var18, var12, var14);
            var5.addVertexWithUV((double)(i + 0), (double)(j + 0), (double)(k + 1) - var18, var12, var16);
            var5.addVertexWithUV((double)(i + 1), (double)(j + 0), (double)(k + 1) - var18, var22, var16);
            var5.addVertexWithUV((double)(i + 1), (double)(j + 1), (double)(k + 1) - var18, var22, var14);
        }

        return true;
    }

	@Override
	public boolean clientSideRequired()
	{
		return true;
	}

	@Override
	public boolean serverSideRequired()
	{
		return false;
	}

	@Override
	public void onPacketData(NetworkManager network, String channel, byte[] data)
	{

	}

	@Override
	public void onConnect(NetworkManager network)
	{
		MessageManager.getInstance().registerChannel(network, this, RopesPlusCore.getPacketChannel());
	}

	@Override
	public void onLogin(NetworkManager network, Packet1Login login)
	{
	}

	@Override
	public void onDisconnect(NetworkManager network, String message, Object[] args)
	{		
	}
}
