package net.minecraft.src.atomicstryker.ropesplus;

import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.src.*;

public class EntityArrow303Ex extends EntityArrow303
{

    public void subscreen()
    {
    }

    public void setupConfig()
    {
    }

    public void entityInit()
    {
        super.entityInit();
        name = "ExArrow";
        craftingResults = 1;
        itemId = AS_Settings_RopePlus.itemIdArrowExplosion;
        tip = Item.gunpowder;
        item = new ItemStack(itemId, 1, 0);
        spriteFile = "/arrows/exarrow.png";
    }

    public EntityArrow303Ex(World world)
    {
        super(world);
    }

    public EntityArrow303Ex(World world, EntityLiving entityliving)
    {
        super(world, entityliving);
    }

    public EntityArrow303Ex(World world, double d, double d1, double d2)
    {
        super(world, d, d1, d2);
    }

    public boolean onHit()
    {
        worldObj.createExplosion(((Entity) (shooter != null ? ((Entity) (shooter)) : ((Entity) (this)))), posX, posY, posZ, 2.0F);
        setDead();
        return true;
    }

    public void tickFlying() {
        super.tickFlying();
		
        if(true)
		{

            if(rand.nextBoolean()) {
                EntitySmokeFX obj = new EntitySmokeFX(worldObj, posX, posY, posZ, 0.01D, 0.01D, 0.01D, 2.5F);
				obj.motionX = obj.motionZ = obj.motionY = 0.01D;
				obj.renderDistanceWeight = 10D;
				mod_RopesPlus.mc.effectRenderer.addEffect(obj);
            }
			else {
                EntityLavaFX obj = new EntityLavaFX(worldObj, posX, posY, posZ);
				obj.motionX = obj.motionZ = obj.motionY = 0.01D;
				obj.renderDistanceWeight = 10D;
				mod_RopesPlus.mc.effectRenderer.addEffect(obj);
            }
        }
    }
}
