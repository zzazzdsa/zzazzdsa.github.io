package net.minecraft.src.atomicstryker.ropesplus;

import java.util.Random;

import net.minecraft.src.AxisAlignedBB;
import net.minecraft.src.Block;
import net.minecraft.src.IBlockAccess;
import net.minecraft.src.Material;
import net.minecraft.src.World;
import net.minecraft.src.mod_RopesPlus;
import net.minecraft.src.forge.ITextureProvider;


public class ASBlockGrapplingHook extends Block implements ITextureProvider
{

    public ASBlockGrapplingHook(int i, int j, int k)
    {
        super(i, j, Material.wood);
        renderType = k;
        setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.125F, 1.0F);
    }

    public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int i, int j, int k)
    {
        return null;
    }

    public boolean isOpaqueCube()
    {
        return false;
    }

    public boolean renderAsNormalBlock()
    {
        return false;
    }

    public boolean canPlaceBlockAt(World world, int i, int j, int k)
    {
        int l = world.getBlockId(i, j - 1, k);
        if(l == 0 || !Block.blocksList[l].isOpaqueCube())
        {
            return false;
        } else
        {
            return world.getBlockMaterial(i, j - 1, k).isSolid();
        }
    }

    public void onNeighborBlockChange(World world, int i, int j, int k, int l)
    {
        if(!canPlaceBlockAt(world, i, j, k))
        {
            dropBlockAsItem(world, i, j, k, world.getBlockMetadata(i, j, k), 0);
            world.setBlockWithNotify(i, j, k, 0);
            onBlockDestroyed(world, i, j, k);
        }
    }

    public int idDropped(int var1, Random var2, int var3)
    {
        return mod_RopesPlus.itemGrapplingHook.shiftedIndex;
    }

    public int quantityDropped(Random random)
    {
        return 1;
    }

    public int getRenderType()
    {
        return renderType;
    }

    public boolean shouldSideBeRendered(IBlockAccess iblockaccess, int i, int j, int k, int l)
    {
        Material material = iblockaccess.getBlockMaterial(i, j, k);
        if(l == 1)
        {
            return true;
        }
        if(material == blockMaterial)
        {
            return false;
        } else
        {
            return super.shouldSideBeRendered(iblockaccess, i, j, k, l);
        }
    }

    public void onBlockDestroyedByPlayer(World world, int i, int j, int k, int l)
    {
        onBlockDestroyed(world, i, j, k);
    }

    public void onBlockDestroyedByExplosion(World world, int i, int j, int k)
    {
        onBlockDestroyed(world, i, j, k);
    }

    private void onBlockDestroyed(World world, int i, int j, int k)
    {
    	System.out.println("Original Hook break at ["+i+","+j+","+k+"]");
    	
        int candidates[][] = {
            {
                i - 1, j - 1, k
            }, {
                i + 1, j - 1, k
            }, {
                i, j - 1, k - 1
            }, {
                i, j - 1, k + 1
            }
        };
        for(int l = 0; l < candidates.length; l++)
        {
            if(world.getBlockId(candidates[l][0], candidates[l][1], candidates[l][2]) != mod_RopesPlus.blockRope.blockID)
            {
                continue;
            }
            
            System.out.println("Rope found at ["+candidates[l][0]+","+candidates[l][1]+","+candidates[l][2]+"]");
            
            for(int m = candidates[l][1]; world.getBlockId(candidates[l][0], m, candidates[l][2]) == mod_RopesPlus.blockRope.blockID; m--)
            {
                world.setBlockWithNotify(candidates[l][0], m, candidates[l][2], 0);
            }

        }

    }

    private int renderType;

	@Override
	public String getTextureFile()
	{
		return "/atomicstryker/ropesplus/ropesPlusBlocks.png";
	}
}
