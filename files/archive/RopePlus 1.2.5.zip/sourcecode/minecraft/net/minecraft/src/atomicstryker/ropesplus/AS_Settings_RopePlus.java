package net.minecraft.src.atomicstryker.ropesplus;

import java.io.*;
import java.util.*;

import org.lwjgl.input.Keyboard;

import net.minecraft.client.Minecraft;
import net.minecraft.src.forge.Configuration;

public class AS_Settings_RopePlus
{
	public AS_Settings_RopePlus()
	{
		InitSettings();
	}
	
	public static int blockIdRopeDJRoslin = 242;
	public static int blockIdRope = 243;
	public static int blockIdGrapplingHook = 244;
	public static int itemIdRope = 2511;
	public static int itemIdGrapplingHook = 2512;
	public static int keyforward = Keyboard.getKeyIndex("COMMA");
	public static int keyback = Keyboard.getKeyIndex("PERIOD");

	public static int itemIdArrowConfusion = 2513;
	public static int itemIdArrowDirt = 2514;
	public static int itemIdArrowExplosion = 2515;
	public static int itemIdArrowFire = 2516;
	public static int itemIdArrowGrass = 2517;
	public static int itemIdArrowIce = 2518;
	public static int itemIdArrowLaser = 2519;
	public static int itemIdArrowRope = 2520;
	public static int itemIdArrowSlime = 2521;
	public static int itemIdArrowTorch = 2522;
	public static int itemIdArrowWarp = 2523;

	public static boolean settingsLoaded = false;
	
	public static Configuration config;
	
	public static void InitSettings()
	{
		if (settingsLoaded) return;
		settingsLoaded = true;
		
		config = new Configuration(new File(Minecraft.getMinecraftDir(), "config/RopePlus.txt"));
		config.load();
				
		blockIdRope = Integer.parseInt(config.getOrCreateBlockIdProperty("blockIdRope", blockIdRope).value);
		blockIdGrapplingHook = Integer.parseInt(config.getOrCreateBlockIdProperty("blockIdGrapplingHook", blockIdGrapplingHook).value);
		blockIdRopeDJRoslin = Integer.parseInt(config.getOrCreateBlockIdProperty("blockIdRopeDJRoslin", blockIdRopeDJRoslin).value);
		itemIdRope = Integer.parseInt(config.getOrCreateIntProperty("itemIdRope", config.CATEGORY_ITEM, itemIdRope).value);
		itemIdGrapplingHook = Integer.parseInt(config.getOrCreateIntProperty("itemIdGrapplingHook", config.CATEGORY_ITEM, itemIdGrapplingHook).value);
		keyforward = Keyboard.getKeyIndex(config.getOrCreateProperty("keySelectArrowUp", config.CATEGORY_GENERAL, "COMMA").value);
		keyback = Keyboard.getKeyIndex(config.getOrCreateProperty("keySelectArrowDown", config.CATEGORY_GENERAL, "PERIOD").value);
		
        itemIdArrowConfusion = Integer.parseInt(config.getOrCreateIntProperty("itemIdArrowConfusion", config.CATEGORY_ITEM, itemIdArrowConfusion).value);
        itemIdArrowDirt = Integer.parseInt(config.getOrCreateIntProperty("itemIdArrowDirt", config.CATEGORY_ITEM, itemIdArrowDirt).value);
        itemIdArrowExplosion = Integer.parseInt(config.getOrCreateIntProperty("itemIdArrowExplosion", config.CATEGORY_ITEM, itemIdArrowExplosion).value);
        itemIdArrowFire = Integer.parseInt(config.getOrCreateIntProperty("itemIdArrowFire", config.CATEGORY_ITEM, itemIdArrowFire).value);
        itemIdArrowGrass = Integer.parseInt(config.getOrCreateIntProperty("itemIdArrowGrass", config.CATEGORY_ITEM, itemIdArrowGrass).value);
        itemIdArrowIce = Integer.parseInt(config.getOrCreateIntProperty("itemIdArrowIce", config.CATEGORY_ITEM, itemIdArrowIce).value);
        itemIdArrowLaser = Integer.parseInt(config.getOrCreateIntProperty("itemIdArrowLaser", config.CATEGORY_ITEM, itemIdArrowLaser).value);
        itemIdArrowRope = Integer.parseInt(config.getOrCreateIntProperty("itemIdArrowRope", config.CATEGORY_ITEM, itemIdArrowRope).value);
        itemIdArrowSlime = Integer.parseInt(config.getOrCreateIntProperty("itemIdArrowSlime", config.CATEGORY_ITEM, itemIdArrowSlime).value);
        itemIdArrowTorch = Integer.parseInt(config.getOrCreateIntProperty("itemIdArrowTorch", config.CATEGORY_ITEM, itemIdArrowTorch).value);
        itemIdArrowWarp = Integer.parseInt(config.getOrCreateIntProperty("itemIdArrowWarp", config.CATEGORY_ITEM, itemIdArrowWarp).value);
		
		config.save();
	}
}
