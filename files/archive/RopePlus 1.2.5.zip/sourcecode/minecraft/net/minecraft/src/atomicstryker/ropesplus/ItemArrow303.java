package net.minecraft.src.atomicstryker.ropesplus;

import net.minecraft.src.Item;
import net.minecraft.src.forge.ITextureProvider;

public class ItemArrow303 extends Item implements ITextureProvider
{
	public EntityArrow303 arrow;

    public ItemArrow303(int i, EntityArrow303 entityarrow303)
    {
        super(i);
        arrow = entityarrow303;
    }

	@Override
	public String getTextureFile()
	{
		return "/atomicstryker/ropesplus/ropesPlusItems.png";
	}
}
