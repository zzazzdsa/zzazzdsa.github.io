package net.minecraft.src.atomicstryker.ropesplus;

import net.minecraft.src.*;

public class EntityArrow303Dirt extends EntityArrow303
{

    public void subscreen()
    {
    }

    public void setupConfig()
    {
    }

    public void entityInit()
    {
        super.entityInit();
        name = "DirtArrow";
        craftingResults = 1;
        itemId = AS_Settings_RopePlus.itemIdArrowDirt;
        tip = Block.dirt;
        item = new ItemStack(itemId, 1, 0);
        spriteFile = "/arrows/dirtarrow.png";
    }

    public EntityArrow303Dirt(World world)
    {
        super(world);
    }

    public EntityArrow303Dirt(World world, EntityLiving entityliving)
    {
        super(world, entityliving);
    }

    public EntityArrow303Dirt(World world, double d, double d1, double d2)
    {
        super(world, d, d1, d2);
    }

    public boolean onHit()
    {
        spawnDirt();
        return true;
    }

    public boolean onHitBlock()
    {
    	setDead();
        return true;
    }

    public void spawnDirt()
    {

        int i = MathHelper.floor_double(posX);
        int j = MathHelper.floor_double(posY);
        int k = MathHelper.floor_double(posZ);
        for(int l = -0; l <= 0; l++)
        {
            for(int i1 = -0; i1 <= 0; i1++)
            {
                for(int j1 = -0; j1 <= 0; j1++)
                {
                    int k1 = i + l;
                    int l1 = j + j1;
                    int i2 = k + i1;

                    if(Math.abs(l) != 0 && Math.abs(j1) != 0 && Math.abs(i1) != 0)
                    {
                        continue;
                    }
                    if(!worldObj.canBlockBePlacedAt(defaultBlockId, k1, l1, i2, true, Block.dirt.blockID))
                    {
                        continue;
                    }
                    worldObj.setBlockWithNotify(k1, l1, i2, Block.dirt.blockID);
                    break;
                }

            }

        }

    }

    public void tickFlying()
    {
        super.tickFlying();
    }

    public static final int defaultBlockId;

    static 
    {
        defaultBlockId = Block.dirt.blockID;
    }
}
