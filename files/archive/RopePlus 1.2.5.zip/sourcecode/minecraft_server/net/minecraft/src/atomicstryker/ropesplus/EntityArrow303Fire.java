package net.minecraft.src.atomicstryker.ropesplus;

import java.util.Random;
import net.minecraft.src.*;

public class EntityArrow303Fire extends EntityArrow303
{

    public EntityArrow303Fire(World world)
    {
        super(world);
    }

    public EntityArrow303Fire(World world, EntityLiving entityliving)
    {
        super(world, entityliving);
    }

    public EntityArrow303Fire(World world, double d, double d1, double d2)
    {
        super(world, d, d1, d2);
    }

    public void entityInit()
    {
        super.entityInit();
        name = "FiArrow";
        craftingResults = 1;
        itemId = AS_Settings_RopePlus.itemIdArrowFire;
        tip = Item.coal;
        item = new ItemStack(itemId, 1, 0);
        spriteFile = "/arrows/fiarrow.png";
    }

    public boolean onHit()
    {
        if(tryToPlaceBlock((EntityPlayer)shooter, 51))
        {
        	setDead();
        }
        return true;
    }

    public boolean onHitTarget(Entity entity)
    {
    	entity.setFire(300/20);
        return true;
    }

    public void tickFlying()
    {
        super.tickFlying();
    }
}
