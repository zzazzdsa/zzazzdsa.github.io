package net.minecraft.src.atomicstryker.ropesplus;

import java.util.Map;
import java.util.Random;

import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.World;
import net.minecraft.src.mod_RopesPlus;


public class ASItemGrapplingHook extends Item
{

    public ASItemGrapplingHook(int i)
    {
        super(i);
        maxStackSize = 1;
    }

    public boolean isFull3D()
    {
        return true;
    }

    public boolean shouldRotateAroundWhenRendering()
    {
        return true;
    }

    public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer)
    {
        if(mod_RopesPlus.grapplingHooks.get(entityplayer) != null)
        {
            int i = ((ASEntityGrapplingHook)mod_RopesPlus.grapplingHooks.get(entityplayer)).recallHook();
            entityplayer.swingItem();
        }
		else
        {
            world.playSoundAtEntity(entityplayer, "random.hurt", 1.0F, 1.0F / (itemRand.nextFloat() * 0.1F + 0.95F));
            if(!world.isRemote)
            {
                world.spawnEntityInWorld(new ASEntityGrapplingHook(world, entityplayer));
            }
            entityplayer.swingItem();
        }
        return itemstack;
    }
}
