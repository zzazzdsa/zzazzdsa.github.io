package net.minecraft.src.atomicstryker.ropesplus;

import net.minecraft.src.*;
import net.minecraft.src.forge.*;

public class ItemBowRopesPlus extends ItemBow
{
	public static ItemStack vanillaBowToRetain;
	
	public ItemBowRopesPlus(int i)
	{
		super(i);
	}
	
    public static void setVanillaBow(ItemStack vanillaBow)
    {
        vanillaBowToRetain = vanillaBow;
    }

    /**
     * called when the player releases the use item button.
     */
    public void onPlayerStoppedUsing(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer, int heldTicks)
    {
    	int arrowSlot = mod_RopesPlus.inst.selectedSlot(par3EntityPlayer);
        if (par3EntityPlayer.inventory.mainInventory[arrowSlot] != null && par3EntityPlayer.inventory.hasItem(par3EntityPlayer.inventory.mainInventory[arrowSlot].itemID))
        {
            int ticksLeftToCharge = this.getMaxItemUseDuration(par1ItemStack) - heldTicks;
            float bowChargeRatio = (float)ticksLeftToCharge / 20.0F;
            bowChargeRatio = (bowChargeRatio * bowChargeRatio + bowChargeRatio * 2.0F) / 3.0F;

            if ((double)bowChargeRatio < 0.1D)
            {
				par3EntityPlayer.inventory.mainInventory[par3EntityPlayer.inventory.currentItem] = vanillaBowToRetain;
                return;
            }

            if (bowChargeRatio > 1.0F)
            {
                bowChargeRatio = 1.0F;
            }
            
    		EntityArrow303 entityarrow303 = null;
    		Item arrowCandidate = par3EntityPlayer.inventory.getStackInSlot(arrowSlot).getItem();
    		if (arrowCandidate != null && arrowCandidate instanceof ItemArrow303)
    		{
    			entityarrow303 = ((ItemArrow303)arrowCandidate).arrow;
    		}
    		if(entityarrow303 == null)
    		{
    			par3EntityPlayer.inventory.mainInventory[par3EntityPlayer.inventory.currentItem] = vanillaBowToRetain;
    			return;
    		}
            
    		EntityArrow303 newArrow = entityarrow303.newArrow(par2World, par3EntityPlayer);

            if (bowChargeRatio == 1.0F)
            {
                newArrow.arrowCritical = true;
            }

            int var9 = EnchantmentHelper.getEnchantmentLevel(Enchantment.power.effectId, par1ItemStack);

            if (var9 > 0)
            {
                newArrow.dmg = (int) Math.rint(newArrow.dmg + (double)var9 * 0.5D + 0.5D);
            }

            if (EnchantmentHelper.getEnchantmentLevel(Enchantment.flame.effectId, par1ItemStack) > 0)
            {
                newArrow.setFire(100);
            }

            par1ItemStack.damageItem(1, par3EntityPlayer);
            par2World.playSoundAtEntity(par3EntityPlayer, "random.bow", 1.0F, 1.0F / (itemRand.nextFloat() * 0.4F + 1.2F) + bowChargeRatio * 0.5F);

            par3EntityPlayer.inventory.consumeInventoryItem(par3EntityPlayer.inventory.mainInventory[arrowSlot].itemID);

            if (!par2World.isRemote)
            {
                par2World.spawnEntityInWorld(newArrow);
            }
        }
        
        // put vanilla bow back in hands, do damage etc
        par3EntityPlayer.inventory.mainInventory[par3EntityPlayer.inventory.currentItem] = vanillaBowToRetain;
        vanillaBowToRetain.damageItem(1, par3EntityPlayer);
    }
    
    /**
     * Called whenever this item is equipped and the right mouse button is pressed. Args: itemStack, world, entityPlayer
     */
    public ItemStack onItemRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer)
    {
    	par3EntityPlayer.setItemInUse(par1ItemStack, this.getMaxItemUseDuration(par1ItemStack));
        return par1ItemStack;
    }
}
