package net.minecraft.src.atomicstryker.ropesplus;

import net.minecraft.src.BaseMod;
import vazkii.um.UpdateManagerMod;

public class RopesPlusUpdater extends UpdateManagerMod
{
    public RopesPlusUpdater(BaseMod m)
    {
        super(m);
    }

    @Override
    public String getUpdateURL()
    {
        return "http://www.atomicstryker.net/updatemanager/version_ropes.txt";
    }

    @Override
    public String getModName()
    {
        return "Ropes+";
    }
}
