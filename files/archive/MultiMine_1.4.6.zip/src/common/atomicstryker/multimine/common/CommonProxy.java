package atomicstryker.multimine.common;

import atomicstryker.multimine.client.MultiMineClient;

public class CommonProxy
{
    public void onLoad()
    {
        // NOOP
    }
}
