// This file ONLY tells you what and where this mod specifically adds to the minecraft sourcecode.

public abstract class EntityPlayer extends EntityLiving
{
	public PlayerTorch playertorch;
	private int carriedItemID;
	
    public EntityPlayer(Minecraft minecraft, World world, Session session, int i)
    {
		playertorch = new PlayerTorch(this);
		PlayerTorchArray.AddTorchToArray(playertorch);
    }

	// the bigger function 3 above from string "Notch"
    public void onLivingUpdate()
    {
		//.....
		if (this.inventory.mainInventory[this.inventory.currentItem] != null)
		{
			int ID = this.inventory.mainInventory[this.inventory.currentItem].itemID;
			
			if (ID != carriedItemID)
			{
				// this is a debug function for modder use.
				//Minecraft.theMinecraft.ingameGUI.addChatMessage("Player Item changed, item now: " + ID);
			
				int brightness = PlayerTorchArray.GetItemBrightnessValue(ID);
				if (brightness > 0)
				{
					this.playertorch.SetTorchBrightness(brightness);
					this.playertorch.SetTorchRange(PlayerTorchArray.GetItemLightRangeValue(ID));
					this.playertorch.setTorchState(this.worldObj, true);
				}
				else
				{
					this.playertorch.setTorchState(this.worldObj, false);
				}
			}
			
			if (this.playertorch.isTorchActive())
			{
				this.playertorch.setTorchPos(this.worldObj, (float)this.posX, (float)this.posY, (float)this.posZ);
			}
		}
		else
			this.playertorch.setTorchState(this.worldObj, false);
    }
}
