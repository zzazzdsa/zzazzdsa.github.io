// This file ONLY tells you what and where this mod specifically adds to the minecraft sourcecode.


public class World
    implements IBlockAccess
{
	//public float getLightBrightness(int i, int j, int k) needs to be completely replaced with this
	
    public float getLightBrightness(int i, int j, int k)
    {
		int oldLightValue = getBlockLightValue(i, j, k);
		float torchLight = PlayerTorchArray.getLightBrightness(this, i, j, k);
		
		if (oldLightValue < torchLight)
		{
			int floorValue = (int)Math.floor(torchLight);
			if (floorValue == 15)
			{
				return this.worldProvider.lightBrightnessTable[15];
			}
			
			int ceilValue = (int)Math.ceil(torchLight);
			float lerpValue = torchLight - floorValue;
			return (1.0F - lerpValue) * this.worldProvider.lightBrightnessTable[floorValue] + lerpValue * this.worldProvider.lightBrightnessTable[ceilValue];
		}
		
		return this.worldProvider.lightBrightnessTable[oldLightValue];
	}
	
	
	// add this into public void setEntityDead(Entity entity)
	
		if(entity instanceof EntityItem)
        {
			EntityItem entityItem = (EntityItem)entity;
			if(entityItem.bIsLight)
			{
				PlayerTorchArray.RemoveTorchFromArray(this, entityItem.itemtorch);
			}
		}
}