import org.lwjgl.input.Keyboard;

public class mod_dynamiclights extends BaseMod
{
	private final String togglekey = "L";
	private final int itogglekey = Keyboard.getKeyIndex(togglekey);
	
	private final int mintickdiff = 30;
	private int tickcount = 0;

	public mod_dynamiclights()
	{
		ModLoader.SetInGameHook(this, true, false);
	}
	
	public void OnTickInGame(net.minecraft.client.Minecraft mc)
	{
		if (tickcount != 0)
		{
			tickcount --;
		}
	
		if (Keyboard.getEventKeyState()
		&& Keyboard.getEventKey() == itogglekey
		&& tickcount == 0)
		{
			PlayerTorchArray.ToggleDynamicLights();
			tickcount = mintickdiff;
		}
	}
	
	public String Version()
	{
		return "v1.0.0";
	}
}