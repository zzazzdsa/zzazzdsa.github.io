package net.minecraft.server;

import java.util.Random;

public class AS_TowerDestroyer
{
    private int x;
    private int y;
    private int z;
    private World world;
    private Entity player;
    private long triggerTime;
    private long lastExplosionSoundTime;
    private final int maxfloor = 6;
    private int floor;
    private final int floorDistance = 7;
    private final float explosionPower = 10F;

    public AS_TowerDestroyer(World world1, ChunkCoordinates chunkcoordinates, long l, Entity entity)
    {
        floor = 6;
        world = world1;
        player = entity;
        x = chunkcoordinates.x;
        y = chunkcoordinates.y;
        z = chunkcoordinates.z;
        triggerTime = l;
        lastExplosionSoundTime = l;
    }

    public void Update()
    {
        if (floor == 6 && System.currentTimeMillis() > triggerTime + 30000L)
        {
            triggerTime = System.currentTimeMillis();
            if (!world.isStatic)
            {
                world.a(player, x, yCoord(), z, 10F);
                cleanUpStragglerBlocks();
            }
            floor--;
        }
        else if (floor < 6 && System.currentTimeMillis() > triggerTime + 10000L)
        {
            if (floor < 1)
            {
                mod_AS_BattleTowers.unRegisterTowerDestroyer(this);
                return;
            }
            triggerTime = System.currentTimeMillis();
            if (!world.isStatic)
            {
                world.a(player, x, yCoord(), z, 10F);
                cleanUpStragglerBlocks();
            }
            floor--;
        }
    }

    private double yCoord()
    {
        return (double)(y - 7 * Math.abs(6 - floor));
    }

    private int randomTowerCoord(int i)
    {
        return (i - 7) + world.random.nextInt(15);
    }

    private void cleanUpStragglerBlocks()
    {
        int i = (int)yCoord();
        for (int j = -8; j < 8; j++)
        {
            for (int k = -8; k < 8; k++)
            {
                for (int l = 1; l < 9; l++)
                {
                    if (world.getTypeId(x + j, i + l, z + k) != 0)
                    {
                        world.setRawTypeId(x + j, i + l, z + k, 0);
                    }
                }
            }
        }
    }
}
