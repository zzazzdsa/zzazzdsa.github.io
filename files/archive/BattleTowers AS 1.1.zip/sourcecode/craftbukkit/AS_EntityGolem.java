package net.minecraft.server;

import java.util.Random;

public class AS_EntityGolem extends EntityMonster
{
    private int rageCounter;
    private int explosionAttack;
    private int drops;
    private float golemMoveSpeed;
    private int attackCounter;
    private ChunkCoordinates towerTopCoord;

    public AS_EntityGolem(World world, int i)
    {
        super(world);
        golemMoveSpeed = 0.05F;
        towerTopCoord = null;
        texture = "/mob/golemdormant.png";
        bb = golemMoveSpeed;
        damage = 6;
        health = 150 + 50 * i;
        b(1.6F, 3.4F);
        yaw = 0.0F;
        rageCounter = 0;
        explosionAttack = 0;
        fireProof = true;
        drops = 5 + i;
        setPositionRotation(locX, locY, locZ, 0.0F, 0.0F);
        attackCounter = 0;
    }

    public AS_EntityGolem(World world)
    {
        super(world);
        golemMoveSpeed = 0.05F;
        towerTopCoord = null;
        texture = "/mob/golem.png";
        bb = golemMoveSpeed;
        damage = 6;
        health = 300;
        b(1.6F, 3.4F);
        yaw = 0.0F;
        rageCounter = 0;
        explosionAttack = 0;
        fireProof = true;
        drops = 1;
        setPositionRotation(locX, locY, locZ, 0.0F, 0.0F);
        attackCounter = 0;
    }

    protected void b()
    {
        super.b();
        datawatcher.a(16, new Integer(Integer.valueOf(1).intValue()));
    }

    private void setDormant()
    {
        datawatcher.watch(16, new Integer(Integer.valueOf(1).intValue()));
    }

    private void setAwake()
    {
        datawatcher.watch(16, new Integer(Integer.valueOf(0).intValue()));
    }

    private boolean getIsDormant()
    {
        return datawatcher.getInt(16) != 0;
    }

    public int getMaxHealth()
    {
        return 150 + 50 * (drops - 5);
    }

    public void die()
    {
        super.die();
    }

    public void die(DamageSource damagesource)
    {
        super.die(damagesource);
        Entity entity = damagesource.getEntity();
        if (aj > 0 && entity != null)
        {
            entity.b(this, aj);
        }
        if (!world.isStatic)
        {
            int i = drops;
            for (int j = 0; j < i; j++)
            {
                b(Item.DIAMOND.id, 1);
                b(Item.REDSTONE.id, 1);
            }

            i = random.nextInt(4) + 8;
            for (int k = 0; k < i; k++)
            {
                b(Block.CLAY.id, 1);
            }

            if (towerTopCoord != null && target != null && mod_AS_BattleTowers.towerDestroyerEnabled != 0)
            {
                ModLoaderMp.sendChatToAll("A Tower Guardian has fallen! Without it's energy, the tower will collapse...");
                mod_AS_BattleTowers.registerTowerDestroyer(new AS_TowerDestroyer(world, towerTopCoord, System.currentTimeMillis(), target));
            }
        }
        world.a(this, (byte)3);
    }

    public void a(Entity entity, int i, double d, double d1)
    {
        if (random.nextInt(5) == 0)
        {
            motX *= 1.5D;
            motZ *= 1.5D;
            motY += 0.60000002384185791D;
        }
    }

    protected void look()
    {
        if (getIsDormant())
        {
            EntityHuman entityhuman = world.findNearbyPlayer(this, 6D);
            if (entityhuman != null && g(entityhuman))
            {
                setAwake();
                if ((int)locY > 90)
                {
                    towerTopCoord = new ChunkCoordinates((int)locX, (int)locY, (int)locZ);
                }
                world.makeSound(locX, locY, locZ, "ambient.cave.cave", 0.7F, 1.0F);
                world.makeSound(this, "golemawaken", o() * 2.0F, ((random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F) * 1.8F);
                texture = "/mob/golem.png";
                rageCounter = 175;
            }
        }
        else if (target != null)
        {
            if (towerTopCoord == null)
            {
                towerTopCoord = new ChunkCoordinates((int)locX, (int)locY, (int)locZ);
            }
            boolean flag = target.i(this) < 36D;
            if (!flag || explosionAttack == 1 || flag && locY - target.locY > 0.29999999999999999D)
            {
                rageCounter -= 2;
            }
            else
            {
                rageCounter = 175;
            }
            double d = target.locX - locX;
            double d1 = (target.boundingBox.b + (double)(target.length / 2.0F)) - (locY + (double)length * 0.80000000000000004D);
            double d2 = target.locZ - locZ;
            V = yaw = (-(float)Math.atan2(d, d2) * 180F) / 3.141593F;
            if (g(target))
            {
                if (attackCounter == 10)
                {
                    world.makeSound(this, "golemcharge", o(), (random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F);
                }
                attackCounter++;
                if (attackCounter == 20)
                {
                    world.makeSound(this, "mob.ghast.fireball", o(), (random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F);
                    if (!world.isStatic)
                    {
                        AS_EntityGolemFireball as_entitygolemfireball = new AS_EntityGolemFireball(world, this, d, d1, d2);
                        Vec3D vec3d = e(1.0F);
                        as_entitygolemfireball.locX = locX + vec3d.a * 2D;
                        as_entitygolemfireball.locY = locY + (double)length * 0.80000000000000004D;
                        as_entitygolemfireball.locZ = locZ + vec3d.c * 2D;
                        world.addEntity(as_entitygolemfireball);
                    }
                    attackCounter = -40;
                }
            }
            else if (attackCounter > 0)
            {
                attackCounter--;
            }
        }
        else
        {
            V = yaw = (-(float)Math.atan2(motX, motZ) * 180F) / 3.141593F;
            if (attackCounter > 0)
            {
                attackCounter--;
            }
        }
    }

    protected boolean d_()
    {
        return dead;
    }

    public void y_()
    {
        if (!getIsDormant())
        {
            motX *= 0.69999999999999996D;
            motZ *= 0.69999999999999996D;
            if (rageCounter <= 0 && explosionAttack == 0)
            {
                if (explosionAttack == 0 && (target instanceof EntityHuman) && world.findNearbyPlayer(this, 24D) == null)
                {
                    target = null;
                }
                else
                {
                    world.makeSound(this, "golemspecial", o() * 2.0F, ((random.nextFloat() - random.nextFloat()) * 0.2F + 1.0F) * 1.8F);
                    motY += 0.90000000000000002D;
                    explosionAttack = 1;
                    bb = 1.0F;
                }
            }
            else if (target == null)
            {
                health = 300;
                rageCounter = 125;
                explosionAttack = 0;
                if (towerTopCoord != null)
                {
                    enderTeleportTo(towerTopCoord.x, towerTopCoord.y, towerTopCoord.z);
                    setDormant();
                    texture = "/mob/golemdormant.png";
                }
            }
            else if ((rageCounter <= -30 || onGround) && explosionAttack == 1)
            {
                if (health <= 100)
                {
                    health += 15;
                }
                if (!world.isStatic && locY - target.locY > 0.29999999999999999D)
                {
                    world.a(this, locX, locY - 0.29999999999999999D, locZ, 4F);
                }
                rageCounter = 125;
                explosionAttack = 0;
                bb = golemMoveSpeed;
            }
            super.y_();
        }
        look();
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
        nbttagcompound.setByte("isDormant", (byte)(getIsDormant() ? 1 : 0));
        nbttagcompound.setByte("hasexplosionAttacked", (byte)explosionAttack);
        nbttagcompound.setByte("rageCounter", (byte)rageCounter);
        nbttagcompound.setByte("Drops", (byte)drops);
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
        if ((nbttagcompound.getByte("isDormant") & 0xff) == 1)
        {
            setDormant();
        }
        else
        {
            setAwake();
        }
        explosionAttack = nbttagcompound.getByte("hasexplosionAttacked") & 0xff;
        rageCounter = nbttagcompound.getByte("rageCounter") & 0xff;
        drops = nbttagcompound.getByte("Drops") & 0xff;
        bb = golemMoveSpeed;
        texture = getIsDormant() ? "/mob/golemdormant.png" : "/mob/golem.png";
        damage = 8;
    }

    protected void a(Entity entity, float f)
    {
        if ((double)f < 3D && entity.boundingBox.e > boundingBox.b && entity.boundingBox.b < boundingBox.e)
        {
            entity.damageEntity(DamageSource.mobAttack(this), damage);
        }
        if (onGround)
        {
            double d = entity.locX - locX;
            double d1 = entity.locZ - locZ;
            float f1 = MathHelper.sqrt(d * d + d1 * d1);
            motX = (d / (double)f1) * 0.5D * 0.20000000192092895D + motX * 0.20000000098023224D;
            motZ = (d1 / (double)f1) * 0.5D * 0.10000000192092896D + motZ * 0.20000000098023224D;
        }
        else
        {
            super.a(entity, f);
        }
    }

    protected String c_()
    {
        if (!getIsDormant())
        {
            return "golem";
        }
        else
        {
            return null;
        }
    }

    protected String m()
    {
        return "golemhurt";
    }

    protected String n()
    {
        return "golemdeath";
    }

    protected int getLootId()
    {
        return Item.CLAY_BRICK.id;
    }
}
