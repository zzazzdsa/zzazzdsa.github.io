package net.minecraft.server;

import java.util.Arrays;
import java.util.Random;

public class AS_WorldGenTower extends WorldGenerator
{
    public static final class towerTypes
    {
        public static final towerTypes CobbleStone;
        public static final towerTypes CobbleStoneMossy;
        public static final towerTypes SandStone;
        public static final towerTypes Ice;
        public static final towerTypes SmoothStone;
        public static final towerTypes Netherrack;
        private int ord;
        private int wallBlockID;
        private int lightBlockID;
        private int floorBlockID;
        private int floorBlockMetaData;
        private int stairBlockID;
        private static final towerTypes $VALUES[];

        public static towerTypes[] values()
        {
            return (towerTypes[])$VALUES.clone();
        }

        int GetWallBlockID()
        {
            return wallBlockID;
        }

        int GetLightBlockID()
        {
            return lightBlockID;
        }

        int GetFloorBlockID()
        {
            return floorBlockID;
        }

        int GetFloorBlockMetaData()
        {
            return floorBlockMetaData;
        }

        int GetStairBlockID()
        {
            return stairBlockID;
        }

        static
        {
            CobbleStone = new towerTypes("CobbleStone", 0, Block.COBBLESTONE.id, Block.TORCH.id, Block.DOUBLE_STEP.id, 0, Block.COBBLESTONE_STAIRS.id);
            CobbleStoneMossy = new towerTypes("CobbleStoneMossy", 1, Block.MOSSY_COBBLESTONE.id, Block.TORCH.id, Block.DOUBLE_STEP.id, 0, Block.COBBLESTONE_STAIRS.id);
            SandStone = new towerTypes("SandStone", 2, Block.SANDSTONE.id, Block.TORCH.id, Block.DOUBLE_STEP.id, 1, Block.COBBLESTONE_STAIRS.id);
            Ice = new towerTypes("Ice", 3, Block.ICE.id, 0, Block.CLAY.id, 2, Block.WOOD_STAIRS.id);
            SmoothStone = new towerTypes("SmoothStone", 4, Block.STONE.id, Block.TORCH.id, Block.DOUBLE_STEP.id, 3, Block.COBBLESTONE_STAIRS.id);
            Netherrack = new towerTypes("Netherrack", 5, Block.NETHERRACK.id, Block.GLOWSTONE.id, Block.SOUL_SAND.id, 0, Block.COBBLESTONE_STAIRS.id);
            $VALUES = (new towerTypes[]
                    {
                        CobbleStone, CobbleStoneMossy, SandStone, Ice, SmoothStone, Netherrack
                    });
        }

        private towerTypes(String s, int i, int j, int k, int l, int i1, int j1)
        {
        	ord = i;
            wallBlockID = j;
            lightBlockID = k;
            floorBlockID = l;
            floorBlockMetaData = i1;
            stairBlockID = j1;
        }

		public int ordinal() {
			return ord;
		}
    }

    private int floor;
    private int floorIterator;
    private boolean topFloor;
    private int candidates[][] =
    {
        {
            4, -5
        }, {
            4, 0
        }, {
            4, 5
        }, {
            0, -5
        }, {
            0, 0
        }, {
            0, 5
        }, {
            -4, -5
        }, {
            -4, 0
        }, {
            -4, 5
        }
    };
    private int candidatecount;
    final int maxHoleDepthInBase = 22;
    private towerTypes towerChosen;

    public AS_WorldGenTower()
    {
        candidatecount = candidates.length;
    }

    public boolean a(World world, Random random, int i, int j, int k)
    {
        int l = j;
        int i1 = 0;
        int j1 = 0;
        int k1 = 0;
        int l1 = 0;
        for (int i2 = 0; i2 < candidatecount; i2++)
        {
            int ai1[] = candidates[i2];
            int k2 = GetSurfaceBlockHeight(world, i + ai1[0], k + ai1[1]);
            int i3 = world.getTypeId(i + ai1[0], k2, k + ai1[1]);
            if (world.getTypeId(i + ai1[0], k2 + 1, k + ai1[1]) == Block.SNOW.id || i3 == Block.ICE.id)
            {
                k1++;
            }
            else if (i3 == Block.SAND.id || i3 == Block.SANDSTONE.id)
            {
                j1++;
            }
            else if (i3 == Block.STATIONARY_WATER.id)
            {
                i1++;
            }
            else
            {
                l1++;
            }
            if (Math.abs(k2 - l) > 22)
            {
                return false;
            }
            for (int i4 = 1; i4 <= 3; i4++)
            {
                int j3 = world.getTypeId(i + ai1[0], k2 + i4, k + ai1[1]);
                if (IsBannedBlockID(j3))
                {
                    return false;
                }
            }

            for (int j4 = 1; j4 <= 5; j4++)
            {
                int k3 = world.getTypeId(i + ai1[0], k2 - j4, k + ai1[1]);
                if (k3 == 0 || IsBannedBlockID(k3))
                {
                    return false;
                }
            }
        }

        int ai[] =
        {
            i1, k1, j1, l1
        };
        Arrays.sort(ai);
        int j2 = ai[ai.length - 1];
        if (j1 == j2)
        {
            towerChosen = towerTypes.SandStone;
        }
        else if (k1 == j2)
        {
            towerChosen = towerTypes.Ice;
        }
        else if (i1 == j2)
        {
            towerChosen = towerTypes.CobbleStoneMossy;
        }
        else if (random.nextInt(10) == 0)
        {
            towerChosen = towerTypes.Netherrack;
        }
        else
        {
            towerChosen = random.nextInt(5) != 0 ? towerTypes.CobbleStone : towerTypes.SmoothStone;
        }
        int l2 = towerChosen.GetWallBlockID();
        int l3 = towerChosen.GetLightBlockID();
        int k4 = towerChosen.GetFloorBlockID();
        floor = 1;
        topFloor = false;
        for (int l4 = j - 6; l4 < 120; l4 += 7)
        {
            if (l4 + 7 >= 120)
            {
                topFloor = true;
            }
            for (floorIterator = 0; floorIterator < 7; floorIterator++)
            {
                if (floor == 1 && floorIterator < 4)
                {
                    floorIterator = 4;
                }
                for (int i5 = -7; i5 < 7; i5++)
                {
                    for (int l5 = -7; l5 < 7; l5++)
                    {
                        int j6 = i5 + i;
                        int i7 = floorIterator + l4;
                        int k7 = l5 + k;
                        if (l5 == -7)
                        {
                            if (i5 > -5 && i5 < 4)
                            {
                                BuildWallPiece(world, j6, i7, k7, l2);
                            }
                            continue;
                        }
                        if (l5 == -6 || l5 == -5)
                        {
                            if (i5 == -5 || i5 == 4)
                            {
                                BuildWallPiece(world, j6, i7, k7, l2);
                                continue;
                            }
                            if (l5 == -6)
                            {
                                if (i5 == (floorIterator + 1) % 7 - 3)
                                {
                                    world.setRawTypeId(j6, i7, k7, towerChosen.GetStairBlockID());
                                    if (floorIterator == 5)
                                    {
                                        world.setRawTypeId(j6 - 7, i7, k7, k4);
                                    }
                                    if (floorIterator == 6 && topFloor)
                                    {
                                        BuildWallPiece(world, j6, i7, k7, l2);
                                    }
                                    continue;
                                }
                                if (i5 < 4 && i5 > -5)
                                {
                                    world.setRawTypeId(j6, i7, k7, 0);
                                }
                                continue;
                            }
                            if (l5 != -5 || i5 <= -5 || i5 >= 5)
                            {
                                continue;
                            }
                            if (floorIterator != 0 && floorIterator != 6 || i5 != -4 && i5 != 3)
                            {
                                if (floorIterator == 5 && (i5 == 3 || i5 == -4))
                                {
                                    BuildFloorPiece(world, j6, i7, k7, k4);
                                }
                                else
                                {
                                    BuildWallPiece(world, j6, i7, k7, l2);
                                }
                            }
                            else
                            {
                                world.setRawTypeId(j6, i7, k7, 0);
                            }
                            continue;
                        }
                        if (l5 == -4 || l5 == -3 || l5 == 2 || l5 == 3)
                        {
                            if (i5 == -6 || i5 == 5)
                            {
                                BuildWallPiece(world, j6, i7, k7, l2);
                                continue;
                            }
                            if (i5 <= -6 || i5 >= 5)
                            {
                                continue;
                            }
                            if (floorIterator == 5)
                            {
                                BuildFloorPiece(world, j6, i7, k7, k4);
                                continue;
                            }
                            if (world.getTypeId(j6, i7, k7) != Block.CHEST.id)
                            {
                                world.setRawTypeId(j6, i7, k7, 0);
                            }
                            continue;
                        }
                        if (l5 > -3 && l5 < 2)
                        {
                            if (i5 == -7 || i5 == 6)
                            {
                                if (floorIterator < 0 || floorIterator > 3 || i5 != -7 && i5 != 6 || l5 != -1 && l5 != 0)
                                {
                                    BuildWallPiece(world, j6, i7, k7, l2);
                                }
                                else
                                {
                                    world.setRawTypeId(j6, i7, k7, 0);
                                }
                                continue;
                            }
                            if (i5 <= -7 || i5 >= 6)
                            {
                                continue;
                            }
                            if (floorIterator == 5)
                            {
                                BuildFloorPiece(world, j6, i7, k7, k4);
                            }
                            else
                            {
                                world.setRawTypeId(j6, i7, k7, 0);
                            }
                            continue;
                        }
                        if (l5 == 4)
                        {
                            if (i5 == -5 || i5 == 4)
                            {
                                BuildWallPiece(world, j6, i7, k7, l2);
                                continue;
                            }
                            if (i5 <= -5 || i5 >= 4)
                            {
                                continue;
                            }
                            if (floorIterator == 5)
                            {
                                BuildFloorPiece(world, j6, i7, k7, k4);
                            }
                            else
                            {
                                world.setRawTypeId(j6, i7, k7, 0);
                            }
                            continue;
                        }
                        if (l5 == 5)
                        {
                            if (i5 == -4 || i5 == -3 || i5 == 2 || i5 == 3)
                            {
                                BuildWallPiece(world, j6, i7, k7, l2);
                                continue;
                            }
                            if (i5 <= -3 || i5 >= 2)
                            {
                                continue;
                            }
                            if (floorIterator == 5)
                            {
                                BuildFloorPiece(world, j6, i7, k7, k4);
                            }
                            else
                            {
                                BuildWallPiece(world, j6, i7, k7, l2);
                            }
                            continue;
                        }
                        if (l5 != 6 || i5 <= -3 || i5 >= 2)
                        {
                            continue;
                        }
                        if (floorIterator < 0 || floorIterator > 3 || i5 != -1 && i5 != 0)
                        {
                            BuildWallPiece(world, j6, i7, k7, l2);
                        }
                        else
                        {
                            BuildWallPiece(world, j6, i7, k7, l2);
                        }
                    }
                }
            }

            if (floor == 2)
            {
                world.setRawTypeId(i + 3, l4, k - 5, l2);
                world.setRawTypeId(i + 3, l4 - 1, k - 5, l2);
            }
            if (topFloor)
            {
                double d = i;
                double d1 = l4 + 6;
                double d2 = (double)k + 0.5D;
                AS_EntityGolem as_entitygolem = new AS_EntityGolem(world, towerChosen.ordinal());
                as_entitygolem.setPositionRotation(d, d1, d2, world.random.nextFloat() * 360F, 0.0F);
                as_entitygolem.setPosition(d, d1, d2);
                world.addEntity(as_entitygolem);
            }
            else
            {
                world.setTypeId(i + 2, l4 + 6, k + 2, Block.MOB_SPAWNER.id);
                TileEntityMobSpawner tileentitymobspawner = (TileEntityMobSpawner)world.getTileEntity(i + 2, l4 + 6, k + 2);
                tileentitymobspawner.a(getMobType(random));
                world.setTypeId(i - 3, l4 + 6, k + 2, Block.MOB_SPAWNER.id);
                TileEntityMobSpawner tileentitymobspawner1 = (TileEntityMobSpawner)world.getTileEntity(i - 3, l4 + 6, k + 2);
                tileentitymobspawner1.a(getMobType(random));
            }
            world.setRawTypeId(i, l4 + 6, k + 3, k4);
            world.setRawTypeId(i - 1, l4 + 6, k + 3, k4);
            if (l4 + 56 >= 120 && floor == 1)
            {
                floor = 2;
            }
            for (int j5 = 0; j5 < 2; j5++)
            {
                world.setRawTypeId(i - j5, l4 + 7, k + 3, Block.CHEST.id);
                world.setRawData(i - j5, l4 + 7, k + 3, 2);
                TileEntityChest tileentitychest = new TileEntityChest();
                world.setTileEntity(i - j5, l4 + 7, k + 3, tileentitychest);
                for (int k6 = 0; k6 < 3; k6++)
                {
                    ItemStack itemstack = getChestRewardItem(floor, random);
                    if (itemstack != null)
                    {
                        tileentitychest.setItem(random.nextInt(tileentitychest.getSize()), itemstack);
                    }
                }
            }

            if (l3 != 0 && Block.byId[l3].a())
            {
                l4 += 2;
            }
            world.setRawTypeId(i + 3, l4, k - 6, l3);
            world.setRawTypeId(i - 4, l4, k - 6, l3);
            world.setRawTypeId(i + 1, l4, k - 4, l3);
            world.setRawTypeId(i - 2, l4, k - 4, l3);
            if (l3 != 0 && Block.byId[l3].a())
            {
                l4 -= 2;
            }
            for (int k5 = 0; k5 < (floor * 4 + towerChosen.ordinal()) - 8 && !topFloor; k5++)
            {
                int i6 = 5 - random.nextInt(12);
                int l6 = l4 + 5;
                int j7 = 5 - random.nextInt(10);
                if (j7 < -2 && i6 < 4 && i6 > -5 && i6 != 1 && i6 != -2)
                {
                    continue;
                }
                i6 += i;
                j7 += k;
                if (world.getTypeId(i6, l6, j7) == k4 && world.getTypeId(i6, l6 + 1, j7) != Block.MOB_SPAWNER.id)
                {
                    world.setRawTypeId(i6, l6, j7, 0);
                }
            }

            floor++;
        }

        return true;
    }

    private void BuildFloorPiece(World world, int i, int j, int k, int l)
    {
        world.setRawTypeId(i, j, k, l);
        if (towerChosen.GetFloorBlockMetaData() != 0)
        {
            world.setData(i, j, k, towerChosen.GetFloorBlockMetaData());
        }
    }

    private void BuildWallPiece(World world, int i, int j, int k, int l)
    {
        world.setRawTypeId(i, j, k, l);
        if (floor == 1 && floorIterator == 4)
        {
            FillTowerBaseToGround(world, i, j, k, l);
        }
    }

    private void FillTowerBaseToGround(World world, int i, int j, int k, int l)
    {
        int i1 = j - 1;
        do
        {
            world.setRawTypeId(i, i1, k, l);
            i1--;
        }
        while (!IsBuildableBlockID(world.getTypeId(i, i1, k)));
    }

    private int GetSurfaceBlockHeight(World world, int i, int j)
    {
        int k = 50;
        do
        {
            k++;
        }
        while (world.getTypeId(i, k, j) != 0 && !IsFoliageBlockID(world.getTypeId(i, k, j)));
        return k - 1;
    }

    private boolean IsFoliageBlockID(int i)
    {
        return i == Block.SNOW.id || i == Block.LONG_GRASS.id || i == Block.DEAD_BUSH.id || i == Block.LOG.id || i == Block.LEAVES.id;
    }

    private boolean IsBuildableBlockID(int i)
    {
        return i == Block.STONE.id || i == Block.GRASS.id || i == Block.SAND.id || i == Block.SANDSTONE.id || i == Block.GRAVEL.id || i == Block.DIRT.id;
    }

    private boolean IsBannedBlockID(int i)
    {
        return i == Block.YELLOW_FLOWER.id || i == Block.RED_ROSE.id || i == Block.BROWN_MUSHROOM.id || i == Block.RED_MUSHROOM.id || i == Block.CACTUS.id || i == Block.PUMPKIN.id || i == Block.LAVA.id || i == Block.STATIONARY_LAVA.id;
    }

    private ItemStack getChestRewardItem(int i, Random random)
    {
        int j = random.nextInt(4);
        if (topFloor)
        {
            switch (j)
            {
                case 0:
                    return new ItemStack(Item.REDSTONE, random.nextInt(8));

                case 1:
                    return new ItemStack(Item.IRON_INGOT, random.nextInt(8));

                case 2:
                    return new ItemStack(Item.DIAMOND, random.nextInt(6));

                case 3:
                    return new ItemStack(Item.GOLD_INGOT, random.nextInt(8));
            }
        }
        switch (i)
        {
            case 1:
                switch (j)
                {
                    case 0:
                        return new ItemStack(Item.STICK, random.nextInt(5) + 6);

                    case 1:
                        return new ItemStack(Item.SEEDS, random.nextInt(5) + 6);

                    case 2:
                        return new ItemStack(Block.WOOD, random.nextInt(5) + 7);

                    case 3:
                        return new ItemStack(Item.COAL, random.nextInt(5) + 6);
                }

            case 2:
                switch (j)
                {
                    case 0:
                        return new ItemStack(Item.COAL, random.nextInt(3) + 6);

                    case 1:
                        return new ItemStack(Item.WOOD_PICKAXE, 1);

                    case 2:
                        return new ItemStack(Block.WOOD, random.nextInt(3) + 6);

                    case 3:
                        return new ItemStack(Block.WOOL, random.nextInt(3) + 6);
                }

            case 3:
                switch (j)
                {
                    case 0:
                        return new ItemStack(Item.FEATHER, random.nextInt(3) + 6);

                    case 1:
                        return new ItemStack(Item.BREAD, 1);

                    case 2:
                        return new ItemStack(Block.GLASS, random.nextInt(3) + 6);

                    case 3:
                        return new ItemStack(Block.RED_MUSHROOM, 1);
                }

            case 4:
                switch (j)
                {
                    case 0:
                        return new ItemStack(Item.STRING, random.nextInt(3) + 4);

                    case 1:
                        return new ItemStack(Item.IRON_SWORD, 1);

                    case 2:
                        return new ItemStack(Block.TORCH, random.nextInt(3) + 8);

                    case 3:
                        return new ItemStack(Block.RED_ROSE, random.nextInt(3) + 3);
                }

            case 5:
                switch (j)
                {
                    case 0:
                        return new ItemStack(Item.SIGN, 1);

                    case 1:
                        return new ItemStack(Item.BOW, 1);

                    case 2:
                        return new ItemStack(Block.BRICK, random.nextInt(3) + 5);

                    case 3:
                        return new ItemStack(Item.CHAINMAIL_BOOTS, 1);
                }

            case 6:
                switch (j)
                {
                    case 0:
                        return new ItemStack(Block.LADDER, random.nextInt(3) + 9);

                    case 1:
                        return new ItemStack(Item.FLINT_AND_STEEL, 1);

                    case 2:
                        return new ItemStack(Block.GLOWSTONE, random.nextInt(3) + 5);

                    case 3:
                        return new ItemStack(Item.CHAINMAIL_HELMET, 1);
                }

            case 7:
                switch (j)
                {
                    case 0:
                        return new ItemStack(Block.TNT, random.nextInt(3) + 6);

                    case 1:
                        return new ItemStack(Item.DIAMOND_HOE, 1);

                    case 2:
                        return new ItemStack(Block.OBSIDIAN, random.nextInt(3) + 2);

                    case 3:
                        return new ItemStack(Item.CHAINMAIL_CHESTPLATE, 1);
                }

            case 8:
                switch (j)
                {
                    case 0:
                        return new ItemStack(Item.DIAMOND_SWORD, 1);

                    case 1:
                        return new ItemStack(Item.DIAMOND_PICKAXE, 1);

                    case 2:
                        return new ItemStack(Item.DIAMOND_AXE, 1);

                    case 3:
                        return new ItemStack(Item.DIAMOND_SPADE, 1);
                }

            default:
                return null;
        }
    }

    private String getMobType(Random random)
    {
        switch (random.nextInt(4))
        {
            case 0:
                if (ModLoader.isModLoaded("mod_prefixskeletons"))
                {
                    return "PrefixSkeleton";
                }
                else
                {
                    return "Skeleton";
                }

            case 1:
                if (ModLoader.isModLoaded("mod_MoreCreepsAndWeirdos"))
                {
                    return "Mummy";
                }
                else
                {
                    return "Zombie";
                }

            case 2:
                return "Zombie";

            case 3:
                return "Spider";

            case 4:
                return "";
        }
        return "";
    }
}
