package net.minecraft.server;

import java.util.List;
import java.util.Random;

public class AS_EntityGolemFireball extends Entity
{
    private int xTile;
    private int yTile;
    private int zTile;
    private int inTile;
    private boolean wasDeflected;
    private boolean inGround;
    public int shake;
    public EntityLiving shooterEntity;
    public double accelerationX;
    public double accelerationY;
    public double accelerationZ;

    public AS_EntityGolemFireball(World world)
    {
        super(world);
        xTile = -1;
        yTile = -1;
        zTile = -1;
        inTile = 0;
        inGround = false;
        shake = 0;
        b(0.3F, 0.3F);
        wasDeflected = false;
    }

    protected void b()
    {
    }

    public AS_EntityGolemFireball(World world, EntityLiving entityliving, double d, double d1, double d2)
    {
        super(world);
        xTile = -1;
        yTile = -1;
        zTile = -1;
        inTile = 0;
        inGround = false;
        shake = 0;
        shooterEntity = entityliving;
        b(0.3F, 0.3F);
        setPosition(locX, locY, locZ);
        height = 0.0F;
        motX = motY = motZ = 0.0D;
        d += random.nextGaussian() * 0.40000000000000002D;
        d1 += random.nextGaussian() * 0.40000000000000002D;
        d2 += random.nextGaussian() * 0.40000000000000002D;
        double d3 = MathHelper.sqrt(d * d + d1 * d1 + d2 * d2);
        accelerationX = (d / d3) * 0.10000000000000001D;
        accelerationY = (d1 / d3) * 0.10000000000000001D;
        accelerationZ = (d2 / d3) * 0.10000000000000001D;
        wasDeflected = false;
    }

    public void y_()
    {
        super.y_();
        setOnFire(1);
        if (shake > 0)
        {
            shake--;
        }
        if (inGround)
        {
            int i = world.getTypeId(xTile, yTile, zTile);
            if (i != inTile)
            {
                inGround = false;
                motX *= random.nextFloat() * 0.2F;
                motY *= random.nextFloat() * 0.2F;
                motZ *= random.nextFloat() * 0.2F;
            }
            else
            {
                if (ticksLived >= 1200)
                {
                    die();
                }
                return;
            }
        }
        Vec3D vec3d = Vec3D.create(locX, locY, locZ);
        Vec3D vec3d1 = Vec3D.create(locX + motX, locY + motY, locZ + motZ);
        MovingObjectPosition movingobjectposition = world.a(vec3d, vec3d1);
        vec3d = Vec3D.create(locX, locY, locZ);
        vec3d1 = Vec3D.create(locX + motX, locY + motY, locZ + motZ);
        if (movingobjectposition != null)
        {
            vec3d1 = Vec3D.create(movingobjectposition.f.a, movingobjectposition.f.b, movingobjectposition.f.c);
        }
        Entity entity = null;
        List list = world.getEntities(this, boundingBox.a(motX, motY, motZ).grow(1.0D, 1.0D, 1.0D));
        double d = 0.0D;
        for (int j = 0; j < list.size(); j++)
        {
            Entity entity1 = (Entity)list.get(j);
            if (!entity1.e_() || entity1 == shooterEntity && ticksLived < 25 && !wasDeflected)
            {
                continue;
            }
            float f2 = 0.3F;
            AxisAlignedBB axisalignedbb = entity1.boundingBox.grow(f2, f2, f2);
            MovingObjectPosition movingobjectposition1 = axisalignedbb.a(vec3d, vec3d1);
            if (movingobjectposition1 == null)
            {
                continue;
            }
            double d1 = vec3d.b(movingobjectposition1.f);
            if (d1 < d || d == 0.0D)
            {
                entity = entity1;
                d = d1;
            }
        }

        if (entity != null)
        {
            movingobjectposition = new MovingObjectPosition(entity);
        }
        if (movingobjectposition != null)
        {
            if (!world.isStatic)
            {
                if (movingobjectposition.entity != null)
                {
                    if (movingobjectposition.entity.damageEntity(DamageSource.mobAttack(shooterEntity), 0));
                }
                world.createExplosion(null, locX, locY, locZ, 1.0F, true);
            }
            die();
        }
        locX += motX;
        locY += motY;
        locZ += motZ;
        float f = MathHelper.sqrt(motX * motX + motZ * motZ);
        yaw = (float)((Math.atan2(motX, motZ) * 180D) / 3.1415927410125732D);
        for (pitch = (float)((Math.atan2(motY, f) * 180D) / 3.1415927410125732D); pitch - lastPitch < -180F; lastPitch -= 360F) { }
        for (; pitch - lastPitch >= 180F; lastPitch += 360F) { }
        for (; yaw - lastYaw < -180F; lastYaw -= 360F) { }
        for (; yaw - lastYaw >= 180F; lastYaw += 360F) { }
        pitch = lastPitch + (pitch - lastPitch) * 0.2F;
        yaw = lastYaw + (yaw - lastYaw) * 0.2F;
        float f1 = 0.95F;
        if (aK())
        {
            for (int k = 0; k < 4; k++)
            {
                float f3 = 0.25F;
                world.a("bubble", locX - motX * (double)f3, locY - motY * (double)f3, locZ - motZ * (double)f3, motX, motY, motZ);
            }

            f1 = 0.8F;
        }
        motX += accelerationX;
        motY += accelerationY;
        motZ += accelerationZ;
        motX *= f1;
        motY *= f1;
        motZ *= f1;
        world.a("smoke", locX, locY + 0.5D, locZ, 0.0D, 0.0D, 0.0D);
        setPosition(locX, locY, locZ);
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        nbttagcompound.setShort("xTile", (short)xTile);
        nbttagcompound.setShort("yTile", (short)yTile);
        nbttagcompound.setShort("zTile", (short)zTile);
        nbttagcompound.setByte("inTile", (byte)inTile);
        nbttagcompound.setByte("shake", (byte)shake);
        nbttagcompound.setByte("inGround", (byte)(inGround ? 1 : 0));
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        xTile = nbttagcompound.getShort("xTile");
        yTile = nbttagcompound.getShort("yTile");
        zTile = nbttagcompound.getShort("zTile");
        inTile = nbttagcompound.getByte("inTile") & 0xff;
        shake = nbttagcompound.getByte("shake") & 0xff;
        inGround = nbttagcompound.getByte("inGround") == 1;
    }

    public boolean e_()
    {
        return true;
    }

    public float j_()
    {
        return 1.0F;
    }

    public boolean damageEntity(DamageSource damagesource, int i)
    {
        aM();
        Entity entity = damagesource.getEntity();
        if (entity != null)
        {
            Vec3D vec3d = entity.aA();
            if (vec3d != null)
            {
                motX = vec3d.a;
                motY = vec3d.b;
                motZ = vec3d.c;
                accelerationX = motX * 0.10000000000000001D;
                accelerationY = motY * 0.10000000000000001D;
                accelerationZ = motZ * 0.10000000000000001D;
                wasDeflected = true;
            }
            return true;
        }
        else
        {
            return false;
        }
    }

    public float getShadowSize()
    {
        return 0.0F;
    }
}
