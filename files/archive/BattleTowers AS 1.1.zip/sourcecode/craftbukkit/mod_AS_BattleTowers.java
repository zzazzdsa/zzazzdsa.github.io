package net.minecraft.server;

import java.io.*;
import java.net.*;
import java.security.CodeSource;
import java.security.ProtectionDomain;
import java.util.*;
import net.minecraft.server.MinecraftServer;

public class mod_AS_BattleTowers extends BaseModMp
{
    static boolean isWorking = false;
    private List TowerPositions;
    private static List TowerDestroyers;
    private int raritycounter;
    private int spawncounter;
    private static int rarity;
    private double minDistanceBetweenTowers;
    public static int towerDestroyerEnabled;
    public static String configpath;
    private long time;
    static BaseModMp instance;
    private boolean hasinit;

    public mod_AS_BattleTowers()
    {
        raritycounter = 400;
        hasinit = false;
        if (!hasinit)
        {
            init();
        }
    }

    public void load()
    {
        if (!hasinit)
        {
            init();
        }
    }

    private void init()
    {
        hasinit = true;
        ModLoader.RegisterEntityID(net.minecraft.server.AS_EntityGolem.class, "Golem", 27);
        ModLoaderMp.RegisterEntityTrackerEntry(net.minecraft.server.AS_EntityGolemFireball.class, 27);
        ModLoaderMp.RegisterEntityTracker(net.minecraft.server.AS_EntityGolemFireball.class, 160, 5);
        spawncounter = 200;
        try
        {
            Properties properties = new Properties();
            String s = (net.minecraft.server.mod_AS_BattleTowers.class).getProtectionDomain().getCodeSource().getLocation().toURI().getPath();
            s = s.substring(0, s.lastIndexOf('/'));
            s = s.substring(0, s.lastIndexOf('/'));
            s = (new StringBuilder()).append(s).append("/mods/BattleTowers.txt").toString();
            File file = new File(s);
            configpath = s;
            properties.load(new InputStreamReader(new FileInputStream(file)));
            rarity = Integer.valueOf(properties.getProperty("rarity")).intValue();
            minDistanceBetweenTowers = Double.valueOf(properties.getProperty("minDistanceBetweenTowers")).doubleValue();
            towerDestroyerEnabled = Integer.valueOf(properties.getProperty("towerDestroyerEnabled")).intValue();
        }
        catch (URISyntaxException urisyntaxexception)
        {
            System.err.println((new StringBuilder()).append("BattleTowers URISyntaxException: ").append(urisyntaxexception).toString());
            UseDefaults();
        }
        catch (FileNotFoundException filenotfoundexception)
        {
            System.err.println((new StringBuilder()).append("BattleTowers properties file not found, using default values: ").append(filenotfoundexception).toString());
            UseDefaults();
        }
        catch (IOException ioexception)
        {
            System.err.println((new StringBuilder()).append("Error reading BattleTowers properties file, using default values: ").append(ioexception).toString());
            UseDefaults();
        }
        catch (NumberFormatException numberformatexception)
        {
            System.err.println((new StringBuilder()).append("Incorrect value property, using default value. ").append(numberformatexception).toString());
            UseDefaults();
        }
        if (rarity < 1)
        {
            rarity = 1;
        }
        raritycounter = rarity * 100;
        TowerPositions = new ArrayList();
        TowerDestroyers = new ArrayList();
        time = System.currentTimeMillis();
        ModLoader.SetInGameHook(this, true, true);
        instance = this;
    }

    public void OnTickInGame(MinecraftServer minecraftserver)
    {
        if (System.currentTimeMillis() > time + 1000L)
        {
            for (int i = 0; i < TowerDestroyers.size(); i++)
            {
                AS_TowerDestroyer as_towerdestroyer = (AS_TowerDestroyer)TowerDestroyers.get(i);
                as_towerdestroyer.Update();
            }
        }
    }

    public static void registerTowerDestroyer(AS_TowerDestroyer as_towerdestroyer)
    {
        forceAllClientsDestroyerSetting();
        if (towerDestroyerEnabled != 0)
        {
            TowerDestroyers.add(as_towerdestroyer);
        }
    }

    private static void forceAllClientsDestroyerSetting()
    {
        int ai[] = new int[1];
        ai[0] = towerDestroyerEnabled;
        Packet230ModLoader packet230modloader = new Packet230ModLoader();
        packet230modloader.packetType = 0;
        packet230modloader.dataInt = ai;
        ModLoaderMp.SendPacketToAll(instance, packet230modloader);
    }

    public void HandlePacket(Packet230ModLoader packet230modloader)
    {
        switch (packet230modloader.packetType)
        {
            case 1:
                forceAllClientsDestroyerSetting();
                break;
        }
    }

    public static void unRegisterTowerDestroyer(AS_TowerDestroyer as_towerdestroyer)
    {
        TowerDestroyers.remove(as_towerdestroyer);
    }

    public void UseDefaults()
    {
        rarity = 3;
        minDistanceBetweenTowers = 64D;
        towerDestroyerEnabled = 1;
    }

    public void ModsLoaded()
    {
        System.err.println("BATTLE TOWERS CONFIG");
        System.err.println((new StringBuilder()).append("Tower Rarity ").append(String.valueOf(rarity)).toString());
        System.err.println((new StringBuilder()).append("Min Tower Distance ").append(String.valueOf(minDistanceBetweenTowers)).toString());
        System.err.println((new StringBuilder()).append("MINECRAFT PROPERTIES ").append(String.valueOf(configpath)).toString());
    }

    public void GenerateSurface(World world, Random random, int i, int j)
    {
        if (!hasinit)
        {
            init();
        }
        if (!isWorking)
        {
            isWorking = true;
            if (spawncounter > raritycounter)
            {
                boolean flag = true;
                double d1 = 100D;
                int k = 0;
                do
                {
                    if (k >= TowerPositions.size())
                    {
                        break;
                    }
                    ChunkCoordinates chunkcoordinates1 = (ChunkCoordinates)TowerPositions.get(k);
                    double d = chunkcoordinates1.a(i, 64, j);
                    if (d < d1)
                    {
                        d1 = d;
                    }
                    if (d < minDistanceBetweenTowers)
                    {
                        flag = false;
                        break;
                    }
                    k++;
                }
                while (true);
                if (flag && AttemptToSpawnTower(world, random, i, j))
                {
                    if (TowerPositions.size() > 30)
                    {
                        TowerPositions.remove(0);
                    }
                    ChunkCoordinates chunkcoordinates = new ChunkCoordinates(i, 64, j);
                    TowerPositions.add(chunkcoordinates);
                    spawncounter = 0;
                }
            }
            else
            {
                spawncounter++;
            }
            isWorking = false;
        }
    }

    private boolean AttemptToSpawnTower(World world, Random random, int i, int j)
    {
        int k = GetSurfaceBlockHeight(world, i, j);
        if (k == 49)
        {
            return false;
        }
        else
        {
            return (new AS_WorldGenTower()).a(world, random, i, k, j);
        }
    }

    private int GetSurfaceBlockHeight(World world, int i, int j)
    {
        int k = 50;
        do
        {
            k++;
        }
        while (world.getTypeId(i, k, j) != 0);
        return k - 1;
    }

    public String getVersion()
    {
        return "1.1";
    }
}
