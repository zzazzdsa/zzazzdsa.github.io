package net.minecraft.src;

import java.util.Map;
import org.lwjgl.input.*;
import net.minecraft.client.Minecraft;
import java.util.*;

public class mod_FinderCompass extends BaseMod
{
	private long time = 0;
	
	@Override
	public void load()
	{
        ModLoader.setInGameHook(this, true, false);
	}
	
	@Override
    public String getVersion()
	{
        return "1.2.5";
    }

	@Override
    public boolean onTickInGame(float renderTick, Minecraft mc)
	{
    	if (mc.theWorld != null
    	&& mc.thePlayer != null
    	&& !AS_FinderCompass.isHackedIn)
    	{
    		if (time == 0)
    		{
    			time = System.currentTimeMillis();
    		}
    		else if (System.currentTimeMillis() > time+5000L)
    		{
	    		AS_FinderCompass replacement = new AS_FinderCompass(mc, true);
	    		
	    		if (AS_FinderCompass.isHackedIn)
	    		{
	    			mc.renderEngine.registerTextureFX(replacement);
	    		}
    		}
    	}
        
        return true;
    }
}
