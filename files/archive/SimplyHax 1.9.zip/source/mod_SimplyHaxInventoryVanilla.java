package net.minecraft.src;

import net.minecraft.client.Minecraft;

import java.lang.reflect.*;


public class mod_SimplyHaxInventoryVanilla extends BaseMod
{

    private long lastTime;
	private boolean isAetherModInstalled = false;
	
	private InventoryPlayer vanillainv;

	private ItemStack[] mainInv;
	private ItemStack[] armorInv;
	
	private boolean savedInventory = false;
	

    public mod_SimplyHaxInventoryVanilla()
    {
        lastTime = System.currentTimeMillis();
        ModLoader.SetInGameHook(this, true, true);
		
		isAetherModInstalled = IsAetherInstalled();
    }
	
    public boolean OnTickInGame(Minecraft mc)
    {
		if (mc.theWorld != null && mc.thePlayer != null)
		{
			long l = System.currentTimeMillis();
			if(l > lastTime + 1000L)
			{
				lastTime = l;
				// do once a second stuff
				
				HaxInventory(mc.thePlayer);
			}
			
			// do every tick stuff
			
			if ((mc.thePlayer.health <= 0 || mc.thePlayer.isDead) && !savedInventory)
			{
				deleteDroppingItems(mc.thePlayer);
			}
		}
        return true;
    }
	
	private void HaxInventory(EntityPlayer entityplayer)
	{
		if (IsAlive(entityplayer) && hasItems(entityplayer))
		{
			int i;
			if (!savedInventory)
			{
				if (!isAetherModInstalled)
				{
					vanillainv = entityplayer.inventory;
					
					mainInv = new ItemStack[36];
					for (i = 0; i < vanillainv.mainInventory.length; i++)
					{
						if (vanillainv.mainInventory[i] != null)
						{
							mainInv[i] = vanillainv.mainInventory[i].copy();
						}
					}
					
					armorInv = new ItemStack[4];
					for (i = 0; i < vanillainv.armorInventory.length; i++)
					{
						if (vanillainv.armorInventory[i] != null)
						{
							armorInv[i] = vanillainv.armorInventory[i].copy();
						}
					}
				}
			}
			else
			{
				if (!isAetherModInstalled && vanillainv != null)
				{
					entityplayer.inventory.mainInventory = mainInv;
					entityplayer.inventory.armorInventory = armorInv;
					System.out.println("Restored Vanilla inv!");
					
					savedInventory = false;
				}
			}
		}
		else
		{
			savedInventory = true;
		}
	}
	
	private void deleteDroppingItems(EntityPlayer entityplayer)
	{
		java.util.List list = entityplayer.worldObj.getEntitiesWithinAABBExcludingEntity(entityplayer, entityplayer.boundingBox.expand(2D, 2D, 2D));
		
		if (list.size() > 0)
			System.out.println("Player dead, deleting "+list.size()+" dropped items");
		
		for(int i = 0; i < list.size(); i++)
		{
			Entity ent = (Entity)list.get(i);
			if(!ent.isDead && ent instanceof EntityItem)
			{
				ent.setEntityDead();
			}
		}
	}
	
	private boolean hasItems(EntityPlayer entityplayer)
	{
		return entityplayer.inventory.mainInventory.length > 0 || entityplayer.inventory.armorInventory.length > 0;
	}
	
	private boolean IsAlive(EntityLiving ent)
	{
		return ent != null && ent.health > 0 && !ent.isDead;
	}
	
	private boolean IsAetherInstalled()
	{
        try
        {
            return Class.forName("mod_Aether") != null;
        }
        catch(ClassNotFoundException classnotfoundexception)
        {
            return false;
        }
	}

    public String Version()
    {
        return "1.7.3";
    }
}
