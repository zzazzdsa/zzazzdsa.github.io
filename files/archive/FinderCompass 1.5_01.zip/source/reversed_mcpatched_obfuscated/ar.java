import com.pclewis.mcpatcher.mod.TextureUtils;
import com.pclewis.mcpatcher.mod.TileSize;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.client.Minecraft;

public class ar extends as {

  private Minecraft g;
  private int[] h;
  private double[] i = new double[10];
  private double[] j = new double[10];

  private int[] spawnNeedleColor = { 255, 20, 20 };
  private int[] spawnerNeedleColor = { 26, 255, 26 };
  private int[] diamondNeedleColor = { 51, 255, 204 };

  private static Map<Integer, int[]> customNeedles = new HashMap();
  private static Map<int[], bk> customNeedleTargets = new HashMap();
  private static boolean areSettingsLoaded = false;
  static File settingsFile;
  final double HEADING_DOWN = 0.0D;
  final double HEADING_UP = 135.0D;
  private int x;
  private int y;
  private int z;
  private bk DiamondOre = new bk(0, 0, 0);
  private bk MobSpawner = new bk(0, 0, 0);
  private bk lastScanBlock = new bk(0, 0, 0);
  private bk NullChunk = new bk(0, 0, 0);

  static int scanrangediamond = 7;
  static int scanrangespawners = scanrangediamond * 4;

   public ar(Minecraft var1)
   {
      super(gb.aO.a(0));
      this.h = new int[TileSize.int_numPixels];
      this.g = var1;
      this.f = 1;

      try {
         BufferedImage var2 = TextureUtils.getResourceAsBufferedImage("/gui/items.png");
         int var3 = this.b % 16 * TileSize.int_size;
         int var4 = this.b / 16 * TileSize.int_size;
         var2.getRGB(var3, var4, TileSize.int_size, TileSize.int_size, this.h, 0, TileSize.int_size);
      } catch (IOException var5) {
         var5.printStackTrace();
      }

   }

   public void a()
   {
      for(int var1 = 0; var1 < TileSize.int_numPixels; ++var1) {
         int var2 = this.h[var1] >> 24 & 255;
         int var3 = this.h[var1] >> 16 & 255;
         int var4 = this.h[var1] >> 8 & 255;
         int var5 = this.h[var1] >> 0 & 255;
         if(this.c) {
            int var6 = (var3 * 30 + var4 * 59 + var5 * 11) / 100;
            int var7 = (var3 * 30 + var4 * 70) / 100;
            int var8 = (var3 * 30 + var5 * 70) / 100;
            var3 = var6;
            var4 = var7;
            var5 = var8;
         }

         this.a[var1 * 4 + 0] = (byte)var3;
         this.a[var1 * 4 + 1] = (byte)var4;
         this.a[var1 * 4 + 2] = (byte)var5;
         this.a[var1 * 4 + 3] = (byte)var2;
      }

	  int iterator;
      if(this.g.e != null && this.g.g != null)
	  {
	    if (!areSettingsLoaded)
		{
			initializeSettingsFile();
		}
		
		drawNeedle(0, computeNeedleHeading(this.g.e.u()), this.spawnNeedleColor, true);
		
		boolean updateScan = false;
		if (((int)this.g.g.aK != this.x) || ((int)this.g.g.aL != this.y) || ((int)this.g.g.aM != this.z))
		{
			this.x = (int)this.g.g.aK;
			this.y = (int)this.g.g.aL;
			this.z = (int)this.g.g.aM;
			updateScan = true;
		}
		
		if ((this.y <= 16) && (updateScan))
		{
			this.DiamondOre = findNearestBlockChunkOfIDInRange(to.aw.bl, this.x, this.y, this.z, scanrangediamond, 1);
		}
		  

		if (!this.DiamondOre.equals(this.NullChunk)) {
			drawNeedle(1, computeNeedleHeading(this.DiamondOre), this.diamondNeedleColor, false);
		}
		if ((this.y <= 60) && (updateScan))
		{
			bk currentBlock = new bk(this.x, this.y, this.z);

			if (GetDistanceBetweenChunks(this.lastScanBlock, currentBlock) > scanrangespawners)
			{
			  this.lastScanBlock = currentBlock;
			  this.MobSpawner = findNearestBlockChunkOfIDInRange(to.as.bl, this.x, this.y, this.z, scanrangespawners, scanrangespawners);
			}
		}

		if (!this.MobSpawner.equals(this.NullChunk))
		{
			if ((Math.abs(this.x - this.MobSpawner.a) < 2) && (Math.abs(this.z - this.MobSpawner.c) < 2))
			{
			  if (this.y > this.MobSpawner.b)
			  {
				drawNeedle(2, 0.0D, this.spawnerNeedleColor, false);
			  }
			  else
			  {
				drawNeedle(2, 135.0D, this.spawnerNeedleColor, false);
			  }
			}
			else
			{
			  drawNeedle(2, computeNeedleHeading(this.MobSpawner), this.spawnerNeedleColor, false);
			}
		}

		if (updateScan)
		{
			for (Map.Entry entry : customNeedles.entrySet())
			{
			  int ID = ((Integer)entry.getKey()).intValue();
			  int[] color = (int[])entry.getValue();

			  bk iC = findNearestBlockChunkOfIDInRange(ID, this.x, this.y, this.z, scanrangediamond, 1);

			  if (!iC.equals(this.NullChunk))
			  {
				if (customNeedleTargets.containsKey(color))
				{
				  customNeedleTargets.remove(color);
				}
				customNeedleTargets.put(color, iC);
			  }
			  else
			  {
				customNeedleTargets.remove(color);
			  }
			}
		}

		iterator = 2;

		for (Map.Entry entry2 : customNeedleTargets.entrySet())
		{
			int[] color2 = (int[])entry2.getKey();
			bk target = (bk)entry2.getValue();
			iterator++;

			drawNeedle(iterator, computeNeedleHeading(target), color2, false);
		}
	  }
	}
		  
		  
	public double computeNeedleHeading(bk chunkcoordinates)
	{
		double var20 = 0.0D;
		if(this.g.e != null && this.g.g != null)
		{
			double var23 = chunkcoordinates.a - this.g.g.aK;
			double var25 = chunkcoordinates.c - this.g.g.aM;
			var20 = (double)(this.g.g.aQ - 90.0F) * 3.141592653589793D / 180.0D - Math.atan2(var25, var23);
			if(this.g.e.o.c)
			{
				var20 = Math.random() * 3.1415927410125732D * 2.0D;
			}
		}

		return var20;
	}
	
  public void drawNeedle(int needleIterator, double d, int[] color, boolean drawCenter)
  {
    double d1;
    for (d1 = d - this.i[needleIterator]; d1 < -3.141592653589793D; d1 += 6.283185307179586D);
    while (d1 >= 3.141592653589793D) d1 -= 6.283185307179586D;
    if (d1 < -1.0D)
    {
      d1 = -1.0D;
    }
    if (d1 > 1.0D)
    {
      d1 = 1.0D;
    }
    this.i[needleIterator] += d1 * 0.1D;
    this.j[needleIterator] *= 0.8D;
    this.j[needleIterator] += this.i[needleIterator];
    double d3 = Math.sin(this.i[needleIterator]);
    double d5 = Math.cos(this.i[needleIterator]);

    if (drawCenter)
    {
      for (int i2 = TileSize.int_compassCrossMin; i2 <= TileSize.int_compassCrossMax; i2++)
      {
        int k2 = (int)(TileSize.double_compassCenterMax + d5 * i2 * 0.3D);
        int i3 = (int)(TileSize.double_compassCenterMin - d3 * i2 * 0.3D * 0.5D);
        int k3 = i3 * TileSize.int_size + k2;
        int i4 = 100;
        int k4 = 100;
        int i5 = 100;
        char c = '�';
        if (this.c)
        {
          int k5 = (i4 * 30 + k4 * 59 + i5 * 11) / 100;
          int i6 = (i4 * 30 + k4 * 70) / 100;
          int k6 = (i4 * 30 + i5 * 70) / 100;
          i4 = k5;
          k4 = i6;
          i5 = k6;
        }
        this.a[(k3 * 4 + 0)] = (byte)i4;
        this.a[(k3 * 4 + 1)] = (byte)k4;
        this.a[(k3 * 4 + 2)] = (byte)i5;
        this.a[(k3 * 4 + 3)] = (byte)c;
      }
    }

    for (int j2 = TileSize.int_compassNeedleMin; j2 <= TileSize.int_compassNeedleMax; j2++)
    {
      int l2 = (int)(TileSize.double_compassCenterMax + d3 * j2 * 0.3D);
      int j3 = (int)(TileSize.double_compassCenterMin + d5 * j2 * 0.3D * 0.5D);
      int l3 = j3 * TileSize.int_size + l2;
      int j4 = j2 < 0 ? 100 : color[0];
      int l4 = j2 < 0 ? 100 : color[1];
      int j5 = j2 < 0 ? 100 : color[2];
      char c1 = '�';
      if (this.c)
      {
        int l5 = (j4 * 30 + l4 * 59 + j5 * 11) / 100;
        int j6 = (j4 * 30 + l4 * 70) / 100;
        int l6 = (j4 * 30 + j5 * 70) / 100;
        j4 = l5;
        l4 = j6;
        j5 = l6;
      }
      this.a[(l3 * 4 + 0)] = (byte)j4;
      this.a[(l3 * 4 + 1)] = (byte)l4;
      this.a[(l3 * 4 + 2)] = (byte)j5;
      this.a[(l3 * 4 + 3)] = (byte)c1;
    }
  }

  void initializeSettingsFile()
  {
    settingsFile = new File(Minecraft.a("minecraft"), "findercompass.cfg");
    System.out.println("initializeSettingsFile() running");
    try
    {
      if (settingsFile.exists())
      {
        System.out.println(".minecraft/findercompass.cfg found and opened");

        BufferedReader in = new BufferedReader(new FileReader(settingsFile));
        String sCurrentLine;
        while ((sCurrentLine = in.readLine()) != null)
        {
          if (sCurrentLine.startsWith("SearchDistance"))
          {
            String[] distLine = sCurrentLine.split(":");
            scanrangediamond = Integer.parseInt(distLine[1]);
            scanrangespawners = scanrangediamond * 4;
            continue;
          }if (sCurrentLine.startsWith("//"))
            continue;
          String[] curLine = sCurrentLine.split(":");

          int ID = Integer.parseInt(curLine[0]);

          int[] color = new int[3];
          color[0] = Integer.parseInt(curLine[1]);
          color[1] = Integer.parseInt(curLine[2]);
          color[2] = Integer.parseInt(curLine[3]);

          customNeedles.put(Integer.valueOf(ID), color);
          this.g.u.a(new StringBuilder().append("Finder Compass: loaded custom needle of id ").append(ID).append(", color [").append(color[0]).append(",").append(color[1]).append(",").append(color[2]).toString());
          System.out.println(new StringBuilder().append("Finder Compass: loaded custom needle of id ").append(ID).append(", color [").append(color[0]).append(",").append(color[1]).append(",").append(color[2]).toString());
        }

        in.close();
      }
      else
      {
        this.g.u.a(".minecraft/findercompass.cfg not found, using defaults");
      }
    }
    catch (Exception fuckdammit)
    {
      System.out.println("EXCEPTION BufferedReader");
    }

    areSettingsLoaded = true;
  }

  List findBlocksOfIDInRange(int ID, int xpos, int ypos, int zpos, int flatrange, int depthrange)
  {
    List returnList = new ArrayList();

    for (int b = ypos - depthrange - 1; b <= ypos + depthrange; b++)
    {
      if (b < 1)
        continue;
      for (int c = zpos - flatrange; c <= zpos + flatrange; c++)
      {
        for (int a = xpos - flatrange; a <= xpos + flatrange; a++)
        {
          if (this.g.e.a(a, b, c) != ID)
            continue;
          bk addObj = new bk(a, b, c);
          returnList.add(addObj);
        }
      }

    }

    return returnList;
  }

  bk findNearestBlockChunkOfIDInRange(int ID, int xpos, int ypos, int zpos, int flatrange, int depthrange)
  {
    List blocklist = findBlocksOfIDInRange(ID, xpos, ypos, zpos, flatrange, depthrange);

    bk origin = new bk(xpos, ypos, zpos);
    bk returnblock = new bk(0, 0, 0);
    double mindistance = 9999.0D;

    for (int a = 0; a < blocklist.size(); a++)
    {
      bk loopagainst = (bk)blocklist.get(a);
      double checkdistance = GetDistanceBetweenChunks(origin, loopagainst);

      if (checkdistance >= mindistance)
        continue;
      returnblock = loopagainst;
      mindistance = checkdistance;
    }

    bk returnchunkcoords = new bk(returnblock.a, returnblock.b, returnblock.c);
    return returnchunkcoords;
  }

  double GetDistanceBetweenChunks(bk BlockA, bk BlockB)
  {
    int xDiff = Math.abs(BlockA.a - BlockB.a);
    int yDiff = Math.abs(BlockA.b - BlockB.b);
    int zDiff = Math.abs(BlockA.c - BlockB.c);

    return Math.sqrt(Math.pow(xDiff, 2.0D) + Math.pow(yDiff, 2.0D) + Math.pow(zDiff, 2.0D));
  }

	/*
  public void drawNeedle(int needleIterator, double d, int[] color, boolean drawCenter)
  {
      double var22;
      for(var22 = var20 - this.i; var22 < -3.141592653589793D; var22 += 6.283185307179586D) {
         ;
      }

      while(var22 >= 3.141592653589793D) {
         var22 -= 6.283185307179586D;
      }

      if(var22 < -1.0D) {
         var22 = -1.0D;
      }

      if(var22 > 1.0D) {
         var22 = 1.0D;
      }

      this.j += var22 * 0.1D;
      this.j *= 0.8D;
      this.i += this.j;
      double var24 = Math.sin(this.i);
      double var26 = Math.cos(this.i);

      int var9;
      int var10;
      int var11;
      int var12;
      int var13;
      int var14;
      int var15;
      int var17;
      short var16;
      int var19;
      int var18;
      for(var9 = TileSize.int_compassCrossMin; var9 <= TileSize.int_compassCrossMax; ++var9) {
         var10 = (int)(TileSize.double_compassCenterMax + var26 * (double)var9 * 0.3D);
         var11 = (int)(TileSize.double_compassCenterMin - var24 * (double)var9 * 0.3D * 0.5D);
         var12 = var11 * TileSize.int_size + var10;
         var13 = 100;
         var14 = 100;
         var15 = 100;
         var16 = 255;
         if(this.c) {
            var17 = (var13 * 30 + var14 * 59 + var15 * 11) / 100;
            var18 = (var13 * 30 + var14 * 70) / 100;
            var19 = (var13 * 30 + var15 * 70) / 100;
            var13 = var17;
            var14 = var18;
            var15 = var19;
         }

         this.a[var12 * 4 + 0] = (byte)var13;
         this.a[var12 * 4 + 1] = (byte)var14;
         this.a[var12 * 4 + 2] = (byte)var15;
         this.a[var12 * 4 + 3] = (byte)var16;
      }

      for(var9 = TileSize.int_compassNeedleMin; var9 <= TileSize.int_compassNeedleMax; ++var9) {
         var10 = (int)(TileSize.double_compassCenterMax + var24 * (double)var9 * 0.3D);
         var11 = (int)(TileSize.double_compassCenterMin + var26 * (double)var9 * 0.3D * 0.5D);
         var12 = var11 * TileSize.int_size + var10;
         var13 = var9 >= 0?255:100;
         var14 = var9 >= 0?20:100;
         var15 = var9 >= 0?20:100;
         var16 = 255;
         if(this.c) {
            var17 = (var13 * 30 + var14 * 59 + var15 * 11) / 100;
            var18 = (var13 * 30 + var14 * 70) / 100;
            var19 = (var13 * 30 + var15 * 70) / 100;
            var13 = var17;
            var14 = var18;
            var15 = var19;
         }

         this.a[var12 * 4 + 0] = (byte)var13;
         this.a[var12 * 4 + 1] = (byte)var14;
         this.a[var12 * 4 + 2] = (byte)var15;
         this.a[var12 * 4 + 3] = (byte)var16;
      }

   }
   */
}
