package com.pclewis.mcpatcher.mod;

import com.pclewis.mcpatcher.*;
import javassist.bytecode.*;
import java.io.IOException;
import static javassist.bytecode.Opcode.*;

public class SimplyHax extends Mod {

    public SimplyHax(MinecraftVersion minecraftVersion) {
        name = "SimplyHax";
        author = "AtomicStryker";
        description = "Flying, keep Inventory on Death, Vision through walls";
        website = "";
        version = "1.0.2";

        classMods.add(new AxisAlignedBBMod());
        classMods.add(new BlockMod());
        classMods.add(new EntityMod());
        classMods.add(new EntityItemMod());
        classMods.add(new EntityLivingMod());
        classMods.add(new EntityPlayerMod());
        classMods.add(new EntityPlayerSPMod());
        classMods.add(new EntityRendererMod());
        classMods.add(new EnumMovingObjectTypeMod());
        classMods.add(new GuiScreenMod());
        classMods.add(new ItemStackMod());
        classMods.add(new InventoryPlayerMod());
        classMods.add(new MinecraftMod());
        classMods.add(new NBTTagCompoundMod());
        classMods.add(new MovingObjectPositionMod());
        classMods.add(new PlayerControllerMod());
        classMods.add(new PlayerControllerSPMod());
        classMods.add(new RenderMod());
        classMods.add(new RenderHelperMod());
        classMods.add(new RenderGlobalMod());
        classMods.add(new RenderManagerMod());
        classMods.add(new WorldMod());
        classMods.add(new WorldRendererMod());

        filesToAdd.add(ClassMap.classNameToFilename("SimplyHaxFlying"));
        filesToAdd.add(ClassMap.classNameToFilename("SimplyHaxVision"));
        filesToAdd.add(ClassMap.classNameToFilename("SimplyHaxInventoryVanilla"));
    }

    private class AxisAlignedBBMod extends ClassMod {
        AxisAlignedBBMod() {
            classSignatures.add(new ConstSignature("box["));
            classSignatures.add(new ConstSignature(" -> "));
            classSignatures.add(new ConstSignature("]"));
            // those unique strings should determine AxisAlignedBB safely

            memberMappers.add(new MethodMapper(new String[]{
                "clearBoundingBoxes",
                "clearBoundingBoxPool"},
                "()V")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, true)
            );

            memberMappers.add(new MethodMapper(new String[]{
                "addCoord",
                "expand"},
                "(DDD)LAxisAlignedBB;")
            );
        }
    }

    private class BlockMod extends ClassMod {
        public BlockMod() {
            classSignatures.add(new ConstSignature(" is already occupied by "));

            memberMappers.add(new FieldMapper("blocksList", "[LBlock;"));

            memberMappers.add(new MethodMapper("renderAsNormalBlock", "()Z")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false)
            );

            memberMappers.add(new MethodMapper("blockStrength", "(LEntityPlayer;)F"));
        }
    }

    private class EntityMod extends ClassMod {
        public EntityMod() {
            classSignatures.add(new ConstSignature("Pos"));
            classSignatures.add(new ConstSignature("Motion"));
            classSignatures.add(new ConstSignature("Rotation"));

            memberMappers.add(new FieldMapper("worldObj", "LWorld;"));
            memberMappers.add(new FieldMapper("boundingBox", "LAxisAlignedBB;"));

            memberMappers.add(new MethodMapper("entityInit", "()V")
                .accessFlag(AccessFlag.PROTECTED, true)
                .accessFlag(AccessFlag.ABSTRACT, true)
            );

            memberMappers.add(new MethodMapper(new String[]{
                "readEntityFromNBT",
                "writeEntityToNBT",
            }, "(LNBTTagCompound;)V"));

            memberMappers.add(new FieldMapper(new String[]{
                "preventEntitySpawning",
                "onGround",
                "isCollidedHorizontally",
                "isCollidedVertically",
                "isCollided",
                "beenAttacked",
                null,
                "isDead",
                "noClip",
                null,
                "ignoreFrustumCheck"
            }, "Z").accessFlag(AccessFlag.PROTECTED, false));

            memberMappers.add(new FieldMapper(new String[]{
                "renderDistanceWeight",
                "prevPosX",
                "prevPosY",
                "prevPosZ",
                "posX",
                "posY",
                "posZ",
                "motionX",
                "motionY",
                "motionZ",
            }, "D"));

            memberMappers.add(new FieldMapper(new String[]{
                "rotationYaw",
                "rotationPitch",
                "prevRotationYaw",
                "prevRotationPitch",
                "yOffset",
                "width",
                "height",
                "prevDistanceWalkedModified",
                "distanceWalkedModified",
                "fallDistance",
            }, "F"));

            memberMappers.add(new MethodMapper(new String[]{
                "isWet",
                "isInWater",
                null,
                null,
                null,
                null,
                null,
                "isEntityAlive",
                null,
                "isEntityBurning"
                }, "()Z")
                .accessFlag(AccessFlag.PUBLIC, true)
                .accessFlag(AccessFlag.STATIC, false)
            );

            memberMappers.add(new MethodMapper(new String[]{
                "setEntityDead",
                "onUpdate",
                "onEntityUpdate"
                }, "()V")
                .accessFlag(AccessFlag.PUBLIC, true)
                .accessFlag(AccessFlag.STATIC, false)
                .accessFlag(AccessFlag.ABSTRACT, false)
                .accessFlag(AccessFlag.PROTECTED, false)
            );

            memberMappers.add(new MethodMapper(new String[]{
                "setPosition",
                "moveEntity",
                "addVelocity"
                }, "(DDD)V")
                .accessFlag(AccessFlag.PUBLIC, true)
                .accessFlag(AccessFlag.STATIC, false)
                .accessFlag(AccessFlag.ABSTRACT, false)
                .accessFlag(AccessFlag.PROTECTED, false)
            );
        }

        @Override
        public void prePatch(String filename, ClassFile classFile) {
            mod.getClassMap().addInheritance(getDeobfClass(), "EntityPlayer");
            mod.getClassMap().addInheritance(getDeobfClass(), "EntityPlayerSP");
        }
    }

    private class EntityItemMod extends ClassMod {
        public EntityItemMod() {
            classSignatures.add(new ConstSignature("Health"));
            classSignatures.add(new ConstSignature("Age"));
            classSignatures.add(new ConstSignature("Item"));
            classSignatures.add(new ConstSignature("random.pop"));
            classSignatures.add(new ConstSignature("random.fizz"));

            memberMappers.add(new FieldMapper("item", "LItemStack;"));

            //memberMappers.add(new FieldMapper("worldObj", "LWorld;"));
        }
    }

    private class EntityLivingMod extends ClassMod {
        public EntityLivingMod() {
            parentClass = "Entity";

            classSignatures.add(new ConstSignature("ActiveEffects"));
            classSignatures.add(new ConstSignature("Health"));
            classSignatures.add(new ConstSignature("HurtTime"));

            memberMappers.add(new FieldMapper("health", "I").accessFlag(AccessFlag.PROTECTED, true));
        }

        @Override
        public void prePatch(String filename, ClassFile classFile) {
            mod.getClassMap().addInheritance(getDeobfClass(), "EntityPlayer");
            mod.getClassMap().addInheritance(getDeobfClass(), "EntityPlayerSP");
        }
    }

    private class EntityPlayerMod extends ClassMod {
        public EntityPlayerMod() {
            parentClass = "EntityLiving";

            classSignatures.add(new ConstSignature("humanoid"));
            classSignatures.add(new ConstSignature("/mob/char.png"));

            memberMappers.add(new FieldMapper("inventory", "LInventoryPlayer;"));
            //memberMappers.add(new FieldMapper("worldObj", "LWorld;"));
        }
    }

    private class EntityPlayerSPMod extends ClassMod {
        public EntityPlayerSPMod() {
            parentClass = "EntityPlayer";

            classSignatures.add(new ConstSignature("http://s3.amazonaws.com/MinecraftSkins/"));

            classSignatures.add(new BytecodeSignature() {
                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    return buildExpression(
                        push(methodInfo, "portal.trigger")
                    );
                }
            }.setMethodName("onLivingUpdate"));
        }
    }

    private class EntityRendererMod extends ClassMod {
        public EntityRendererMod() {
            classSignatures.add(new ConstSignature("/terrain.png"));
            classSignatures.add(new ConstSignature("ambient.weather.rain"));
            classSignatures.add(new ConstSignature("/environment/snow.png"));
            classSignatures.add(new ConstSignature("/environment/rain.png"));

            memberMappers.add(new MethodMapper(new String[]{
                "getMouseOver",
                "updateCameraAndRender"},
                "(F)V")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false)
            );

            patches.add(new BytecodePatch.InsertAfter() {
                @Override
                public String getDescription() {
                    return "add OnTick Hook";
                }

                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    JavaRef actionPerformed = classMap.map(new MethodRef("EntityRenderer", "updateCameraAndRender", "(F)V"));
                    if (methodInfo.getName().equals(actionPerformed.getName()) &&
                        methodInfo.getDescriptor().equals(actionPerformed.getType())) {
                        return buildExpression(
                            BinaryRegex.begin()
                        );
                    } else {
                        return null;
                    }
                }

                @Override
                public byte[] getInsertBytes(MethodInfo methodInfo) throws IOException {
                    return buildCode(
                        reference(methodInfo, INVOKESTATIC, new MethodRef("SimplyHaxFlying", "OnTickInGame", "()V")),
                        reference(methodInfo, INVOKESTATIC, new MethodRef("SimplyHaxVision", "OnTickInGame", "()V")),
                        reference(methodInfo, INVOKESTATIC, new MethodRef("SimplyHaxInventoryVanilla", "OnTickInGame", "()V"))
                    );
                }
            });
        }
    }

    private class EnumMovingObjectTypeMod extends ClassMod {
        EnumMovingObjectTypeMod() {
            classSignatures.add(new ConstSignature("TILE"));
            classSignatures.add(new ConstSignature("ENTITY"));

            memberMappers.add(new FieldMapper(new String[]{"TILE", "ENTITY"}, "LEnumMovingObjectType;"));
        }
    }

    private class GuiScreenMod extends ClassMod {
        GuiScreenMod() {
            classSignatures.add(new ConstSignature("random.click"));
            classSignatures.add(new ConstSignature("/gui/background.png"));
        }
    }

    private class InventoryPlayerMod extends ClassMod {
        public InventoryPlayerMod() {
            classSignatures.add(new ConstSignature("Inventory"));
            classSignatures.add(new ConstSignature("Slot"));

            memberMappers.add(new MethodMapper(new String[]{
                "getStackInSlot",
                "armorItemInSlot"},
                "(I)LItemStack;")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false)
            );

            memberMappers.add(new MethodMapper("getCurrentItem", "()LItemStack;"));
            memberMappers.add(new FieldMapper("currentItem", "I"));

            memberMappers.add(new FieldMapper(new String[]{
                "mainInventory",
                "armorInventory"},
                "[LItemStack;")
                .accessFlag(AccessFlag.PUBLIC, true)
                .accessFlag(AccessFlag.STATIC, false)
            );
        }
    }

    private class ItemStackMod extends ClassMod {
        public ItemStackMod() {
            classSignatures.add(new ConstSignature("id"));
            classSignatures.add(new ConstSignature("Count"));
            classSignatures.add(new ConstSignature("Damage"));

            memberMappers.add(new FieldMapper(new String[]{
                "stackSize",
                "animationsToGo",
                "itemID"
            }, "I")
                .accessFlag(AccessFlag.PUBLIC, true)
            );

            memberMappers.add(new MethodMapper("copy", "()LItemStack;"));
        }
    }

    private class MinecraftMod extends ClassMod {
        public MinecraftMod()
        {
            classSignatures.add(new FilenameSignature("net/minecraft/client/Minecraft.class"));

            memberMappers.add(new FieldMapper("thePlayer", "LEntityPlayerSP;"));
            memberMappers.add(new FieldMapper("theWorld", "LWorld;"));
            memberMappers.add(new MethodMapper("getMinecraftDir", "()Ljava/io/File;"));
            memberMappers.add(new MethodMapper("getAppDir", "(Ljava/lang/String;)Ljava/io/File;"));

            memberMappers.add(new FieldMapper("objectMouseOver", "LMovingObjectPosition;"));
            memberMappers.add(new FieldMapper("renderGlobal", "LRenderGlobal;"));
            memberMappers.add(new FieldMapper("currentScreen", "LGuiScreen;"));

            patches.add(new BytecodePatch.InsertAfter() {
                @Override
                public String getDescription() {
                    return "init in Minecraft";
                }

                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    return buildExpression(
                        push(methodInfo, "Post startup")
                    );
                }

                @Override
                public byte[] getInsertBytes(MethodInfo methodInfo) throws IOException {
                    return buildCode(
                        ALOAD_0,
                        reference(methodInfo, INVOKESTATIC, new MethodRef("SimplyHaxFlying", "init", "(LMinecraft;)V")),
                        ALOAD_0,
                        reference(methodInfo, INVOKESTATIC, new MethodRef("SimplyHaxVision", "init", "(LMinecraft;)V")),
                        ALOAD_0,
                        reference(methodInfo, INVOKESTATIC, new MethodRef("SimplyHaxInventoryVanilla", "init", "(LMinecraft;)V"))
                    );
                }
            });
        }
    }

    private class NBTTagCompoundMod extends ClassMod {
        NBTTagCompoundMod() {
            classSignatures.add(new ConstSignature(" entries"));
        }
    }

    private class MovingObjectPositionMod extends ClassMod {
        MovingObjectPositionMod() {
            classSignatures.add(new BytecodeSignature() {
                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    return buildExpression(
                        BinaryRegex.begin(),
                        ALOAD_0,
                        INVOKESPECIAL, BinaryRegex.any(2),
                        ALOAD_0,

                        BinaryRegex.or(
                            buildExpression(
                                GETSTATIC, BinaryRegex.any(2)
                            ),
                            buildExpression(
                                ICONST_M1,
                                PUTFIELD, BinaryRegex.any(2),
                                ALOAD_0,
                                GETSTATIC, BinaryRegex.any(2)
                            )
                        ),

                        PUTFIELD, BinaryRegex.any(2),
                        ALOAD_0,
                        ILOAD_1,
                        PUTFIELD, BinaryRegex.any(2),
                        ALOAD_0,
                        ILOAD_2,
                        PUTFIELD, BinaryRegex.any(2),
                        ALOAD_0,
                        ILOAD_3,
                        PUTFIELD, BinaryRegex.any(2),
                        ALOAD_0,
                        ILOAD, 4,
                        PUTFIELD, BinaryRegex.any(2),
                        ALOAD_0,
                        ALOAD, 5,
                        GETFIELD, BinaryRegex.any(2),
                        ALOAD, 5,
                        GETFIELD, BinaryRegex.any(2),
                        ALOAD, 5,
                        GETFIELD, BinaryRegex.any(2),
                        INVOKESTATIC, BinaryRegex.any(2),
                        PUTFIELD, BinaryRegex.any(2),
                        RETURN,
                        BinaryRegex.end()
                    );
                }
            });

            memberMappers.add(new FieldMapper("typeOfHit", "LEnumMovingObjectType;"));

            memberMappers.add(new FieldMapper(new String[]{
                "blockX",
                "blockY",
                "blockZ"
                }, "I")
                .accessFlag(AccessFlag.PUBLIC, true)
                .accessFlag(AccessFlag.STATIC, false)
                .accessFlag(AccessFlag.ABSTRACT, false)
                .accessFlag(AccessFlag.PROTECTED, false)
            );
        }
    }

    private class PlayerControllerMod extends ClassMod {
        PlayerControllerMod() {
            classSignatures.add(new BytecodeSignature() {
                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    return buildExpression(
                        ALOAD, 5,
                        push(methodInfo, 2001),
                        ILOAD_1,
                        ILOAD_2,
                        ILOAD_3,
                        ALOAD, 6,
                        GETFIELD, BinaryRegex.any(2),
                        ALOAD, 5,
                        ILOAD_1,
                        ILOAD_2,
                        ILOAD_3,
                        INVOKEVIRTUAL, BinaryRegex.any(2),
                        push(methodInfo, 256),
                        IMUL,
                        IADD
                    );
                }
            });

            memberMappers.add(new FieldMapper("mc", "LMinecraft;"));
        }
    }

    private class PlayerControllerSPMod extends ClassMod {
        PlayerControllerSPMod() {
            parentClass = "PlayerController";

            classSignatures.add(new BytecodeSignature() {
                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    return buildExpression(
                        BinaryRegex.begin(),
                        ALOAD_1,
                        push(methodInfo, -180F),
                        PUTFIELD, BinaryRegex.any(2),
                        RETURN,
                        BinaryRegex.end()
                    );
                }
            });

            classSignatures.add(new BytecodeSignature() {
                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    return buildExpression(
                        BinaryRegex.begin(),
                        push(methodInfo, 4.0F),
                        FRETURN,
                        BinaryRegex.end()
                    );
                }
            });

            memberMappers.add(new MethodMapper("sendBlockRemoved", "(IIII)Z"));
            memberMappers.add(new MethodMapper("resetBlockRemoving", "()V"));

            memberMappers.add(new MethodMapper(new String[]{
                "clickBlock",
                "sendBlockRemoving"
                }, "(IIII)V")
            );

            memberMappers.add(new FieldMapper(new String[]{
                "curBlockDamage",
                "prevBlockDamage"
                }, "F")
                .accessFlag(AccessFlag.PRIVATE, true)
            );

            memberMappers.add(new FieldMapper(new String[]{
                "curBlockX",
                "curBlockY",
                "curBlockZ"
                }, "I")
                .accessFlag(AccessFlag.PRIVATE, true)
            );
        }
    }

    private class RenderMod extends ClassMod {
        RenderMod() {
            classSignatures.add(new ConstSignature("/terrain.png"));
            classSignatures.add(new ConstSignature("%clamp%/misc/shadow.png"));

            memberMappers.add(new MethodMapper("doRender", "(LEntity;DDDFF)V"));
        }
    }

    private class RenderHelperMod extends ClassMod {
        RenderHelperMod() {
            classSignatures.add(new BytecodeSignature() {
                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    return buildExpression(
                        push(methodInfo, 0.4F),
                        FSTORE_0,
                        push(methodInfo, 0.6F),
                        FSTORE_1,
                        FCONST_0,
                        FSTORE_2,
                        push(methodInfo, 0.20000000298023224D),
                        DCONST_1,
                        push(methodInfo, -0.699999988079071D),
                        INVOKESTATIC, BinaryRegex.any(2),
                        INVOKEVIRTUAL, BinaryRegex.any(2),
                        ASTORE_3
                    );
                }
            });

            memberMappers.add(new MethodMapper(new String[]{
                "disableStandardItemLighting",
                "enableStandardItemLighting"
                }, "()V")
                .accessFlag(AccessFlag.PUBLIC, true)
                .accessFlag(AccessFlag.STATIC, true)
                .accessFlag(AccessFlag.ABSTRACT, false)
                .accessFlag(AccessFlag.PROTECTED, false)
            );
        }
    }

    private class RenderGlobalMod extends ClassMod {
        RenderGlobalMod() {
            classSignatures.add(new ConstSignature("smoke"));

            classSignatures.add(new BytecodeSignature() {
                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    return buildExpression(
                        push(methodInfo, "/environment/clouds.png")
                    );
                }
            }.setMethodName("renderClouds"));

            // public boolean updateRenderers(EntityLiving var1, boolean var2) <- unique constructor
            memberMappers.add(new MethodMapper("updateRenderers", "(LEntityLiving;Z)Z"));

            memberMappers.add(new MethodMapper("sortAndRender", "(LEntityLiving;ID)I"));

            memberMappers.add(new FieldMapper("damagePartialTime", "F"));

            memberMappers.add(new MethodMapper(new String[]{
                "drawBlockBreaking",
                "drawSelectionBox"
                }, "(LEntityPlayer;LMovingObjectPosition;ILItemStack;F)V")
                .accessFlag(AccessFlag.PUBLIC, true)
                .accessFlag(AccessFlag.STATIC, false)
                .accessFlag(AccessFlag.ABSTRACT, false)
                .accessFlag(AccessFlag.PROTECTED, false)
            );

            patches.add(new BytecodePatch.InsertAfter() {
                @Override
                public String getDescription() {
                    return "Vision Renderer Hook";
                }

                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    JavaRef actionPerformed = classMap.map(new MethodRef("RenderGlobal", "sortAndRender", "(LEntityLiving;ID)I"));
                    if (methodInfo.getName().equals(actionPerformed.getName()) &&
                        methodInfo.getDescriptor().equals(actionPerformed.getType())) {
                        return buildExpression(
                            BinaryRegex.begin()
                        );
                    } else {
                        return null;
                    }
                }

                @Override
                public byte[] getInsertBytes(MethodInfo methodInfo) throws IOException {
                    return buildCode(
                        reference(methodInfo, INVOKESTATIC, new MethodRef("SimplyHaxVision", "preRender", "()V"))
                    );
                }
            });
        }
    }

    private class RenderManagerMod extends ClassMod {
        RenderManagerMod() {

            classSignatures.add(new BytecodeSignature() {
                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    return buildExpression(
                        BinaryRegex.begin(),
                        ALOAD_0,
                        GETFIELD, BinaryRegex.any(2),
                        ARETURN,
                        BinaryRegex.end()
                    );
                }
            });

            classSignatures.add(new BytecodeSignature() {
                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    return buildExpression(
                        BinaryRegex.begin(),
                        ALOAD_0,
                        ALOAD_1,
                        reference(methodInfo, INVOKEVIRTUAL, new MethodRef("java/lang/Object", "getClass", "()Ljava/lang/Class;")),
                        INVOKEVIRTUAL, BinaryRegex.any(2),
                        ARETURN,
                        BinaryRegex.end()
                    );
                }
            });

            memberMappers.add(new FieldMapper("entityRenderMap", "Ljava/util/Map;"));
            memberMappers.add(new FieldMapper("worldObj", "LWorld;"));
        }
    }

    private class WorldMod extends ClassMod {
        WorldMod() {
            classSignatures.add(new ConstSignature("ambient.cave.cave"));
            classSignatures.add(new ConstSignature("Unable to find spawn biome"));

            //public void playSoundAtEntity(Entity var1, String var2, float var3, float var4)
            memberMappers.add(new MethodMapper("playSoundAtEntity", "(LEntity;Ljava.lang.String;FF)V"));

            //public void markBlocksDirty(int var1, int var2, int var3, int var4, int var5, int var6)
            memberMappers.add(new MethodMapper("markBlocksDirty", "(IIIIII)V"));

            //public void setEntityDead()
            memberMappers.add(new MethodMapper("setEntityDead", "()V"));

            memberMappers.add(new MethodMapper("getBlockId", "(III)I")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false));

            memberMappers.add(new FieldMapper(new String[]{
                "loadedEntityList",
                "loadedTileEntityList"},
                "Ljava.util.List;")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false)
            );

            memberMappers.add(new MethodMapper(new String[]{
                "getBlockId",
                "getBlockMetadata",
                "getFullBlockLightValue",
                "getBlockLightValue"},
                "(III)I")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false)
            );

            memberMappers.add(new MethodMapper(new String[]{
                "markBlockNeedsUpdate",
                "markBlockAsNeedsUpdate",
                "removeBlockTileEntity",
                "updateAllLightTypes",
                "randomDisplayUpdates"},
                "(III)V")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false)
            );

            memberMappers.add(new MethodMapper("getBlockId", "(III)I")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false));

            memberMappers.add(new MethodMapper(new String[]{
                "getWorldSeed",
                "getWorldTime"},
                "()J")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false)
            );

            memberMappers.add(new MethodMapper(new String[]{
                "addWeatherEffect",
                "entityJoinedWorld"},
                "(LEntity;)Z")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false)
            );

            memberMappers.add(new MethodMapper(new String[]{
                "getCollidingBoundingBoxes",
                "getEntitiesWithinAABBExcludingEntity"},
                "(LEntity;LAxisAlignedBB;)Ljava/util/List;")
            );
        }
    }

    private class WorldRendererMod extends ClassMod {
        public WorldRendererMod() {
            classSignatures.add(new ConstSignature(new MethodRef("org.lwjgl.opengl.GL11", "glNewList", "(II)V")));

            classSignatures.add(new BytecodeSignature() {
                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    return buildExpression(
                        push(methodInfo, -999)
                    );
                }
            });

            memberMappers.add(new MethodMapper(new String[]{
                "setupGLTranslation",
                "updateRenderer"},
                "()V")
            );

            memberMappers.add(new FieldMapper(new String[]{
                "isInFrustum",
                "needsUpdate"},
                "Z")
            );

            memberMappers.add(new FieldMapper("isInitialized", "Z")
            .accessFlag(AccessFlag.PRIVATE, true)
            .accessFlag(AccessFlag.STATIC, false));
        }
    }
}
