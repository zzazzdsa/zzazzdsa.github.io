package com.pclewis.mcpatcher.mod;

import com.pclewis.mcpatcher.*;
import com.sun.org.apache.bcel.internal.generic.ALOAD;
import com.sun.org.apache.bcel.internal.generic.ILOAD;
import javassist.bytecode.AccessFlag;
import javassist.bytecode.ClassFile;
import javassist.bytecode.MethodInfo;
import java.io.IOException;
import static javassist.bytecode.Opcode.*;

public class MultiMine extends Mod {

    public MultiMine(MinecraftVersion minecraftVersion) {
        name = "MultiMine";
        author = "AtomicStryker";
        description = "partially mined Blocks!";
        website = "";
        version = "1.0.2";

        classMods.add(new BlockMod());
        classMods.add(new EntityMod());
        classMods.add(new EntityPlayerMod());
        classMods.add(new EntityPlayerSPMod());
        classMods.add(new EntityRendererMod());
        classMods.add(new EnumMovingObjectTypeMod());
        classMods.add(new ItemStackMod());
        classMods.add(new InventoryPlayerMod());
        classMods.add(new MinecraftMod());
        classMods.add(new NBTTagCompoundMod());
        classMods.add(new MovingObjectPositionMod());
        classMods.add(new PlayerControllerMod());
        classMods.add(new PlayerControllerSPMod());
        classMods.add(new RenderMod());
        classMods.add(new RenderHelperMod());
        classMods.add(new RenderGlobalMod());
        classMods.add(new RenderManagerMod());
        classMods.add(new WorldMod());
        classMods.add(new WorldRendererMod());

        filesToAdd.add(ClassMap.classNameToFilename("AS_BlockWithDamage"));
        filesToAdd.add(ClassMap.classNameToFilename("AS_RenderEntityLahwran"));
        filesToAdd.add(ClassMap.classNameToFilename("AS_RenderHooks"));
        filesToAdd.add(ClassMap.classNameToFilename("AS_Settings_MultiMine"));
        filesToAdd.add(ClassMap.classNameToFilename("MultiMine"));
    }

    private class BlockMod extends ClassMod {
        public BlockMod() {
            classSignatures.add(new ConstSignature(" is already occupied by "));

            memberMappers.add(new FieldMapper("blocksList", "[LBlock;"));

            memberMappers.add(new MethodMapper("renderAsNormalBlock", "()Z")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false)
            );

            memberMappers.add(new MethodMapper("blockStrength", "(LEntityPlayer;)F"));
        }
    }

    private class EntityMod extends ClassMod {
        public EntityMod() {
            classSignatures.add(new ConstSignature("Pos"));
            classSignatures.add(new ConstSignature("Motion"));
            classSignatures.add(new ConstSignature("Rotation"));

            memberMappers.add(new FieldMapper("worldObj", "LWorld;"));

            memberMappers.add(new MethodMapper("entityInit", "()V")
                .accessFlag(AccessFlag.PROTECTED, true)
                .accessFlag(AccessFlag.ABSTRACT, true)
            );

            memberMappers.add(new MethodMapper(new String[]{
                "readEntityFromNBT",
                "writeEntityToNBT",
            }, "(LNBTTagCompound;)V"));

            memberMappers.add(new FieldMapper(new String[]{
                "preventEntitySpawning",
                "onGround",
                "isCollidedHorizontally",
                "isCollidedVertically",
                "isCollided",
                "beenAttacked",
                null,
                "isDead",
                "noClip",
                null,
                "ignoreFrustumCheck"
            }, "Z").accessFlag(AccessFlag.PROTECTED, false));

            memberMappers.add(new FieldMapper(new String[]{
                "renderDistanceWeight",
                "prevPosX",
                "prevPosY",
                "prevPosZ",
                "posX",
                "posY",
                "posZ",
            }, "D"));

            memberMappers.add(new MethodMapper(new String[]{
                "isWet",
                "isInWater",
                null,
                null,
                null,
                null,
                null,
                "isEntityAlive",
                null,
                "isEntityBurning"
                }, "()Z")
                .accessFlag(AccessFlag.PUBLIC, true)
                .accessFlag(AccessFlag.STATIC, false)
            );

            memberMappers.add(new MethodMapper(new String[]{
                "setEntityDead",
                "onUpdate",
                "onEntityUpdate"
                }, "()V")
                .accessFlag(AccessFlag.PUBLIC, true)
                .accessFlag(AccessFlag.STATIC, false)
                .accessFlag(AccessFlag.ABSTRACT, false)
                .accessFlag(AccessFlag.PROTECTED, false)
            );

            memberMappers.add(new MethodMapper(new String[]{
                "setPosition",
                "moveEntity",
                "addVelocity"
                }, "(DDD)V")
                .accessFlag(AccessFlag.PUBLIC, true)
                .accessFlag(AccessFlag.STATIC, false)
                .accessFlag(AccessFlag.ABSTRACT, false)
                .accessFlag(AccessFlag.PROTECTED, false)
            );
        }

        @Override
        public void prePatch(String filename, ClassFile classFile) {
            mod.getClassMap().addInheritance(getDeobfClass(), "AS_RenderEntityLahwran");
            mod.getClassMap().addInheritance(getDeobfClass(), "EntityPlayer");
            mod.getClassMap().addInheritance(getDeobfClass(), "EntityPlayerSP");
        }
    }

    private class EntityPlayerMod extends ClassMod {
        public EntityPlayerMod() {
            parentClass = "EntityLiving";

            classSignatures.add(new ConstSignature("humanoid"));
            classSignatures.add(new ConstSignature("/mob/char.png"));

            memberMappers.add(new FieldMapper("inventory", "LInventoryPlayer;"));
            //memberMappers.add(new FieldMapper("worldObj", "LWorld;"));
        }
    }

    private class EntityPlayerSPMod extends ClassMod {
        public EntityPlayerSPMod() {
            parentClass = "EntityPlayer";

            classSignatures.add(new ConstSignature("http://s3.amazonaws.com/MinecraftSkins/"));

            classSignatures.add(new BytecodeSignature() {
                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    return buildExpression(
                        push(methodInfo, "portal.trigger")
                    );
                }
            }.setMethodName("onLivingUpdate"));
        }
    }

    private class EntityRendererMod extends ClassMod {
        public EntityRendererMod() {
            classSignatures.add(new ConstSignature("/terrain.png"));
            classSignatures.add(new ConstSignature("ambient.weather.rain"));
            classSignatures.add(new ConstSignature("/environment/snow.png"));
            classSignatures.add(new ConstSignature("/environment/rain.png"));

            memberMappers.add(new MethodMapper(new String[]{
                "getMouseOver",
                "updateCameraAndRender"},
                "(F)V")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false)
            );

            patches.add(new BytecodePatch.InsertAfter() {
                @Override
                public String getDescription() {
                    return "add MultiMine OnTick Hook";
                }

                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    JavaRef actionPerformed = classMap.map(new MethodRef("EntityRenderer", "updateCameraAndRender", "(F)V"));
                    if (methodInfo.getName().equals(actionPerformed.getName()) &&
                        methodInfo.getDescriptor().equals(actionPerformed.getType())) {
                        return buildExpression(
                            BinaryRegex.begin()
                        );
                    } else {
                        return null;
                    }
                }

                @Override
                public byte[] getInsertBytes(MethodInfo methodInfo) throws IOException {
                    return buildCode(
                        reference(methodInfo, INVOKESTATIC, new MethodRef("MultiMine", "OnTickInGame", "()V"))
                    );
                }
            });
        }
    }

    private class EnumMovingObjectTypeMod extends ClassMod {
        EnumMovingObjectTypeMod() {
            classSignatures.add(new ConstSignature("TILE"));
            classSignatures.add(new ConstSignature("ENTITY"));

            memberMappers.add(new FieldMapper(new String[]{"TILE", "ENTITY"}, "LEnumMovingObjectType;"));
        }
    }

    private class InventoryPlayerMod extends ClassMod {
        public InventoryPlayerMod() {
            classSignatures.add(new ConstSignature("Inventory"));
            classSignatures.add(new ConstSignature("Slot"));

            memberMappers.add(new MethodMapper(new String[]{
                "getStackInSlot",
                "armorItemInSlot"},
                "(I)LItemStack;")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false)
            );

            memberMappers.add(new MethodMapper("getCurrentItem", "()LItemStack;"));
            memberMappers.add(new FieldMapper("currentItem", "I"));

            memberMappers.add(new FieldMapper(new String[]{"mainInventory", "armorInventory"}, "[LItemStack;")
                .accessFlag(AccessFlag.PUBLIC, true)
                .accessFlag(AccessFlag.STATIC, false)
            );
        }
    }

    private class ItemStackMod extends ClassMod {
        public ItemStackMod() {
            classSignatures.add(new ConstSignature("id"));
            classSignatures.add(new ConstSignature("Count"));
            classSignatures.add(new ConstSignature("Damage"));

            memberMappers.add(new FieldMapper(new String[]{
                "stackSize",
                "animationsToGo",
                "itemID"
            }, "I")
                .accessFlag(AccessFlag.PUBLIC, true)
            );
        }
    }

    private class MinecraftMod extends ClassMod {
        public MinecraftMod()
        {
            classSignatures.add(new FilenameSignature("net/minecraft/client/Minecraft.class"));

            memberMappers.add(new FieldMapper("thePlayer", "LEntityPlayerSP;"));
            memberMappers.add(new FieldMapper("theWorld", "LWorld;"));
            memberMappers.add(new MethodMapper("getMinecraftDir", "()Ljava/io/File;"));
            memberMappers.add(new MethodMapper("getAppDir", "(Ljava/lang/String;)Ljava/io/File;"));

            memberMappers.add(new FieldMapper("objectMouseOver", "LMovingObjectPosition;"));
            memberMappers.add(new FieldMapper("renderGlobal", "LRenderGlobal;"));

            patches.add(new BytecodePatch.InsertAfter() {
                @Override
                public String getDescription() {
                    return "MultiMine init in Minecraft";
                }

                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    return buildExpression(
                        push(methodInfo, "Post startup")
                    );
                }

                @Override
                public byte[] getInsertBytes(MethodInfo methodInfo) throws IOException {
                    return buildCode(
                        ALOAD_0,
                        reference(methodInfo, INVOKESTATIC, new MethodRef("MultiMine", "init", "(LMinecraft;)V"))
                    );
                }
            });
        }
    }

    private class NBTTagCompoundMod extends ClassMod {
        NBTTagCompoundMod() {
            classSignatures.add(new ConstSignature(" entries"));
        }
    }

    private class MovingObjectPositionMod extends ClassMod {
        MovingObjectPositionMod() {
            classSignatures.add(new BytecodeSignature() {
                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    return buildExpression(
                        BinaryRegex.begin(),
                        ALOAD_0,
                        INVOKESPECIAL, BinaryRegex.any(2),
                        ALOAD_0,

                        BinaryRegex.or(
                            buildExpression(
                                GETSTATIC, BinaryRegex.any(2)
                            ),
                            buildExpression(
                                ICONST_M1,
                                PUTFIELD, BinaryRegex.any(2),
                                ALOAD_0,
                                GETSTATIC, BinaryRegex.any(2)
                            )
                        ),

                        PUTFIELD, BinaryRegex.any(2),
                        ALOAD_0,
                        ILOAD_1,
                        PUTFIELD, BinaryRegex.any(2),
                        ALOAD_0,
                        ILOAD_2,
                        PUTFIELD, BinaryRegex.any(2),
                        ALOAD_0,
                        ILOAD_3,
                        PUTFIELD, BinaryRegex.any(2),
                        ALOAD_0,
                        ILOAD, 4,
                        PUTFIELD, BinaryRegex.any(2),
                        ALOAD_0,
                        ALOAD, 5,
                        GETFIELD, BinaryRegex.any(2),
                        ALOAD, 5,
                        GETFIELD, BinaryRegex.any(2),
                        ALOAD, 5,
                        GETFIELD, BinaryRegex.any(2),
                        INVOKESTATIC, BinaryRegex.any(2),
                        PUTFIELD, BinaryRegex.any(2),
                        RETURN,
                        BinaryRegex.end()
                    );
                }
            });

            memberMappers.add(new FieldMapper("typeOfHit", "LEnumMovingObjectType;"));

            memberMappers.add(new FieldMapper(new String[]{
                "blockX",
                "blockY",
                "blockZ"
                }, "I")
                .accessFlag(AccessFlag.PUBLIC, true)
                .accessFlag(AccessFlag.STATIC, false)
                .accessFlag(AccessFlag.ABSTRACT, false)
                .accessFlag(AccessFlag.PROTECTED, false)
            );
        }
    }

    private class PlayerControllerMod extends ClassMod {
        PlayerControllerMod() {
            classSignatures.add(new BytecodeSignature() {
                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    return buildExpression(
                        ALOAD, 5,
                        push(methodInfo, 2001),
                        ILOAD_1,
                        ILOAD_2,
                        ILOAD_3,
                        ALOAD, 6,
                        GETFIELD, BinaryRegex.any(2),
                        ALOAD, 5,
                        ILOAD_1,
                        ILOAD_2,
                        ILOAD_3,
                        INVOKEVIRTUAL, BinaryRegex.any(2),
                        push(methodInfo, 256),
                        IMUL,
                        IADD
                    );
                }
            });

            memberMappers.add(new FieldMapper("mc", "LMinecraft;"));
        }
    }

    private class PlayerControllerSPMod extends ClassMod {
        PlayerControllerSPMod() {
            parentClass = "PlayerController";

            classSignatures.add(new BytecodeSignature() {
                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    return buildExpression(
                        BinaryRegex.begin(),
                        ALOAD_1,
                        push(methodInfo, -180F),
                        PUTFIELD, BinaryRegex.any(2),
                        RETURN,
                        BinaryRegex.end()
                    );
                }
            });

            classSignatures.add(new BytecodeSignature() {
                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    return buildExpression(
                        BinaryRegex.begin(),
                        push(methodInfo, 4.0F),
                        FRETURN,
                        BinaryRegex.end()
                    );
                }
            });

            memberMappers.add(new MethodMapper("sendBlockRemoved", "(IIII)Z"));
            memberMappers.add(new MethodMapper("resetBlockRemoving", "()V"));

            memberMappers.add(new MethodMapper(new String[]{
                "clickBlock",
                "sendBlockRemoving"
                }, "(IIII)V")
            );

            memberMappers.add(new FieldMapper(new String[]{
                "curBlockDamage",
                "prevBlockDamage"
                }, "F")
                .accessFlag(AccessFlag.PRIVATE, true)
            );

            memberMappers.add(new FieldMapper(new String[]{
                "curBlockX",
                "curBlockY",
                "curBlockZ"
                }, "I")
                .accessFlag(AccessFlag.PRIVATE, true)
            );

            patches.add(new AddFieldPatch("curObject", "Ljava/lang/Object;", AccessFlag.PRIVATE));

            patches.add(new BytecodePatch.InsertBefore(){
                @Override
                public String getDescription() {
                    return "sendBlockRemoved Additions";
                }

                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    JavaRef actionPerformed = classMap.map(new MethodRef("PlayerControllerSP", "sendBlockRemoved", "(IIII)Z"));
                    if (methodInfo.getName().equals(actionPerformed.getName()) &&
                        methodInfo.getDescriptor().equals(actionPerformed.getType()))
                    {
                        return buildExpression(
                            ILOAD, 7,
                            IRETURN,
                            BinaryRegex.end()
                        );
                    }
                    else return null;
                }

                @Override
                public byte[] getInsertBytes(MethodInfo methodInfo) throws IOException {
                    //methodInfo.getCodeAttribute().setMaxLocals(25);
                    return buildCode(
                        reference(methodInfo, GETSTATIC, new FieldRef("MultiMine", "partiallyMinedBlocksList", "Ljava/util/ArrayList;")),
                        reference(methodInfo, NEW, new ClassRef("AS_BlockWithDamage")),
                        DUP,
                        ILOAD_1,
                        ILOAD_2,
                        ILOAD_3,
                        FCONST_0,
                        ACONST_NULL,
                        reference(methodInfo, INVOKESPECIAL, new MethodRef("AS_BlockWithDamage", "<init>", "(IIIFLjava/lang/Object;)V")),
                        reference(methodInfo, INVOKEVIRTUAL, new MethodRef("java/util/ArrayList", "remove", "(Ljava/lang/Object;)Z")),
                        POP
                    );
                }
            });

            patches.add(new BytecodePatch.InsertAfter(){
                @Override
                public String getDescription() {
                    return "resetBlockRemoving Additions";
                }

                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    JavaRef actionPerformed = classMap.map(new MethodRef("PlayerControllerSP", "resetBlockRemoving", "()V"));
                    if (methodInfo.getName().equals(actionPerformed.getName()) &&
                        methodInfo.getDescriptor().equals(actionPerformed.getType()))
                    {
                        return buildExpression(
                            BinaryRegex.begin()
                        );
                    }
                    else return null;
                }

                @Override
                public byte[] getInsertBytes(MethodInfo methodInfo) throws IOException {
                    return buildCode(
                        ALOAD_0,
                        reference(methodInfo, INVOKESPECIAL, new MethodRef("PlayerControllerSP", "saveCurrentDamagedBlock", "()V"))
                    );
                }
            });

            patches.add(new BytecodePatch.InsertBefore(){
                @Override
                public String getDescription() {
                    return "sendBlockRemoving after if==0 return Additions";
                }

                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    JavaRef actionPerformed = classMap.map(new MethodRef("PlayerControllerSP", "sendBlockRemoving", "(IIII)V"));
                    if (methodInfo.getName().equals(actionPerformed.getName()) &&
                        methodInfo.getDescriptor().equals(actionPerformed.getType()))
                    {
                        return buildExpression(
                            reference(methodInfo, GETSTATIC, new FieldRef("Block", "blocksList", "[LBlock;"))
                        );
                    }
                    else return null;
                }

                @Override
                public byte[] getInsertBytes(MethodInfo methodInfo) throws IOException {
                    return buildCode(
                        ALOAD_0,
                        ALOAD_0,
                        reference(methodInfo, GETFIELD, new FieldRef("PlayerControllerSP", "curBlockDamage", "F")),
                        ILOAD_1,
                        ILOAD_2,
                        ILOAD_3,
                        reference(methodInfo, INVOKESTATIC, new MethodRef("MultiMine", "cBD_checkBlockRemoving", "(FIII)F")),
                        reference(methodInfo, PUTFIELD, new FieldRef("PlayerControllerSP", "curBlockDamage", "F"))
                    );
                }
            });

            patches.add(new BytecodePatch(){
                @Override
                public String getDescription() {
                    return "sendBlockRemoving BlockStrength mod";
                }

                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    JavaRef actionPerformed = classMap.map(new MethodRef("PlayerControllerSP", "sendBlockRemoving", "(IIII)V"));
                    if (methodInfo.getName().equals(actionPerformed.getName()) &&
                        methodInfo.getDescriptor().equals(actionPerformed.getType()))
                    {
                        return buildExpression(
                            ALOAD_0,
                            DUP,
                            reference(methodInfo, GETFIELD, new FieldRef("PlayerControllerSP", "curBlockDamage", "F")),
                            ALOAD, 6,
                            ALOAD_0,
                            reference(methodInfo, GETFIELD, new FieldRef("PlayerControllerSP", "mc", "LMinecraft;")),
                            reference(methodInfo, GETFIELD, new FieldRef("Minecraft", "thePlayer", "LEntityPlayerSP;")),
                            reference(methodInfo, INVOKEVIRTUAL, new MethodRef("Block", "blockStrength", "(Lnet/minecraft/src/EntityPlayer;)F")),
                            FADD,
                            reference(methodInfo, PUTFIELD, new FieldRef("PlayerControllerSP", "curBlockDamage", "F"))
                        );
                    }
                    else return null;
                }

                @Override
                public byte[] getReplacementBytes(MethodInfo methodInfo) throws IOException {
                    return buildCode(
                        ALOAD_0,
                        ALOAD_0,
                        reference(methodInfo, GETFIELD, new FieldRef("PlayerControllerSP", "curBlockDamage", "F")),
                        ALOAD, 6,
                        reference(methodInfo, INVOKESTATIC, new MethodRef("MultiMine", "cBD_MineSpeedMod", "(FLBlock;)F")),
                        reference(methodInfo, PUTFIELD, new FieldRef("PlayerControllerSP", "curBlockDamage", "F"))
                    );
                }
            });

            patches.add(new BytecodePatch(){
                @Override
                public String getDescription() {
                    return "sendBlockRemoving else Additions";
                }

                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    JavaRef actionPerformed = classMap.map(new MethodRef("PlayerControllerSP", "sendBlockRemoving", "(IIII)V"));
                    if (methodInfo.getName().equals(actionPerformed.getName()) &&
                        methodInfo.getDescriptor().equals(actionPerformed.getType()))
                    {
                        return buildExpression(
                            ALOAD_0,
                            FCONST_0,
                            reference(methodInfo, PUTFIELD, new FieldRef("PlayerControllerSP", "curBlockDamage", "F"))
                        );
                    }
                    else return null;
                }

                @Override
                public byte[] getReplacementBytes(MethodInfo methodInfo) throws IOException {
                    return buildCode(
                        ALOAD_0,
                        reference(methodInfo, INVOKESPECIAL, new MethodRef("PlayerControllerSP", "saveCurrentDamagedBlock", "()V")),
                        ALOAD_0,
                        ALOAD_0,
                        reference(methodInfo, GETFIELD, new FieldRef("PlayerControllerSP", "mc", "LMinecraft;")),
                        reference(methodInfo, GETFIELD, new FieldRef("Minecraft", "objectMouseOver", "LMovingObjectPosition;")),
                        reference(methodInfo, PUTFIELD, new FieldRef("PlayerControllerSP", "curObject", "Ljava/lang/Object;")),
                        ALOAD_0,
                        ALOAD_0,
                        reference(methodInfo, GETFIELD, new FieldRef("PlayerControllerSP", "curBlockDamage", "F")),
                        ILOAD_1,
                        ILOAD_2,
                        ILOAD_3,
                        reference(methodInfo, INVOKESTATIC, new MethodRef("MultiMine", "cBD_checkBlockRemovingStopped", "(FIII)F")),
                        reference(methodInfo, PUTFIELD, new FieldRef("PlayerControllerSP", "curBlockDamage", "F"))
                    );
                }
            });

            patches.add(new AddMethodPatch("saveCurrentDamagedBlock", "()V") {
                @Override
                public byte[] generateMethod(ClassFile classFile, MethodInfo methodInfo) throws IOException {
                    maxStackSize = 7;
                    numLocals = 2;
                    methodInfo.setAccessFlags(AccessFlag.PRIVATE);
                    return buildCode(
                        ALOAD_0,
                        reference(methodInfo, GETFIELD, new FieldRef("PlayerControllerSP", "curBlockDamage", "F")),
                        F2D,
                        DCONST_0,
                        DCMPL,
                        IFNE, branch("L1"),
                        RETURN,
                        label("L1"),
                        reference(methodInfo, GETSTATIC, new FieldRef("MultiMine", "partiallyMinedBlocksList", "Ljava/util/ArrayList;")),
                        reference(methodInfo, INVOKEVIRTUAL, new MethodRef("java/util/ArrayList", "size", "()I")),
                        reference(methodInfo, GETSTATIC, new FieldRef("AS_Settings_MultiMine", "maxDamagedBlocks", "I")),
                        IF_ICMPLE, branch("L2"),
                        reference(methodInfo, GETSTATIC, new FieldRef("MultiMine", "partiallyMinedBlocksList", "Ljava/util/ArrayList;")),
                        ICONST_0,
                        reference(methodInfo, INVOKEVIRTUAL, new MethodRef("java/util/ArrayList", "remove", "(I)Ljava/lang/Object;")),
                        POP,
                        label("L2"),
                        reference(methodInfo, NEW, new ClassRef("AS_BlockWithDamage")),
                        DUP,
                        ALOAD_0,
                        reference(methodInfo, GETFIELD, new FieldRef("PlayerControllerSP", "curBlockX", "I")),
                        ALOAD_0,
                        reference(methodInfo, GETFIELD, new FieldRef("PlayerControllerSP", "curBlockY", "I")),
                        ALOAD_0,
                        reference(methodInfo, GETFIELD, new FieldRef("PlayerControllerSP", "curBlockZ", "I")),
                        ALOAD_0,
                        reference(methodInfo, GETFIELD, new FieldRef("PlayerControllerSP", "curBlockDamage", "F")),
                        ALOAD_0,
                        reference(methodInfo, GETFIELD, new FieldRef("PlayerControllerSP", "curObject", "Ljava/lang/Object;")),
                        reference(methodInfo, INVOKESPECIAL, new MethodRef("AS_BlockWithDamage", "<init>", "(IIIFLjava/lang/Object;)V")),
                        ASTORE_1,
                        reference(methodInfo, GETSTATIC, new FieldRef("MultiMine", "partiallyMinedBlocksList", "Ljava/util/ArrayList;")),
                        ALOAD_1,
                        reference(methodInfo, INVOKEVIRTUAL, new MethodRef("java/util/ArrayList", "remove", "(Ljava/lang/Object;)Z")),
                        POP,
                        ALOAD_0,
                        reference(methodInfo, GETFIELD, new FieldRef("PlayerControllerSP", "curObject", "Ljava/lang/Object;")),
                        IFNULL, branch("L6"),
                        reference(methodInfo, GETSTATIC, new FieldRef("MultiMine", "partiallyMinedBlocksList", "Ljava/util/ArrayList;")),
                        ALOAD_1,
                        reference(methodInfo, INVOKEVIRTUAL, new MethodRef("java/util/ArrayList", "add", "(Ljava/lang/Object;)Z")),
                        POP,
                        label("L6"),
                        RETURN
                    );
                }
            });
        }
    }

    private class RenderMod extends ClassMod {
        RenderMod() {
            classSignatures.add(new ConstSignature("/terrain.png"));
            classSignatures.add(new ConstSignature("%clamp%/misc/shadow.png"));

            memberMappers.add(new MethodMapper("doRender", "(LEntity;DDDFF)V"));
        }

        @Override
        public void prePatch(String filename, ClassFile classFile) {
            mod.getClassMap().addInheritance(getDeobfClass(), "AS_RenderHooks");
        }
    }

    private class RenderHelperMod extends ClassMod {
        RenderHelperMod() {
            classSignatures.add(new BytecodeSignature() {
                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    return buildExpression(
                        push(methodInfo, 0.4F),
                        FSTORE_0,
                        push(methodInfo, 0.6F),
                        FSTORE_1,
                        FCONST_0,
                        FSTORE_2,
                        push(methodInfo, 0.20000000298023224D),
                        DCONST_1,
                        push(methodInfo, -0.699999988079071D),
                        INVOKESTATIC, BinaryRegex.any(2),
                        INVOKEVIRTUAL, BinaryRegex.any(2),
                        ASTORE_3
                    );
                }
            });

            memberMappers.add(new MethodMapper(new String[]{
                "disableStandardItemLighting",
                "enableStandardItemLighting"
                }, "()V")
                .accessFlag(AccessFlag.PUBLIC, true)
                .accessFlag(AccessFlag.STATIC, true)
                .accessFlag(AccessFlag.ABSTRACT, false)
                .accessFlag(AccessFlag.PROTECTED, false)
            );
        }
    }

    private class RenderGlobalMod extends ClassMod {
        RenderGlobalMod() {
            classSignatures.add(new ConstSignature("smoke"));

            classSignatures.add(new BytecodeSignature() {
                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    return buildExpression(
                        push(methodInfo, "/environment/clouds.png")
                    );
                }
            }.setMethodName("renderClouds"));

            // public boolean updateRenderers(EntityLiving var1, boolean var2) <- unique constructor
            memberMappers.add(new MethodMapper("updateRenderers", "(LEntityLiving;Z)Z"));

            memberMappers.add(new FieldMapper("damagePartialTime", "F"));

            memberMappers.add(new MethodMapper(new String[]{
                "drawBlockBreaking",
                "drawSelectionBox"
                }, "(LEntityPlayer;LMovingObjectPosition;ILItemStack;F)V")
                .accessFlag(AccessFlag.PUBLIC, true)
                .accessFlag(AccessFlag.STATIC, false)
                .accessFlag(AccessFlag.ABSTRACT, false)
                .accessFlag(AccessFlag.PROTECTED, false)
            );
        }
    }

    private class RenderManagerMod extends ClassMod {
        RenderManagerMod() {

            classSignatures.add(new BytecodeSignature() {
                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    return buildExpression(
                        BinaryRegex.begin(),
                        ALOAD_0,
                        GETFIELD, BinaryRegex.any(2),
                        ARETURN,
                        BinaryRegex.end()
                    );
                }
            });

            classSignatures.add(new BytecodeSignature() {
                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    return buildExpression(
                        BinaryRegex.begin(),
                        ALOAD_0,
                        ALOAD_1,
                        reference(methodInfo, INVOKEVIRTUAL, new MethodRef("java/lang/Object", "getClass", "()Ljava/lang/Class;")),
                        INVOKEVIRTUAL, BinaryRegex.any(2),
                        ARETURN,
                        BinaryRegex.end()
                    );
                }
            });

            memberMappers.add(new FieldMapper("entityRenderMap", "Ljava/util/Map;"));
            memberMappers.add(new FieldMapper("worldObj", "LWorld;"));

            patches.add(new BytecodePatch.InsertBefore() {
                @Override
                public String getDescription() {
                    return "MultiMine Renderer Map insert";
                }

                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    return buildExpression(
                        ALOAD_0,
                        GETFIELD, BinaryRegex.any(2),
                        reference(methodInfo, INVOKEINTERFACE, new InterfaceMethodRef("java/util/Map", "values", "()Ljava/util/Collection;")),
                        reference(methodInfo, INVOKEINTERFACE, new InterfaceMethodRef("java/util/Collection", "iterator", "()Ljava/util/Iterator;")),
                        BinaryRegex.any(1),
                        BinaryRegex.any(1)
                    );
                }

                @Override
                public byte[] getInsertBytes(MethodInfo methodInfo) throws IOException {
                    return buildCode(
                        ALOAD_0,
                        reference(methodInfo, GETFIELD, new FieldRef("RenderManager", "entityRenderMap", "Ljava/util/Map;")),
                        reference(methodInfo, INVOKESTATIC, new MethodRef("MultiMine", "AddRenderer", "(Ljava/util/Map;)V"))
                    );
                }
            });
        }
    }

    private class WorldMod extends ClassMod {
        WorldMod() {
            classSignatures.add(new ConstSignature("ambient.cave.cave"));
            classSignatures.add(new ConstSignature("Unable to find spawn biome"));

            //public void playSoundAtEntity(Entity var1, String var2, float var3, float var4)
            memberMappers.add(new MethodMapper("playSoundAtEntity", "(LEntity;Ljava.lang.String;FF)V"));

            //public void markBlocksDirty(int var1, int var2, int var3, int var4, int var5, int var6)
            memberMappers.add(new MethodMapper("markBlocksDirty", "(IIIIII)V"));

            //public void setEntityDead()
            memberMappers.add(new MethodMapper("setEntityDead", "()V"));

            memberMappers.add(new MethodMapper("getBlockId", "(III)I")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false));

            memberMappers.add(new FieldMapper(new String[]{
                "loadedEntityList",
                "loadedTileEntityList"},
                "Ljava.util.List;")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false)
            );

            memberMappers.add(new MethodMapper(new String[]{
                "getBlockId",
                "getBlockMetadata",
                "getFullBlockLightValue",
                "getBlockLightValue"},
                "(III)I")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false)
            );

            memberMappers.add(new MethodMapper(new String[]{
                "markBlockNeedsUpdate",
                "markBlockAsNeedsUpdate",
                "removeBlockTileEntity",
                "updateAllLightTypes",
                "randomDisplayUpdates"},
                "(III)V")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false)
            );

            memberMappers.add(new MethodMapper("getBlockId", "(III)I")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false));

            memberMappers.add(new MethodMapper(new String[]{
                "getWorldSeed",
                "getWorldTime"},
                "()J")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false)
            );

            memberMappers.add(new MethodMapper(new String[]{
                "addWeatherEffect",
                "entityJoinedWorld"},
                "(LEntity;)Z")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false)
            );
        }
    }

    private class WorldRendererMod extends ClassMod {
        public WorldRendererMod() {
            classSignatures.add(new ConstSignature(new MethodRef("org.lwjgl.opengl.GL11", "glNewList", "(II)V")));

            classSignatures.add(new BytecodeSignature() {
                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    return buildExpression(
                        push(methodInfo, -999)
                    );
                }
            });

            memberMappers.add(new MethodMapper(new String[]{
                "setupGLTranslation",
                "updateRenderer"},
                "()V")
            );

            memberMappers.add(new FieldMapper(new String[]{
                "isInFrustum",
                "needsUpdate"},
                "Z")
            );

            memberMappers.add(new FieldMapper("isInitialized", "Z")
            .accessFlag(AccessFlag.PRIVATE, true)
            .accessFlag(AccessFlag.STATIC, false));
        }
    }
}
