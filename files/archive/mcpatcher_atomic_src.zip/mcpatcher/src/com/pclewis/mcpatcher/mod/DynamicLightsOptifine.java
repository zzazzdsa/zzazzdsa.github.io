package com.pclewis.mcpatcher.mod;

import com.pclewis.mcpatcher.*;
import javassist.bytecode.AccessFlag;
import javassist.bytecode.ClassFile;
import javassist.bytecode.MethodInfo;

import java.io.File;
import java.io.IOException;
import static javassist.bytecode.Opcode.*;

public class DynamicLightsOptifine extends Mod {

    boolean versionAbove18;

    public DynamicLightsOptifine(MinecraftVersion minecraftVersion) {
        name = "Dynamic Lights (Optifine version)";
        author = "Cryect, AtomicStryker";
        description = "Adds dynamic Light to Minecraft, DO NOT USE WITHOUT OPTIFINE";
        website = "http://www.minecraftforum.net/topic/184426-v19-pre5-dynamic-lights/";
        version = "1.0.1";

        addConflict("Dynamic Lights");

        versionAbove18 = minecraftVersion.compareTo(MinecraftVersion.parseVersion("Minecraft Beta 1.9"))  >= 0;

        classMods.add(new AxisAlignedBBMod());
        classMods.add(new BlockMod());
        classMods.add(new ChunkMod());
        classMods.add(new ChunkCacheMod());
        classMods.add(new EntityMod());
        classMods.add(new EntityItemMod());
        classMods.add(new EntityLivingMod());
        classMods.add(new EntityPlayerMod());
        classMods.add(new EntityPlayerSPMod());
        classMods.add(new EntityRendererMod());
        classMods.add(new EnumSkyBlockMod());
        classMods.add(new ItemStackMod());
        classMods.add(new InventoryPlayerMod());
        classMods.add(new MinecraftMod());
        classMods.add(new RenderGlobalMod());
        classMods.add(new WorldMod());
        classMods.add(new WorldInfoMod());
        classMods.add(new WorldRendererMod());

        filesToAdd.add(ClassMap.classNameToFilename("BlockCoord"));
        filesToAdd.add(ClassMap.classNameToFilename("DynamicLights"));
        filesToAdd.add(ClassMap.classNameToFilename("EnumLight"));
        filesToAdd.add(ClassMap.classNameToFilename("IDynamicLights"));
        filesToAdd.add(ClassMap.classNameToFilename("LightCache"));
        filesToAdd.add(ClassMap.classNameToFilename("PlayerTorch"));
        filesToAdd.add(ClassMap.classNameToFilename("PlayerTorchArray"));
    }

    private class AxisAlignedBBMod extends ClassMod {
        AxisAlignedBBMod() {
            classSignatures.add(new ConstSignature("box["));
            classSignatures.add(new ConstSignature(" -> "));
            classSignatures.add(new ConstSignature("]"));
            // those unique strings should determine AxisAlignedBB safely

            memberMappers.add(new MethodMapper(new String[]{
                "clearBoundingBoxes",
                "clearBoundingBoxPool"},
                "()V")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, true)
            );
            // wanted method is the SECOND public static void

            patches.add(new AddFieldPatch("nextFrameTime", "I", AccessFlag.PUBLIC | AccessFlag.STATIC));
            patches.add(new AddFieldPatch("prevFrameTimeForAvg", "J", AccessFlag.PUBLIC | AccessFlag.STATIC));
            patches.add(new AddFieldPatch("tFrameTimes", "[J", AccessFlag.PUBLIC | AccessFlag.STATIC));

            patches.add(new BytecodePatch.InsertBefore() {
                @Override
                public String getDescription() {
                    return "add AxisAlignedBB FPS watcher";
                }

                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    JavaRef actionPerformed = classMap.map(new MethodRef("AxisAlignedBB", "clearBoundingBoxPool", "()V"));
                    if (methodInfo.getName().equals(actionPerformed.getName()) &&
                        methodInfo.getDescriptor().equals(actionPerformed.getType())) {
                        return buildExpression(
                            BinaryRegex.begin()
                        );
                    } else {
                        return null;
                    }
                }

                @Override
                public byte[] getInsertBytes(MethodInfo methodInfo) throws IOException {
                    return buildCode(
                        reference(methodInfo, INVOKESTATIC, new MethodRef("java/lang/System", "nanoTime", "()J")),
                        reference(methodInfo, PUTSTATIC, new FieldRef("AxisAlignedBB", "prevFrameTimeForAvg", "J")),
                        reference(methodInfo, GETSTATIC, new FieldRef("AxisAlignedBB", "tFrameTimes", "[J")),
                        reference(methodInfo, GETSTATIC, new FieldRef("AxisAlignedBB", "nextFrameTime", "I")),
                        reference(methodInfo, GETSTATIC, new FieldRef("AxisAlignedBB", "prevFrameTimeForAvg", "J")),
                        LASTORE,
                        reference(methodInfo, GETSTATIC, new FieldRef("AxisAlignedBB", "nextFrameTime", "I")),
                        ICONST_1,
                        IADD,
                        BIPUSH, 60,
                        IREM,
                        reference(methodInfo, PUTSTATIC, new FieldRef("AxisAlignedBB", "nextFrameTime", "I"))
                    );
                }
            });

            patches.add(new BytecodePatch.InsertAfter() {
                @Override
                public String getDescription() {
                    return "initialize the array";
                }

                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    if (methodInfo.getName().equals("<clinit>"))
                    {
                        return buildExpression(
                            BinaryRegex.begin()
                        );
                    } else {
                        return null;
                    }
                }

                @Override
                public byte[] getInsertBytes(MethodInfo methodInfo) throws IOException {
                    return buildCode(
                        push(methodInfo, 60),
                        NEWARRAY, T_LONG,
                        reference(methodInfo, PUTSTATIC, new FieldRef("AxisAlignedBB", "tFrameTimes", "[J"))
                    );
                }
            });

            patches.add(new AddMethodPatch("getAvgFrameTime", "()J") {
                @Override
                public byte[] generateMethod(ClassFile classFile, MethodInfo methodInfo) throws IOException {
                    maxStackSize = 4;
                    numLocals = 1;
                    methodInfo.setAccessFlags(AccessFlag.STATIC | AccessFlag.PUBLIC);
                    return buildCode(
                        reference(methodInfo, GETSTATIC, new FieldRef("AxisAlignedBB", "tFrameTimes", "[J")),
                        reference(methodInfo, GETSTATIC, new FieldRef("AxisAlignedBB", "nextFrameTime", "I")),
                        LALOAD,
                        LCONST_0,
                        LCMP,
                        IFEQ, branch("L2"),
                        reference(methodInfo, GETSTATIC, new FieldRef("AxisAlignedBB", "prevFrameTimeForAvg", "J")),
                        reference(methodInfo, GETSTATIC, new FieldRef("AxisAlignedBB", "tFrameTimes", "[J")),
                        reference(methodInfo, GETSTATIC, new FieldRef("AxisAlignedBB", "nextFrameTime", "I")),
                        LALOAD,
                        LSUB,
                        push(methodInfo, 60L),
                        LDIV,
                        LRETURN,
                        label("L2"),
                        push(methodInfo, 23333333L),
                        LRETURN
                    );
                }
            });
        }
    }

    private class BlockMod extends ClassMod {
        public BlockMod() {
            classSignatures.add(new ConstSignature(" is already occupied by "));

            memberMappers.add(new FieldMapper("blocksList", "[LBlock;"));

            memberMappers.add(new MethodMapper("renderAsNormalBlock", "()Z")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false)
            );
        }
    }

    private class ChunkMod extends ClassMod {
        public ChunkMod() {
            classSignatures.add(new ConstSignature("Wrong location! "));

            //public int getSavedLightValue(EnumSkyBlock var1, int var2, int var3, int var4)
            memberMappers.add(new MethodMapper("getSavedLightValue", "(LEnumSkyBlock;III)I"));
        }
    }

    private class ChunkCacheMod extends ClassMod {
        ChunkCacheMod() {
            classSignatures.add(new BytecodeSignature() {
                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    return buildExpression(
                        ISUB,
                        ICONST_1,
                        IADD,
                        MULTIANEWARRAY, BinaryRegex.any(3),
                        PUTFIELD, BinaryRegex.any(2),
                        ALOAD_0,
                        GETFIELD, BinaryRegex.any(2),
                        ISTORE, 10,
                        ILOAD, 10,
                        ILOAD, 8,
                        IF_ICMPGT
                    );
                }
            });

            memberMappers.add(new FieldMapper("chunkArray", "[[LChunk;"));
            memberMappers.add(new FieldMapper("worldObj", "LWorld;"));

            memberMappers.add(new MethodMapper(new String[]{
                "getSkyBlockTypeBrightness",
                "getSpecialBlockBrightness"},
                "(LEnumSkyBlock;III)I")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false)
            );

            patches.add(new BytecodePatch(){

                @Override
                public String getDescription() {
                    return "override getSkyBlockTypeBrightness return";
                }

                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    JavaRef actionPerformed = classMap.map(new MethodRef("ChunkCache", "getSkyBlockTypeBrightness", "(LEnumSkyBlock;III)I"));
                    if (methodInfo.getName().equals(actionPerformed.getName()) &&
                        methodInfo.getDescriptor().equals(actionPerformed.getType()))
                    {
                        return buildExpression(
                            ALOAD_0,
                            reference(methodInfo, GETFIELD, new FieldRef("ChunkCache", "chunkArray", "[[LChunk;")),
                            ILOAD, 5,
                            AALOAD,
                            ILOAD, 6,
                            AALOAD,
                            ALOAD_1,
                            ILOAD_2,
                            BIPUSH, 15,
                            IAND,
                            ILOAD_3,
                            ILOAD, 4,
                            BIPUSH, 15,
                            IAND,
                            reference(methodInfo, INVOKEVIRTUAL, new MethodRef("Chunk", "getSavedLightValue", "(LEnumSkyBlock;III)I")),
                            IRETURN
                        );
                    }
                    else return null;
                }

                @Override
                public byte[] getReplacementBytes(MethodInfo methodInfo) throws IOException {
                    return buildCode(
                        ALOAD_0,
                        reference(methodInfo, GETFIELD, new FieldRef("ChunkCache", "chunkArray", "[[LChunk;")),
                        ILOAD, 5,
                        AALOAD,
                        ILOAD, 6,
                        AALOAD,
                        ALOAD_1,
                        ILOAD_2,
                        BIPUSH, 15,
                        IAND,
                        ILOAD_3,
                        ILOAD, 4,
                        BIPUSH, 15,
                        IAND,
                        reference(methodInfo, INVOKEVIRTUAL, new MethodRef("Chunk", "getSavedLightValue", "(LEnumSkyBlock;III)I")),
                        ALOAD_0,
                        reference(methodInfo, GETFIELD, new FieldRef("ChunkCache", "worldObj", "LWorld;")),
                        ALOAD_1,
                        ILOAD_2,
                        ILOAD_3,
                        ILOAD, 4,
                        reference(methodInfo, INVOKESTATIC, new MethodRef("PlayerTorchArray", "getBlockTorchBrightness", "(ILWorld;LEnumSkyBlock;III)I")),
                        IRETURN
                    );
                }
            });
        }
    }

    private class EntityMod extends ClassMod {
        public EntityMod() {
            classSignatures.add(new ConstSignature("Pos"));
            classSignatures.add(new ConstSignature("Motion"));
            classSignatures.add(new ConstSignature("Rotation"));

            memberMappers.add(new FieldMapper("worldObj", "LWorld;"));

            memberMappers.add(new FieldMapper(new String[]{
                "renderDistanceWeight",
                "prevPosX",
                "prevPosY",
                "prevPosZ",
                "posX",
                "posY",
                "posZ",
            }, "D"));

            memberMappers.add(new MethodMapper(new String[]{
                "isWet",
                "isInWater",
                null,
                null,
                null,
                null,
                null,
                "isEntityAlive",
                null,
                "isEntityBurning"
                }, "()Z")
                .accessFlag(AccessFlag.PUBLIC, true)
                .accessFlag(AccessFlag.STATIC, false)
            );

            memberMappers.add(new MethodMapper(new String[]{
                "setEntityDead",
                "onUpdate",
                "onEntityUpdate"
                }, "()V")
                .accessFlag(AccessFlag.PUBLIC, true)
                .accessFlag(AccessFlag.STATIC, false)
                .accessFlag(AccessFlag.ABSTRACT, false)
                .accessFlag(AccessFlag.PROTECTED, false)
            );
        }
    }

    private class EntityItemMod extends ClassMod {
        public EntityItemMod() {
            classSignatures.add(new ConstSignature("Health"));
            classSignatures.add(new ConstSignature("Age"));
            classSignatures.add(new ConstSignature("Item"));
            classSignatures.add(new ConstSignature("random.pop"));
            classSignatures.add(new ConstSignature("random.fizz"));

            memberMappers.add(new FieldMapper("item", "LItemStack;"));

            //memberMappers.add(new FieldMapper("worldObj", "LWorld;"));
        }
    }

    private class EntityLivingMod extends ClassMod {
        public EntityLivingMod() {
            parentClass = "Entity";

            classSignatures.add(new ConstSignature("ActiveEffects"));
            classSignatures.add(new ConstSignature("Health"));
            classSignatures.add(new ConstSignature("HurtTime"));

            //memberMappers.add(new FieldMapper("worldObj", "LWorld;"));
        }
    }

    private class EntityPlayerMod extends ClassMod {
        public EntityPlayerMod() {
            parentClass = "EntityLiving";

            classSignatures.add(new ConstSignature("humanoid"));
            classSignatures.add(new ConstSignature("/mob/char.png"));

            memberMappers.add(new FieldMapper("inventory", "LInventoryPlayer;"));
            //memberMappers.add(new FieldMapper("worldObj", "LWorld;"));
        }
    }

    private class EntityPlayerSPMod extends ClassMod {
        public EntityPlayerSPMod() {
            parentClass = "EntityPlayer";

            classSignatures.add(new ConstSignature("http://s3.amazonaws.com/MinecraftSkins/"));

            classSignatures.add(new BytecodeSignature() {
                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    return buildExpression(
                        push(methodInfo, "portal.trigger")
                    );
                }
            }.setMethodName("onLivingUpdate"));
        }
    }

    private class EntityRendererMod extends ClassMod {
        public EntityRendererMod() {
            classSignatures.add(new ConstSignature("/terrain.png"));
            classSignatures.add(new ConstSignature("ambient.weather.rain"));
            classSignatures.add(new ConstSignature("/environment/snow.png"));
            classSignatures.add(new ConstSignature("/environment/rain.png"));

            memberMappers.add(new MethodMapper(new String[]{
                "getMouseOver",
                "updateCameraAndRender"},
                "(F)V")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false)
            );

            patches.add(new BytecodePatch.InsertAfter() {
                @Override
                public String getDescription() {
                    return "add Dynamic Lights OnTick Hook";
                }

                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    JavaRef actionPerformed = classMap.map(new MethodRef("EntityRenderer", "updateCameraAndRender", "(F)V"));
                    if (methodInfo.getName().equals(actionPerformed.getName()) &&
                        methodInfo.getDescriptor().equals(actionPerformed.getType())) {
                        return buildExpression(
                            BinaryRegex.begin()
                        );
                    } else {
                        return null;
                    }
                }

                @Override
                public byte[] getInsertBytes(MethodInfo methodInfo) throws IOException {
                    return buildCode(
                        reference(methodInfo, INVOKESTATIC, new MethodRef("DynamicLights", "OnTickInGame", "()V"))
                    );
                }
            });
        }
    }

    private class EnumSkyBlockMod extends ClassMod {
        public EnumSkyBlockMod() {
            classSignatures.add(new ConstSignature("Sky"));
            classSignatures.add(new ConstSignature("Block"));

            memberMappers.add(new FieldMapper(new String[]{"Sky", "Block"}, "LEnumSkyBlock;"));
        }
    }

    private class InventoryPlayerMod extends ClassMod {
        public InventoryPlayerMod() {
            classSignatures.add(new ConstSignature("Inventory"));
            classSignatures.add(new ConstSignature("Slot"));

            memberMappers.add(new MethodMapper(new String[]{
                "getStackInSlot",
                "armorItemInSlot"},
                "(I)LItemStack;")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false)
            );

            memberMappers.add(new MethodMapper("getCurrentItem", "()LItemStack;"));
            memberMappers.add(new FieldMapper("currentItem", "I"));

            memberMappers.add(new FieldMapper(new String[]{"mainInventory", "armorInventory"}, "[LItemStack;")
                .accessFlag(AccessFlag.PUBLIC, true)
                .accessFlag(AccessFlag.STATIC, false)
            );
        }
    }

    private class ItemStackMod extends ClassMod {
        public ItemStackMod() {
            classSignatures.add(new ConstSignature("id"));
            classSignatures.add(new ConstSignature("Count"));
            classSignatures.add(new ConstSignature("Damage"));

            memberMappers.add(new FieldMapper(new String[]{
                "stackSize",
                "animationsToGo",
                "itemID"
            }, "I")
                .accessFlag(AccessFlag.PUBLIC, true)
            );
        }
    }

    private class MinecraftMod extends ClassMod {
        public MinecraftMod()
        {
            classSignatures.add(new FilenameSignature("net/minecraft/client/Minecraft.class"));

            memberMappers.add(new FieldMapper("thePlayer", "LEntityPlayerSP;"));
            memberMappers.add(new FieldMapper("theWorld", "LWorld;"));
            memberMappers.add(new MethodMapper("getAppDir", "(Ljava/lang/String;)Ljava/io/File;"));

            patches.add(new BytecodePatch.InsertAfter() {
                @Override
                public String getDescription() {
                    return "Dynamic Lights init in Minecraft";
                }

                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    return buildExpression(
                        push(methodInfo, "Post startup")
                    );
                }

                @Override
                public byte[] getInsertBytes(MethodInfo methodInfo) throws IOException {
                    return buildCode(
                        ALOAD_0,
                        reference(methodInfo, INVOKESTATIC, new MethodRef("DynamicLights", "init", "(LMinecraft;)V"))
                    );
                }
            });
        }
    }

    private class RenderGlobalMod extends ClassMod {
        RenderGlobalMod() {
            classSignatures.add(new ConstSignature("smoke"));

            classSignatures.add(new BytecodeSignature() {
                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    return buildExpression(
                        push(methodInfo, "/environment/clouds.png")
                    );
                }
            }.setMethodName("renderClouds"));

            // public boolean updateRenderers(EntityLiving var1, boolean var2) <- unique constructor
            memberMappers.add(new MethodMapper("updateRenderers", "(LEntityLiving;Z)Z"));
        }
    }

    private class WorldMod extends ClassMod {
        WorldMod() {
            classSignatures.add(new ConstSignature("ambient.cave.cave"));
            classSignatures.add(new ConstSignature("Unable to find spawn biome"));

            memberMappers.add(new FieldMapper("worldInfo", "LWorldInfo;"));

            //public void playSoundAtEntity(Entity var1, String var2, float var3, float var4)
            memberMappers.add(new MethodMapper("playSoundAtEntity", "(LEntity;Ljava.lang.String;FF)V"));

            //public void markBlocksDirty(int var1, int var2, int var3, int var4, int var5, int var6)
            memberMappers.add(new MethodMapper("markBlocksDirty", "(IIIIII)V"));

            //public void setEntityDead()
            memberMappers.add(new MethodMapper("setEntityDead", "()V"));

            memberMappers.add(new MethodMapper("getBlockId", "(III)I")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false));

            memberMappers.add(new FieldMapper(new String[]{
                "loadedEntityList",
                "loadedTileEntityList"},
                "Ljava.util.List;")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false)
            );

            memberMappers.add(new MethodMapper(new String[]{
                "getBlockId",
                "getBlockMetadata",
                "getFullBlockLightValue",
                "getBlockLightValue"},
                "(III)I")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false)
            );

            memberMappers.add(new MethodMapper(new String[]{
                "markBlockNeedsUpdate",
                "markBlockAsNeedsUpdate",
                "removeBlockTileEntity",
                "updateAllLightTypes",
                "randomDisplayUpdates"},
                "(III)V")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false)
            );

            memberMappers.add(new MethodMapper("getBlockId", "(III)I")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false));

            memberMappers.add(new MethodMapper(new String[]{
                "getWorldSeed",
                "getWorldTime"},
                "()J")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false)
            );

            memberMappers.add(new MethodMapper(new String[]{
                "getSkyBlockTypeBrightness",
                "getSavedLightValue"},
                "(LEnumSkyBlock;III)I")
            .accessFlag(AccessFlag.PUBLIC, true)
            .accessFlag(AccessFlag.STATIC, false)
            );

            patches.add(new BytecodePatch(){

                @Override
                public String getDescription() {
                    return "override getSkyBlockTypeBrightness return";
                }

                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    JavaRef actionPerformed = classMap.map(new MethodRef("World", "getSkyBlockTypeBrightness", "(LEnumSkyBlock;III)I"));
                    if (methodInfo.getName().equals(actionPerformed.getName()) &&
                        methodInfo.getDescriptor().equals(actionPerformed.getType()))
                    {
                        return buildExpression(
                            ASTORE, 7,
                            ALOAD, 7,
                            ALOAD_1,
                            ILOAD_2,
                            BIPUSH, 15,
                            IAND,
                            ILOAD_3,
                            ILOAD, 4,
                            BIPUSH, 15,
                            IAND,
                            reference(methodInfo, INVOKEVIRTUAL, new MethodRef("Chunk", "getSavedLightValue", "(LEnumSkyBlock;III)I")),
                            IRETURN
                        );
                    }
                    else return null;
                }

                @Override
                public byte[] getReplacementBytes(MethodInfo methodInfo) throws IOException {
                    return buildCode(
                        ASTORE, 7,
                        ALOAD, 7,
                        ALOAD, 1,
                        ILOAD, 2,
                        BIPUSH, 15,
                        IAND,
                        ILOAD, 3,
                        ILOAD, 4,
                        BIPUSH, 15,
                        IAND,
                        reference(methodInfo, INVOKEVIRTUAL, new MethodRef("Chunk", "getSavedLightValue", "(LEnumSkyBlock;III)I")),
                        ALOAD, 0,
                        ALOAD, 1,
                        ILOAD, 2,
                        ILOAD, 3,
                        ILOAD, 4,
                        reference(methodInfo, INVOKESTATIC, new MethodRef("PlayerTorchArray", "getBlockTorchBrightness", "(ILWorld;LEnumSkyBlock;III)I")),
                        IRETURN
                    );
                }
            });
        }
    }

    private class WorldInfoMod extends ClassMod {
        public WorldInfoMod() {
            classSignatures.add(new ConstSignature("RandomSeed"));
            classSignatures.add(new ConstSignature("SpawnX"));

            memberMappers.add(new MethodMapper(new String[]{
                "getRandomSeed",
                "getWorldTime"
            }, "()J"));
        }
    }

    private class WorldRendererMod extends ClassMod {
        public WorldRendererMod() {
            classSignatures.add(new ConstSignature(new MethodRef("org.lwjgl.opengl.GL11", "glNewList", "(II)V")));

            classSignatures.add(new BytecodeSignature() {
                @Override
                public String getMatchExpression(MethodInfo methodInfo) {
                    return buildExpression(
                        push(methodInfo, -999)
                    );
                }
            });

            memberMappers.add(new MethodMapper(new String[]{
                "setupGLTranslation",
                "updateRenderer"},
                "()V")
            );

            memberMappers.add(new FieldMapper(new String[]{
                "isInFrustum",
                "needsUpdate"},
                "Z")
            );

            memberMappers.add(new FieldMapper("isInitialized", "Z")
            .accessFlag(AccessFlag.PRIVATE, true)
            .accessFlag(AccessFlag.STATIC, false));
        }
    }
}
