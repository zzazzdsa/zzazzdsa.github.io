package net.minecraft.src;

public class RenderGlobal {

    public float damagePartialTime;

    public int sortAndRender(EntityLiving entityLiving, int i, double d) {
        return 0;
    }

    public void drawBlockBreaking(EntityPlayer entityplayer, MovingObjectPosition obj, int i, ItemStack currentItem, float renderTick) {
    }
}
