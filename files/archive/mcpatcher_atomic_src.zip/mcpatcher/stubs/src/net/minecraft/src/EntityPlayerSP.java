package net.minecraft.src;

public class EntityPlayerSP extends EntityPlayer {
    public float distanceWalkedModified;

    public EntityPlayerSP(World worldObj) {
        super(worldObj);
    }
}
