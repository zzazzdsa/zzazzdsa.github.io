package net.minecraft.src;

public class EntityPlayer extends EntityLiving {
    public InventoryPlayer inventory;

    public EntityPlayer(World worldObj) {
        super(worldObj);
    }

    @Override
    protected void entityInit() {
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound var1) {
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound var1) {
    }
}
