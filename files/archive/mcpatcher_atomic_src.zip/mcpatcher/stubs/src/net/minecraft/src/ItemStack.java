package net.minecraft.src;

public class ItemStack {
    public int itemID;
	public int stackSize;

    public ItemStack copy() {
        return null;
    }
}