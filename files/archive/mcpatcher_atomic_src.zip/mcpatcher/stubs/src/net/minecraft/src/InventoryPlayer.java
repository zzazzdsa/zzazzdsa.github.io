package net.minecraft.src;

public class InventoryPlayer {

    public ItemStack[] mainInventory = new ItemStack[36];
    public ItemStack[] armorInventory = new ItemStack[4];
    public int currentItem = 0;
	
    public ItemStack getCurrentItem() {
        return null;
    }
	
    public ItemStack armorItemInSlot(int var1)
    {
        return null;
    }
}
