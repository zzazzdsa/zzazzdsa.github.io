

public class BaseMod {

}
