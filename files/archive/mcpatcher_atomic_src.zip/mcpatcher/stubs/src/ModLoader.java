

public class ModLoader {
	public static void SetInGameHook(BaseMod whatever, boolean whocares, boolean shutup){};
}
