import net.minecraft.src.AxisAlignedBB;
import net.minecraft.src.Block;
import net.minecraft.src.Entity;
import net.minecraft.src.World;

public class PlayerTorch {

   boolean bIsTorchActive = false;
   float posX;
   float posY;
   float posZ;
   int iX;
   int iY;
   int iZ;
   private int torchBrightness = 15;
   private int range;
   private final float[] cache;
   private Entity torchentity;
   public int currentItemID;
   private boolean worksUnderwater;
   public int deathAge;
   private boolean IsCustomTorch;
   public boolean IsArmorTorch;
   private long updateTime;

   public PlayerTorch(Entity var1) {
      this.range = this.torchBrightness * 2 + 1;
      this.cache = new float[this.range * this.range * this.range];
      this.currentItemID = 0;
      this.worksUnderwater = true;
      this.deathAge = -1;
      this.IsCustomTorch = false;
      this.IsArmorTorch = false;
      this.torchentity = var1;
   }

   public boolean isTorchActive() {
      return (this.bIsTorchActive && this.torchentity.isEntityAlive() && !this.IsPutOutByWater());
   }

   public void setTorchState(World var1, boolean var2) {
      if(this.bIsTorchActive != var2) {
         this.bIsTorchActive = var2;
         this.markBlocksDirty(var1, true);
      }
   }

   public void setTorchPos(World var1, float var2, float var3, float var4) {
      long var5 = AxisAlignedBB.getAvgFrameTime();
      byte var7 = 1;
      if(var5 > 33333333L) {
         var7 = 3;
      } else if(var5 > 16666666L) {
         var7 = 2;
      }

      if(var1.worldInfo.getWorldTime() % (long)var7 == 0L && (this.posX != var2 || this.posY != var3 || this.posZ != var4 || System.currentTimeMillis() > this.updateTime + 1000L) && !this.IsPutOutByWater()) {
         this.posX = var2;
         this.posY = var3;
         this.posZ = var4;
         this.iX = (int)this.posX;
         this.iY = (int)this.posY;
         this.iZ = (int)this.posZ;
         this.markBlocksDirty(var1);
      }

   }

   public float getTorchLight(World var1, int var2, int var3, int var4) {
      if(this.bIsTorchActive && !this.IsPutOutByWater())
      {
         int var5 = var2 - this.iX + this.torchBrightness;
         int var6 = var3 - this.iY + this.torchBrightness;
         int var7 = var4 - this.iZ + this.torchBrightness;
         if(var5 >= 0 && var5 < this.range && var6 >= 0 && var6 < this.range && var7 >= 0 && var7 < this.range)
         {
            return this.cache[var5 * this.range * this.range + var6 * this.range + var7];
         }
      }

      return 0.0F;
   }

   private boolean IsPutOutByWater() {
      return !this.worksUnderwater && this.torchentity.isInWater();
   }

   private void markBlocksDirty(World var1)
   {
       markBlocksDirty(var1, false);
   }

   private void markBlocksDirty(World var1, boolean forceUpdate) {
      float var2 = this.posX - (float)this.iX;
      float var3 = this.posY - (float)this.iY;
      float var4 = this.posZ - (float)this.iZ;
      int var5 = 0;

      if (System.currentTimeMillis() < this.updateTime+100L && !forceUpdate) return;

      for(int var10 = -this.torchBrightness; var10 <= this.torchBrightness; ++var10) {
         int var6 = var10 + this.iX;

         for(int var11 = -this.torchBrightness; var11 <= this.torchBrightness; ++var11) {
            int var7 = var11 + this.iY;

            for(int var12 = -this.torchBrightness; var12 <= this.torchBrightness; ++var12) {
               int var8 = var12 + this.iZ;
               int var9 = var1.getBlockId(var6, var7, var8);
               if(var9 != 0 && Block.blocksList[var9].renderAsNormalBlock())
               {
                  this.cache[var5++] = 0.0F;
               }
               else
               {
                  float var13 = (float)(Math.abs((double)var10 + 0.5D - (double)var2) + Math.abs((double)var11 + 0.5D - (double)var3) + Math.abs((double)var12 + 0.5D - (double)var4));
                  if(var13 <= (float)this.torchBrightness)
                  {
                     if((float)this.torchBrightness - var13 > (float)var1.getBlockLightValue(var6, var7, var8)) {
                        var1.markBlockNeedsUpdate(var6, var7, var8);
                     }

                     this.cache[var5++] = (float)this.torchBrightness - var13;
                  } else {
                     this.cache[var5++] = 0.0F;
                  }
               }
            }
         }
      }

      this.updateTime = System.currentTimeMillis();
   }

   public void SetTorchBrightness(int var1) {
      this.torchBrightness = var1;
   }

   public int GetTorchBrightness() {
      return this.torchBrightness;
   }

   public void SetTorchRange(int var1) {
      this.range = var1;
   }

   public Entity GetTorchEntity() {
      return this.torchentity;
   }

   public void SetWorksUnderwater(boolean var1) {
      this.worksUnderwater = var1;
   }

   public void setDeathAge(int var1) {
      this.deathAge = var1;
   }

   public void doAgeTick() {
      --this.deathAge;
   }

   public boolean hasDeathAge() {
      return this.deathAge != -1;
   }

   public boolean hasReachedDeathAge() {
      return this.deathAge == 0;
   }

   public void FlagTorchAsCustom() {
      this.IsCustomTorch = true;
   }

   public void UnFlagTorchAsCustom() {
      this.IsCustomTorch = false;
   }

   public boolean IsTorchCustom() {
      return this.IsCustomTorch;
   }
}
