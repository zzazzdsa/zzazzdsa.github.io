import net.minecraft.client.Minecraft;
import net.minecraft.src.*;

/**
 * 
 */

/**
 * @author lahwran
 * 
 */
public class AS_RenderEntityLahwran extends Entity {

    public static Minecraft mc;
    
    public AS_RenderEntityLahwran(Minecraft minecraft, World arg0) {
        super(arg0);
        ignoreFrustumCheck = true;
        this.mc = minecraft;
    }

    @Override
    protected void entityInit() {
    }

    @Override
    public void readEntityFromNBT(net.minecraft.src.NBTTagCompound var1) {
    }

    @Override
    public void writeEntityToNBT(net.minecraft.src.NBTTagCompound var1) {
    }

    @Override
    public void onUpdate()
	{
        this.setPosition(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ);
    }

    @Override
    public void setEntityDead() {
    }
}