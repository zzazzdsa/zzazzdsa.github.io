import net.minecraft.client.Minecraft;
import net.minecraft.src.*;
import java.io.*;
import java.util.*;
import org.lwjgl.input.*;

import org.lwjgl.opengl.*;
import java.nio.*;
import java.lang.reflect.*;

public class SimplyHaxVision
{
	private final static String modname = "Vision";
	private static File configfile = new File(Minecraft.getMinecraftDir(), "mods/SimplyHax"+modname+".txt");
	private static boolean configLoaded = false;
	private static Minecraft mcinstance;
	
	private static String visionkey = "I";
	private static int ivisionkey = Keyboard.getKeyIndex(visionkey);
	private static float visiondist = 4.0F;
	
	private static boolean visionActive = false;
	private boolean rendererReplaced = false;
	private static RenderGlobal original;
	private static RenderGlobal replacement;
    private static SimplyHaxVision instance;

    public SimplyHaxVision(Minecraft mc)
    {
        mcinstance = mc;
        InitSettings();
    }
    
	public static void init(Minecraft minecraft)
	{
		instance = new SimplyHaxVision(minecraft);
	}
	
    public static void OnTickInGame()
    {
		if (mcinstance.theWorld != null && mcinstance.thePlayer != null)
		{
			visionActive = (Keyboard.isKeyDown(ivisionkey));
			if (instance.IsMenuOpen()) visionActive = false;
		}
    }
	
	public static void preRender()
	{
		if (IsAlive(mcinstance.thePlayer) && visionActive)
		{
			obliqueNearPlaneClip(0.0F, 0.0F, -1F, -visiondist);
		}
	}
	
    private static void obliqueNearPlaneClip(float f, float f1, float f2, float f3)
    {	
        float af[] = new float[16];
        FloatBuffer floatbuffer = makeBuffer(16);
        GL11.glGetFloat(2983 /*GL_PROJECTION_MATRIX*/, floatbuffer);
        floatbuffer.get(af).rewind();
        float f4 = (sgn(f) + af[8]) / af[0];
        float f5 = (sgn(f1) + af[9]) / af[5];
        float f6 = -1F;
        float f7 = (1.0F + af[10]) / af[14];
        float f8 = f * f4 + f1 * f5 + f2 * f6 + f3 * f7;
        af[2] = f * (2.0F / f8);
        af[6] = f1 * (2.0F / f8);
        af[10] = f2 * (2.0F / f8) + 1.0F;
        af[14] = f3 * (2.0F / f8);
        floatbuffer.put(af).rewind();
        GL11.glMatrixMode(5889 /*GL_PROJECTION*/);
        GL11.glLoadMatrix(floatbuffer);
        GL11.glMatrixMode(5888 /*GL_MODELVIEW0_ARB*/);
    }
	
	public static void InitSettings()
	{
		Properties properties = new Properties();
		
		if (configfile.exists())
		{
			System.out.println("SimplyHax"+modname+" config found, proceeding...");
		
			try
			{
				properties.load(new FileInputStream(configfile));
			}
			catch (IOException localIOException)
			{
				System.out.println("SimplyHax"+modname+" config exception: "+localIOException);
			}
			
			visionkey = properties.getProperty("visionkey", "I");
			ivisionkey = Keyboard.getKeyIndex(visionkey);
			visiondist = Float.parseFloat(properties.getProperty("visiondist", "4.0"));
		}
		else
		{
			System.out.println("No SimplyHax"+modname+" config found, trying to create...");
		
			try
			{
				configfile.createNewFile();
				properties.load(new FileInputStream(configfile));
			}
			catch (IOException localIOException)
			{
				System.out.println("SimplyHax"+modname+" config exception: "+localIOException);
			}
			
			properties.setProperty("visionkey", "I");
			properties.setProperty("visiondist", "4.0");
			
			try
			{
				FileOutputStream fostream = new FileOutputStream(configfile);
				properties.store(fostream, "Settings");
			}
			catch (IOException localIOException)
			{
				System.out.println("SimplyHax"+modname+" config exception: "+localIOException);
			}
		}
	}
	
	private static boolean IsAlive(EntityLiving ent)
	{
		return ent != null && ent.isEntityAlive();
	}
	
	private boolean IsMenuOpen()
	{
	    return mcinstance.currentScreen != null;
	}
	
    private static FloatBuffer makeBuffer(int length)
	{
		return ByteBuffer.allocateDirect(length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
	}
	
    private static FloatBuffer makeBuffer(float[] array)
	{
		return (FloatBuffer)ByteBuffer.allocateDirect(array.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(array).flip();
	}
	
    private static float sgn(float f)
	{
		return f<0f ? -1f : (f>0f ? 1f : 0f);
	}
}
