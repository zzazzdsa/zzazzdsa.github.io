import java.util.Map;
import org.lwjgl.input.*;
import net.minecraft.client.Minecraft;
import net.minecraft.src.*;
import java.util.*;
import org.lwjgl.opengl.GL11;

public class MultiMine
{
    public static World lastworld = null;
    public static AS_RenderEntityLahwran entity;
	public static ArrayList partiallyMinedBlocksList;
	public static final boolean DEBUGMODE = false;
	private static Minecraft mc;
    private static MultiMine instance;

    public MultiMine(Minecraft input)
	{
        mc = input;
        AS_RenderHooks.setMinecraft(mc);
		partiallyMinedBlocksList = new ArrayList();
        //ModLoader.SetInGameHook(this, true, true);
    }

	public static void init(Minecraft minecraft)
	{
		instance = new MultiMine(minecraft);
	}
	
    public static void OnTickInGame()
	{
        if (mc.theWorld != lastworld && mc.theWorld != null)
		{
            spawn(mc);
            lastworld = mc.theWorld;
        }
		
        if(lastworld != null
		&& mc.objectMouseOver != null
		&& mc.objectMouseOver.typeOfHit == EnumMovingObjectType.TILE
		&& Mouse.getEventButton() == 1
		&& Mouse.getEventButtonState())
        {
            int j = mc.objectMouseOver.blockX;
            int k = mc.objectMouseOver.blockY;
            int l = mc.objectMouseOver.blockZ;
			
			AS_BlockWithDamage dummy = new AS_BlockWithDamage(j, k, l, 0, null); //just the three ints describe the block object, hence this equals any present block in the list
			partiallyMinedBlocksList.remove(dummy);
		}
    }

    public static void spawn(Minecraft mc)
	{
		AS_Settings_MultiMine.InitSettings();
        entity = new AS_RenderEntityLahwran(mc, mc.theWorld);
        //entity.setPosition(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ); //huh?
        mc.theWorld.addWeatherEffect((Entity) entity);
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
	public static void AddRenderer(Map entityRenderMap)
    {
		entityRenderMap.put(AS_RenderEntityLahwran.class, new AS_RenderHooks());
	}
	
	public static void DebugPrint(String s)
	{
		if(DEBUGMODE)
		{
			System.out.println(s);
		}
	}

	public static float cBD_checkBlockRemoving(float curBlockDamage, int var1, int var2, int var3)
	{
	    AS_BlockWithDamage newb = new AS_BlockWithDamage(var1, var2, var3, 0, null);
		if (partiallyMinedBlocksList.contains(newb))
		{
			int index = partiallyMinedBlocksList.indexOf(newb);
			newb = (AS_BlockWithDamage)partiallyMinedBlocksList.get(index);
			if(newb.getDamage() > curBlockDamage)
			{
				return newb.getDamage();
			}
		}
		return curBlockDamage;
	}

    public static float cBD_MineSpeedMod(float curBlockDamage, Block target)
    {
        EntityPlayer player = mc.thePlayer;
		if (!AS_Settings_MultiMine.mineSpeedChanged)
		{
			curBlockDamage += target.blockStrength(player);
		}
		else
		{
			curBlockDamage += (target.blockStrength(player) * AS_Settings_MultiMine.mineSpeed);
		}
        return curBlockDamage;
    }

	public static float cBD_checkBlockRemovingStopped(float curBlockDamage, int var1, int var2, int var3)
	{
		AS_BlockWithDamage newb = new AS_BlockWithDamage(var1, var2, var3, 0, null);
		if (partiallyMinedBlocksList.contains(newb))
		{
			int index = partiallyMinedBlocksList.indexOf(newb);
			newb = (AS_BlockWithDamage)partiallyMinedBlocksList.get(index);
			return newb.getDamage();
		}
		else return 0.0F;
	}
}
