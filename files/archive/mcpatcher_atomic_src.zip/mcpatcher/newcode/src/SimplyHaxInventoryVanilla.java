import net.minecraft.client.Minecraft;
import net.minecraft.src.*;
import java.lang.reflect.*;


public class SimplyHaxInventoryVanilla
{
    private static long lastTime;
	
	private InventoryPlayer vanillainv;

	private ItemStack[] mainInv;
	private ItemStack[] armorInv;

    private static SimplyHaxInventoryVanilla instance;
    private static Minecraft mcInstance;
	
	private static boolean savedInventory = false;


    public SimplyHaxInventoryVanilla(Minecraft minecraft)
    {
        mcInstance = minecraft;
        lastTime = System.currentTimeMillis();
    }

	public static void init(Minecraft minecraft)
	{
		instance = new SimplyHaxInventoryVanilla(minecraft);
	}
	
    public static void OnTickInGame()
    {
		if (mcInstance.theWorld != null && mcInstance.thePlayer != null)
		{
			long l = System.currentTimeMillis();
			if(l > lastTime + 1000L)
			{
				lastTime = l;
				// do once a second stuff
				
				instance.HaxInventory(mcInstance.thePlayer);
			}
			
			// do every tick stuff
			
			if ((!mcInstance.thePlayer.isEntityAlive()) && !savedInventory)
			{
				instance.deleteDroppingItems(mcInstance.thePlayer);
			}
		}
    }
	
	private void HaxInventory(EntityPlayer entityplayer)
	{
		if (IsAlive(entityplayer) && hasItems(entityplayer))
		{
			int i;
			if (!savedInventory)
			{
				vanillainv = entityplayer.inventory;

				mainInv = new ItemStack[36];
				for (i = 0; i < vanillainv.mainInventory.length; i++)
				{
					if (vanillainv.mainInventory[i] != null)
					{
						mainInv[i] = vanillainv.mainInventory[i].copy();
					}
				}

				armorInv = new ItemStack[4];
				for (i = 0; i < vanillainv.armorInventory.length; i++)
				{
					if (vanillainv.armorInventory[i] != null)
					{
						armorInv[i] = vanillainv.armorInventory[i].copy();
					}
				}
			}
			else
			{
				if (vanillainv != null)
				{
					entityplayer.inventory.mainInventory = mainInv;
					entityplayer.inventory.armorInventory = armorInv;
					System.out.println("Restored Vanilla inv!");
					
					savedInventory = false;
				}
			}
		}
		else
		{
			savedInventory = true;
		}
	}
	
	private void deleteDroppingItems(EntityPlayer entityplayer)
	{
		java.util.List list = entityplayer.worldObj.getEntitiesWithinAABBExcludingEntity(entityplayer, entityplayer.boundingBox.expand(2D, 2D, 2D));
		
		if (list.size() > 0)
			System.out.println("Player dead, deleting "+list.size()+" dropped items");
		
		for(int i = 0; i < list.size(); i++)
		{
			Entity ent = (Entity)list.get(i);
			if(!ent.isDead && ent instanceof EntityItem)
			{
				ent.setEntityDead();
			}
		}
	}
	
	private boolean hasItems(EntityPlayer entityplayer)
	{
		return entityplayer.inventory.mainInventory.length > 0 || entityplayer.inventory.armorInventory.length > 0;
	}
	
	private boolean IsAlive(EntityLiving ent)
	{
		return ent != null && ent.isEntityAlive();
	}
}
