public class AS_BlockWithDamage
{
	public AS_BlockWithDamage(int bx, int by, int bz, float damagex, Object obj)
	{
		this.x = bx;
		this.y = by;
		this.z = bz;
		this.damage = damagex;
		this.blockObject = obj;
	}
	
	public float getDamage() { return damage; }
	public Object getObject() { return blockObject; }
	
	public void setDamage(float f)
	{
		this.damage = f;
	}
	
	private int x;
	private int y;
	private int z;
	private float damage;
	private Object blockObject;
	
	public boolean equals(Object obj)
	{
		if(obj instanceof AS_BlockWithDamage)
		{
			AS_BlockWithDamage o = (AS_BlockWithDamage)obj;
			return (o.x == this.x && o.y == this.y && o.z == this.z);
		}
		return false;
	}
}