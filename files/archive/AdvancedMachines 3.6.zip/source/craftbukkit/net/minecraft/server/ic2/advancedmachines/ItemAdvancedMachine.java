package net.minecraft.server.ic2.advancedmachines;

import net.minecraft.server.*;

public class ItemAdvancedMachine extends ItemBlock
{
    public ItemAdvancedMachine(int i)
    {
        super(i);
        setMaxDurability(0);
        a(true);
    }

    public int filterData(int i)
    {
        return i;
    }

    public String a(ItemStack itemstack)
    {
        int i = itemstack.getData();
        switch (i)
        {
            case 0:
                return "blockRotaryMacerator";

            case 1:
                return "blockSingularityCompressor";

            case 2:
                return "blockCentrifugeExtractor";
        }
        return null;
    }
}
