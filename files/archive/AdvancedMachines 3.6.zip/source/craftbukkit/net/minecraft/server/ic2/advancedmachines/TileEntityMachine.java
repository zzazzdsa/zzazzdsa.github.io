package net.minecraft.server.ic2.advancedmachines;

import net.minecraft.server.*;

public abstract class TileEntityMachine extends TileEntityBlock
    implements IInventory
{
    public ItemStack inventory[];

    public TileEntityMachine(int i)
    {
        inventory = new ItemStack[i];
    }

    public int getSize()
    {
        return inventory.length;
    }

    public ItemStack getItem(int i)
    {
        return inventory[i];
    }

    public ItemStack splitStack(int i, int j)
    {
        if (inventory[i] != null)
        {
            if (inventory[i].count <= j)
            {
                ItemStack itemstack = inventory[i];
                inventory[i] = null;
                return itemstack;
            }
            ItemStack itemstack1 = inventory[i].a(j);
            if (inventory[i].count == 0)
            {
                inventory[i] = null;
            }
            return itemstack1;
        }
        else
        {
            return null;
        }
    }

    public void setItem(int i, ItemStack itemstack)
    {
        inventory[i] = itemstack;
        if (itemstack != null && itemstack.count > getMaxStackSize())
        {
            itemstack.count = getMaxStackSize();
        }
    }

    public int getMaxStackSize()
    {
        return 64;
    }

    public boolean a(EntityHuman entityhuman)
    {
        return world.getTileEntity(x, y, z) == this ? entityhuman.f((double)x + 0.5D, (double)y + 0.5D, (double)z + 0.5D) <= 64D : false;
    }

    public abstract String getName();

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
        NBTTagList nbttaglist = nbttagcompound.getList("Items");
        inventory = new ItemStack[getSize()];
        for (int i = 0; i < nbttaglist.size(); i++)
        {
            NBTTagCompound nbttagcompound1 = (NBTTagCompound)nbttaglist.get(i);
            byte byte0 = nbttagcompound1.getByte("Slot");
            if (byte0 >= 0 && byte0 < inventory.length)
            {
                inventory[byte0] = ItemStack.a(nbttagcompound1);
            }
        }
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
        NBTTagList nbttaglist = new NBTTagList();
        for (int i = 0; i < inventory.length; i++)
        {
            if (inventory[i] != null)
            {
                NBTTagCompound nbttagcompound1 = new NBTTagCompound();
                nbttagcompound1.setByte("Slot", (byte)i);
                inventory[i].b(nbttagcompound1);
                nbttaglist.add(nbttagcompound1);
            }
        }

        nbttagcompound.set("Items", nbttaglist);
    }

    public void l_()
    {
        super.l_();
    }

    public void f()
    {
    }

    public void g()
    {
    }
    
	@Override
	public ItemStack[] getContents()
	{
		return this.inventory;
	}
}
