package net.minecraft.src;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.src.forge.*;
import net.minecraft.src.ic2.advancedmachines.*;
import net.minecraft.src.ic2.api.*;

public class mod_IC2AdvancedMachines extends BaseModMp
{
    public static Configuration config;
    
    public static Block blockAdvancedMachine;

    public static int guiIdRotary;
    public static int guiIdSingularity;
    public static int guiIdCentrifuge;
    
    public static String advMaceSound = "Machines/MaceratorOp.ogg";
    public static String advCompSound = "Machines/CompressorOp.ogg";
    public static String advExtcSound = "Machines/ExtractorOp.ogg";
    
    public static String interuptSound = "Machines/InterruptOne.ogg";
    
    public static String advMaceName = "Rotary Macerator";
    public static String advCompName = "Singularity Compressor";
    public static String advExtcName = "Centrifuge Extractor";
    
    public static boolean useBlock_0 = true;
    
    public static int[][] sideAndFacingToSpriteOffset;
    
    public GuiScreen HandleGUI(int var1)
    {
        EntityPlayerSP var2 = ModLoader.getMinecraftInstance().thePlayer;
        return var2 == null ? null : getGuiFor(var2, var1, (TileEntity)null);
    }

    public static GuiScreen getGuiFor(EntityPlayer var0, int var1, TileEntity var2)
    {
    	if (var1 ==  guiIdRotary)
    	{
    		return new GuiRotaryMacerator(var0.inventory, var2 == null ? new TileEntityRotaryMacerator() : (TileEntityRotaryMacerator)var2);
    	}
    	else if (var1 == guiIdSingularity)	
    	{
    		return new GuiSingularityCompressor(var0.inventory, var2 == null ? new TileEntitySingularityCompressor() : (TileEntitySingularityCompressor)var2);
    	}
    	else if (var1 == guiIdCentrifuge)	
    	{
    		return new GuiCentrifugeExtractor(var0.inventory, var2 == null ? new TileEntityCentrifugeExtractor() : (TileEntityCentrifugeExtractor)var2);
    	}	
    	
    	return null;
    }

    public String getVersion()
    {
        return "v3.4";
    }

    public static int getConfigInt(String stringValue, int defaultValue, int kind, boolean useComment, String comment)
    {
        if (config == null)
        {
            return defaultValue;
        } else
        {
            try
            {
            	if(useComment)
            	{
            		Property prop = config.getOrCreateIntProperty(stringValue, kind, defaultValue);
            		prop.comment = comment;
            		return Integer.valueOf(prop.value).intValue();
            	}
                return Integer.valueOf(config.getOrCreateIntProperty(stringValue, kind, defaultValue).value).intValue();
            }
            catch (Exception var3)
            {
                System.out.println("[Advanced Machines] Error while trying to access config, wasn\'t loaded properly!");
                return defaultValue;
            }
        }
    }
    
    public static int getBlockId(String stringValue, int defaultValue)
    {
        if (config == null)
        {
            return defaultValue;
        } else
        {
            try
            {
                return Integer.valueOf(config.getOrCreateBlockIdProperty(stringValue, defaultValue).value).intValue();
            }
            catch (Exception var3)
            {
                System.out.println("[Advanced Machines] Error while trying to access config, wasn\'t loaded properly!");
                return defaultValue;
            }
        }
    }

    public static void showGui(EntityPlayer var0, int var1, TileEntity var2)
    {
        ModLoader.OpenGUI(var0, getGuiFor(var0, var1, var2));
    }
    
    //////////////////////////////////////////////////////////////////
    public String getPriorities()	//								//
    {								//			IMPORTANT			//
    	return "after:mod_IC2";		//		 ALWAYS USE THIS		//
    }								//								//
    //////////////////////////////////////////////////////////////////
    public void load()
    {
    	try
    	{
    		sideAndFacingToSpriteOffset = (int[][])Class.forName("ic2.common.BlockMultiID").getField("sideAndFacingToSpriteOffset").get(null);
    	} catch (Exception e)
    	{
    		sideAndFacingToSpriteOffset = new int[][]{
    				{
    		            3, 2, 0, 0, 0, 0
    		        }, {
    		            2, 3, 1, 1, 1, 1
    		        }, {
    		            1, 1, 3, 2, 5, 4
    		        }, {
    		            0, 0, 2, 3, 4, 5
    		        }, {
    		            4, 5, 4, 5, 3, 2
    		        }, {
    		            5, 4, 5, 4, 2, 3
    		        }
    		    };
    	}
    	try
        {
            config = new Configuration(new File(Minecraft.getMinecraftDir().getPath(), "/config/IC2AdvancedMachine.cfg"));
            config.load();
        }
        catch (Exception var2)
        {
            System.out.println("[Advanced Machines] Error while trying to access configuration!");
            config = null;
        }

        blockAdvancedMachine = new BlockAdvancedMachines(getBlockId("blockAdvancedMachine", 188));

        guiIdRotary = getConfigInt("guiIdRotary", 40, 0, false, "");
        guiIdSingularity = getConfigInt("guiIdSingularity", 41, 0, false, "");
        guiIdCentrifuge = getConfigInt("guiIdCentrifuge", 42, 0, true, "GUI IDs. Only change them if you got a conflict.");
        
        Property prop = config.getOrCreateBooleanProperty("useDefaultTexture", 0, useBlock_0);
        prop.comment = "Set to true to use the default block_0. Useful for texture packs";
        useBlock_0 = Boolean.parseBoolean(prop.value);
        
        prop = config.getOrCreateProperty("advCompressorSound", 0, advCompSound);
        prop.comment = "Sound files to use on operation. Remember to use '/' instead of backslashes and the Sound directory starts on ic2/sounds. Set to null to not use any sound.";
        advCompSound = prop.value;
        advExtcSound = config.getOrCreateProperty("advExtractorSound", 0, advExtcSound).value;
        advMaceSound = config.getOrCreateProperty("advMaceratorSound", 0, advMaceSound).value;
        
        prop = config.getOrCreateProperty("nameAdvCompressor", 0, advCompName);
        prop.comment = "Item names. This will also affect their GUI";
        advCompName = prop.value;
        advExtcName = config.getOrCreateProperty("nameAdvExtractor", 0, advExtcName).value;
        advMaceName = config.getOrCreateProperty("nameAdvMacerator", 0, advMaceName).value;
        
        prop = config.getOrCreateProperty("interuptSound", 0, interuptSound);
        prop.comment = "Interupt sound file";
        
        if (config != null)
        {
            config.save();
        }

        ModLoader.RegisterBlock(blockAdvancedMachine, ItemAdvancedMachine.class);
    	
    	ModLoader.AddLocalization("blockRotaryMacerator.name", advMaceName);
        ModLoader.AddLocalization("blockSingularityCompressor.name", advCompName);
        ModLoader.AddLocalization("blockCentrifugeExtractor.name", advExtcName);

        ModLoader.RegisterTileEntity(TileEntityRotaryMacerator.class, "Rotary Macerator");
        ModLoader.RegisterTileEntity(TileEntitySingularityCompressor.class, "Singularity Compressor");
        ModLoader.RegisterTileEntity(TileEntityCentrifugeExtractor.class, "Centrifuge Extractor");

        ModLoaderMp.RegisterGUI(this, guiIdRotary);
        ModLoaderMp.RegisterGUI(this, guiIdSingularity);
        ModLoaderMp.RegisterGUI(this, guiIdCentrifuge);
        
        MinecraftForgeClient.preloadTexture("ic2/sprites/block_advmachine.png");
    }
    
    public void ModsLoaded()
    {
        Ic2Recipes.addCraftingRecipe(new ItemStack(blockAdvancedMachine, 1, 0),
        		new Object[] {"RRR", "RMR", "RAR",
        	Character.valueOf('R'), Items.getItem("refinedIronIngot"),
        	Character.valueOf('M'), Items.getItem("macerator"),
        	Character.valueOf('A'), Items.getItem("advancedMachine")});
        
        Ic2Recipes.addCraftingRecipe(new ItemStack(blockAdvancedMachine, 1, 1),
        		new Object[] {"RRR", "RMR", "RAR",
        	Character.valueOf('R'), Block.obsidian,
        	Character.valueOf('M'), Items.getItem("compressor"),
        	Character.valueOf('A'), Items.getItem("advancedMachine")});
        
        Ic2Recipes.addCraftingRecipe(new ItemStack(blockAdvancedMachine, 1, 2),
        		new Object[] {"RRR", "RMR", "RAR",
        	Character.valueOf('R'), Items.getItem("electrolyzedWaterCell"),
        	Character.valueOf('M'), Items.getItem("extractor"),
        	Character.valueOf('A'), Items.getItem("advancedMachine")});
    }
    
    public static void explodeMachineAt(World world, int x, int y, int z)
    {
		try 
		{
			Class<?> mainIC2Class = Class.forName("mod_IC2");
			mainIC2Class.getMethod("explodeMachineAt", World.class, Integer.TYPE, Integer.TYPE, Integer.TYPE).invoke(null, world, x, y, z);
		} catch (NoSuchMethodException e) 
		{
			System.out.println("[Advanced Machines] An error occured when trying to explode machine: " + e);
		} catch (SecurityException e) 
		{
			System.out.println("[Advanced Machines] An error occured when trying to explode machine: " + e);
		} catch (ClassNotFoundException e) 
		{
			System.out.println("[Advanced Machines] An error occured when trying to explode machine: " + e);
		} catch (IllegalAccessException e) 
		{
			System.out.println("[Advanced Machines] An error occured when trying to explode machine: " + e);
		} catch (IllegalArgumentException e) 
		{
			System.out.println("[Advanced Machines] An error occured when trying to explode machine: " + e);
		} catch (InvocationTargetException e) 
		{
			System.out.println("[Advanced Machines] An error occured when trying to explode machine: " + e);
		}
    }
}
