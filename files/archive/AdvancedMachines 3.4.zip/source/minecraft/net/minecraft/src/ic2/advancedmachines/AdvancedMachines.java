package net.minecraft.src.ic2.advancedmachines;

import net.minecraft.src.*;
import net.minecraft.src.forge.*;
import net.minecraft.src.ic2.api.*;

public abstract class AdvancedMachines extends BaseModMp
{
    public static Block blockAdvancedMachine;
    public static Block blockSolarArray;

    public static void initialize()
    {
        ModLoader.RegisterBlock(blockAdvancedMachine, ItemAdvancedMachine.class);
        Ic2Recipes.addCraftingRecipe(new ItemStack(blockAdvancedMachine, 1, 0), new Object[] {"RRR", "RMR", "RAR", Character.valueOf('R'), Items.getItem("refinedIronIngot"), Character.valueOf('M'), Items.getItem("macerator"), Character.valueOf('A'), Items.getItem("advancedMachine")});
        Ic2Recipes.addCraftingRecipe(new ItemStack(blockAdvancedMachine, 1, 1), new Object[] {"RRR", "RMR", "RAR", Character.valueOf('R'), Block.obsidian, Character.valueOf('M'), Items.getItem("compressor"), Character.valueOf('A'), Items.getItem("advancedMachine")});
        Ic2Recipes.addCraftingRecipe(new ItemStack(blockAdvancedMachine, 1, 2), new Object[] {"RRR", "RMR", "RAR", Character.valueOf('R'), Items.getItem("electrolyzedWaterCell"), Character.valueOf('M'), Items.getItem("extractor"), Character.valueOf('A'), Items.getItem("advancedMachine")});
        ModLoader.AddLocalization("blockRotaryMacerator.name", "Rotary Macerator");
        ModLoader.AddLocalization("blockSingularityCompressor.name", "Singularity Compressor");
        ModLoader.AddLocalization("blockCentrifugeExtractor.name", "Centrifuge Extractor");
        ModLoader.RegisterTileEntity(TileEntityRotaryMacerator.class, "Rotary Macerator");
        ModLoader.RegisterTileEntity(TileEntitySingularityCompressor.class, "Singularity Compressor");
        ModLoader.RegisterTileEntity(TileEntityCentrifugeExtractor.class, "Centrifuge Extractor");
    }
}
