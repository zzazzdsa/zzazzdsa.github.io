package net.minecraft.server.ic2.advancedmachines;

import java.lang.reflect.Method;
import net.minecraft.server.*;

public class IC2AudioSource
{
    private static boolean initFailed = false;
    private static Class audioManagerClass;
    private static Method audioManagercreateSource;
    private static Method audioManagerremoveSource;
    private static Method audioManagerplayOnce;
    private static Class audioSourceClass;
    private static Method audioSourcePlay;
    private static Method audioSourceStop;
    private static Method audioSourceRemove;
    private Object audioSourceinstance;

    public IC2AudioSource(TileEntity tileentity, String s)
    {
    }

    public static void removeSource(Object obj)
    {
    }

    public static void playOnce(TileEntity tileentity, String s)
    {
    }

    public void play()
    {
    }

    public void stop()
    {
    }

    public void remove()
    {
    }
}
