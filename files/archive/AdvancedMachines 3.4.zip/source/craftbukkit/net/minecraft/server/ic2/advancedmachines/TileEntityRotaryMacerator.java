package net.minecraft.server.ic2.advancedmachines;

import ic2.api.*;
import java.util.*;
import net.minecraft.server.*;

public class TileEntityRotaryMacerator extends TileEntityAdvancedMachine
    implements IInventory
{
    public TileEntityRotaryMacerator()
    {
        super("Rotary Macerator", "%5d RPM", 1, new int[]
                {
                    0
                }, new int[]
                {
                    2, 3
                });
    }

    public Container getGuiContainer(PlayerInventory playerinventory)
    {
        return new ContainerRotaryMacerator(playerinventory, this);
    }

    protected List getResultMap()
    {
        return Ic2Recipes.getMaceratorRecipes();
    }

    public ItemStack getResultFor(ItemStack itemstack, boolean flag)
    {
        return Ic2Recipes.getMaceratorOutputFor(itemstack, flag);
    }
}
