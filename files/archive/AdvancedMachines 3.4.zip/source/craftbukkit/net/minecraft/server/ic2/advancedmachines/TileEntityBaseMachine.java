package net.minecraft.server.ic2.advancedmachines;

import ic2.api.*;
import ic2.api.Direction;

import net.minecraft.server.*;

public abstract class TileEntityBaseMachine extends TileEntityMachine
    implements IEnergySink
{
    public int energy;
    public int fuelslot;
    public int maxEnergy;
    public int maxInput;
    public int tier;
    public boolean addedToEnergyNet;

    public TileEntityBaseMachine(int i, int j, int k, int l)
    {
        super(i);
        energy = 0;
        tier = 0;
        addedToEnergyNet = false;
        fuelslot = j;
        maxEnergy = k;
        maxInput = l;
        tier = 1;
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
        energy = nbttagcompound.getInt("energy");
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
        nbttagcompound.setInt("energy", energy);
    }

    public void l_()
    {
        super.l_();
        if (!addedToEnergyNet)
        {
            EnergyNet.getForWorld(world).addTileEntity(this);
            addedToEnergyNet = true;
        }
    }

    public void i()
    {
        if (addedToEnergyNet)
        {
            EnergyNet.getForWorld(world).removeTileEntity(this);
            addedToEnergyNet = false;
        }
        super.i();
    }

    public boolean provideEnergy()
    {
        if (inventory[fuelslot] == null)
        {
            return false;
        }
        int i = inventory[fuelslot].id;
        if (Item.byId[i] instanceof IElectricItem)
        {
            if (!((IElectricItem)Item.byId[i]).canProvideEnergy())
            {
                return false;
            }
            else
            {
                int j = ElectricItem.discharge(inventory[fuelslot], maxEnergy - energy, tier, false, false);
                energy += j;
                return j > 0;
            }
        }
        if (i == Item.REDSTONE.id)
        {
            energy += maxEnergy;
            inventory[fuelslot].count--;
            if (inventory[fuelslot].count <= 0)
            {
                inventory[fuelslot] = null;
            }
            return true;
        }
        if (i == Items.getItem("suBattery").id)
        {
            energy += 1000;
            inventory[fuelslot].count--;
            if (inventory[fuelslot].count <= 0)
            {
                inventory[fuelslot] = null;
            }
            return true;
        }
        else
        {
            return false;
        }
    }

    public boolean isAddedToEnergyNet()
    {
        return addedToEnergyNet;
    }

    public boolean demandsEnergy()
    {
        return energy <= maxEnergy - maxInput;
    }

    public int injectEnergy(Direction direction, int i)
    {
        if (i > maxInput)
        {
            mod_IC2AdvancedMachines.explodeMachineAt(world, x, y, z);
            return 0;
        }
        energy += i;
        int j = 0;
        if (energy > maxEnergy)
        {
            j = energy - maxEnergy;
            energy = maxEnergy;
        }
        return j;
    }

    public boolean acceptsEnergyFrom(TileEntity tileentity, Direction direction)
    {
        return true;
    }

    public boolean isRedstonePowered()
    {
        return world.isBlockIndirectlyPowered(x, y, z);
    }
}
