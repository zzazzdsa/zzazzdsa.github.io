package net.minecraft.server.ic2.advancedmachines;

import ic2.api.*;
import net.minecraft.server.*;

public abstract class AdvancedMachines
{
    public static Block blockAdvancedMachine;
    public static Block blockSolarArray;

    public AdvancedMachines()
    {
    }

    public static void initialize()
    {
        ModLoader.RegisterBlock(blockAdvancedMachine, ItemAdvancedMachine.class);
        Ic2Recipes.addCraftingRecipe(new ItemStack(blockAdvancedMachine, 1, 0), new Object[]
                {
                    "RRR", "RMR", "RAR", Character.valueOf('R'), Items.getItem("refinedIronIngot"), Character.valueOf('M'), Items.getItem("macerator"), Character.valueOf('A'), Items.getItem("advancedMachine")
                });
        Ic2Recipes.addCraftingRecipe(new ItemStack(blockAdvancedMachine, 1, 1), new Object[]
                {
                    "RRR", "RMR", "RAR", Character.valueOf('R'), Block.OBSIDIAN, Character.valueOf('M'), Items.getItem("compressor"), Character.valueOf('A'), Items.getItem("advancedMachine")
                });
        Ic2Recipes.addCraftingRecipe(new ItemStack(blockAdvancedMachine, 1, 2), new Object[]
                {
                    "RRR", "RMR", "RAR", Character.valueOf('R'), Items.getItem("electrolyzedWaterCell"), Character.valueOf('M'), Items.getItem("extractor"), Character.valueOf('A'), Items.getItem("advancedMachine")
                });
        ModLoader.RegisterTileEntity(TileEntityRotaryMacerator.class, "Rotary Macerator");
        ModLoader.RegisterTileEntity(TileEntitySingularityCompressor.class, "Singularity Compressor");
        ModLoader.RegisterTileEntity(TileEntityCentrifugeExtractor.class, "Centrifuge Extractor");
    }
}
