package net.minecraft.src;

import java.io.*;
import java.net.*;
import java.security.*;
import java.util.*;

import net.minecraft.server.MinecraftServer;
import net.minecraft.src.*;
import net.minecraft.src.atomicstryker.ForgePacketWrapper;
import net.minecraft.src.atomicstryker.ropesplus.*;
import net.minecraft.src.forge.*;

public class mod_RopesPlus extends NetworkMod implements IConnectionHandler, IPacketHandler
{
	public static RopesPlusCore core;
	
	// Rope mod part
	public static int idRopeBlock;
	public static Block ropeBlock;
	public static int rtex;
	public static List ropeEntArray = new ArrayList();
	public static List ropePosArray = new ArrayList();
	
	// Grappling Hook mod part
	public static Block blockRope;
	public static Block blockGrapplingHook;
	public static int ropeTexture;
	public static Item itemRope;
	public static Item itemGrapplingHook;
	public static Map grapplingHooks = new HashMap();
	
	// 303 Arrows part
	public static mod_RopesPlus inst;
	public static MinecraftServer mc = ModLoader.getMinecraftServerInstance();
	
	@Override
	public void load()
	{
		AS_Settings_RopePlus.InitSettings();
		
		// Rope mod part
		itemRope = new Item(AS_Settings_RopePlus.itemIdRope).setIconIndex(ModLoader.addOverride("/gui/items.png", "/imgz/rope.png")).setItemName("itemRope");
		rtex = ModLoader.addOverride("/terrain.png", "/imgz/rope2.png");
		idRopeBlock = AS_Settings_RopePlus.blockIdRopeDJRoslin;
		ropeBlock = (new BlockRope(idRopeBlock, rtex)).setHardness(0.3F).setStepSound(Block.soundMetalFootstep).setBlockName("rope");
		ModLoader.addName(ropeBlock, "Rope");

		// Grappling Hook mod part
		itemGrapplingHook = new ASItemGrapplingHook(AS_Settings_RopePlus.itemIdGrapplingHook).setIconIndex(ModLoader.addOverride("/gui/items.png", "/imgz/itemGrapplingHook.png")).setItemName("itemGrapplingHook");
		ropeTexture = ModLoader.addOverride("/terrain.png", "/imgz/rope.png");
		blockRope = (new ASBlockRope(AS_Settings_RopePlus.blockIdRope, ropeTexture, ModLoader.getUniqueBlockModelID(this, false))).setHardness(0.5F).setStepSound(Block.soundClothFootstep).setBlockName("blockRope");
		blockGrapplingHook = (new ASBlockGrapplingHook(AS_Settings_RopePlus.blockIdGrapplingHook, ModLoader.addOverride("/terrain.png", "/imgz/blockGrapplingHook.png"), ModLoader.getUniqueBlockModelID(this, false))).setHardness(0.0F).setStepSound(Block.soundMetalFootstep).setBlockName("blockGrapplingHook");
		ModLoader.addName(blockRope, "GrHk Rope");
		ModLoader.addName(blockGrapplingHook, "Grappling Hook");
		ModLoader.addName(itemRope, "GrHk Rope");
		ModLoader.addName(itemGrapplingHook, "Grappling Hook");

		// 303 Arrows part
		inst = this;
		
		core = new RopesPlusCore();
		RopesPlusCore.load(this);
		
		ModLoader.setInGameHook(this, true, true);
	}

	@Override
	public boolean onTickInGame(MinecraftServer mc)
	{
		for(int x = 0; x < ropeEntArray.size(); x++)
		{
			Object temp = ropeEntArray.get(x);
			if (temp instanceof BlockRopePseudoEnt)
			{
				if (((BlockRopePseudoEnt) temp).OnUpdate())
				{
					ropeEntArray.remove(x);
				}
			}
			else if (temp instanceof ASTileEntityRope)
			{
				if (((ASTileEntityRope) temp).OnUpdate())
				{
					ropeEntArray.remove(x);
				}
			}
		}

		return true;
	}

	@Override
	public String getVersion()
	{
		return RopesPlusCore.getVersion();
	}

	@Override
	public void modsLoaded()
	{
		RopesPlusCore.modsLoaded();
	}

	@Override
	public boolean dispenseEntity(World world, double d, double d1, double d2, 
			int i, int j, ItemStack itemstack)
	{
		return RopesPlusCore.dispenseEntity(world, d, d1, d2, i, j, itemstack);
	}
	
	private static HashMap<EntityPlayer, Integer> selectedSlotMap = new HashMap<EntityPlayer, Integer>();
	private HashMap<EntityPlayer, Boolean> cycledMap = new HashMap<EntityPlayer, Boolean>();
	
	public static int selectedSlot(EntityPlayer p)
	{
		if (selectedSlotMap.get(p) == null)
			return 0;
		
		return selectedSlotMap.get(p);
	}
	
	public static void setselectedSlot(EntityPlayer p, int i)
	{
		selectedSlotMap.put(p, i);
	}

	@Override
	public boolean clientSideRequired()
	{
		return true;
	}

	@Override
	public boolean serverSideRequired()
	{
		return false;
	}

	@Override
	public void onPacketData(NetworkManager network, String channel, byte[] bytes)
	{
		DataInputStream data = new DataInputStream(new ByteArrayInputStream(bytes));
		
		int packetID = ForgePacketWrapper.readPacketID(data);
		
		if (packetID == 1)
		{
			Class[] decodeAs = {String.class, Integer.class};
			Object[] packetReadout = ForgePacketWrapper.readPacketData(data, decodeAs);
			
			setselectedSlot(mc.configManager.getPlayerEntity((String) packetReadout[0]), (Integer) packetReadout[1]);
		}
	}

	@Override
	public void onConnect(NetworkManager network)
	{
	}

	@Override
	public void onLogin(NetworkManager network, Packet1Login login)
	{
		MessageManager.getInstance().registerChannel(network, this, RopesPlusCore.getPacketChannel());
	}

	@Override
	public void onDisconnect(NetworkManager network, String message, Object[] args)
	{		
	}
}
