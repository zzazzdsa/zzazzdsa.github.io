package net.minecraft.src.atomicstryker.ropesplus;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import net.minecraft.src.*;
import net.minecraft.src.forge.*;

public class RopesPlusCore implements IArrowNockHandler
{
	final static Class coreArrowClasses[] = {
			EntityArrow303Dirt.class,
			EntityArrow303Ex.class,
			EntityArrow303Fire.class,
			EntityArrow303Grass.class,
			EntityArrow303Ice.class,
			EntityArrow303Laser.class,
			EntityArrow303Slime.class,
			EntityArrow303Torch.class, 
			EntityArrow303Warp.class,
			EntityArrow303Confusion.class,
			EntityArrow303Rope.class
	};
	public static List arrows = new ArrayList();
	public static Item bowRopesPlus;
	public static List arrowItems = new ArrayList();
	public static RopesPlusCore instance;
	
	public RopesPlusCore()
	{
		instance = this;
	}

	public static String getVersion()
	{
		return "1.0.1 @ MC 1.2.5";
	}
	
	public static int getFirstArrowEntityID()
	{
		return 35;
	}

	public static void load(mod_RopesPlus mod)
	{
		MinecraftForge.registerConnectionHandler(mod);
		
		// Rope
		ModLoader.registerBlock(mod_RopesPlus.ropeBlock);
        ModLoader.addRecipe(new ItemStack(mod_RopesPlus.ropeBlock, 12), new Object[] {
            " # ", " # ", " # ", Character.valueOf('#'), Item.silk
        });
		
		// Grappling Hook
        ModLoader.registerEntityID(ASEntityGrapplingHook.class, "GrapplingHook", 254);
        MinecraftForge.registerEntity(ASEntityGrapplingHook.class, mod, 254, 20, 5, true);
		
		ModLoader.registerBlock(mod_RopesPlus.blockRope);
        ModLoader.registerBlock(mod_RopesPlus.blockGrapplingHook);
        ModLoader.addRecipe(new ItemStack(mod_RopesPlus.itemGrapplingHook, 1), new Object[] {
            " X ", " # ", " # ", Character.valueOf('#'), mod_RopesPlus.ropeBlock, Character.valueOf('X'), Item.ingotIron
        });
        
        // 303 Arrows
        bowRopesPlus = new ItemBowRopesPlus(8343).setIconCoord(5, 1).setItemName("bowRopesPlus");;
        
		int index = getFirstArrowEntityID();
		for(Class class1 : coreArrowClasses)
		{
			addArrow(makeArrow(class1));
			MinecraftForge.registerEntity(class1, mod, index, 40, 5, true);
			index++;
		}
		arrows.add(new EntityArrow303(null));
		MinecraftForge.registerEntity(EntityArrow303.class, mod, index, 40, 5, true);
		
		MinecraftForge.registerArrowNockHandler(instance);
	}
	
    /**
     * This is called before a player tries to load an arrow. If it returns
     * a non-null result, then the normal arrow will not be loaded and the
     * bow will be changed to the returned value.
     *
     * @param itemstack The ItemStack for the bow doing the firing
     * @param world The current world
     * @param player The player that is using the bow
     * @return The new bow item, or null to continue normally.
     */
	@Override
	public ItemStack onArrowNock(ItemStack itemstack, World world, EntityPlayer player)
	{
		if (player.inventory.mainInventory[mod_RopesPlus.inst.selectedSlot(player)] != null && player.inventory.mainInventory[mod_RopesPlus.inst.selectedSlot(player)].itemID != Item.arrow.shiftedIndex)
		{
			ItemBowRopesPlus.setVanillaBow(itemstack);
			return new ItemStack(bowRopesPlus);
		}
		
		return null;
	}

	private static void makeItem(EntityArrow303 entityarrow303)
	{
		Item item = null;
		if(entityarrow303.itemId == Item.arrow.shiftedIndex)
		{
			Item.itemsList[Item.arrow.shiftedIndex] = null;
			item = Item.arrow = (new ItemArrow303(Item.arrow.shiftedIndex - 256, entityarrow303)).setItemName(Item.arrow.getItemName());
		}
		else if (Item.arrow != null)
		{
			item = (new ItemArrow303(entityarrow303.itemId - 256, entityarrow303)).setItemName(entityarrow303.name);
			ModLoader.addRecipe(new ItemStack(entityarrow303.itemId, entityarrow303.craftingResults, 0), new Object[] {
				"X", "#", "Y", Character.valueOf('X'), entityarrow303.tip, Character.valueOf('#'), Item.stick, Character.valueOf('Y'), Item.feather
			});

			arrowItems.add(item);
		}
		ModLoader.addName(item, entityarrow303.name);
	}

	public static EntityArrow303 makeArrow(Class class1)
	{
		try
		{
			return (EntityArrow303)class1.getConstructor(new Class[] {net.minecraft.src.World.class}).newInstance(new Object[] {(World)null});
		}
		catch(Throwable throwable)
		{
			throw new RuntimeException(throwable);
		}
	}

	public static void addArrow(EntityArrow303 entityarrow303)
	{
		arrows.add(entityarrow303);
	}
	
	public static Item getArrowItemByTip(Object desiredtip)
	{
		for(Iterator iterator = arrowItems.iterator(); iterator.hasNext();)
		{
			ItemArrow303 itemarrow303 = (ItemArrow303)iterator.next();
			if(itemarrow303.arrow.tip == desiredtip)
			{
				return (Item)itemarrow303;
			}
		}

		return null;
	}
	
	public static void onRopeArrowHit(World world, int x, int y, int z)
	{
		int[] coords = new int[3];
		coords[0] = x;
		coords[1] = y;
		coords[2] = z;
		addCoordsToRopeArray(coords);
		
		BlockRopePseudoEnt newent = new BlockRopePseudoEnt(world, x, y, z, 31);
		addRopeToArray(newent);
	}
	
	public static void addRopeToArray(BlockRopePseudoEnt ent)
	{
		mod_RopesPlus.ropeEntArray.add(ent);
	}
	
	public static void addRopeToArray(ASTileEntityRope newent)
	{
		mod_RopesPlus.ropeEntArray.add(newent);
	}
	
	public static void addCoordsToRopeArray(int[] coords)
	{
		mod_RopesPlus.ropePosArray.add(coords);
	}
	
	public static void removeCoordsFromRopeArray(int[] coords)
	{
		mod_RopesPlus.ropePosArray.remove(coords);
	}
	
	public static int[] areCoordsArrowRope(int i, int j, int k)
	{
		for(int w = 0; w < mod_RopesPlus.ropePosArray.size(); w++)
		{
			int[] coords = (int[])mod_RopesPlus.ropePosArray.get(w);
			
			if (i == coords[0] && j == coords[1] && k == coords[2])
			{
				return coords;
			}
		}
		return null;
	}

	public static String getPacketChannel()
	{
		return "mod_RopesPlus";
	}

	public static void modsLoaded()
	{
		EntityArrow303 entArrow303;
		for(Iterator iter = RopesPlusCore.arrows.iterator(); iter.hasNext(); ModLoader.registerEntityID(entArrow303.getClass(), (new StringBuilder()).append(entArrow303.name).append("303").toString(), ModLoader.getUniqueEntityId()))
		{
			entArrow303 = (EntityArrow303)iter.next();
			makeItem(entArrow303);
		}
	}

	public static boolean dispenseEntity(World world, double d, double d1, double d2, int i, int j, ItemStack itemstack)
	{
		for(Iterator iterator = arrows.iterator(); iterator.hasNext();)
		{
			EntityArrow303 entityarrow303 = (EntityArrow303)iterator.next();
			if(entityarrow303.itemId == itemstack.itemID)
			{
				EntityArrow303 entityarrow303_1 = entityarrow303.newArrow(world);
				entityarrow303_1.setPosition(d, d1, d2);
				entityarrow303_1.setArrowHeading(i, 0.10000000000000001D, j, 1.1F, 6F);
				world.spawnEntityInWorld(entityarrow303_1);
				world.playSoundEffect(d, d1, d2, "random.bow", 1.0F, 1.2F);
				return true;
			}
		}

		return false;
	}
}
