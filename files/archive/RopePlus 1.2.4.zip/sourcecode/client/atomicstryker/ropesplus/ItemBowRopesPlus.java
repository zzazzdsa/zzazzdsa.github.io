package net.minecraft.src.atomicstryker.ropesplus;

import net.minecraft.src.*;
import net.minecraft.src.forge.*;

public class ItemBowRopesPlus extends ItemBow
{
	public static ItemStack vanillaBowToRetain;

	public ItemBowRopesPlus(int i)
	{
		super(i);
	}

	public static void setVanillaBow(ItemStack vanillaBow)
	{
		vanillaBowToRetain = vanillaBow;
	}

	/**
	 * called when the player releases the use item button.
	 */
	public void onPlayerStoppedUsing(ItemStack par1ItemStack, World par2World,
			EntityPlayer par3EntityPlayer, int heldTicks)
	{
		if (par3EntityPlayer.inventory.hasItem(mod_RopesPlus.inst.selectedArrow.itemId))
		{
			int ticksLeftToCharge = this.getMaxItemUseDuration(par1ItemStack) - heldTicks;
			float bowChargeRatio = (float) ticksLeftToCharge / 20.0F;
			bowChargeRatio = (bowChargeRatio * bowChargeRatio + bowChargeRatio * 2.0F) / 3.0F;

			if ((double) bowChargeRatio < 0.1D)
			{
				return;
			}

			if (bowChargeRatio > 1.0F)
			{
				bowChargeRatio = 1.0F;
			}

			EntityArrow303 newArrow = mod_RopesPlus.inst.selectedArrow.newArrow(par2World, par3EntityPlayer);

			if (bowChargeRatio == 1.0F)
			{
				newArrow.arrowCritical = true;
			}

			int var9 = EnchantmentHelper.getEnchantmentLevel(Enchantment.power.effectId, par1ItemStack);

			if (var9 > 0)
			{
				newArrow.dmg = (int) Math.rint(newArrow.dmg + (double) var9 * 0.5D + 0.5D);
			}

			if (EnchantmentHelper.getEnchantmentLevel(Enchantment.flame.effectId, par1ItemStack) > 0)
			{
				newArrow.setFire(100);
			}

			par1ItemStack.damageItem(1, par3EntityPlayer);
			par2World.playSoundAtEntity(par3EntityPlayer, "random.bow", 1.0F, 1.0F / (itemRand.nextFloat() * 0.4F + 1.2F) + bowChargeRatio * 0.5F);

			par3EntityPlayer.inventory.consumeInventoryItem(mod_RopesPlus.inst.selectedArrow.itemId);

			if (!par2World.isRemote)
			{
				par2World.spawnEntityInWorld(newArrow);
			}
		}

		// put vanilla bow back in hands, do damage etc
		par3EntityPlayer.inventory.mainInventory[par3EntityPlayer.inventory.currentItem] = vanillaBowToRetain;
		par1ItemStack.damageItem(1, par3EntityPlayer);
	}

	/**
	 * Called whenever this item is equipped and the right mouse button is
	 * pressed. Args: itemStack, world, entityPlayer
	 */
	public ItemStack onItemRightClick(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer)
	{
		if (par3EntityPlayer.inventory.hasItem(Item.arrow.shiftedIndex))
		{
			par3EntityPlayer.setItemInUse(par1ItemStack, this.getMaxItemUseDuration(par1ItemStack));
		}

		return par1ItemStack;
	}
}
