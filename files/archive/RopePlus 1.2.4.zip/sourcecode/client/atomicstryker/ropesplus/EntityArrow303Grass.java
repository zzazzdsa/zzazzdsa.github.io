package net.minecraft.src.atomicstryker.ropesplus;

import net.minecraft.client.Minecraft;
import net.minecraft.src.*;

public class EntityArrow303Grass extends EntityArrow303
{

    public void entityInit()
    {
        super.entityInit();
        name = "GrassArrow";
        craftingResults = 1;
        itemId = 3439 + Block.blocksList.length;
        tip = Item.seeds;
        item = new ItemStack(itemId, 1, 0);
        spriteFile = "/arrows/grassarrow.png";
    }

    public EntityArrow303Grass(World world)
    {
        super(world);
    }

    public EntityArrow303Grass(World world, EntityLiving entityliving)
    {
        super(world, entityliving);
    }

    public EntityArrow303Grass(World world, double d, double d1, double d2)
    {
        super(world, d, d1, d2);
    }

    public boolean onHit()
    {
        int i = MathHelper.floor_double(posX);
        int j = MathHelper.floor_double(posY);
        int k = MathHelper.floor_double(posZ);
        for(int l = i - 1; l <= i + 1; l++)
        {
            for(int i1 = j - 1; i1 <= j + 1; i1++)
            {
                for(int j1 = k - 1; j1 <= k + 1; j1++)
                {
                    int k1 = worldObj.getBlockId(l, i1, j1);
                    if(k1 == 3)
                    {
                        worldObj.setBlockWithNotify(l, i1, j1, 2);
                        setDead();
                        continue;
                    }
                    if(k1 == 4)
                    {
                        worldObj.setBlockWithNotify(l, i1, j1, 48);
                        setDead();
                        continue;
                    }
                    if(k1 == 60 && i1 != 127 && worldObj.getBlockId(l, i1 + 1, j1) == 0)
                    {
                        worldObj.setBlockWithNotify(l, i1 + 1, j1, 59);
                        setDead();
                    }
                }

            }

        }

        return true;
    }

    public void tickFlying()
    {
        super.tickFlying();
        if(true)
        {
			int i = rand.nextInt(6);
			int j = 0;
		
            EntityDiggingFX entitydiggingfx = new EntityDiggingFX(worldObj, posX, posY, posZ, 0.01D, 0.01D, 0.01D, Block.sandStone, i, j);
            entitydiggingfx.motionX = entitydiggingfx.motionZ = entitydiggingfx.motionY = 0.01D;
            entitydiggingfx.renderDistanceWeight = 10D;
            mod_RopesPlus.mc.effectRenderer.addEffect(entitydiggingfx);
        }
    }
}
