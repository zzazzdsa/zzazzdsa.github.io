package atomicstryker.kenshiro.common;

public class CommonProxy
{
    public void load()
    {
        // NOOP
    }
}
