package net.minecraft.server.ic2.advancedmachines;

import java.util.List;
import net.minecraft.server.*;

public class ContainerCentrifugeExtractor extends Container
{
    public TileEntityCentrifugeExtractor tileentity;
    public int progress;
    public int energy;
    public int speed;

    public ContainerCentrifugeExtractor(PlayerInventory playerinventory, TileEntityCentrifugeExtractor tileentitycentrifugeextractor)
    {
        progress = 0;
        energy = 0;
        speed = 0;
        tileentity = tileentitycentrifugeextractor;
        a(new Slot(tileentitycentrifugeextractor, 0, 56, 17));
        a(new Slot(tileentitycentrifugeextractor, 1, 56, 53));
        a(new SlotResult2(playerinventory.d, tileentitycentrifugeextractor, 2, 115, 35));
        a(new SlotResult2(playerinventory.d, tileentitycentrifugeextractor, 3, 131, 35));
        a(new Slot(tileentitycentrifugeextractor, 4, 152, 6));
        a(new Slot(tileentitycentrifugeextractor, 5, 152, 24));
        a(new Slot(tileentitycentrifugeextractor, 6, 152, 42));
        a(new Slot(tileentitycentrifugeextractor, 7, 152, 60));
        for (int i = 0; i < 3; i++)
        {
            for (int k = 0; k < 9; k++)
            {
                a(new Slot(playerinventory, k + i * 9 + 9, 8 + k * 18, 84 + i * 18));
            }
        }

        for (int j = 0; j < 9; j++)
        {
            a(new Slot(playerinventory, j, 8 + j * 18, 142));
        }
    }

    public ItemStack a(int i)
    {
        ItemStack itemstack = null;
        Slot slot = (Slot)e.get(i);
        if (slot != null && slot.c())
        {
            ItemStack itemstack1 = slot.getItem();
            itemstack = itemstack1.cloneItemStack();
            if (i < 2)
            {
                a(itemstack1, 2, 38, false);
            }
            else if (i >= 2 && i < 29)
            {
                a(itemstack1, 0, 1, false);
            }
            else if (i >= 29 && i < 38)
            {
                a(itemstack1, 2, 29, false);
            }
            if (itemstack1.count == 0)
            {
                slot.c((ItemStack)null);
            }
            else
            {
                slot.d();
            }
            if (itemstack1.count == itemstack.count)
            {
                return null;
            }
            slot.c(itemstack1);
        }
        return itemstack;
    }

    public void a()
    {
        super.a();
        for (int i = 0; i < listeners.size(); i++)
        {
            ICrafting icrafting = (ICrafting)listeners.get(i);
            if (progress != tileentity.progress)
            {
                icrafting.a(this, 0, tileentity.progress);
            }
            if (energy != tileentity.energy)
            {
                icrafting.a(this, 1, tileentity.energy & 0xffff);
                icrafting.a(this, 2, tileentity.energy >>> 16);
            }
            if (speed != tileentity.speed)
            {
                icrafting.a(this, 3, tileentity.speed);
            }
        }

        progress = tileentity.progress;
        energy = tileentity.energy;
        speed = tileentity.speed;
    }

    public void updateProgressBar(int i, int j)
    {
        switch (i)
        {
            case 0:
                tileentity.progress = (short)j;
                break;

            case 1:
                tileentity.energy = tileentity.energy & 0xffff0000 | j;
                break;

            case 2:
                tileentity.energy = tileentity.energy & 0xffff | j << 16;
                break;

            case 3:
                tileentity.speed = (short)j;
                break;
        }
    }

    public boolean b(EntityHuman entityhuman)
    {
        return tileentity.a(entityhuman);
    }

    public int guiInventorySize()
    {
        return 8;
    }

    public int getInput()
    {
        return 0;
    }
}
