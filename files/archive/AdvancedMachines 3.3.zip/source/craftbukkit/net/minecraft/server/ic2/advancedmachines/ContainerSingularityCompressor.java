package net.minecraft.server.ic2.advancedmachines;

import java.util.List;
import net.minecraft.server.*;

public class ContainerSingularityCompressor extends Container
{
    public TileEntitySingularityCompressor tileentity;
    public int progress;
    public int energy;
    public int PSI;

    public ContainerSingularityCompressor(PlayerInventory playerinventory, TileEntitySingularityCompressor tileentitysingularitycompressor)
    {
        progress = 0;
        energy = 0;
        PSI = 0;
        tileentity = tileentitysingularitycompressor;
        a(new Slot(tileentitysingularitycompressor, 0, 56, 17));
        a(new Slot(tileentitysingularitycompressor, 1, 56, 53));
        a(new SlotResult2(playerinventory.d, tileentitysingularitycompressor, 2, 115, 35));
        a(new Slot(tileentitysingularitycompressor, 3, 152, 6));
        a(new Slot(tileentitysingularitycompressor, 4, 152, 24));
        a(new Slot(tileentitysingularitycompressor, 5, 152, 42));
        a(new Slot(tileentitysingularitycompressor, 6, 152, 60));
        for (int i = 0; i < 3; i++)
        {
            for (int k = 0; k < 9; k++)
            {
                a(new Slot(playerinventory, k + i * 9 + 9, 8 + k * 18, 84 + i * 18));
            }
        }

        for (int j = 0; j < 9; j++)
        {
            a(new Slot(playerinventory, j, 8 + j * 18, 142));
        }
    }

    public void a()
    {
        super.a();
        for (int i = 0; i < listeners.size(); i++)
        {
            ICrafting icrafting = (ICrafting)listeners.get(i);
            if (progress != tileentity.progress)
            {
                icrafting.a(this, 0, tileentity.progress);
            }
            if (energy != tileentity.energy)
            {
                icrafting.a(this, 1, tileentity.energy & 0xffff);
                icrafting.a(this, 2, tileentity.energy >>> 16);
            }
            if (PSI != tileentity.speed)
            {
                icrafting.a(this, 3, tileentity.speed);
            }
        }

        progress = tileentity.progress;
        energy = tileentity.energy;
        PSI = tileentity.speed;
    }

    public ItemStack a(int i)
    {
        ItemStack itemstack = null;
        Slot slot = (Slot)e.get(i);
        if (slot != null && slot.c())
        {
            ItemStack itemstack1 = slot.getItem();
            itemstack = itemstack1.cloneItemStack();
            if (i < 2)
            {
                a(itemstack1, 2, 38, false);
            }
            else if (i >= 2 && i < 29)
            {
                a(itemstack1, 0, 1, false);
            }
            else if (i >= 29 && i < 38)
            {
                a(itemstack1, 2, 29, false);
            }
            if (itemstack1.count == 0)
            {
                slot.c((ItemStack)null);
            }
            else
            {
                slot.d();
            }
            if (itemstack1.count == itemstack.count)
            {
                return null;
            }
            slot.c(itemstack1);
        }
        return itemstack;
    }

    public void updateProgressBar(int i, int j)
    {
        switch (i)
        {
            case 0:
                tileentity.progress = (short)j;
                break;

            case 1:
                tileentity.energy = tileentity.energy & 0xffff0000 | j;
                break;

            case 2:
                tileentity.energy = tileentity.energy & 0xffff | j << 16;
                break;

            case 3:
                tileentity.speed = (short)j;
                break;
        }
    }

    public boolean b(EntityHuman entityhuman)
    {
        return tileentity.a(entityhuman);
    }

    public int guiInventorySize()
    {
        return 7;
    }

    public int getInput()
    {
        return 0;
    }
}
