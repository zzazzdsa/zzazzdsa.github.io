package net.minecraft.server.ic2.advancedmachines;

import net.minecraft.server.*;
import forge.ITextureProvider;
import ic2.api.Items;
import java.util.*;

public class BlockAdvancedMachines extends BlockContainer
    implements ITextureProvider
{
    public int sprites[][] =
    {
        {
            86, 20, 86, 19, 86, 21, 86, 19
        }, {
            86, 26, 86, 27, 86, 26, 86, 28
        }, {
            86, 86, 24, 22, 86, 86, 25, 23
        }
    };

    public BlockAdvancedMachines(int i)
    {
        super(i, Material.ORE);
        c(2.0F);
        a(i);
        textureId = sprites[0][0];
    }

    public int getBlockTexture(IBlockAccess iblockaccess, int i, int j, int k, int l)
    {
        int i1 = iblockaccess.getData(i, j, k);
        byte byte0 = 0;
        if (isActive(iblockaccess, i, j, k))
        {
            byte0 = 4;
        }
        return l >= 2 ? l == getFacing(iblockaccess, i, j, k) ? sprites[i1][3 + byte0] : sprites[i1][2 + byte0] : sprites[i1][l + byte0];
    }

    public int a(int i, int j)
    {
        return j < sprites.length ? i >= 2 ? i != 3 ? sprites[j][2] : sprites[j][3] : sprites[j][i] : 0;
    }

    public TileEntity a_()
    {
        return null;
    }

    public void onPlace(World world, int i, int j, int k)
    {
        TileEntityAdvancedMachine tileentityadvancedmachine = getBlockEntity(world.getData(i, j, k));
        world.setTileEntity(i, j, k, tileentityadvancedmachine);
    }

    public ArrayList getBlockDropped(World world, int i, int j, int k, int l, int i1)
    {
        ArrayList arraylist = super.getBlockDropped(world, i, j, k, l, i1);
        TileEntity tileentity = world.getTileEntity(i, j, k);
        if (tileentity instanceof IInventory)
        {
            IInventory iinventory = (IInventory)tileentity;
            for (int j1 = 0; j1 < iinventory.getSize(); j1++)
            {
                ItemStack itemstack = iinventory.getItem(j1);
                if (itemstack != null)
                {
                    arraylist.add(itemstack);
                    iinventory.setItem(j1, (ItemStack)null);
                }
            }
        }
        return arraylist;
    }

    public void remove(World world, int i, int j, int k)
    {
        boolean flag = true;
        for (Iterator iterator = getBlockDropped(world, i, j, k, world.getData(i, j, k), 0).iterator(); iterator.hasNext();)
        {
            ItemStack itemstack = (ItemStack)iterator.next();
            if (!flag)
            {
                if (itemstack == null)
                {
                    return;
                }
                else
                {
                    double d = 0.69999999999999996D;
                    double d1 = (double)world.random.nextFloat() * d + (1.0D - d) * 0.5D;
                    double d2 = (double)world.random.nextFloat() * d + (1.0D - d) * 0.5D;
                    double d3 = (double)world.random.nextFloat() * d + (1.0D - d) * 0.5D;
                    EntityItem entityitem = new EntityItem(world, (double)i + d1, (double)j + d2, (double)k + d3, itemstack);
                    entityitem.pickupDelay = 10;
                    world.addEntity(entityitem);
                    return;
                }
            }
            flag = false;
        }
    }

    public int getDropType(int i, Random random, int j)
    {
        return Items.getItem("advancedMachine").id;
    }

    protected int getDropData(int i)
    {
        return 12;
    }

    public String getTextureFile()
    {
        return "/ic2/sprites/block_0.png";
    }

    public Integer getGui(World world, int i, int j, int k, EntityHuman entityhuman)
    {
        switch (world.getData(i, j, k))
        {
            case 0:
                return Integer.valueOf(mod_IC2AdvancedMachines.guiIdRotary);

            case 1:
                return Integer.valueOf(mod_IC2AdvancedMachines.guiIdSingularity);

            case 2:
                return Integer.valueOf(mod_IC2AdvancedMachines.guiIdCentrifuge);
        }
        return null;
    }

    public TileEntityAdvancedMachine getBlockEntity(int i)
    {
        switch (i)
        {
            case 0:
                return new TileEntityRotaryMacerator();

            case 1:
                return new TileEntitySingularityCompressor();

            case 2:
                return new TileEntityCentrifugeExtractor();
        }
        return null;
    }

    public void postPlace(World world, int i, int j, int k, EntityLiving entityliving)
    {
        int l = MathHelper.floor((double)((entityliving.yaw * 4F) / 360F) + 0.5D) & 3;
        TileEntityAdvancedMachine tileentityadvancedmachine = (TileEntityAdvancedMachine)world.getTileEntity(i, j, k);
        switch (l)
        {
            case 0:
                tileentityadvancedmachine.setFacing((short)2);
                break;

            case 1:
                tileentityadvancedmachine.setFacing((short)5);
                break;

            case 2:
                tileentityadvancedmachine.setFacing((short)3);
                break;

            case 3:
                tileentityadvancedmachine.setFacing((short)4);
                break;
        }
    }

    public boolean interact(World world, int i, int j, int k, EntityHuman entityhuman)
    {
        if (entityhuman.isSneaking())
        {
            return false;
        }
        Integer integer = getGui(world, i, j, k, entityhuman);
        if (integer == null)
        {
            return false;
        }
        else
        {
            mod_IC2AdvancedMachines.showGui((EntityPlayer) entityhuman, integer.intValue(), world.getTileEntity(i, j, k));
            return true;
        }
    }

    public static boolean isActive(IBlockAccess iblockaccess, int i, int j, int k)
    {
        return ((TileEntityAdvancedMachine)iblockaccess.getTileEntity(i, j, k)).getActive();
    }

    public static int getFacing(IBlockAccess iblockaccess, int i, int j, int k)
    {
        return ((TileEntityAdvancedMachine)iblockaccess.getTileEntity(i, j, k)).getFacing();
    }

    public static float getWrenchRate(IBlockAccess iblockaccess, int i, int j, int k)
    {
        return ((TileEntityAdvancedMachine)iblockaccess.getTileEntity(i, j, k)).getWrenchDropRate();
    }

    public void randomDisplayTick(World world, int i, int j, int k, Random random)
    {
        int l = world.getData(i, j, k);
        if (l == 0 && isActive(world, i, j, k))
        {
            float f = (float)i + 1.0F;
            float f1 = (float)j + 1.0F;
            float f2 = (float)k + 1.0F;
            for (int i1 = 0; i1 < 4; i1++)
            {
                float f3 = -0.2F - random.nextFloat() * 0.6F;
                float f4 = -0.1F + random.nextFloat() * 0.2F;
                float f5 = -0.2F - random.nextFloat() * 0.6F;
                world.a("smoke", f + f3, f1 + f4, f2 + f5, 0.0D, 0.0D, 0.0D);
            }
        }
    }
}
