package net.minecraft.server.ic2.advancedmachines;

import ic2.api.IWrenchable;
import net.minecraft.server.*;

public class TileEntityBlock extends TileEntity
    implements IWrenchable
{
    protected boolean created;
    private boolean active;
    private short facing;
    public boolean prevActive;
    public short prevFacing;

    public TileEntityBlock()
    {
        created = false;
        active = false;
        facing = 0;
        prevActive = false;
        prevFacing = 0;
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
        prevFacing = facing = nbttagcompound.getShort("facing");
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
        nbttagcompound.setShort("facing", facing);
    }

    public void l_()
    {
        if (!created)
        {
            created = true;
        }
    }

    public boolean getActive()
    {
        return active;
    }

    public void setActiveWithoutNotify(boolean flag)
    {
        active = flag;
        prevActive = flag;
    }

    public short getFacing()
    {
        return facing;
    }

    public boolean wrenchCanSetFacing(EntityHuman entityhuman, int i)
    {
        return false;
    }

    public void setFacing(short word0)
    {
        facing = word0;
        prevFacing = word0;
    }

    public boolean wrenchCanRemove(EntityHuman entityhuman)
    {
        return true;
    }

    public float getWrenchDropRate()
    {
        return 1.0F;
    }
}
