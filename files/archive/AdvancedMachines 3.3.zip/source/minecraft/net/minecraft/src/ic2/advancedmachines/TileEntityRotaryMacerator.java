package net.minecraft.src.ic2.advancedmachines;

import java.util.*;
import net.minecraft.src.*;
import net.minecraft.src.forge.*;
import net.minecraft.src.ic2.api.*;

public class TileEntityRotaryMacerator extends TileEntityAdvancedMachine implements IInventory
{
    public TileEntityRotaryMacerator()
    {
        super("Rotary Macerator", "%5d RPM", 1, new int[] {0}, new int[] {2, 3});
    }

    public Container getGuiContainer(InventoryPlayer var1)
    {
        return new ContainerRotaryMacerator(var1, this);
    }

    protected List getResultMap()
    {
        return Ic2Recipes.getMaceratorRecipes();
    }

    public ItemStack getResultFor(ItemStack var1, boolean var2)
    {
        return Ic2Recipes.getMaceratorOutputFor(var1, var2);
    }
    
    public String getStartSoundFile()
    {
    	return "Machines/MaceratorOp.ogg";
    }

    public String getInterruptSoundFile()
    {
    	return "Machines/InterruptOne.ogg";
    }
}
