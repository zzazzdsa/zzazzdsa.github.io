package net.minecraft.src;

import java.util.*;
import net.minecraft.src.*;
import net.minecraft.src.forge.*;
import net.minecraft.src.ic2.advancedmachines.*;
import net.minecraft.src.ic2.api.*;

import java.io.File;


public class mod_IC2AdvancedMachines extends BaseModMp
{
    public static Configuration config;
    public static Block blockAdvancedMachine;

    public static int guiIdRotary;
    public static int guiIdSingularity;
    public static int guiIdCentrifuge;

    public String getVersion()
    {
        return "v3.3";
    }

    public static int getConfigInt(String var0, int var1)
    {
        if (config == null)
        {
            return var1;
        }
        else
        {
            try
            {
                return Integer.valueOf(config.getOrCreateIntProperty(var0, 0, var1).value).intValue();
            }
            catch (Exception var3)
            {
                System.out.println("[Advanced Machines] Error while trying to access config, wasn\'t loaded properly!");
                return var1;
            }
        }
    }
    
    public static void showGui(EntityPlayer player, int guiID, TileEntity tileEnt)
    {
    	ModLoader.OpenGUI(player, guiID, player.inventory, ((TileEntityAdvancedMachine)tileEnt).getGuiContainer(player.inventory));
    }

    public void load()
    {
    	
    }
    
    public void ModsLoaded()
    {
        try
        {
            config = new Configuration(new File((new File(".")).getPath(), "/config/IC2AdvancedMachine.cfg"));
            config.load();
        }
        catch (Exception var2)
        {
            System.out.println("[Advanced Machines] Error while trying to access configuration!");
            config = null;
        }

        blockAdvancedMachine = new BlockAdvancedMachines(getConfigInt("blockAdvancedMachine", 188));

        guiIdRotary = getConfigInt("guiIdRotary", 40);
        guiIdSingularity = getConfigInt("guiIdSingularity", 41);
        guiIdCentrifuge = getConfigInt("guiIdCentrifuge", 42);

        if (config != null)
        {
            config.save();
        }

        ModLoader.RegisterBlock(blockAdvancedMachine, ItemAdvancedMachine.class);

        Ic2Recipes.addCraftingRecipe(new ItemStack(blockAdvancedMachine, 1, 0),
        		new Object[] {"RRR", "RMR", "RAR",
        	Character.valueOf('R'), Items.getItem("refinedIronIngot"),
        	Character.valueOf('M'), Items.getItem("macerator"),
        	Character.valueOf('A'), Items.getItem("advancedMachine")});
        
        Ic2Recipes.addCraftingRecipe(new ItemStack(blockAdvancedMachine, 1, 1),
        		new Object[] {"RRR", "RMR", "RAR",
        	Character.valueOf('R'), Block.obsidian,
        	Character.valueOf('M'), Items.getItem("compressor"),
        	Character.valueOf('A'), Items.getItem("advancedMachine")});
        
        Ic2Recipes.addCraftingRecipe(new ItemStack(blockAdvancedMachine, 1, 2),
        		new Object[] {"RRR", "RMR", "RAR",
        	Character.valueOf('R'), Items.getItem("electrolyzedWaterCell"),
        	Character.valueOf('M'), Items.getItem("extractor"),
        	Character.valueOf('A'), Items.getItem("advancedMachine")});

        ModLoader.RegisterTileEntity(TileEntityRotaryMacerator.class, "Rotary Macerator");
        ModLoader.RegisterTileEntity(TileEntitySingularityCompressor.class, "Singularity Compressor");
        ModLoader.RegisterTileEntity(TileEntityCentrifugeExtractor.class, "Centrifuge Extractor");
    }
}
