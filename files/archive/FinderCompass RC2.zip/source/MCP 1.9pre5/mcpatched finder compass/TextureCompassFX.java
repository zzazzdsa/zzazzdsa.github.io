package net.minecraft.src;

import com.pclewis.mcpatcher.mod.TextureUtils;
import com.pclewis.mcpatcher.mod.TileSize;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.client.Minecraft;
import net.minecraft.src.ChunkCoordinates;
import net.minecraft.src.Item;
import net.minecraft.src.TextureFX;

public class TextureCompassFX extends TextureFX {

   private Minecraft mc;
   private int[] compassIconImageData;
   private double[] textureId = new double[10];
   private double[] tileSize = new double[10];
   private int[] spawnNeedlecolor = new int[]{255, 20, 20};
   private static Map customNeedles = new HashMap();
   private static Map customNeedleTargets = new HashMap();
   private static boolean areSettingsLoaded = false;
   static File settingsFile;
   final double HEADING_DOWN = 0.0D;
   final double HEADING_UP = 135.0D;
   private int x;
   private int y;
   private int z;
   private ChunkCoordinates NullChunk = new ChunkCoordinates(0, 0, 0);
   private long lastTime;
   private int seccounter = 0;
   private boolean updateScan = false;


   public TextureCompassFX(Minecraft var1) {
      super(Item.compass.getIconFromDamage(0));
      this.compassIconImageData = new int[TileSize.int_numPixels];
      this.mc = var1;
      this.tileImage = 1;

      try {
         BufferedImage var2 = TextureUtils.getResourceAsBufferedImage("/gui/items.png");
         int var3 = this.iconIndex % 16 * TileSize.int_size;
         int var4 = this.iconIndex / 16 * TileSize.int_size;
         var2.getRGB(var3, var4, TileSize.int_size, TileSize.int_size, this.compassIconImageData, 0, TileSize.int_size);
      } catch (IOException var5) {
         var5.printStackTrace();
      }

   }

   public void onTick() {
      int var3;
      int var5;
      for(int var1 = 0; var1 < TileSize.int_numPixels; ++var1) {
         int var2 = this.compassIconImageData[var1] >> 24 & 255;
         var3 = this.compassIconImageData[var1] >> 16 & 255;
         int var4 = this.compassIconImageData[var1] >> 8 & 255;
         var5 = this.compassIconImageData[var1] >> 0 & 255;
         if(this.anaglyphEnabled) {
            int var6 = (var3 * 30 + var4 * 59 + var5 * 11) / 100;
            int var7 = (var3 * 30 + var4 * 70) / 100;
            int var8 = (var3 * 30 + var5 * 70) / 100;
            var3 = var6;
            var4 = var7;
            var5 = var8;
         }

         this.imageData[var1 * 4 + 0] = (byte)var3;
         this.imageData[var1 * 4 + 1] = (byte)var4;
         this.imageData[var1 * 4 + 2] = (byte)var5;
         this.imageData[var1 * 4 + 3] = (byte)var2;
      }

      if(this.mc.theWorld != null && this.mc.thePlayer != null) {
         if(!areSettingsLoaded) {
            this.lastTime = System.currentTimeMillis();
            this.initializeSettingsFile();
         }

         boolean var9 = false;
         boolean var10 = false;
         if(System.currentTimeMillis() > this.lastTime + 1000L) {
            var9 = true;
            ++this.seccounter;
            this.lastTime = System.currentTimeMillis();
         }

         this.drawNeedle(0, this.computeNeedleHeading(this.mc.theWorld.getSpawnPoint()), this.spawnNeedlecolor, true);
         if((int)this.mc.thePlayer.posX != this.x || (int)this.mc.thePlayer.posY != this.y || (int)this.mc.thePlayer.posZ != this.z) {
            this.x = (int)this.mc.thePlayer.posX;
            this.y = (int)this.mc.thePlayer.posY;
            this.z = (int)this.mc.thePlayer.posZ;
            this.updateScan = true;
         }

         if(this.updateScan && var9 && this.seccounter > 14) {
            this.seccounter = 0;
            var10 = true;
         }

         int[] var14;
         ChunkCoordinates var16;
         if(this.updateScan && var9) {
            this.updateScan = false;
            Iterator var11 = customNeedles.entrySet().iterator();

            while(var11.hasNext()) {
               Entry var13 = (Entry)var11.next();
               var5 = ((Integer)var13.getKey()).intValue();
               var14 = (int[])((int[])var13.getValue());
               if(var10 || var14[7] == 0) {
                  var16 = this.findNearestBlockChunkOfIDInRange(var5, this.x, this.y, this.z, var14[3], var14[4], var14[5], var14[6]);
                  if(!var16.equals(this.NullChunk)) {
                     if(customNeedleTargets.containsKey(var14)) {
                        customNeedleTargets.remove(var14);
                     }

                     customNeedleTargets.put(var14, var16);
                  } else {
                     customNeedleTargets.remove(var14);
                  }
               }
            }
         }

         var3 = 2;
         Iterator var12 = customNeedleTargets.entrySet().iterator();

         while(var12.hasNext()) {
            Entry var15 = (Entry)var12.next();
            var14 = (int[])((int[])var15.getKey());
            var16 = (ChunkCoordinates)var15.getValue();
            ++var3;
            this.drawNeedle(var3, this.computeNeedleHeading(var16), var14, false);
         }
      }

   }

   public double computeNeedleHeading(ChunkCoordinates var1) {
      double var2 = 0.0D;
      if(this.mc.theWorld != null && this.mc.thePlayer != null) {
         double var4 = (double)var1.posX - this.mc.thePlayer.posX;
         double var6 = (double)var1.posZ - this.mc.thePlayer.posZ;
         var2 = (double)(this.mc.thePlayer.rotationYaw - 90.0F) * 3.141592653589793D / 180.0D - Math.atan2(var6, var4);
         if(this.mc.theWorld.worldProvider.isNether) {
            var2 = Math.random() * 3.1415927410125732D * 2.0D;
         }
      }

      return var2;
   }

   public void drawNeedle(int var1, double var2, int[] var4, boolean var5) {
      double var6;
      for(var6 = var2 - this.textureId[var1]; var6 < -3.141592653589793D; var6 += 6.283185307179586D) {
         ;
      }

      while(var6 >= 3.141592653589793D) {
         var6 -= 6.283185307179586D;
      }

      if(var6 < -1.0D) {
         var6 = -1.0D;
      }

      if(var6 > 1.0D) {
         var6 = 1.0D;
      }

      this.textureId[var1] += var6 * 0.1D;
      this.tileSize[var1] *= 0.8D;
      this.tileSize[var1] += this.textureId[var1];
      double var8 = Math.sin(this.textureId[var1]);
      double var10 = Math.cos(this.textureId[var1]);
      int var12;
      int var13;
      int var14;
      int var15;
      int var17;
      int var16;
      short var19;
      int var18;
      int var21;
      int var20;
      int var22;
      if(var5) {
         for(var12 = TileSize.int_compassCrossMin; var12 <= TileSize.int_compassCrossMax; ++var12) {
            var13 = (int)(TileSize.double_compassCenterMax + var10 * (double)var12 * 0.3D);
            var14 = (int)(TileSize.double_compassCenterMin - var8 * (double)var12 * 0.3D * 0.5D);
            var15 = var14 * TileSize.int_size + var13;
            var16 = 100;
            var17 = 100;
            var18 = 100;
            var19 = 255;
            if(this.anaglyphEnabled) {
               var20 = (var16 * 30 + var17 * 59 + var18 * 11) / 100;
               var21 = (var16 * 30 + var17 * 70) / 100;
               var22 = (var16 * 30 + var18 * 70) / 100;
               var16 = var20;
               var17 = var21;
               var18 = var22;
            }

            this.imageData[var15 * 4 + 0] = (byte)var16;
            this.imageData[var15 * 4 + 1] = (byte)var17;
            this.imageData[var15 * 4 + 2] = (byte)var18;
            this.imageData[var15 * 4 + 3] = (byte)var19;
         }
      }

      for(var12 = TileSize.int_compassNeedleMin; var12 <= TileSize.int_compassNeedleMax; ++var12) {
         var13 = (int)(TileSize.double_compassCenterMax + var8 * (double)var12 * 0.3D);
         var14 = (int)(TileSize.double_compassCenterMin + var10 * (double)var12 * 0.3D * 0.5D);
         var15 = var14 * TileSize.int_size + var13;
         var16 = var12 < 0?100:var4[0];
         var17 = var12 < 0?100:var4[1];
         var18 = var12 < 0?100:var4[2];
         var19 = 255;
         if(this.anaglyphEnabled) {
            var20 = (var16 * 30 + var17 * 59 + var18 * 11) / 100;
            var21 = (var16 * 30 + var17 * 70) / 100;
            var22 = (var16 * 30 + var18 * 70) / 100;
            var16 = var20;
            var17 = var21;
            var18 = var22;
         }

         this.imageData[var15 * 4 + 0] = (byte)var16;
         this.imageData[var15 * 4 + 1] = (byte)var17;
         this.imageData[var15 * 4 + 2] = (byte)var18;
         this.imageData[var15 * 4 + 3] = (byte)var19;
      }

   }

   void initializeSettingsFile() {
      settingsFile = new File(Minecraft.getAppDir("minecraft"), "findercompass.cfg");
      System.out.println("initializeSettingsFile() running");

      try {
         if(settingsFile.exists()) {
            System.out.println(".minecraft/findercompass.cfg found and opened");
            BufferedReader var1 = new BufferedReader(new FileReader(settingsFile));

            String var2;
            while((var2 = var1.readLine()) != null) {
               if(!var2.startsWith("//")) {
                  String[] var3 = var2.split(":");
                  int var4 = Integer.parseInt(var3[0]);
                  int[] var5 = new int[8];
                  var5[0] = Integer.parseInt(var3[1]);
                  var5[1] = Integer.parseInt(var3[2]);
                  var5[2] = Integer.parseInt(var3[3]);
                  System.out.println("Finder Compass: loaded custom needle of id " + var4 + ", color [" + var5[0] + "," + var5[1] + "," + var5[2]);
                  var5[3] = Integer.parseInt(var3[4]);
                  var5[4] = Integer.parseInt(var3[5]);
                  var5[5] = Integer.parseInt(var3[6]);
                  var5[6] = Integer.parseInt(var3[7]);
                  var5[7] = Integer.parseInt(var3[8]);
                  System.out.println("Full readout: " + var5[0] + ":" + var5[1] + ":" + var5[2] + ":" + var5[3] + ":" + var5[4] + ":" + var5[5] + ":" + var5[6] + ":" + var5[7]);
                  customNeedles.put(Integer.valueOf(var4), var5);
               }
            }

            var1.close();
         } else {
            this.mc.ingameGUI.addChatMessage(".minecraft/findercompass.cfg not found, Finder Compass NOT ACTIVE");
         }
      } catch (Exception var6) {
         System.out.println("EXCEPTION BufferedReader");
      }

      this.mc.ingameGUI.addChatMessage("Finder Compass config loaded; " + customNeedles.size() + " custom needles loaded");
      System.out.println("config file reading finished");
      areSettingsLoaded = true;
   }

   ChunkCoordinates findNearestBlockChunkOfIDInRange(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      List var9 = this.findBlocksOfIDInRange(var1, var2, var3, var4, var5, var6, var7, var8);
      ChunkCoordinates var10 = new ChunkCoordinates(var2, var3, var4);
      ChunkCoordinates var11 = new ChunkCoordinates(0, 0, 0);
      double var12 = 9999.0D;

      for(int var14 = 0; var14 < var9.size(); ++var14) {
         ChunkCoordinates var15 = (ChunkCoordinates)var9.get(var14);
         double var16 = this.GetDistanceBetweenChunks(var10, var15);
         if(var16 < var12) {
            var11 = var15;
            var12 = var16;
         }
      }

      ChunkCoordinates var18 = new ChunkCoordinates(var11.posX, var11.posY, var11.posZ);
      return var18;
   }

   List findBlocksOfIDInRange(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      ArrayList var9 = new ArrayList();

      for(int var10 = var3 - var6 - 1; var10 <= var3 + var6; ++var10) {
         if(var10 >= var7 && var10 <= var8) {
            for(int var11 = var4 - var5; var11 <= var4 + var5; ++var11) {
               for(int var12 = var2 - var5; var12 <= var2 + var5; ++var12) {
                  if(this.mc.theWorld.getBlockId(var12, var10, var11) == var1) {
                     ChunkCoordinates var13 = new ChunkCoordinates(var12, var10, var11);
                     var9.add(var13);
                  }
               }
            }
         }
      }

      return var9;
   }

   double GetDistanceBetweenChunks(ChunkCoordinates var1, ChunkCoordinates var2) {
      int var3 = Math.abs(var1.posX - var2.posX);
      int var4 = Math.abs(var1.posY - var2.posY);
      int var5 = Math.abs(var1.posZ - var2.posZ);
      return Math.sqrt(Math.pow((double)var3, 2.0D) + Math.pow((double)var4, 2.0D) + Math.pow((double)var5, 2.0D));
   }

}
