import com.pclewis.mcpatcher.mod.TextureUtils;
import com.pclewis.mcpatcher.mod.TileSize;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.client.Minecraft;

public class sc extends sb {

  private Minecraft a;
  private int[] b;
  private double[] i = new double[10];
  private double[] j = new double[10];

  private int[] spawnNeedlecolor = { 255, 20, 20 };
  /*
  private int[] spawnerNeedlecolor = { 26, 255, 26 };
  private int[] diamondNeedlecolor = { 51, 255, 204 };
  */
  
  private static Map<Integer, int[]> customNeedles = new HashMap();
  private static Map<int[], sn> customNeedleTargets = new HashMap();
  private static boolean areSettingsLoaded = false;
  static File settingsFile;
  final double HEADING_DOWN = 0.0D;
  final double HEADING_UP = 135.0D;
  private int x;
  private int y;
  private int z;
  
  private sn NullChunk = new sn(0, 0, 0);
  /*
  private sn DiamondOre = new sn(0, 0, 0);
  private sn MobSpawner = new sn(0, 0, 0);

  static int scanrangediamond = 7;
  static int scanrangespawners = scanrangediamond * 4;
  */
  
  private long lastTime;
  private int seccounter = 0;
  private boolean updateScan = false;

   public sc(Minecraft var1)
   {
      super(wc.aQ.b(0));
      this.b = new int[TileSize.int_numPixels];
      this.a = var1;
      this.k = 1;

      try {
         BufferedImage var2 = TextureUtils.getResourceAsBufferedImage("/gui/items.png");
         int var3 = this.g % 16 * TileSize.int_size;
         int var4 = this.g / 16 * TileSize.int_size;
         var2.getRGB(var3, var4, TileSize.int_size, TileSize.int_size, this.b, 0, TileSize.int_size);
      } catch (IOException var5) {
         var5.printStackTrace();
      }
   }

   public void a()
   {
      for(int var1 = 0; var1 < TileSize.int_numPixels; ++var1) {
         int var2 = this.b[var1] >> 24 & 255;
         int var3 = this.b[var1] >> 16 & 255;
         int var4 = this.b[var1] >> 8 & 255;
         int var5 = this.b[var1] >> 0 & 255;
         if(this.h) {
            int var6 = (var3 * 30 + var4 * 59 + var5 * 11) / 100;
            int var7 = (var3 * 30 + var4 * 70) / 100;
            int var8 = (var3 * 30 + var5 * 70) / 100;
            var3 = var6;
            var4 = var7;
            var5 = var8;
         }

         this.f[var1 * 4 + 0] = (byte)var3;
         this.f[var1 * 4 + 1] = (byte)var4;
         this.f[var1 * 4 + 2] = (byte)var5;
         this.f[var1 * 4 + 3] = (byte)var2;
      }

      if(this.a.f != null && this.a.h != null)
	  {
	    if (!areSettingsLoaded)
		{
			lastTime = System.currentTimeMillis();
			initializeSettingsFile();
		}
		
		boolean newsecond = false;
		boolean fifteensecinterval = false;
		if (System.currentTimeMillis() > lastTime + 1000L)
		{
			newsecond = true;
			seccounter++;
			//System.out.println("FinderCompass: new second, counter: "+seccounter);
			lastTime = System.currentTimeMillis();
		}
		
		drawNeedle(0, computeNeedleHeading(this.a.f.v()), this.spawnNeedlecolor, true);
		
		if (((int)this.a.h.o != this.x) || ((int)this.a.h.p != this.y) || ((int)this.a.h.q != this.z))
		{
			this.x = (int)this.a.h.o;
			this.y = (int)this.a.h.p;
			this.z = (int)this.a.h.q;
			
			//System.out.println("FinderCompass: pos changed, now ["+this.x+"|"+this.y+"|"+this.z+"]");
			
			updateScan = true;
		}
		
		/*
		if (updateScan && newsecond)
		{
			// DIAMOND ORE BLOCK ID = 56
			this.DiamondOre = findNearestBlockChunkOfIDInRange(56, this.x, this.y, this.z, scanrangediamond, 1);
		}
		  
		if (!this.DiamondOre.equals(this.NullChunk)) {
			drawNeedle(1, computeNeedleHeading(this.DiamondOre), this.diamondNeedlecolor, false);
		}
		*/
		
		if (updateScan && newsecond && seccounter > 14)
		{
			//sn currentBlock = new sn(this.x, this.y, this.z);
			
			seccounter = 0;
			fifteensecinterval = true;
			//MOB SPAWNER BLOCK ID = 52
			//this.MobSpawner = findNearestBlockChunkOfIDInRange(52, this.x, this.y, this.z, scanrangespawners, scanrangespawners);
		}

		/*
		if (!this.MobSpawner.equals(this.NullChunk))
		{
			if ((Math.abs(this.x - this.MobSpawner.a) < 2) && (Math.abs(this.z - this.MobSpawner.c) < 2))
			{
			  if (this.y > this.MobSpawner.b)
			  {
				drawNeedle(2, 0.0D, this.spawnerNeedlecolor, false);
			  }
			  else
			  {
				drawNeedle(2, 135.0D, this.spawnerNeedlecolor, false);
			  }
			}
			else
			{
			  drawNeedle(2, computeNeedleHeading(this.MobSpawner), this.spawnerNeedlecolor, false);
			}
		}
		*/

		if (updateScan && newsecond)
		{
			updateScan = false;
		
			for (Map.Entry entry : customNeedles.entrySet())
			{
			  int ID = ((Integer)entry.getKey()).intValue();
			  int[] infoarray = (int[])entry.getValue();
			  
			  if (!fifteensecinterval && infoarray[7] != 0) continue; // the fifteen sec scan boolean
			  
			  sn iC = findNearestBlockChunkOfIDInRange(ID, this.x, this.y, this.z, infoarray[3], infoarray[4], infoarray[5], infoarray[6]);

			  if (!iC.equals(this.NullChunk))
			  {
				if (customNeedleTargets.containsKey(infoarray))
				{
				  customNeedleTargets.remove(infoarray);
				}
				customNeedleTargets.put(infoarray, iC);
			  }
			  else
			  {
				customNeedleTargets.remove(infoarray);
			  }
			}
		}

		int iterator = 2;

		for (Map.Entry entry2 : customNeedleTargets.entrySet())
		{
			int[] infoarray2 = (int[])entry2.getKey();
			sn target = (sn)entry2.getValue();
			iterator++;

			drawNeedle(iterator, computeNeedleHeading(target), infoarray2, false);
		}
	  }
	}
		  
		  
	public double computeNeedleHeading(sn chunkcoordinates)
	{
		double var20 = 0.0D;
		if(this.a.f != null && this.a.h != null)
		{
			double var23 = chunkcoordinates.a - this.a.h.o;
			double var25 = chunkcoordinates.c - this.a.h.q;
			var20 = (double)(this.a.h.u - 90.0F) * 3.141592653589793D / 180.0D - Math.atan2(var25, var23);
			if(this.a.f.y.c)
			{
				var20 = Math.random() * 3.1415927410125732D * 2.0D;
			}
		}

		return var20;
	}
	
  public void drawNeedle(int needleIterator, double d, int[] infoarray, boolean drawCenter)
  {
    double d1;
    for (d1 = d - this.i[needleIterator]; d1 < -3.141592653589793D; d1 += 6.283185307179586D);
    while (d1 >= 3.141592653589793D) d1 -= 6.283185307179586D;
    if (d1 < -1.0D)
    {
      d1 = -1.0D;
    }
    if (d1 > 1.0D)
    {
      d1 = 1.0D;
    }
    this.i[needleIterator] += d1 * 0.1D;
    this.j[needleIterator] *= 0.8D;
    this.j[needleIterator] += this.i[needleIterator];
    double d3 = Math.sin(this.i[needleIterator]);
    double d5 = Math.cos(this.i[needleIterator]);

    if (drawCenter)
    {
      for (int i2 = TileSize.int_compassCrossMin; i2 <= TileSize.int_compassCrossMax; i2++)
      {
        int k2 = (int)(TileSize.double_compassCenterMax + d5 * i2 * 0.3D);
        int i3 = (int)(TileSize.double_compassCenterMin - d3 * i2 * 0.3D * 0.5D);
        int k3 = i3 * TileSize.int_size + k2;
        int i4 = 100;
        int k4 = 100;
        int i5 = 100;
        char c = '�';
        if (this.h)
        {
          int k5 = (i4 * 30 + k4 * 59 + i5 * 11) / 100;
          int i6 = (i4 * 30 + k4 * 70) / 100;
          int k6 = (i4 * 30 + i5 * 70) / 100;
          i4 = k5;
          k4 = i6;
          i5 = k6;
        }
        this.f[(k3 * 4 + 0)] = (byte)i4;
        this.f[(k3 * 4 + 1)] = (byte)k4;
        this.f[(k3 * 4 + 2)] = (byte)i5;
        this.f[(k3 * 4 + 3)] = (byte)c;
      }
    }

    for (int j2 = TileSize.int_compassNeedleMin; j2 <= TileSize.int_compassNeedleMax; j2++)
    {
      int l2 = (int)(TileSize.double_compassCenterMax + d3 * j2 * 0.3D);
      int j3 = (int)(TileSize.double_compassCenterMin + d5 * j2 * 0.3D * 0.5D);
      int l3 = j3 * TileSize.int_size + l2;
      int j4 = j2 < 0 ? 100 : infoarray[0];
      int l4 = j2 < 0 ? 100 : infoarray[1];
      int j5 = j2 < 0 ? 100 : infoarray[2];
      char c1 = '�';
      if (this.h)
      {
        int l5 = (j4 * 30 + l4 * 59 + j5 * 11) / 100;
        int j6 = (j4 * 30 + l4 * 70) / 100;
        int l6 = (j4 * 30 + j5 * 70) / 100;
        j4 = l5;
        l4 = j6;
        j5 = l6;
      }
      this.f[(l3 * 4 + 0)] = (byte)j4;
      this.f[(l3 * 4 + 1)] = (byte)l4;
      this.f[(l3 * 4 + 2)] = (byte)j5;
      this.f[(l3 * 4 + 3)] = (byte)c1;
    }
  }

  void initializeSettingsFile()
  {
    settingsFile = new File(Minecraft.a("minecraft"), "findercompass.cfg");
    System.out.println("initializeSettingsFile() running");
    try
    {
      if (settingsFile.exists())
      {
        System.out.println(".minecraft/findercompass.cfg found and opened");

        BufferedReader in = new BufferedReader(new FileReader(settingsFile));
        String sCurrentLine;
        while ((sCurrentLine = in.readLine()) != null)
        {
		  /*
          if (sCurrentLine.startsWith("SearchDistance"))
          {
            String[] distLine = sCurrentLine.split(":");
            scanrangediamond = Integer.parseInt(distLine[1]);
            scanrangespawners = scanrangediamond * 4;
			System.out.println("Search distance set to: "+scanrangediamond);
            continue;
          }
		  */
		  if (sCurrentLine.startsWith("//"))
            continue;

          String[] curLine = sCurrentLine.split(":");

          int ID = Integer.parseInt(curLine[0]);

          int[] infoarray = new int[8];
          infoarray[0] = Integer.parseInt(curLine[1]); // color R
          infoarray[1] = Integer.parseInt(curLine[2]); // color G
          infoarray[2] = Integer.parseInt(curLine[3]); // color B
		  System.out.println(new StringBuilder().append("Finder Compass: loaded custom needle of id ").append(ID).append(", color [").append(infoarray[0]).append(",").append(infoarray[1]).append(",").append(infoarray[2]).toString());
		  infoarray[3] = Integer.parseInt(curLine[4]); // scanrange -x,-z to +x,+z
		  infoarray[4] = Integer.parseInt(curLine[5]); // scanrange depth, '1' is visible blocks from a 1x2 tunnel
		  infoarray[5] = Integer.parseInt(curLine[6]); // minimum block height to scan
		  infoarray[6] = Integer.parseInt(curLine[7]); // maximum block height to scan
		  infoarray[7] = Integer.parseInt(curLine[8]); // boolean for scanning only every 15 seconds
		  System.out.println("Full readout: "+infoarray[0]+":"+infoarray[1]+":"+infoarray[2]+":"+infoarray[3]+":"+infoarray[4]+":"+infoarray[5]+":"+infoarray[6]+":"+infoarray[7]);
		
          customNeedles.put(Integer.valueOf(ID), infoarray);
          //this.a.w.a(new StringBuilder().append("Finder Compass: loaded custom needle of id ").append(ID).append(", color [").append(infoarray[0]).append(",").append(infoarray[1]).append(",").append(infoarray[2]).toString());
        }

        in.close();
      }
      else
      {
        this.a.w.a(".minecraft/findercompass.cfg not found, Finder Compass NOT ACTIVE");
      }
    }
    catch (Exception fuckdammit)
    {
      System.out.println("EXCEPTION BufferedReader");
    }
	
	this.a.w.a("Finder Compass config loaded; "+customNeedles.size()+" custom needles loaded");
	System.out.println("config file reading finished");
    areSettingsLoaded = true;
  }

  sn findNearestBlockChunkOfIDInRange(int ID, int xpos, int ypos, int zpos, int flatrange, int depthrange, int minscany, int maxscany)
  {
    List blocklist = findBlocksOfIDInRange(ID, xpos, ypos, zpos, flatrange, depthrange, minscany, maxscany);
	
	//System.out.println("Searching for ["+ID+"], found ["+blocklist.size()+"]");

    sn origin = new sn(xpos, ypos, zpos);
    sn returnblock = new sn(0, 0, 0);
    double mindistance = 9999.0D;

    for (int a = 0; a < blocklist.size(); a++)
    {
      sn loopagainst = (sn)blocklist.get(a);
      double checkdistance = GetDistanceBetweenChunks(origin, loopagainst);

      if (checkdistance >= mindistance)
        continue;
      returnblock = loopagainst;
      mindistance = checkdistance;
    }

    sn returnchunkcoords = new sn(returnblock.a, returnblock.b, returnblock.c);
    return returnchunkcoords;
  }
  
  List findBlocksOfIDInRange(int ID, int xpos, int ypos, int zpos, int flatrange, int depthrange, int minscanhy, int maxscany)
  {
    List returnList = new ArrayList();

    for (int b = ypos - depthrange - 1; b <= ypos + depthrange; b++)
    {
      if (b < minscanhy || b > maxscany)
        continue;
      for (int c = zpos - flatrange; c <= zpos + flatrange; c++)
      {
        for (int a = xpos - flatrange; a <= xpos + flatrange; a++)
        {
          if (this.a.f.a(a, b, c) != ID)
            continue;
          sn addObj = new sn(a, b, c);
          returnList.add(addObj);
        }
      }

    }

    return returnList;
  }

  double GetDistanceBetweenChunks(sn BlockA, sn BlockB)
  {
    int xDiff = Math.abs(BlockA.a - BlockB.a);
    int yDiff = Math.abs(BlockA.b - BlockB.b);
    int zDiff = Math.abs(BlockA.c - BlockB.c);

    return Math.sqrt(Math.pow(xDiff, 2.0D) + Math.pow(yDiff, 2.0D) + Math.pow(zDiff, 2.0D));
  }
}
