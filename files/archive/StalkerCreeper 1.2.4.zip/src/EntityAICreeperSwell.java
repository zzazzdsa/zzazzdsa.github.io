    // put this as additional requirement in public boolean shouldExecute()
	
	private boolean isSeenByTarget()
    {
    	EntityLiving creeper = this.swellingCreeper;
    	EntityLiving seer = this.swellingCreeper.getAttackTarget();
		
		if (creeper == null || seer == null) return true;
    	
        Vec3D visionVec = seer.getLook(1.0F).normalize();
        Vec3D targetVec = Vec3D.createVector(creeper.posX - seer.posX,
        									creeper.boundingBox.minY + (double)(creeper.height / 2.0F) - (seer.posY + (double)seer.getEyeHeight()),
        									creeper.posZ - seer.posZ);
        targetVec = targetVec.normalize();
        double dotProduct = visionVec.dotProduct(targetVec);
        
        boolean inFOV = dotProduct > 0.1 && seer.canEntityBeSeen(creeper);

        //System.out.println("dotProduct result in isSeenByTarget: "+dotProduct+"; inFOV: "+inFOV);
        
        return inFOV;
    }