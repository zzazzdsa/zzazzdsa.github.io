package net.minecraft.src.atomicstryker.infernalmobs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;

import net.minecraft.src.*;
import net.minecraft.src.atomicstryker.infernalmobs.mods.*;
import net.minecraft.src.forge.*;

public class InfernalMobsCore
{
    public static final int RARE_MOB_HEALTH_MODIFIER = 4;
    private static long lastExistCheckTime = System.currentTimeMillis();
    private static final long existCheckDelay = 5000L;
    
    public static String getVersion()
    {
        return "1.0.2";
    }
    
    public static String getNBTTag()
    {
        return "InfernalMobsMod";
    }
    
    public static String getPacketChannel()
    {
        return "InfernalMobs";
    }
    
    private static mod_InfernalMobs modinstance;
    private static HashMap<EntityLiving, MobModifier> rareMobs;
    private static ArrayList<Class> mobMods;
    
    private static int eliteRarity;
    public static Configuration config;
    
    public static void load(mod_InfernalMobs mod_InfernalMobs)
    {
        modinstance = mod_InfernalMobs;
        config = new Configuration(new File(mod_InfernalMobs.getMinecraftDir(), "config/InfernalMobs.cfg"));
        rareMobs = new HashMap();
        loadConfig();
        loadMods();
        MinecraftForge.registerEntityLivingHandler(new EntityEventHandler());
        MinecraftForge.registerSaveHandler(new SaveEventHandler());
        MinecraftForge.registerConnectionHandler(mod_InfernalMobs);
        
        System.out.println("InfernalMobsCore load() completed! Modifiers ready: "+mobMods.size());
    }
    
    public static void onTick()
    {
        if (System.currentTimeMillis() > lastExistCheckTime + existCheckDelay)
        {
            HashMap<EntityLiving, MobModifier> temp = (HashMap) rareMobs.clone();
            lastExistCheckTime = System.currentTimeMillis();
            for (Entity mob : temp.keySet())
            {
                if (!mob.worldObj.loadedEntityList.contains(mob))
                {
                    //System.out.println("Removed unloaded Entity "+mob+" with ID "+mob.entityId+" from rareMobs");
                    removeEntFromElites((EntityLiving) mob);
                }
            }
        }
    }
    
    /**
     * Registers the MobModifier classes for consideration
     */
    private static void loadMods()
    {
        mobMods = new ArrayList();
        
        mobMods.add(MM_1UP.class);
        mobMods.add(MM_Berserk.class);
        mobMods.add(MM_Blastoff.class);
        mobMods.add(MM_Bulwark.class);
        mobMods.add(MM_Darkness.class);
        mobMods.add(MM_Ender.class);
        mobMods.add(MM_Exhaust.class);
        mobMods.add(MM_Fiery.class);
        mobMods.add(MM_Ghastly.class);
        mobMods.add(MM_Gravity.class);
        mobMods.add(MM_Lifesteal.class);
        mobMods.add(MM_Ninja.class);
        mobMods.add(MM_Poisonous.class);
        mobMods.add(MM_Quicksand.class);
        mobMods.add(MM_Regen.class);
        mobMods.add(MM_Rust.class);
        mobMods.add(MM_Sprint.class);
        mobMods.add(MM_Sticky.class);
        mobMods.add(MM_Storm.class);
        mobMods.add(MM_Vengeance.class);
        mobMods.add(MM_Weakness.class);
        mobMods.add(MM_Webber.class);
    }

    /**
     * Forge Config file
     */
    private static void loadConfig()
    {
        config.load();
        eliteRarity = Integer.parseInt(config.getOrCreateIntProperty("eliteRarity", Configuration.CATEGORY_GENERAL, 15).value);
        config.save();
    }
    
    /**
     * Called when an Entity is spawned by natural (Biome Spawning) means, turn them into Elites here
     * @param entity Entity in question
     */
    public static void processEntitySpawn(EntityLiving entity)
    {
        if (!entity.worldObj.isRemote)
        {
            if (!getIsRareEntity(entity))
            {
                if (entity.worldObj.rand.nextInt(eliteRarity-1) == 0)
                {
                    MobModifier mod = createMobModifiers(entity);
                    if (mod != null)
                    {
                        getRareMobs().put(entity, mod);
                        mod.onSpawningComplete();
                        //System.out.println("InfernalMobsCore spawned Elite: "+entity+": "+mod.getModName());
                    }
                }
            }
        }
    }
    
    /**
     * Allows setting Entity Health past the hardcoded getMaxHealth() constraint
     * @param entity Entity instance whose health you want changed
     * @param amount value to set
     */
    public static void setEntityHealthPastMax(EntityLiving entity, int amount)
    {
        try
        {
            Field[] entFields = EntityLiving.class.getDeclaredFields();
            for (Field f : entFields)
            {
                f.setAccessible(true);
                Object o = f.get(entity);
                if (o != null
                && o.getClass().equals(Integer.class))
                {
                    if ((Integer)o == entity.getHealth())
                    {
                        f.set(entity, amount);
                        break;
                    }
                }
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    /**
     * Decides on what, if any, of the possible Modifications to apply to the Entity
     * @param entity Target Entity
     * @return null or the first linked MobModifier instance for the Entity
     */
    private static MobModifier createMobModifiers(EntityLiving entity)
    {
        /* 2-5 modifications */
        int number = 2 + entity.worldObj.rand.nextInt(3);
        /* lets just be lazy and scratch mods off a list copy */
        ArrayList<Class> possibleMods = (ArrayList<Class>) mobMods.clone();
        
        MobModifier lastMod = null;
        while (number > 0 && !possibleMods.isEmpty())
        {
            /* random index of mod list */
            int index = entity.worldObj.rand.nextInt(possibleMods.size());
            MobModifier nextMod = null;
            
            /* instanciate using one of the two constructors, chainlinking modifiers as we go */
            try
            {
                if (lastMod == null)
                {
                    nextMod = (MobModifier) possibleMods.get(index).getConstructor(new Class[] {EntityLiving.class}).newInstance(entity);
                }
                else
                {
                    nextMod = (MobModifier) possibleMods.get(index).getConstructor(new Class[] {EntityLiving.class, MobModifier.class}).newInstance(entity, lastMod);
                }
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
            
            boolean allowed = true;
            /* check white and black lists */
            if (nextMod.getWhiteListMobClasses() != null)
            {
                allowed = false;
                for (Class cl : nextMod.getWhiteListMobClasses())
                {
                    if (entity.getClass().isAssignableFrom(cl))
                    {
                        allowed = true;
                        break;
                    }
                }
            }
            if (nextMod.getBlackListMobClasses() != null)
            {
                for (Class cl : nextMod.getBlackListMobClasses())
                {
                    if (entity.getClass().isAssignableFrom(cl))
                    {
                        allowed = false;
                        break;
                    }
                }
            }
            if (lastMod != null)
            {
                if (lastMod.getModsNotToMixWith() != null)
                {
                    for (Class cl : lastMod.getModsNotToMixWith())
                    {
                        if (lastMod.containsModifierClass(cl))
                        {
                            allowed = false;
                            break;
                        }
                    }
                }
            }
            
            /* scratch mod off list */
            possibleMods.remove(index);
            
            if (allowed)
            {
                lastMod = nextMod;
                number--;
            }
        }
        
        return lastMod;
    }
    
    /**
     * Converts a String to MobModifier instances and connects them to an Entity
     * @param entity Target Entity
     * @param savedMods String depicting the MobModifiers, equal to the ingame Display
     */
    public static void addEntityModifiersByString(EntityLiving entity, String savedMods)
    {
        MobModifier mod = stringToMobModifiers(entity, savedMods);
        getRareMobs().put(entity, mod);
        mod.onSpawningComplete();
    }
    
    private static MobModifier stringToMobModifiers(EntityLiving entity, String buffer)
    {
        MobModifier lastMod = null;
        
        StringTokenizer st = new StringTokenizer(buffer, " ");
        while(st.hasMoreTokens())
        {
            String modName = st.nextToken();
            
            boolean found;
            MobModifier nextMod = null;
            for (int i = 0; i < mobMods.size(); i++)
            {
                /* instanciate using one of the two constructors, chainlinking modifiers as we go */
                try
                {
                    if (lastMod == null)
                    {
                        nextMod = (MobModifier) mobMods.get(i).getConstructor(new Class[] {EntityLiving.class}).newInstance(entity);
                    }
                    else
                    {
                        nextMod = (MobModifier) mobMods.get(i).getConstructor(new Class[] {EntityLiving.class, MobModifier.class}).newInstance(entity, lastMod);
                    }
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
                
                if (nextMod.modName.equals(modName))
                {
                    /* Only actually keep the new linked instance if it's what we wanted */
                    lastMod = nextMod;
                    break;
                }
            }
        }
        
        return lastMod;
    }
    
    public static MobModifier getMobModifiers(EntityLiving target)
    {
        return getRareMobs().get(target);
    }

    public static boolean getIsRareEntity(EntityLiving ent)
    {
        return getRareMobs().containsKey(ent);
    }

    public static void removeEntFromElites(EntityLiving entity)
    {
        getRareMobs().remove(entity);
    }
    
    public static HashMap<EntityLiving, MobModifier> getRareMobs()
    {
        return rareMobs;
    }

    /**
     * Used on World/Server/Savegame change to clear the Boss HashMap of old World Entities
     * @param lastWorld 
     */
    public static void checkRareListForObsoletes(World lastWorld)
    {
        ArrayList<EntityLiving> toRemove = new ArrayList<EntityLiving>();
        for (EntityLiving ent : getRareMobs().keySet())
        {
            if (ent.worldObj != lastWorld)
            {
                toRemove.add(ent);
            }
        }
        
        for (EntityLiving ent : toRemove)
        {
            getRareMobs().remove(ent);
        }
        loadConfig();
    }

    /**
     * Used by the client side to answer to a server packet carrying the Entity ID and mod string
     * @param world World the client is in, and the Entity aswell
     * @param entID unique Entity ID
     * @param mods MobModifier compliant data String from the server
     */
    public static void addRemoteEntityModifiers(World world, int entID, String mods)
    {
        //System.out.println("Client adding remote infernal mob!");
        Iterator iter = world.loadedEntityList.iterator();
        while (iter.hasNext())
        {
            Entity ent = (Entity) iter.next();
            if (ent instanceof EntityLiving && ent.entityId == entID)
            {
                addEntityModifiersByString((EntityLiving)ent, mods);
                MobModifier mod = getMobModifiers((EntityLiving) ent);
                if (mod != null)
                {
                    mod.onSpawningComplete();
                }
                //System.out.println("Client added remote infernal mob!");
                break;
            }
        }
    }

    public static void dropLootForEnt(EntityLiving mob)
    {
        int xpValue = 25;
        while (xpValue > 0)
        {
            int xpDrop = EntityXPOrb.getXPSplit(xpValue);
            xpValue -= xpDrop;
            mob.worldObj.spawnEntityInWorld(new EntityXPOrb(mob.worldObj, mob.posX, mob.posY, mob.posZ, xpDrop));
        }
        
        dropRandomEnchantedItem(mob);
    }

    private static void dropRandomEnchantedItem(EntityLiving mob)
    {
        try
        {
            Item item = getRandomItem(mob);
            ItemStack itemStack = ItemStack.class.getConstructor(new Class[] { Item.class }).newInstance(item);
            EnchantmentHelper.addRandomEnchantment(mob.worldObj.rand, itemStack, item.getItemEnchantability());
            mob.worldObj.spawnEntityInWorld(new EntityItem(mob.worldObj, mob.posX, mob.posY, mob.posZ, itemStack));
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
    
    private static Item getRandomItem(EntityLiving mob)
    {
        return viables[mob.worldObj.rand.nextInt(viables.length)];
    }
    
    private static Item[] viables =
    {
        Item.axeGold,
        Item.axeGold,
        Item.axeDiamond,
        
        Item.shovelGold,
        Item.shovelSteel,
        Item.shovelDiamond,
        
        Item.pickaxeGold,
        Item.pickaxeSteel,
        Item.pickaxeDiamond,
        
        Item.swordGold,
        Item.swordSteel,
        Item.swordDiamond,
        
        Item.bootsChain,
        Item.bootsSteel,
        Item.bootsDiamond,
        
        Item.legsChain,
        Item.legsSteel,
        Item.legsDiamond,
        
        Item.plateChain,
        Item.plateSteel,
        Item.plateDiamond,
        
        Item.helmetChain,
        Item.helmetSteel,
        Item.helmetDiamond,
        
        Item.bow
    };
}
