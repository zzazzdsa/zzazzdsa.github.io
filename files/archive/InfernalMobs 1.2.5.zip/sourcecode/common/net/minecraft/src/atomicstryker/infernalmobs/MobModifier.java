package net.minecraft.src.atomicstryker.infernalmobs;

import java.util.ArrayList;

import net.minecraft.src.DamageSource;
import net.minecraft.src.EntityItem;
import net.minecraft.src.EntityLiving;

public abstract class MobModifier
{
    protected EntityLiving mob;
    protected MobModifier nextMod = null;
    protected String modName;
    private int healthHackDelayTicker = 30;
    private long lastExistCheckTime = System.currentTimeMillis();
    private final long existCheckDelay = 5000L;

    public String getModName()
    {
        return (modName + " " + ((nextMod != null) ? nextMod.getModName() : ""));
    }
    
    public boolean containsModifierClass(Class checkfor)
    {
        if (checkfor.equals(this.getClass()))
        {
            return true;
        }
        
        if (nextMod != null)
        {
            return nextMod.containsModifierClass(checkfor);
        }
        
        return false;
    }
    
    /**
     * Called when local Spawn Processing is completed or when a client remote-attached Modifiers to a local Entity
     */
    public void onSpawningComplete()
    {
        mob.getEntityData().setString(InfernalMobsCore.getNBTTag(), getModName());
        
        /* manually add a datawatcher to network health. 18 is the number mc uses on wolves for health */
        try
        {
            mob.getDataWatcher().addObject(18, new Integer(mob.getHealth()));
        }
        catch (Exception e)
        {
            /* we catch the exceptions resulting from modifying wolves here (18 is taken) */
        }
    }
    
    public boolean onDeath()
    {
        if (nextMod != null)
        {
            return nextMod.onDeath();
        }
        
        return false;
    }
    
    public void onDropItems(DamageSource killSource, ArrayList<EntityItem> drops, int lootingLevel, boolean recentlyHit, int specialDropValue)
    {
        if (recentlyHit)
        {
            InfernalMobsCore.dropLootForEnt(mob);
        }
        
        InfernalMobsCore.removeEntFromElites(mob);
    }
    
    public void onSetAttackTarget(EntityLiving target)
    {
        if (nextMod != null)
        {
            nextMod.onSetAttackTarget(target);
        }
    }
    
    /**
     * Modified Mob attacks something
     * @param entity Entity being attacked
     * @param source DamageSource instance doing the attacking
     * @param damage unmitigated damage value
     * @return
     */
    public int onAttack(EntityLiving entity, DamageSource source, int damage)
    {
        if (nextMod != null)
        {
            return nextMod.onAttack(entity, source, damage);
        }
        
        return damage;
    }
    
    /**
     * Modified Mob is being hurt
     * @param source Damagesource doing the hurting
     * @param damage unmitigated damage value
     * @return
     */
    public int onHurt(DamageSource source, int damage)
    {
        if (nextMod != null)
        {
            return nextMod.onHurt(source, damage);
        }
        
        return damage;
    }
    
    public void onJump()
    {
        if (nextMod != null)
        {
            nextMod.onJump();
        }
    }
    
    public boolean onFall(float distance)
    {
        if (nextMod != null)
        {
            return nextMod.onFall(distance);
        }
        
        return false;
    }
    
    public boolean onUpdate()
    {
        if (nextMod != null)
        {
            return nextMod.onUpdate();
        }
        else
        {
            if (!mob.worldObj.isRemote)
            {
                mob.getDataWatcher().updateObject(18, Integer.valueOf(mob.getHealth()));
            }
            else
            {
                int networkHealth = mob.getDataWatcher().getWatchableObjectInt(18);
                if (mob.getHealth() != networkHealth)
                {
                    InfernalMobsCore.setEntityHealthPastMax(mob, networkHealth);
                }
            }
        }
        
        if (healthHackDelayTicker > 0)
        {
            healthHackDelayTicker--;
            if (healthHackDelayTicker == 0)
            {
                InfernalMobsCore.setEntityHealthPastMax(mob, mob.getMaxHealth()*InfernalMobsCore.RARE_MOB_HEALTH_MODIFIER);
            }
        }
        
        return false;
    }
    
    /**
     * @return Array of classes an EntityLiving must equal, implement or extend in order for this MobModifier to be applied to it
     */
    public Class[] getWhiteListMobClasses()
    {
        return null;
    }
    
    /**
     * @return Array of classes an EntityLiving cannot equal, implement or extend in order for this MobModifier to be applied to it
     */
    public Class[] getBlackListMobClasses()
    {
        return null;
    }
    
    /**
     * @return Array of MobModifiers a considered MobModifier should not be mixed with. Both sides need to exclude each other for this to work.
     */
    public Class[] getModsNotToMixWith()
    {
        return null;
    }
    
    @Override
    public boolean equals(Object o)
    {
        return (o instanceof MobModifier
                && ((MobModifier)o).modName.equals(modName));
    }
}
