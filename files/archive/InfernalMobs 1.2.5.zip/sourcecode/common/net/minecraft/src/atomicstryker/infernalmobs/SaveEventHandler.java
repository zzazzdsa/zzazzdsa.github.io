package net.minecraft.src.atomicstryker.infernalmobs;

import net.minecraft.src.Chunk;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.World;
import net.minecraft.src.forge.ISaveEventHandler;

public class SaveEventHandler implements ISaveEventHandler
{
    @Override
    public void onWorldLoad(World world)
    {
    }

    @Override
    public void onWorldSave(World world)
    {
    }

    @Override
    public void onChunkLoad(World world, Chunk chunk)
    {
        for (int i = 0; i < chunk.entityLists.length; i++)
        {
            for (int j = 0; j < chunk.entityLists[i].size(); j++)
            {
                Entity newEnt = (Entity) chunk.entityLists[i].get(j);
                
                if (newEnt instanceof EntityLiving)
                {
                    /* an EntityLiving was just loaded from a save file and spawned into the world */
                    String savedMods = newEnt.getEntityData().getString(InfernalMobsCore.getNBTTag());
                    if (!savedMods.equals(""))
                    {
                        InfernalMobsCore.addEntityModifiersByString((EntityLiving) newEnt, savedMods);
                    }
                }
            }
        }
    }

    @Override
    public void onChunkUnload(World world, Chunk chunk)
    {
        for (int i = 0; i < chunk.entityLists.length; i++)
        {
            for (int j = 0; j < chunk.entityLists[i].size(); j++)
            {
                Entity newEnt = (Entity) chunk.entityLists[i].get(j);
                
                if (newEnt instanceof EntityLiving)
                {
                    /* an EntityLiving was just dumped to a save file and removed from the world */
                    String savedMods = newEnt.getEntityData().getString(InfernalMobsCore.getNBTTag());
                    if (!savedMods.equals(""))
                    {
                        InfernalMobsCore.removeEntFromElites((EntityLiving) newEnt);
                    }
                }
            }
        }
    }

    @Override
    public void onChunkSaveData(World world, Chunk chunk, NBTTagCompound data)
    {
    }

    @Override
    public void onChunkLoadData(World world, Chunk chunk, NBTTagCompound data)
    {
    }
}
