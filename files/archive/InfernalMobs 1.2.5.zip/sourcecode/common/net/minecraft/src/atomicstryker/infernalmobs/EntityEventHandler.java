package net.minecraft.src.atomicstryker.infernalmobs;

import java.util.ArrayList;

import net.minecraft.src.DamageSource;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityItem;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.World;
import net.minecraft.src.forge.IEntityLivingHandler;

public class EntityEventHandler implements IEntityLivingHandler
{
    /**
     * Links the Forge Event Handler to the registered Entity MobModifier Events (if present)
     */

    @Override
    public boolean onEntityLivingSpawn(EntityLiving entity, World world, float x, float y, float z)
    {
        InfernalMobsCore.processEntitySpawn(entity);
        return false;
    }

    @Override
    public boolean onEntityLivingDeath(EntityLiving entity, DamageSource killer)
    {
        MobModifier mod = InfernalMobsCore.getMobModifiers(entity);
        if (mod != null)
        {
            if(mod.onDeath())
            {
                return true;
            }
        }
        
        return false;
    }

    @Override
    public void onEntityLivingSetAttackTarget(EntityLiving entity, EntityLiving target)
    {
        MobModifier mod = InfernalMobsCore.getMobModifiers(entity);
        if (mod != null)
        {
            mod.onSetAttackTarget(target);
        }
    }

    @Override
    public boolean onEntityLivingAttacked(EntityLiving entity, DamageSource attack, int damage)
    {
        /* fires both client and server before hurt, but we dont need this */
        return false;
    }
    
    @Override
    public int onEntityLivingHurt(EntityLiving entity, DamageSource source, int damage)
    {
        MobModifier mod = InfernalMobsCore.getMobModifiers(entity);
        if (mod != null)
        {
            return mod.onHurt(source, damage);
        }
        
        /*
         * We use the Hook two-sided, both with the Mob as possible target and attacker
         */
        Entity attacker = source.getEntity();
        if (attacker != null
        && attacker instanceof EntityLiving)
        {
            mod = InfernalMobsCore.getMobModifiers((EntityLiving) attacker);
            if (mod != null)
            {
                return mod.onAttack(entity, source, damage);
            }
        }
        
        return damage;
    }

    @Override
    public void onEntityLivingJump(EntityLiving entity)
    {
        MobModifier mod = InfernalMobsCore.getMobModifiers(entity);
        if (mod != null)
        {
            mod.onJump();
        }
    }

    @Override
    public boolean onEntityLivingFall(EntityLiving entity, float distance)
    {
        MobModifier mod = InfernalMobsCore.getMobModifiers(entity);
        if (mod != null)
        {
            return mod.onFall(distance);
        }
        
        return false;
    }

    @Override
    public boolean onEntityLivingUpdate(EntityLiving entity)
    {
        MobModifier mod = InfernalMobsCore.getMobModifiers(entity);
        if (mod != null)
        {
            return mod.onUpdate();
        }
        
        return false;
    }

    @Override
    public void onEntityLivingDrops(EntityLiving entity, DamageSource source, ArrayList<EntityItem> drops, int lootingLevel, boolean recentlyHit, int specialDropValue)
    {
        MobModifier mod = InfernalMobsCore.getMobModifiers(entity);
        if (mod != null)
        {
            mod.onDropItems(source, drops, lootingLevel, recentlyHit, specialDropValue);
            InfernalMobsCore.removeEntFromElites(entity);
        }
    }
}
