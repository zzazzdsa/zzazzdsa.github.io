package net.minecraft.src.atomicstryker.infernalmobs.mods;

import java.lang.reflect.Field;

import net.minecraft.src.DamageSource;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.atomicstryker.infernalmobs.InfernalMobsCore;
import net.minecraft.src.atomicstryker.infernalmobs.MobModifier;

public class MM_Regen extends MobModifier
{
    public MM_Regen(EntityLiving mob)
    {
        this.mob = mob;
        this.modName = "Regen";
    }
    
    public MM_Regen(EntityLiving mob, MobModifier prevMod)
    {
        this.mob = mob;
        this.modName = "Regen";
        this.nextMod = prevMod;
    }
    
    private long lastAbilityUse = 0L;
    private final static long coolDown = 500L;
    
    @Override
    public boolean onUpdate()
    {
        if (mob.getHealth() < (mob.getMaxHealth()*InfernalMobsCore.RARE_MOB_HEALTH_MODIFIER))
        {
            long time = System.currentTimeMillis();
            if (time > lastAbilityUse+coolDown)
            {
                lastAbilityUse = time;
                InfernalMobsCore.setEntityHealthPastMax(mob, mob.getHealth()+1);
            }
        }
        return super.onUpdate();
    }
}
