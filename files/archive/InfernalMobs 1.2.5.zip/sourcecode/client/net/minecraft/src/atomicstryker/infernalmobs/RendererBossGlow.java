package net.minecraft.src.atomicstryker.infernalmobs;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;

import net.minecraft.client.Minecraft;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.Frustrum;
import net.minecraft.src.MathHelper;
import net.minecraft.src.OpenGlHelper;
import net.minecraft.src.Render;
import net.minecraft.src.RenderGlobal;
import net.minecraft.src.RenderLiving;
import net.minecraft.src.RenderManager;
import net.minecraft.src.Vec3D;
import net.minecraft.src.forge.IRenderWorldLastHandler;

public class RendererBossGlow implements IRenderWorldLastHandler
{
    private static long lastRender = 0L;
    
    @Override
    public void onRenderWorldLast(RenderGlobal renderer, float partialTicks)
    {
        if (System.currentTimeMillis() > lastRender+10L)
        {
            lastRender = System.currentTimeMillis();
            renderBossGlow(partialTicks, renderer.mc);
        }
    }
    
    private void renderBossGlow(float renderTick, Minecraft mc)
    {
        EntityLiving viewEnt = mc.renderViewEntity;
        Vec3D curPos = viewEnt.getPosition(renderTick);
        
        Frustrum f = new Frustrum();
        double var7 = viewEnt.lastTickPosX + (viewEnt.posX - viewEnt.lastTickPosX) * (double)renderTick;
        double var9 = viewEnt.lastTickPosY + (viewEnt.posY - viewEnt.lastTickPosY) * (double)renderTick;
        double var11 = viewEnt.lastTickPosZ + (viewEnt.posZ - viewEnt.lastTickPosZ) * (double)renderTick;
        f.setPosition(var7, var9, var11);
        
        for (EntityLiving ent : InfernalMobsCore.getRareMobs().keySet())
        {
            if (ent.isInRangeToRenderVec3D(curPos)
            && (ent.ignoreFrustumCheck || f.isBoundingBoxInFrustum(ent.boundingBox))
            && ent.isEntityAlive())
            {
                //RenderManager.instance.renderEntity(ent, renderTick);
                renderEntityGlowing(ent, renderTick, RenderManager.instance);
            }
        }
    }

    private void renderEntityGlowing(EntityLiving ent, float renderTick, RenderManager rendermanager)
    {
        double xPart = ent.lastTickPosX + (ent.posX - ent.lastTickPosX) * (double)renderTick;
        double yPart = ent.lastTickPosY + (ent.posY - ent.lastTickPosY) * (double)renderTick;
        double zPart = ent.lastTickPosZ + (ent.posZ - ent.lastTickPosZ) * (double)renderTick;
        float rotPart = ent.prevRotationYaw + (ent.rotationYaw - ent.prevRotationYaw) * renderTick;
        int brightness = ent.getBrightnessForRender(renderTick);

        if (ent.isBurning())
        {
            brightness = 15728880;
        }

        int brightnessOver = brightness % 65536;
        int brightnessMain = brightness / 65536;
        OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, (float)brightnessOver / 1.0F, (float)brightnessMain / 1.0F);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        
        renderEntityWithPosYaw(rendermanager, ent, xPart - rendermanager.renderPosX, yPart - rendermanager.renderPosY, zPart - rendermanager.renderPosZ, rotPart, renderTick);
    }
    
    private void renderEntityWithPosYaw(RenderManager rendermanager, EntityLiving ent, double d, double e, double f, float var9, float renderTick)
    {
        Render renderObject = rendermanager.getEntityRenderObject(ent);
        if (renderObject != null && renderObject instanceof RenderLiving)
        {
            try
            {
                RenderLivingGlow r = RenderLivingGlow.hackRenderLiving((RenderLiving) renderObject);
                r.doRenderLiving(ent, d, e, f, var9, renderTick);
            }
            catch (Exception e1)
            {
                e1.printStackTrace();
            }
        }
    }
}
