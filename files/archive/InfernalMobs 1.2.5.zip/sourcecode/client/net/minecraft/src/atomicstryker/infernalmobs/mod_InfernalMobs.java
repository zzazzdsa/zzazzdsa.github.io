package net.minecraft.src.atomicstryker.infernalmobs;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import org.lwjgl.opengl.GL11;

import net.minecraft.client.Minecraft;
import net.minecraft.src.AxisAlignedBB;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.FontRenderer;
import net.minecraft.src.GuiIngame;
import net.minecraft.src.MathHelper;
import net.minecraft.src.ModLoader;
import net.minecraft.src.MovingObjectPosition;
import net.minecraft.src.NetClientHandler;
import net.minecraft.src.NetworkManager;
import net.minecraft.src.Packet1Login;
import net.minecraft.src.ScaledResolution;
import net.minecraft.src.Vec3D;
import net.minecraft.src.World;
import net.minecraft.src.atomicstryker.ForgePacketWrapper;
import net.minecraft.src.atomicstryker.infernalmobs.mods.MM_Gravity;
import net.minecraft.src.forge.IConnectionHandler;
import net.minecraft.src.forge.IPacketHandler;
import net.minecraft.src.forge.IRenderWorldLastHandler;
import net.minecraft.src.forge.MessageManager;
import net.minecraft.src.forge.MinecraftForgeClient;
import net.minecraft.src.forge.NetworkMod;

public class mod_InfernalMobs extends NetworkMod implements IConnectionHandler, IPacketHandler
{
    private final double NAME_VISION_DISTANCE = 32D;
    private final int ENTITY_SPAWN_QUEUE_HASHSET_IN_WORLDCLIENT = 2;
    private World lastWorld;
    private ArrayList<Entity> lastLoadedEntityList = null;
    private long lastTick;
    
    @Override
    public void load()
    {
        InfernalMobsCore.load(this);
        
        ModLoader.setInGameHook(this, true, false);
        lastTick = System.currentTimeMillis();
        
        new InfernalMobsUpdateHandler(this);
    }
    
    @Override
    public boolean onTickInGame(float renderTick, Minecraft mc)
    {        
        renderBossOverlay(renderTick, mc);
        
        MinecraftForgeClient.registerRenderLastHandler(new RendererBossGlow());
        
        /* client reset in case of swapping worlds */
        if (mc.theWorld != lastWorld)
        {
            boolean newGame = lastWorld == null;
            lastWorld = mc.theWorld;
            lastLoadedEntityList = (ArrayList) lastWorld.getLoadedEntityList();
            
            if (!newGame)
            {
                InfernalMobsCore.checkRareListForObsoletes(lastWorld);
            }
        }
        
        if (lastTick != System.currentTimeMillis())
        {
            lastTick = System.currentTimeMillis();
            
            if (mc.theWorld.isRemote
             && lastLoadedEntityList != null)
            {
                ArrayList<Entity> bufferList = (ArrayList<Entity>) ((ArrayList)mc.theWorld.getLoadedEntityList()).clone();
                if (bufferList.hashCode() != lastLoadedEntityList.hashCode()) /*optimization.. make sure entityList changed*/
                {
                    bufferList.removeAll(lastLoadedEntityList);
                    for (Entity ent : bufferList)
                    {
                        if (ent instanceof EntityLiving)
                        {
                            askServerForMobMods((EntityLiving)ent);
                        }
                    }
                }
                lastLoadedEntityList = (ArrayList) ((ArrayList) mc.theWorld.getLoadedEntityList()).clone();
            }
            
            InfernalMobsCore.onTick();
        }
        
        return true;
    }

    private void askServerForMobMods(EntityLiving ent)
    {
        // question: Packet ID 1, from client, { entID }
        Object[] input = { ent.entityId };
        ModLoader.sendPacket(ForgePacketWrapper.createPacket(InfernalMobsCore.getPacketChannel(), 1, input));
    }

    @Override
    public String getVersion()
    {
        return InfernalMobsCore.getVersion();
    }
    
    @Override
    public void onPacketData(NetworkManager network, String channel, byte[] bytes)
    {
        DataInputStream data = new DataInputStream(new ByteArrayInputStream(bytes));
        int packetType = ForgePacketWrapper.readPacketID(data);
        
        /* answer: Packet ID 1, from server, { int entID, String mods } */
        if (packetType == 1)
        {
            Class[] decodeAs = {Integer.class, String.class};
            Object[] packetReadout = ForgePacketWrapper.readPacketData(data, decodeAs);
            
            int entID = (Integer) packetReadout[0];
            String mods = (String) packetReadout[1];
            
            InfernalMobsCore.addRemoteEntityModifiers(lastWorld, entID, mods);
        }
        // addVelocity player: Packet ID 2, from server, { double xVel, double yVel, double zVel }
        else if (packetType == 2)
        {
            Class[] decodeAs = {Double.class, Double.class, Double.class};
            Object[] packetReadout = ForgePacketWrapper.readPacketData(data, decodeAs);
            ModLoader.getMinecraftInstance().thePlayer.addVelocity((Double)packetReadout[0], (Double)packetReadout[1], (Double)packetReadout[2]);
        }
        // knockBack player: Packet ID 3, from server, { double xVel, double zVel }
        else if (packetType == 3)
        {
            Class[] decodeAs = {Double.class, Double.class};
            Object[] packetReadout = ForgePacketWrapper.readPacketData(data, decodeAs);
            MM_Gravity.knockBack(ModLoader.getMinecraftInstance().thePlayer, (Double)packetReadout[0], (Double)packetReadout[1]);
        }
    }
    
    public static void sendVelocityPacket(EntityPlayer target, double x, double y, double z)
    {
        /* client doesnt implement this */
    }
    
    public static void sendKnockBackPacket(EntityPlayer target, double x, double z)
    {
        /* client doesnt implement this */
    }
    
    @Override
    public void onConnect(NetworkManager network)
    {
        MessageManager.getInstance().registerChannel(network, this, InfernalMobsCore.getPacketChannel());
    }

    @Override
    public void onLogin(NetworkManager network, Packet1Login login)
    {
        /* client hack for entities sent from the server */
        NetClientHandler client = ((NetClientHandler)network.getNetHandler());
    }
    
    @Override
    public void onDisconnect(NetworkManager network, String message, Object[] args)
    {
        lastLoadedEntityList = null;
    }
    
    private void renderBossOverlay(float renderTick, Minecraft mc)
    {
        Entity ent = getEntityCrosshairOver(renderTick, mc);
        
        if (ent != null
        && ent instanceof EntityLiving
        && InfernalMobsCore.getIsRareEntity((EntityLiving) ent))
        {
            GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
            GL11.glBindTexture(GL11.GL_TEXTURE_2D, mc.renderEngine.getTexture("/gui/icons.png"));
            GL11.glDisable(GL11.GL_BLEND);
            
            EntityLiving target = (EntityLiving) ent;
            String buffer = target.getClass().getSimpleName();
            if (buffer.startsWith("Entity"))
            {
                buffer = buffer.replaceFirst("Entity", "Rare ");
            }
            
            ScaledResolution resolution = new ScaledResolution(mc.gameSettings, mc.displayWidth, mc.displayHeight);
            int screenwidth = resolution.getScaledWidth();
            FontRenderer fontR = mc.fontRenderer;
            
            GuiIngame gui = mc.ingameGUI;
            short lifeBarLength = 182;
            int x = screenwidth / 2 - lifeBarLength / 2;
            
            int lifeBarLeft = (int)((float)target.getHealth() / ((float)target.getMaxHealth()*InfernalMobsCore.RARE_MOB_HEALTH_MODIFIER) * (float)(lifeBarLength + 1));
            byte y = 12;
            gui.drawTexturedModalRect(x, y, 0, 74, lifeBarLength, 5);
            gui.drawTexturedModalRect(x, y, 0, 74, lifeBarLength, 5);

            if (lifeBarLeft > 0)
            {
                gui.drawTexturedModalRect(x, y, 0, 79, lifeBarLeft, 5);
            }
            
            fontR.drawStringWithShadow(buffer, screenwidth / 2 - fontR.getStringWidth(buffer) / 2, 10, 0x2F96EB);
            buffer = InfernalMobsCore.getMobModifiers(target).getModName();
            fontR.drawStringWithShadow(buffer, screenwidth / 2 - fontR.getStringWidth(buffer) / 2, 20, 0xffffff);
        }
    }

    private Entity getEntityCrosshairOver(float renderTick, Minecraft mc)
    {
        Entity returnedEntity = null;
        
        if (mc.renderViewEntity != null)
        {
            if (mc.theWorld != null)
            {
                double reachDistance = NAME_VISION_DISTANCE;
                mc.objectMouseOver = mc.renderViewEntity.rayTrace(reachDistance, renderTick);
                double reachDist2 = reachDistance;
                Vec3D viewEntPositionVec = mc.renderViewEntity.getPosition(renderTick);

                if (mc.objectMouseOver != null)
                {
                    reachDist2 = mc.objectMouseOver.hitVec.distanceTo(viewEntPositionVec);
                }

                Vec3D viewEntityLookVec = mc.renderViewEntity.getLook(renderTick);
                Vec3D actualReachVector = viewEntPositionVec.addVector(viewEntityLookVec.xCoord * reachDistance, viewEntityLookVec.yCoord * reachDistance, viewEntityLookVec.zCoord * reachDistance);
                Entity pointedEntity = null;
                float expandBBvalue = 1.0F;
                List entsInBBList = mc.theWorld.getEntitiesWithinAABBExcludingEntity(mc.renderViewEntity, mc.renderViewEntity.boundingBox.addCoord(viewEntityLookVec.xCoord * reachDistance, viewEntityLookVec.yCoord * reachDistance, viewEntityLookVec.zCoord * reachDistance).expand((double)expandBBvalue, (double)expandBBvalue, (double)expandBBvalue));
                double lowestDistance = reachDist2;

                for (int i = 0; i < entsInBBList.size(); ++i)
                {
                    Entity iterEnt = (Entity)entsInBBList.get(i);

                    if (iterEnt.canBeCollidedWith())
                    {
                        float entBorderSize = iterEnt.getCollisionBorderSize();
                        AxisAlignedBB entHitBox = iterEnt.boundingBox.expand((double)entBorderSize, (double)entBorderSize, (double)entBorderSize);
                        MovingObjectPosition interceptObjectPosition = entHitBox.calculateIntercept(viewEntPositionVec, actualReachVector);

                        if (entHitBox.isVecInside(viewEntPositionVec))
                        {
                            if (0.0D < lowestDistance || lowestDistance == 0.0D)
                            {
                                pointedEntity = iterEnt;
                                lowestDistance = 0.0D;
                            }
                        }
                        else if (interceptObjectPosition != null)
                        {
                            double distanceToEnt = viewEntPositionVec.distanceTo(interceptObjectPosition.hitVec);

                            if (distanceToEnt < lowestDistance || lowestDistance == 0.0D)
                            {
                                pointedEntity = iterEnt;
                                lowestDistance = distanceToEnt;
                            }
                        }
                    }
                }

                if (pointedEntity != null && (lowestDistance < reachDist2 || mc.objectMouseOver == null))
                {
                    returnedEntity = pointedEntity;
                }
            }
        }
        
        return returnedEntity;
    }

    public File getMinecraftDir()
    {
        return Minecraft.getMinecraftDir();
    }
}
