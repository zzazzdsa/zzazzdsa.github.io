package net.minecraft.src.atomicstryker.infernalmobs;

import net.minecraft.src.BaseMod;
import vazkii.um.ModType;
import vazkii.um.UpdateManagerMod;

public class InfernalMobsUpdateHandler extends UpdateManagerMod
{
    public InfernalMobsUpdateHandler(BaseMod m)
    {
        super(m);
    }

    @Override
    public String getModURL()
    {
        return "http://www.atomicstryker.net/";
    }

    @Override
    public String getUpdateURL()
    {
        return "http://www.atomicstryker.net/updatemanager/version_infernalmobs.txt";
    }
    
    @Override
    public ModType getModType()
    {
        return ModType.ADDON;
    }

    @Override
    public String getModName()
    {
        return "Infernal Mobs!";
    }

    @Override
    public String getChangelogURL()
    {
        return "http://www.atomicstryker.net/updatemanager/changelog_infernalmobs.txt";
    }
}
