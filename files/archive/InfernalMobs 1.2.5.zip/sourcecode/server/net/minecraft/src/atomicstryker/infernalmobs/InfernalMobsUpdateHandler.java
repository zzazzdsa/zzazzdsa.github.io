package net.minecraft.src.atomicstryker.infernalmobs;

import net.minecraft.src.BaseMod;
import vazkii.um.UpdateManagerMod;

public class InfernalMobsUpdateHandler extends UpdateManagerMod
{
    public InfernalMobsUpdateHandler(BaseMod m)
    {
        super(m);
    }

    @Override
    public String getUpdateURL()
    {
        return "http://www.atomicstryker.net/updatemanager/version_infernalmobs.txt";
    }

    @Override
    public String getModName()
    {
        return "Infernal Mobs!";
    }
}
