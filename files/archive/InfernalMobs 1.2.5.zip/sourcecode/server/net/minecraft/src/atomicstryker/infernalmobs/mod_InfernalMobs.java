package net.minecraft.src.atomicstryker.infernalmobs;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;

import net.minecraft.server.MinecraftServer;
import net.minecraft.src.*;
import net.minecraft.src.forge.*;
import net.minecraft.src.atomicstryker.ForgePacketWrapper;
import net.minecraft.src.atomicstryker.infernalmobs.mods.MM_Gravity;

public class mod_InfernalMobs extends NetworkMod implements IConnectionHandler, IPacketHandler
{    
    @Override
    public void load()
    {
        InfernalMobsCore.load(this);
        
        ModLoader.setInGameHook(this, true, true);
        
        new InfernalMobsUpdateHandler(this);
    }
    
    @Override
    public boolean onTickInGame(MinecraftServer minecraftServer)
    {
        InfernalMobsCore.onTick();
        return true;
    }

    @Override
    public String getVersion()
    {
        return InfernalMobsCore.getVersion();
    }
    
    @Override
    public void onPacketData(NetworkManager network, String channel, byte[] bytes)
    {
        DataInputStream data = new DataInputStream(new ByteArrayInputStream(bytes));
        int packetType = ForgePacketWrapper.readPacketID(data);
        
        /* 
         * question: Packet ID 1, from client, { entID }
         * answer: Packet ID 1, from server, { int entID, String mods }
         */
        if (packetType == 1)
        {
            Class[] decodeAs = { Integer.class };
            Object[] packetReadout = ForgePacketWrapper.readPacketData(data, decodeAs);
            World world = ((NetServerHandler)network.getNetHandler()).getPlayerEntity().worldObj;
            int id = (Integer)packetReadout[0];
            
            for (EntityLiving elite : InfernalMobsCore.getRareMobs().keySet())
            {
                if (elite.worldObj == world
                && elite.entityId == id)
                {
                    Object[] input = { elite.entityId, InfernalMobsCore.getMobModifiers(elite).getModName() };
                    network.addToSendQueue(ForgePacketWrapper.createPacket(InfernalMobsCore.getPacketChannel(), 1, input));
                    break;
                }
            }
        }
        // addVelocity player: Packet ID 2, from server, { double xVel, double yVel, double zVel }
        else if (packetType == 2)
        {
        }
        // knockBack player: Packet ID 3, from server, { double xVel, double zVel }
        else if (packetType == 3)
        {
        }
    }
    
    public static void sendVelocityPacket(EntityPlayer target, double x, double y, double z)
    {
        // addVelocity player: Packet ID 2, from server, { double xVel, double yVel, double zVel }
        Object[] input = { x, y, z };
        ModLoader.getMinecraftServerInstance().configManager.sendPacketToPlayer(target.username, ForgePacketWrapper.createPacket(InfernalMobsCore.getPacketChannel(), 2, input));
    }
    
    public static void sendKnockBackPacket(EntityPlayer target, double x, double z)
    {
     // knockBack player: Packet ID 3, from server, { double xVel, double zVel }
        Object[] input = { x, z };
        ModLoader.getMinecraftServerInstance().configManager.sendPacketToPlayer(target.username, ForgePacketWrapper.createPacket(InfernalMobsCore.getPacketChannel(), 3, input));
    }
    
    @Override
    public void onConnect(NetworkManager network)
    {
    }

    @Override
    public void onLogin(NetworkManager network, Packet1Login login)
    {
        MessageManager.getInstance().registerChannel(network, this, InfernalMobsCore.getPacketChannel());
    }
    
    @Override
    public void onDisconnect(NetworkManager network, String message, Object[] args)
    {
    }

    public String getMinecraftDir()
    {
        return "";
    }
}
