
To install: Throw mod zip into mods folder.


Requirements: Forge #152 or newer


Configuration:
	in /config/InfernalMobs.cfg
		- eliteRarity specifies how many EntityLivings have to spawn in order for one of them to become an Infernal Mob
			-> lower value means more rares