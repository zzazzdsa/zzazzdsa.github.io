package net.minecraft.src;

import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.World;

public class MoCItemSugarLump extends Item
{
    private int a;

    public MoCItemSugarLump(int var1)
    {
        super(var1);
        this.maxStackSize = 32;
        this.a = 3;
    }

    public ItemStack onItemRightClick(ItemStack var1, World var2, EntityPlayer var3)
    {
        --var1.stackSize;
        var3.heal(this.a);
        return var1;
    }
}
