package net.minecraft.src;

import java.util.List;
import net.minecraft.src.AxisAlignedBB;
import net.minecraft.src.Block;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.MathHelper;
import net.minecraft.src.MoCEntityAnimal;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityMouse extends MoCEntityAnimal
{
    public boolean textureSet;
    private boolean fertile;
    private int micetimer;
    private boolean isPicked;

    public MoCEntityMouse(World var1)
    {
        super(var1);
        this.texture = "/mocreatures/miceg.png";
        this.setSize(0.3F, 0.3F);
        this.health = 4;
        this.textureSet = false;
    }

    private void checkFertility()
    {
        int var1 = 0;
        List var2 = this.worldObj.getEntitiesWithinAABB(MoCEntityMouse.class, AxisAlignedBB.getBoundingBoxFromPool(this.posX, this.posY, this.posZ, this.posX + 1.0D, this.posY + 1.0D, this.posZ + 1.0D).expand(16.0D, 4.0D, 16.0D));

        for (int var3 = 0; var3 < var2.size(); ++var3)
        {
            ++var1;
        }

        if (var1 > 10)
        {
            this.fertile = false;
        }
    }

    private boolean checkNearCats()
    {
        return true;
    }

    private boolean checkNearRock()
    {
        return true;
    }

    public void chooseType()
    {
        if (this.getType() == 0)
        {
            int var1 = this.rand.nextInt(100);
            if (var1 <= 50)
            {
                this.setType(1);
            }
            else if (var1 <= 80)
            {
                this.setType(2);
            }
            else
            {
                this.setType(3);
            }
        }

        if (!this.getTypeChosen())
        {
            if (this.getType() == 1)
            {
                this.texture = "/mocreatures/miceg.png";
            }
            else if (this.getType() == 2)
            {
                this.texture = "/mocreatures/miceb.png";
            }
            else if (this.getType() == 3)
            {
                this.texture = "/mocreatures/micew.png";
            }
        }

        this.setTypeChosen(true);
    }

    public boolean climbing()
    {
        return !this.onGround && this.isOnLadder();
    }

    public boolean entitiesToInclude(Entity var1)
    {
        return !(var1 instanceof MoCEntityMouse) && super.entitiesToInclude(var1);
    }

    public boolean getCanSpawnHere()
    {
        int var1 = MathHelper.floor_double(this.posX);
        int var2 = MathHelper.floor_double(this.boundingBox.minY);
        int var3 = MathHelper.floor_double(this.posZ);
        return ((Integer)mod_mocreatures.micefreq.get()).intValue() > 0 && this.worldObj.checkIfAABBIsClear(this.boundingBox) && this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox).size() == 0 && !this.worldObj.isAnyLiquid(this.boundingBox) && this.worldObj.getBlockId(var1, var2 - 1, var3) == Block.cobblestone.blockID || this.worldObj.getBlockId(var1, var2 - 1, var3) == Block.planks.blockID || this.worldObj.getBlockId(var1, var2 - 1, var3) == Block.dirt.blockID || this.worldObj.getBlockId(var1, var2 - 1, var3) == Block.stone.blockID || this.worldObj.getBlockId(var1, var2 - 1, var3) == Block.grass.blockID;
    }

    protected String getDeathSound()
    {
        return "micedying";
    }

    protected int getDropItemId()
    {
        return Item.seeds.shiftedIndex;
    }

    /*
    public String getEntityTexture()
    {
        if (!this.getTypeChosen() && !this.worldObj.isRemote)
        {
            this.chooseType();
        }

        if (this.worldObj.isRemote && !this.textureSet && this.getTexture() != null && !this.getTexture().equals(""))
        {
            this.texture = this.getTexture();
        }

        return super.getEntityTexture();
    }
    */

    protected String getHurtSound()
    {
        return "micehurt";
    }

    public boolean getIsPicked()
    {
        return this.isPicked;
    }

    protected String getLivingSound()
    {
        return "micegrunt";
    }

    public int getMaxSpawnedInChunk()
    {
        return 6;
    }

    public double getYOffset()
    {
        return this.ridingEntity instanceof EntityPlayer && !this.worldObj.isRemote ? (double)(this.yOffset - 1.7F) : (double)this.yOffset;
    }

    public boolean interact(EntityPlayer var1)
    {
        this.rotationYaw = var1.rotationYaw;
        if (!this.worldObj.isRemote)
        {
            this.mountEntity(var1);
        }

        if (this.ridingEntity != null)
        {
            this.setPicked(true);
        }
        else
        {
            this.worldObj.playSoundAtEntity(this, "mob.chickenplop", 1.0F, (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F);
            this.setPicked(false);
        }

        this.motionX = var1.motionX * 5.0D;
        this.motionY = var1.motionY / 2.0D + 0.5D;
        this.motionZ = var1.motionZ * 5.0D;
        return true;
    }

    public boolean isOnLadder()
    {
        return this.isCollidedHorizontally;
    }

    public void onLivingUpdate()
    {
        super.onLivingUpdate();
        if (!this.worldObj.isRemote)
        {
            if (this.rand.nextInt(15) == 0)
            {
                EntityLiving var1 = this.getBoogey(6.0D);
                if (var1 != null)
                {
                    this.runLikeHell(var1);
                }
            }

            if (!this.onGround && this.ridingEntity != null)
            {
                this.rotationYaw = this.ridingEntity.rotationYaw;
            }
        }
    }

    private void reproduce() {}

    public void setPicked(boolean var1)
    {
        this.isPicked = var1;
    }

    public boolean upsideDown()
    {
        return this.getIsPicked();
    }

    public void readEntityFromNBT(NBTTagCompound var1)
    {
        super.readEntityFromNBT(var1);
        this.setType(var1.getInteger("TypeInt"));
    }

    public void writeEntityToNBT(NBTTagCompound var1)
    {
        super.writeEntityToNBT(var1);
        var1.setInteger("TypeInt", this.getType());
    }
}
