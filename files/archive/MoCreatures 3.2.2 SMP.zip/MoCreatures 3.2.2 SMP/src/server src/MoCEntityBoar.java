package net.minecraft.src;

import java.util.List;
import net.minecraft.src.DamageSource;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityMob;
import net.minecraft.src.EntityPig;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.MoCTools;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityBoar extends EntityPig
{
    protected int force;
    protected double attackRange;

    public MoCEntityBoar(World var1)
    {
        super(var1);
        this.texture = "/mocreatures/boar.png";
        this.setSize(0.9F, 0.9F);
        this.health = 10;
        this.force = 1;
        this.attackRange = 1.0D;
    }

    protected void attackEntity(Entity var1, float var2)
    {
        if (this.attackTime <= 0 && (double)var2 < 2.5D && var1.boundingBox.maxY > this.boundingBox.minY && var1.boundingBox.minY < this.boundingBox.maxY)
        {
            this.attackTime = 20;
            var1.attackEntityFrom(DamageSource.causeMobDamage(this), this.force);
            if (!(var1 instanceof EntityPlayer))
            {
                MoCTools.destroyDrops(this, 3.0D);
            }
        }
    }

    protected boolean canDespawn()
    {
        return true;
    }

    public boolean attackEntityFrom(DamageSource var1, int var2)
    {
        if (super.attackEntityFrom(var1, var2))
        {
            Entity var3 = var1.getEntity();
            if (this.riddenByEntity != var3 && this.ridingEntity != var3)
            {
                if (var3 != this && this.worldObj.difficultySetting > 0)
                {
                    this.entityToAttack = var3;
                }

                return true;
            }
            else
            {
                return true;
            }
        }
        else
        {
            return false;
        }
    }

    public boolean isNotScared()
    {
        return true;
    }

    protected Entity findPlayerToAttack()
    {
        if (this.worldObj.difficultySetting > 0)
        {
            EntityPlayer var1 = this.worldObj.getClosestPlayerToEntity(this, this.attackRange);
            if (var1 != null && this.rand.nextInt(50) == 0)
            {
                return var1;
            }

            if (this.rand.nextInt(80) == 0)
            {
                EntityLiving var2 = this.getClosestTarget(this, 10.0D);
                return var2;
            }
        }

        return null;
    }

    public boolean getCanSpawnHere()
    {
        return MoCTools.isNearTorch(this) ? false : ((Integer)mod_mocreatures.boarfreq.get()).intValue() > 0 && super.getCanSpawnHere();
    }

    public EntityLiving getClosestTarget(Entity var1, double var2)
    {
        double var4 = -1.0D;
        EntityLiving var6 = null;
        List var7 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(var2, var2, var2));

        for (int var8 = 0; var8 < var7.size(); ++var8)
        {
            Entity var9 = (Entity)var7.get(var8);
            if (var9 instanceof EntityLiving && var9 != var1 && var9 != var1.riddenByEntity && var9 != var1.ridingEntity && !(var9 instanceof EntityPlayer) && !(var9 instanceof EntityMob) && this.height > var9.height && this.width > var9.width)
            {
                double var10 = var9.getDistanceSq(var1.posY, var1.posZ, var1.motionX);
                if ((var2 < 0.0D || var10 < var2 * var2) && (var4 == -1.0D || var10 < var4) && ((EntityLiving)var9).canEntityBeSeen(var1))
                {
                    var4 = var10;
                    var6 = (EntityLiving)var9;
                }
            }
        }

        return var6;
    }

    public void onLivingUpdate()
    {
        if (this.worldObj.difficultySetting == 1)
        {
            this.attackRange = 2.0D;
            this.force = 1;
        }
        else if (this.worldObj.difficultySetting > 1)
        {
            this.attackRange = 3.0D;
            this.force = 2;
        }

        super.onLivingUpdate();
    }
}
