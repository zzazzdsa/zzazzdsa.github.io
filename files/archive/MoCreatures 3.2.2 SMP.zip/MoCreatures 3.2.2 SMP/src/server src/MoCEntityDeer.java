package net.minecraft.src;

import net.minecraft.src.Entity;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.Item;
import net.minecraft.src.MoCEntityAnimal;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.World;

public class MoCEntityDeer extends MoCEntityAnimal
{
    public boolean textureSet;

    public MoCEntityDeer(World var1)
    {
        super(var1);
        this.texture = "/mocreatures/deer.png";
        this.setEdad(0.75F);
        this.setSize(0.9F, 1.3F);
        this.health = 10;
        this.textureSet = false;
        this.setAdult(true);
        this.moveSpeed = 1.7F;
        this.setTamed(false);
    }

    /*
    public String getEntityTexture()
    {
        if (!this.getTypeChosen() && !this.worldObj.isRemote)
        {
            this.chooseType();
        }

        if (this.worldObj.isRemote && !this.textureSet)
        {
            if (this.getTexture() != null && !this.getTexture().equals(""))
            {
                this.texture = this.getTexture();
                this.textureSet = true;
            }

            if (this.getType() == 1)
            {
                this.health = 15;
            }
            else if (this.getType() == 2)
            {
                this.health = 15;
            }
            else
            {
                this.health = 5;
            }
        }

        return super.getEntityTexture();
    }
    */

    public void chooseType()
    {
        if (this.getType() == 0)
        {
            int var1 = this.rand.nextInt(100);
            if (var1 <= 20)
            {
                this.setType(1);
            }
            else if (var1 <= 70)
            {
                this.setType(2);
            }
            else
            {
                this.setType(3);
            }
        }

        if (!this.getTypeChosen())
        {
            if (this.getType() == 1)
            {
                this.texture = "/mocreatures/deer.png";
                this.health = 15;
            }
            else if (this.getType() == 2)
            {
                this.texture = "/mocreatures/deerf.png";
                this.health = 15;
            }
            else
            {
                this.texture = "/mocreatures/deerb.png";
                this.health = 5;
                this.setAdult(false);
            }
        }

        this.setMySpeed(false);
        this.setTypeChosen(true);
    }

    protected void fall(float var1) {}

    public boolean entitiesToInclude(Entity var1)
    {
        return !(var1 instanceof MoCEntityDeer) && super.entitiesToInclude(var1);
    }

    protected String getDeathSound()
    {
        return "deerdying";
    }

    protected int getDropItemId()
    {
        return Item.porkRaw.shiftedIndex;
    }

    protected String getHurtSound()
    {
        return "deerhurt";
    }

    protected String getLivingSound()
    {
        return !this.getIsAdult() ? "deerbgrunt" : "deerfgrunt";
    }

    public void onLivingUpdate()
    {
        super.onLivingUpdate();
        if (!this.worldObj.isRemote)
        {
            if (this.getType() == 3 && !this.getIsAdult() && this.rand.nextInt(250) == 0)
            {
                this.setEdad(this.getEdad() + 0.01F);
                if (this.getEdad() >= 1.3F)
                {
                    this.setAdult(true);
                    int var1 = this.rand.nextInt(1);
                    this.setType(var1);
                }
            }

            if (this.rand.nextInt(5) == 0)
            {
                EntityLiving var2 = this.getBoogey(10.0D);
                if (var2 != null)
                {
                    this.setMySpeed(true);
                    this.runLikeHell(var2);
                }
                else
                {
                    this.setMySpeed(false);
                }
            }
        }
    }

    public void setMySpeed(boolean var1)
    {
        float var2 = 1.0F;
        if (this.getType() == 1)
        {
            var2 = 1.7F;
        }
        else if (this.getType() == 2)
        {
            var2 = 1.9F;
        }
        else
        {
            var2 = 1.3F;
        }

        if (var1)
        {
            var2 *= 2.0F;
        }

        this.moveSpeed = var2;
    }

    public void setTypeInt(int var1)
    {
        this.setType(var1);
        this.setTypeChosen(false);
        this.chooseType();
    }

    protected void updateEntityActionState()
    {
        if (this.moveSpeed > 2.0F && this.onGround && this.rand.nextInt(30) == 0 && (this.motionX > 0.1D || this.motionZ > 0.1D || this.motionX < -0.1D || this.motionZ < -0.1D))
        {
            this.motionY = 0.6D;
        }

        super.updateEntityActionState();
    }

    public void readEntityFromNBT(NBTTagCompound var1)
    {
        super.readEntityFromNBT(var1);
        this.setAdult(var1.getBoolean("Adult"));
        this.setType(var1.getInteger("TypeInt"));
        this.setEdad(var1.getFloat("Edad"));
    }

    public void writeEntityToNBT(NBTTagCompound var1)
    {
        super.writeEntityToNBT(var1);
        var1.setInteger("TypeInt", this.getType());
        var1.setBoolean("Adult", this.getIsAdult());
        var1.setFloat("Edad", this.getEdad());
    }
}
