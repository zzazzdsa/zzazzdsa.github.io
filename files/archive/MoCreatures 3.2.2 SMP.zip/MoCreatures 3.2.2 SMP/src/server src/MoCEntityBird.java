package net.minecraft.src;

import net.minecraft.src.AxisAlignedBB;
import net.minecraft.src.Block;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityItem;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.Material;
import net.minecraft.src.MathHelper;
import net.minecraft.src.MoCEntityAnimal;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityBird extends MoCEntityAnimal
{
    private boolean fleeing;
    public float wingb;
    public float wingc;
    public float wingd;
    public float winge;
    public float wingh;
    public boolean textureSet;
    private boolean isPicked;

    public MoCEntityBird(World var1)
    {
        super(var1);
        this.texture = "/mocreatures/birdblue.png";
        this.setSize(0.4F, 0.3F);
        this.health = 2;
        this.isCollidedVertically = true;
        this.wingb = 0.0F;
        this.wingc = 0.0F;
        this.wingh = 1.0F;
        this.fleeing = false;
        this.textureSet = false;
        this.setTamed(false);
        this.field_9100_aZ = true;
    }

    public void chooseType()
    {
        if (this.getType() == 0)
        {
            int var1 = this.rand.nextInt(100);
            if (var1 <= 15)
            {
                this.setType(1);
            }
            else if (var1 <= 30)
            {
                this.setType(2);
            }
            else if (var1 <= 45)
            {
                this.setType(3);
            }
            else if (var1 <= 60)
            {
                this.setType(4);
            }
            else if (var1 <= 75)
            {
                this.setType(5);
            }
            else if (var1 <= 90)
            {
                this.setType(6);
            }
            else
            {
                this.setType(2);
            }
        }

        if (!this.getTypeChosen())
        {
            if (this.getType() == 1)
            {
                this.texture = "/mocreatures/birdwhite.png";
            }
            else if (this.getType() == 2)
            {
                this.texture = "/mocreatures/birdblack.png";
            }
            else if (this.getType() == 3)
            {
                this.texture = "/mocreatures/birdgreen.png";
            }
            else if (this.getType() == 4)
            {
                this.texture = "/mocreatures/birdblue.png";
            }
            else if (this.getType() == 5)
            {
                this.texture = "/mocreatures/birdyellow.png";
            }
            else if (this.getType() == 6)
            {
                this.texture = "/mocreatures/birdred.png";
            }
        }

        this.setTypeChosen(true);
    }

    protected void entityInit()
    {
        super.entityInit();
    }

    protected void fall(float var1) {}

    private int[] FindTreeTop(int var1, int var2, int var3)
    {
        int var4 = var1 - 5;
        int var5 = var3 - 5;
        int var6 = var1 + 5;
        int var7 = var2 + 7;
        int var8 = var3 + 5;

        for (int var9 = var4; var9 < var6; ++var9)
        {
            for (int var10 = var5; var10 < var8; ++var10)
            {
                int var11 = this.worldObj.getBlockId(var9, var2, var10);
                if (var11 != 0 && Block.blocksList[var11].blockMaterial == Material.wood)
                {
                    for (int var12 = var2; var12 < var7; ++var12)
                    {
                        int var13 = this.worldObj.getBlockId(var9, var12, var10);
                        if (var13 == 0)
                        {
                            return new int[] {var9, var12 + 2, var10};
                        }
                    }
                }
            }
        }

        return new int[] {0, 0, 0};
    }

    private boolean FlyToNextEntity(Entity var1)
    {
        if (var1 != null)
        {
            int var2 = MathHelper.floor_double(var1.posX);
            int var3 = MathHelper.floor_double(var1.posY);
            int var4 = MathHelper.floor_double(var1.posZ);
            this.faceLocation(var2, var3, var4, 30.0F);
            if (MathHelper.floor_double(this.posY) < var3)
            {
                this.motionY += 0.15D;
            }

            double var5;
            if (this.posX < var1.posX)
            {
                var5 = var1.posX - this.posX;
                if (var5 > 0.5D)
                {
                    this.motionX += 0.05D;
                }
            }
            else
            {
                var5 = this.posX - var1.posX;
                if (var5 > 0.5D)
                {
                    this.motionX -= 0.05D;
                }
            }

            if (this.posZ < var1.posZ)
            {
                var5 = var1.posZ - this.posZ;
                if (var5 > 0.5D)
                {
                    this.motionZ += 0.05D;
                }
            }
            else
            {
                var5 = this.posZ - var1.posZ;
                if (var5 > 0.5D)
                {
                    this.motionZ -= 0.05D;
                }
            }

            return true;
        }
        else
        {
            return false;
        }
    }

    private boolean FlyToNextTree()
    {
        int[] var1 = this.ReturnNearestMaterialCoord(this, Material.leaves, Double.valueOf(20.0D));
        int[] var2 = this.FindTreeTop(var1[0], var1[1], var1[2]);
        if (var2[1] != 0)
        {
            int var3 = var2[0];
            int var4 = var2[1];
            int var5 = var2[2];
            this.faceLocation(var3, var4, var5, 30.0F);
            if (var4 - MathHelper.floor_double(this.posY) > 2)
            {
                this.motionY += 0.15D;
            }

            boolean var6 = false;
            boolean var7 = false;
            int var10;
            if (this.posX < (double)var3)
            {
                var10 = var3 - MathHelper.floor_double(this.posX);
                this.motionX += 0.05D;
            }
            else
            {
                var10 = MathHelper.floor_double(this.posX) - var3;
                this.motionX -= 0.05D;
            }

            int var11;
            if (this.posZ < (double)var5)
            {
                var11 = var5 - MathHelper.floor_double(this.posZ);
                this.motionZ += 0.05D;
            }
            else
            {
                var11 = MathHelper.floor_double(this.posX) - var5;
                this.motionZ -= 0.05D;
            }

            double var8 = (double)(var10 + var11);
            if (var8 < 3.0D)
            {
                return true;
            }
        }

        return false;
    }

    public boolean getCanSpawnHere()
    {
        return ((Integer)mod_mocreatures.birdfreq.get()).intValue() > 0 && super.getCanSpawnHere();
    }

    public boolean entitiesToIgnore(Entity var1)
    {
        return var1 instanceof MoCEntityBird || var1.height <= this.height && var1.width <= this.width || super.entitiesToIgnore(var1);
    }

    protected String getDeathSound()
    {
        return "birddying";
    }

    protected int getDropItemId()
    {
        return Item.feather.shiftedIndex;
    }

    /*
    public String getEntityTexture()
    {
        if (!this.getTypeChosen() && !this.worldObj.isRemote)
        {
            this.chooseType();
        }

        if (this.worldObj.isRemote && !this.textureSet && this.getTexture() != null && !this.getTexture().equals(""))
        {
            this.texture = this.getTexture();
            this.textureSet = true;
        }

        return super.getEntityTexture();
    }
    */

    protected String getHurtSound()
    {
        return "birdhurt";
    }

    protected String getLivingSound()
    {
        return this.getType() == 1 ? "birdwhite" : (this.getType() == 2 ? "birdblack" : (this.getType() == 3 ? "birdgreen" : (this.getType() == 4 ? "birdblue" : (this.getType() == 5 ? "birdyellow" : "birdred"))));
    }

    public int getMaxSpawnedInChunk()
    {
        return 6;
    }

    public boolean getPicked()
    {
        return this.isPicked;
    }

    public double getYOffset()
    {
        return this.ridingEntity instanceof EntityPlayer && !this.worldObj.isRemote ? (double)(this.yOffset - 1.15F) : (double)this.yOffset;
    }

    public boolean interact(EntityPlayer var1)
    {
        if (!this.getIsTamed())
        {
            return false;
        }
        else
        {
            this.rotationYaw = var1.rotationYaw;
            if (!this.worldObj.isRemote)
            {
                this.mountEntity(var1);
            }

            if (this.ridingEntity != null)
            {
                this.setPicked(true);
            }
            else
            {
                this.worldObj.playSoundAtEntity(this, "mob.chickenplop", 1.0F, (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F);
            }

            this.motionX = var1.motionX * 5.0D;
            this.motionY = var1.motionY / 2.0D + 0.5D;
            this.motionZ = var1.motionZ * 5.0D;
            return true;
        }
    }

    public void onLivingUpdate()
    {
        super.onLivingUpdate();
        if (this.worldObj.isRemote)
        {
            if (this.ridingEntity == null)
            {
                return;
            }

            this.updateEntityActionState();
        }

        this.winge = this.wingb;
        this.wingd = this.wingc;
        this.wingc = (float)((double)this.wingc + (double)(this.onGround ? -1 : 4) * 0.3D);
        if (this.wingc < 0.0F)
        {
            this.wingc = 0.0F;
        }

        if (this.wingc > 1.0F)
        {
            this.wingc = 1.0F;
        }

        if (!this.onGround && this.wingh < 1.0F)
        {
            this.wingh = 1.0F;
        }

        this.wingh = (float)((double)this.wingh * 0.9D);
        if (!this.onGround && this.motionY < 0.0D)
        {
            this.motionY *= 0.8D;
        }

        this.wingb += this.wingh * 2.0F;
        EntityLiving var1 = this.getClosestEntityLiving(this, 4.0D);
        if (var1 != null && !this.getIsTamed() && this.canEntityBeSeen(var1))
        {
            this.fleeing = true;
        }

        if (this.rand.nextInt(300) == 0)
        {
            this.fleeing = true;
        }

        if (this.fleeing)
        {
            if (this.FlyToNextTree())
            {
                this.fleeing = false;
            }

            int[] var2 = this.ReturnNearestMaterialCoord(this, Material.leaves, Double.valueOf(16.0D));
            if (var2[0] == -1)
            {
                for (int var3 = 0; var3 < 2; ++var3)
                {
                    this.WingFlap();
                }

                this.fleeing = false;
            }

            if (this.rand.nextInt(50) == 0)
            {
                this.fleeing = false;
            }
        }

        if (!this.fleeing)
        {
            EntityItem var4 = this.getClosestItem(this, 12.0D, Item.seeds.shiftedIndex, -1);
            if (var4 != null)
            {
                this.FlyToNextEntity(var4);
                EntityItem var5 = this.getClosestItem(this, 1.0D, Item.seeds.shiftedIndex, -1);
                if (this.rand.nextInt(50) == 0 && var5 != null)
                {
                    var5.setEntityDead();
                    this.setTamed(true);
                }
            }
        }

        if (this.isInsideOfMaterial(Material.water))
        {
            this.WingFlap();
        }
    }

    public void readEntityFromNBT(NBTTagCompound var1)
    {
        super.readEntityFromNBT(var1);
        this.setTamed(var1.getBoolean("Tamed"));
        this.setType(var1.getInteger("TypeInt"));
    }

    public int[] ReturnNearestMaterialCoord(Entity var1, Material var2, Double var3)
    {
        AxisAlignedBB var4 = var1.boundingBox.expand(var3.doubleValue(), var3.doubleValue(), var3.doubleValue());
        int var5 = MathHelper.floor_double(var4.minX);
        int var6 = MathHelper.floor_double(var4.maxX + 1.0D);
        int var7 = MathHelper.floor_double(var4.minY);
        int var8 = MathHelper.floor_double(var4.maxY + 1.0D);
        int var9 = MathHelper.floor_double(var4.minZ);
        int var10 = MathHelper.floor_double(var4.maxZ + 1.0D);

        for (int var11 = var5; var11 < var6; ++var11)
        {
            for (int var12 = var7; var12 < var8; ++var12)
            {
                for (int var13 = var9; var13 < var10; ++var13)
                {
                    int var14 = this.worldObj.getBlockId(var11, var12, var13);
                    if (var14 != 0 && Block.blocksList[var14].blockMaterial == var2)
                    {
                        return new int[] {var11, var12, var13};
                    }
                }
            }
        }

        return new int[] { -1, 0, 0};
    }

    public void setEntityDead()
    {
        if (!this.getIsTamed() || this.health <= 0)
        {
            super.setEntityDead();
        }
    }

    public void setPicked(boolean var1)
    {
        this.isPicked = var1;
    }

    public void setTypeInt(int var1)
    {
        this.setType(var1);
        this.setTypeChosen(false);
        this.chooseType();
    }

    protected void updateEntityActionState()
    {
        if (this.onGround && this.rand.nextInt(10) == 0 && (this.motionX > 0.05D || this.motionZ > 0.05D || this.motionX < -0.05D || this.motionZ < -0.05D))
        {
            this.motionY = 0.25D;
        }

        if (this.ridingEntity != null && this.ridingEntity instanceof EntityPlayer)
        {
            EntityPlayer var1 = (EntityPlayer)this.ridingEntity;
            if (var1 != null)
            {
                this.rotationYaw = var1.rotationYaw;
                var1.fallDistance = 0.0F;
                if (var1.motionY < -0.1D)
                {
                    var1.motionY = -0.1D;
                }
            }
        }

        if (this.fleeing && this.getPicked())
        {
            if (this.onGround)
            {
                this.setPicked(false);
            }
        }
        else
        {
            super.updateEntityActionState();
        }
    }

    private void WingFlap()
    {
        this.motionY += 0.05D;
        if (this.rand.nextInt(30) == 0)
        {
            this.motionX += 0.2D;
        }

        if (this.rand.nextInt(30) == 0)
        {
            this.motionX -= 0.2D;
        }

        if (this.rand.nextInt(30) == 0)
        {
            this.motionZ += 0.2D;
        }

        if (this.rand.nextInt(30) == 0)
        {
            this.motionZ -= 0.2D;
        }
    }

    public void writeEntityToNBT(NBTTagCompound var1)
    {
        super.writeEntityToNBT(var1);
        var1.setInteger("TypeInt", this.getType());
        var1.setBoolean("Tamed", this.getIsTamed());
    }
}
