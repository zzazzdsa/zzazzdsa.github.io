package net.minecraft.src;

import java.util.List;
import net.minecraft.src.AxisAlignedBB;
import net.minecraft.src.Block;
import net.minecraft.src.DamageSource;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityCreature;
import net.minecraft.src.EntityItem;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityMob;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.EntityWolf;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.Material;
import net.minecraft.src.MathHelper;
import net.minecraft.src.MoCEntityAnimal;
import net.minecraft.src.MoCEntityHorse;
import net.minecraft.src.MoCEntityKitty;
import net.minecraft.src.MoCEntityKittyBed;
import net.minecraft.src.MoCEntityLitterBox;
import net.minecraft.src.MoCTools;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityBigCat extends MoCEntityAnimal
{
    protected int force;
    protected double attackRange;
    private boolean textureSet;
    public float heightF;
    public float widthF;
    public float lengthF;
    public EntityLiving roper;
    private boolean isHungry;
    private boolean isSitting;
    private boolean hasEaten;

    public MoCEntityBigCat(World var1)
    {
        super(var1);
        this.texture = "/mocreatures/lionf.png";
        this.setEdad(0.35F);
        this.setSize(0.9F, 1.3F);
        this.health = 25;
        this.force = 1;
        this.attackRange = 1.0D;
        this.setAdult(true);
        this.setHungry(true);
        this.textureSet = false;
        this.setMaxHealth(25);
        this.setTamed(false);
    }

    protected void attackEntity(Entity var1, float var2)
    {
        if (this.attackTime <= 0 && var2 > 2.0F && var2 < 6.0F && this.rand.nextInt(50) == 0)
        {
            if (this.onGround)
            {
                double var3 = var1.posX - this.posX;
                double var5 = var1.posZ - this.posZ;
                float var7 = MathHelper.sqrt_double(var3 * var3 + var5 * var5);
                this.motionX = var3 / (double)var7 * 0.5D * 0.8D + this.motionX * 0.2D;
                this.motionZ = var5 / (double)var7 * 0.5D * 0.8D + this.motionZ * 0.2D;
                this.motionY = 0.4D;
            }
        }
        else if ((double)var2 < 2.5D && var1.boundingBox.maxY > this.boundingBox.minY && var1.boundingBox.minY < this.boundingBox.maxY)
        {
            this.attackTime = 20;
            var1.attackEntityFrom(DamageSource.causeMobDamage(this), this.force);
            if (!(var1 instanceof EntityPlayer))
            {
                MoCTools.destroyDrops(this, 3.0D);
            }
        }
    }

    public boolean attackEntityFrom(DamageSource var1, int var2)
    {
        if (super.attackEntityFrom(var1, var2))
        {
            Entity var3 = var1.getEntity();
            if (this.riddenByEntity != var3 && this.ridingEntity != var3)
            {
                if (var3 != this && this.worldObj.difficultySetting > 0 && !this.getIsTamed())
                {
                    this.entityToAttack = var3;
                }

                return true;
            }
            else
            {
                return true;
            }
        }
        else
        {
            return false;
        }
    }

    public float b(float var1, float var2, float var3)
    {
        float var4;
        for (var4 = var2 - var1; var4 < -180.0F; var4 += 360.0F)
        {
            ;
        }

        while (var4 >= 180.0F)
        {
            var4 -= 360.0F;
        }

        if (var4 > var3)
        {
            var4 = var3;
        }

        if (var4 < -var3)
        {
            var4 = -var3;
        }

        return var1 + var4;
    }

    protected boolean canDespawn()
    {
        return !this.getIsTamed();
    }

    public int checkNearBigKitties(double var1)
    {
        boolean var3 = false;
        List var4 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(var1, var1, var1));

        for (int var5 = 0; var5 < var4.size(); ++var5)
        {
            Entity var6 = (Entity)var4.get(var5);
            if (var6 != this && var6 instanceof MoCEntityBigCat)
            {
                MoCEntityBigCat var7 = (MoCEntityBigCat)var6;
                int var8 = var7.getType();
                if (var8 == 2)
                {
                    var8 = 1;
                }

                return var8;
            }
        }

        return 0;
    }

    public void chooseType()
    {
        boolean var1 = false;
        if (this.getType() == 0)
        {
            var1 = true;
            if (this.rand.nextInt(4) == 0)
            {
                this.setAdult(false);
                this.field_9100_aZ = true;
            }

            int var2 = this.rand.nextInt(100);
            if (var2 <= 5)
            {
                this.setType(1);
            }
            else if (var2 <= 25)
            {
                this.setType(2);
            }
            else if (var2 <= 50)
            {
                this.setType(3);
            }
            else if (var2 <= 70)
            {
                this.setType(4);
            }
            else if (var2 <= 75)
            {
                this.setType(7);
            }
            else
            {
                this.setType(5);
            }
        }

        if (!this.getTypeChosen())
        {
            if (this.getType() == 1)
            {
                this.texture = "/mocreatures/lionf.png";
                this.widthF = 1.0F;
                this.heightF = 1.0F;
                this.lengthF = 1.0F;
                this.moveSpeed = 1.4F;
                this.attackRange = 8.0D;
                this.force = 5;
                this.setMaxHealth(25);
            }
            else if (this.getType() == 2)
            {
                this.texture = "/mocreatures/lionf.png";
                this.widthF = 1.1F;
                this.heightF = 1.1F;
                this.lengthF = 1.0F;
                this.moveSpeed = 1.4F;
                this.attackRange = 4.0D;
                this.force = 5;
                this.setMaxHealth(30);
            }

            if (this.getType() == 3)
            {
                this.texture = "/mocreatures/panther.png";
                this.widthF = 0.9F;
                this.heightF = 0.9F;
                this.lengthF = 0.9F;
                this.moveSpeed = 1.6F;
                this.attackRange = 6.0D;
                this.force = 4;
                this.setMaxHealth(20);
            }
            else if (this.getType() == 4)
            {
                this.texture = "/mocreatures/cheetah.png";
                this.widthF = 0.8F;
                this.heightF = 0.8F;
                this.lengthF = 1.0F;
                this.moveSpeed = 1.9F;
                this.attackRange = 6.0D;
                this.force = 3;
                this.setMaxHealth(20);
            }
            else if (this.getType() == 5)
            {
                this.texture = "/mocreatures/tiger.png";
                this.widthF = 1.1F;
                this.heightF = 1.1F;
                this.lengthF = 1.1F;
                this.moveSpeed = 1.6F;
                this.attackRange = 8.0D;
                this.force = 6;
                this.setMaxHealth(35);
            }
            else if (this.getType() == 6)
            {
                this.texture = "/mocreatures/leopard.png";
                this.widthF = 0.8F;
                this.heightF = 0.8F;
                this.lengthF = 0.9F;
                this.moveSpeed = 1.7F;
                this.attackRange = 4.0D;
                this.force = 3;
                this.setMaxHealth(25);
            }
            else if (this.getType() == 7)
            {
                this.texture = "/mocreatures/tigerw.png";
                this.widthF = 1.2F;
                this.heightF = 1.2F;
                this.lengthF = 1.2F;
                this.moveSpeed = 1.7F;
                this.attackRange = 10.0D;
                this.force = 8;
                this.setMaxHealth(40);
            }
        }

        if (var1)
        {
            var1 = false;
            this.health = this.getMaxHealth();
        }

        this.setTypeChosen(true);
    }

    protected void entityInit()
    {
        super.entityInit();
    }

    public void faceItem(int var1, int var2, int var3, float var4)
    {
        double var5 = (double)var1 - this.posX;
        double var7 = (double)var3 - this.posZ;
        double var9 = (double)var2 - this.posY;
        double var11 = (double)MathHelper.sqrt_double(var5 * var5 + var7 * var7);
        float var13 = (float)(Math.atan2(var7, var5) * 180.0D / 3.141592741012573D) - 90.0F;
        float var14 = (float)(Math.atan2(var9, var11) * 180.0D / 3.141592741012573D);
        this.rotationPitch = -this.b(this.rotationPitch, var14, var4);
        this.rotationYaw = this.b(this.rotationYaw, var13, var4);
    }

    protected Entity findPlayerToAttack()
    {
        if (this.roper != null)
        {
            return this.getMastersEnemy((EntityPlayer)this.roper, 12.0D);
        }
        else
        {
            if (this.worldObj.difficultySetting > 0)
            {
                EntityPlayer var1 = this.worldObj.getClosestPlayerToEntity(this, 12.0D);
                if (!this.getIsTamed() && var1 != null && this.getIsAdult() && this.getIsHungry())
                {
                    if (this.getType() == 1 || this.getType() == 5 || this.getType() == 7)
                    {
                        this.setHungry(false);
                        return var1;
                    }

                    if (this.rand.nextInt(30) == 0)
                    {
                        this.setHungry(false);
                        return var1;
                    }
                }

                if (this.rand.nextInt(80) == 0 && this.getIsHungry())
                {
                    EntityLiving var2 = this.getClosestTarget(this, 10.0D);
                    this.setHungry(false);
                    return var2;
                }
            }

            return null;
        }
    }

    public boolean getCanSpawnHere()
    {
        if (MoCTools.isNearTorch(this))
        {
            return false;
        }
        else
        {
            boolean var1 = false;
            int var2;
            if (this.NearSnowWithDistance(this, Double.valueOf(1.0D)))
            {
                var2 = 6;
            }
            else
            {
                var2 = this.checkNearBigKitties(12.0D);
                if (var2 == 7)
                {
                    var2 = 5;
                }
            }

            this.setTypeInt(var2);
            return ((Integer)mod_mocreatures.lionfreq.get()).intValue() > 0 && super.getCanSpawnHere();
        }
    }

    public EntityItem getClosestItem(Entity var1, double var2, int var4, int var5)
    {
        double var6 = -1.0D;
        EntityItem var8 = null;
        List var9 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(var2, var2, var2));

        for (int var10 = 0; var10 < var9.size(); ++var10)
        {
            Entity var11 = (Entity)var9.get(var10);
            if (var11 instanceof EntityItem)
            {
                EntityItem var12 = (EntityItem)var11;
                if (var12.item.itemID == var4 || var5 == 0 || var12.item.itemID == var5)
                {
                    double var13 = var12.getDistanceSq(var1.posX, var1.posY, var1.posZ);
                    if ((var2 < 0.0D || var13 < var2 * var2) && (var6 == -1.0D || var13 < var6))
                    {
                        var6 = var13;
                        var8 = var12;
                    }
                }
            }
        }

        return var8;
    }

    public EntityLiving getClosestTarget(Entity var1, double var2)
    {
        double var4 = -1.0D;
        EntityLiving var6 = null;
        List var7 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(var2, var2, var2));

        for (int var8 = 0; var8 < var7.size(); ++var8)
        {
            Entity var9 = (Entity)var7.get(var8);
            if (var9 instanceof EntityLiving && var9 != var1 && var9 != var1.riddenByEntity && var9 != var1.ridingEntity && !(var9 instanceof EntityPlayer) && (this.getIsAdult() || (double)var9.width <= 0.5D && (double)var9.height <= 0.5D) && !(var9 instanceof MoCEntityKittyBed) && !(var9 instanceof MoCEntityLitterBox) && (!(var9 instanceof EntityMob) || this.getIsTamed() && this.getIsAdult()) && (!this.getIsTamed() || !(var9 instanceof MoCEntityKitty)) && (!(var9 instanceof MoCEntityHorse) || ((Boolean)mod_mocreatures.attackhorses.get()).booleanValue()) && (!(var9 instanceof EntityWolf) || ((Boolean)mod_mocreatures.attackwolves.get()).booleanValue()))
            {
                if (var9 instanceof MoCEntityBigCat)
                {
                    if (!this.getIsAdult())
                    {
                        continue;
                    }

                    MoCEntityBigCat var10 = (MoCEntityBigCat)var9;
                    if (this.getIsTamed() && var10.getIsTamed() || var10.getType() == 7 || this.getType() != 2 && this.getType() == var10.getType() || this.getType() == 2 && var10.getType() == 1 || this.health < var10.health)
                    {
                        continue;
                    }
                }

                double var12 = var9.getDistanceSq(var1.posX, var1.posY, var1.posZ);
                if ((var2 < 0.0D || var12 < var2 * var2) && (var4 == -1.0D || var12 < var4) && ((EntityLiving)var9).canEntityBeSeen(var1))
                {
                    var4 = var12;
                    var6 = (EntityLiving)var9;
                }
            }
        }

        return var6;
    }

    protected String getDeathSound()
    {
        return this.getIsAdult() ? "liondeath" : "cubdying";
    }

    protected int getDropItemId()
    {
        return mod_mocreatures.bigcatclaw.shiftedIndex;
    }

    /*
    public String getEntityTexture()
    {
        if (!this.getTypeChosen() && !this.worldObj.isRemote)
        {
            this.chooseType();
        }

        if (this.worldObj.isRemote && !this.textureSet)
        {
            if (this.getTexture() == null || this.getTexture().equals(""))
            {
                return super.getEntityTexture();
            }

            this.texture = this.getTexture();
            this.textureSet = true;
            if (this.getType() == 1)
            {
                this.widthF = 1.0F;
                this.heightF = 1.0F;
                this.lengthF = 1.0F;
                this.moveSpeed = 1.4F;
                this.attackRange = 8.0D;
                this.force = 5;
            }
            else if (this.getType() == 2)
            {
                this.widthF = 1.1F;
                this.heightF = 1.1F;
                this.lengthF = 1.0F;
                this.moveSpeed = 1.4F;
                this.attackRange = 4.0D;
                this.force = 5;
            }
            else if (this.getType() == 3)
            {
                this.widthF = 0.9F;
                this.heightF = 0.9F;
                this.lengthF = 0.9F;
                this.moveSpeed = 1.6F;
                this.attackRange = 6.0D;
                this.force = 4;
            }
            else if (this.getType() == 4)
            {
                this.widthF = 0.8F;
                this.heightF = 0.8F;
                this.lengthF = 1.0F;
                this.moveSpeed = 1.9F;
                this.attackRange = 6.0D;
                this.force = 3;
            }
            else if (this.getType() == 5)
            {
                this.widthF = 1.1F;
                this.heightF = 1.1F;
                this.lengthF = 1.1F;
                this.moveSpeed = 1.6F;
                this.attackRange = 8.0D;
                this.force = 6;
            }
            else if (this.getType() == 6)
            {
                this.widthF = 0.8F;
                this.heightF = 0.8F;
                this.lengthF = 0.9F;
                this.moveSpeed = 1.7F;
                this.attackRange = 4.0D;
                this.force = 3;
            }
            else if (this.getType() == 7)
            {
                this.widthF = 1.2F;
                this.heightF = 1.2F;
                this.lengthF = 1.2F;
                this.moveSpeed = 1.7F;
                this.attackRange = 10.0D;
                this.force = 8;
            }
        }

        return super.getEntityTexture();
    }
    */

    public boolean getHasEaten()
    {
        return this.hasEaten;
    }

    protected String getHurtSound()
    {
        return this.getIsAdult() ? "lionhurt" : "cubhurt";
    }

    public boolean getIsHungry()
    {
        return this.isHungry;
    }

    public boolean getIsSitting()
    {
        return this.isSitting;
    }

    protected String getLivingSound()
    {
        return this.getIsAdult() ? "liongrunt" : "cubgrunt";
    }

    public EntityCreature getMastersEnemy(EntityPlayer var1, double var2)
    {
        double var4 = -1.0D;
        Object var6 = null;
        List var7 = this.worldObj.getEntitiesWithinAABBExcludingEntity(var1, this.boundingBox.expand(var2, 4.0D, var2));

        for (int var8 = 0; var8 < var7.size(); ++var8)
        {
            Entity var9 = (Entity)var7.get(var8);
            if (var9 instanceof EntityCreature && var9 != this)
            {
                EntityCreature var10 = (EntityCreature)var9;
                if (var10 != null && var10.entityToAttack == var1)
                {
                    return var10;
                }
            }
        }

        return (EntityCreature)var6;
    }

    public int getMaxSpawnedInChunk()
    {
        return 3;
    }

    public boolean interact(EntityPlayer var1)
    {
        ItemStack var2 = var1.inventory.getCurrentItem();
        if (var2 != null && !this.getIsTamed() && this.getHasEaten() && var2.itemID == mod_mocreatures.medallion.shiftedIndex)
        {
            if (--var2.stackSize == 0)
            {
                var1.inventory.setInventorySlotContents(var1.inventory.currentItem, (ItemStack)null);
            }

            this.setTamed(true);
            // mod_mocreatures.setName((MoCEntityAnimal)this);
            return true;
        }
        else if (var2 != null && this.getIsTamed() && var2.itemID == mod_mocreatures.whip.shiftedIndex)
        {
            this.setSitting(!this.getIsSitting());
            return true;
        }
        else
        {
            if (var2 != null && this.getIsTamed() && (var2.itemID == Item.porkRaw.shiftedIndex || var2.itemID == Item.fishRaw.shiftedIndex))
            {
                this.health = this.getMaxHealth();
                this.worldObj.playSoundAtEntity(this, "eating", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
                this.setHungry(false);
            }

            if (var2 != null && this.getIsTamed() && (var2.itemID == Item.pickaxeDiamond.shiftedIndex || var2.itemID == Item.pickaxeWood.shiftedIndex || var2.itemID == Item.pickaxeStone.shiftedIndex || var2.itemID == Item.pickaxeSteel.shiftedIndex || var2.itemID == Item.pickaxeGold.shiftedIndex))
            {
                this.setDisplayName(!this.getDisplayName());
                return true;
            }
            else if (var2 != null && this.getIsTamed() && (var2.itemID == mod_mocreatures.medallion.shiftedIndex || var2.itemID == Item.book.shiftedIndex))
            {
                // mod_mocreatures.setName((MoCEntityAnimal)this);
                return true;
            }
            else if (var2 != null && this.riddenByEntity == null && this.roper == null && this.getIsTamed() && var2.itemID == mod_mocreatures.rope.shiftedIndex)
            {
                if (--var2.stackSize == 0)
                {
                    var1.inventory.setInventorySlotContents(var1.inventory.currentItem, (ItemStack)null);
                }

                this.worldObj.playSoundAtEntity(this, "roping", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
                this.roper = var1;
                return true;
            }
            else if (this.roper != null && this.getIsTamed())
            {
                var1.inventory.addItemStackToInventory(new ItemStack(mod_mocreatures.rope));
                this.worldObj.playSoundAtEntity(this, "roping", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
                this.roper = null;
                return true;
            }
            else
            {
                return false;
            }
        }
    }

    protected boolean isMovementCeased()
    {
        return this.getIsSitting();
    }

    protected boolean MoveToNextEntity(Entity var1)
    {
        if (var1 != null)
        {
            int var2 = MathHelper.floor_double(var1.posX);
            int var3 = MathHelper.floor_double(var1.posY);
            int var4 = MathHelper.floor_double(var1.posZ);
            this.faceItem(var2, var3, var4, 30.0F);
            double var5;
            if (this.posX < (double)var2)
            {
                var5 = var1.posX - this.posX;
                if (var5 > 0.5D)
                {
                    this.motionX += 0.03D;
                }
            }
            else
            {
                var5 = this.posX - var1.posX;
                if (var5 > 0.5D)
                {
                    this.motionX -= 0.03D;
                }
            }

            if (this.posZ < (double)var4)
            {
                var5 = var1.posZ - this.posZ;
                if (var5 > 0.5D)
                {
                    this.motionZ += 0.03D;
                }
            }
            else
            {
                var5 = this.posZ - var1.posZ;
                if (var5 > 0.5D)
                {
                    this.motionZ -= 0.03D;
                }
            }

            return true;
        }
        else
        {
            return false;
        }
    }

    public void setEntityDead()
    {
        if (!worldObj.isRemote || !this.getIsTamed() || this.health <= 0)
        {
            super.setEntityDead();
        }
    }

    public boolean NearSnowWithDistance(Entity var1, Double var2)
    {
        AxisAlignedBB var3 = var1.boundingBox.expand(var2.doubleValue(), var2.doubleValue(), var2.doubleValue());
        int var4 = MathHelper.floor_double(var3.minX);
        int var5 = MathHelper.floor_double(var3.maxX + 1.0D);
        int var6 = MathHelper.floor_double(var3.minY);
        int var7 = MathHelper.floor_double(var3.maxY + 1.0D);
        int var8 = MathHelper.floor_double(var3.minZ);
        int var9 = MathHelper.floor_double(var3.maxZ + 1.0D);

        for (int var10 = var4; var10 < var5; ++var10)
        {
            for (int var11 = var6; var11 < var7; ++var11)
            {
                for (int var12 = var8; var12 < var9; ++var12)
                {
                    int var13 = this.worldObj.getBlockId(var10, var11, var12);
                    if (var13 != 0 && Block.blocksList[var13].blockMaterial == Material.snow)
                    {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    public void onLivingUpdate()
    {
        super.onLivingUpdate();
        if (this.rand.nextInt(300) == 0 && this.health <= this.getMaxHealth() && this.deathTime == 0 && !this.worldObj.isRemote)
        {
            ++this.health;
        }

        if (!this.getIsAdult() && this.rand.nextInt(250) == 0)
        {
            this.setEdad(this.getEdad() + 0.01F);
            if (this.getEdad() >= 1.0F)
            {
                this.setAdult(true);
                this.field_9100_aZ = false;
            }
        }

        if (!this.getIsHungry() && !this.getIsSitting() && this.rand.nextInt(200) == 0)
        {
            this.setHungry(true);
        }

        if (this.roper != null)
        {
            float var1 = this.roper.getDistanceToEntity(this);
            if (var1 > 5.0F && !this.getIsSitting())
            {
                this.getPathOrWalkableBlock(this.roper, var1);
            }

            if (var1 > 18.0F & this.getIsSitting())
            {
                this.roper = null;
            }
        }

        if (this.deathTime == 0 && this.getIsHungry() && !this.getIsSitting())
        {
            EntityItem var3 = this.getClosestItem(this, 12.0D, Item.porkRaw.shiftedIndex, Item.fishRaw.shiftedIndex);
            if (var3 != null)
            {
                this.MoveToNextEntity(var3);
                EntityItem var2 = this.getClosestItem(this, 2.0D, Item.porkRaw.shiftedIndex, Item.fishRaw.shiftedIndex);
                if (this.rand.nextInt(80) == 0 && var2 != null && this.deathTime == 0)
                {
                    var2.setEntityDead();
                    this.health = this.getMaxHealth();
                    if (!this.getIsAdult() && this.getEdad() < 0.8F)
                    {
                        this.setEaten(true);
                    }

                    this.worldObj.playSoundAtEntity(this, "eating", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
                    this.setHungry(false);
                }
            }
        }
    }

    public boolean isNotScared()
    {
        return true;
    }

    public boolean renderName()
    {
        return !this.getName().isEmpty() && this.getDisplayName() && ((Boolean)mod_mocreatures.displayname.get()).booleanValue();
    }

    public void setEaten(boolean var1)
    {
        this.hasEaten = var1;
    }

    public void setHungry(boolean var1)
    {
        this.isHungry = var1;
    }

    public void setSitting(boolean var1)
    {
        this.isSitting = var1;
    }

    public void setTypeInt(int var1)
    {
        this.setType(var1);
        this.setTypeChosen(false);
        if (this.rand.nextInt(4) == 0)
        {
            this.setAdult(false);
            this.field_9100_aZ = true;
        }

        this.chooseType();
    }

    public void readEntityFromNBT(NBTTagCompound var1)
    {
        super.readEntityFromNBT(var1);
        this.setAdult(var1.getBoolean("Adult"));
        this.setType(var1.getInteger("TypeInt"));
        this.setEdad(var1.getFloat("Edad"));
        this.setTamed(var1.getBoolean("Tamed"));
        this.setSitting(var1.getBoolean("Sitting"));
        this.setName(var1.getString("Name"));
        this.setDisplayName(var1.getBoolean("DisplayName"));
    }

    public void writeEntityToNBT(NBTTagCompound var1)
    {
        super.writeEntityToNBT(var1);
        var1.setInteger("TypeInt", this.getType());
        var1.setBoolean("Adult", this.getIsAdult());
        var1.setBoolean("Tamed", this.getIsTamed());
        var1.setBoolean("Sitting", this.getIsSitting());
        var1.setFloat("Edad", this.getEdad());
        var1.setString("Name", this.getName());
        var1.setBoolean("DisplayName", this.getDisplayName());
    }
}
