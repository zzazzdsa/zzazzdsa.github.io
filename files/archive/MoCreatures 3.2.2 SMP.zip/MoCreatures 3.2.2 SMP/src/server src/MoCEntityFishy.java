package net.minecraft.src;

import java.util.List;
import net.minecraft.src.DamageSource;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.EntityWolf;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.MoCEntityAquatic;
import net.minecraft.src.MoCEntityFishyEgg;
import net.minecraft.src.MoCEntityHorse;
import net.minecraft.src.MoCEntitySharkEgg;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityFishy extends MoCEntityAquatic
{
    public int gestationtime;
    private boolean hasEaten;

    public MoCEntityFishy(World var1)
    {
        super(var1);
        this.texture = "/mocreatures/fishy1.png";
        this.setSize(0.3F, 0.3F);
        this.health = 6;
        this.setEdad(1.0F);
        this.field_9100_aZ = true;
    }

    protected void attackEntity(Entity var1, float var2)
    {
        if (this.attackTime <= 0 && (double)var2 < 2.0D && var1.boundingBox.maxY > this.boundingBox.minY && var1.boundingBox.minY < this.boundingBox.maxY)
        {
            this.attackTime = 20;
            var1.attackEntityFrom(DamageSource.causeMobDamage(this), 1);
        }
    }

    public boolean attackEntityFrom(DamageSource var1, int var2)
    {
        if (super.attackEntityFrom(var1, var2))
        {
            Entity var3 = var1.getEntity();
            if (this.riddenByEntity != var3 && this.ridingEntity != var3)
            {
                if (var3 != this && this.getType() == 10)
                {
                    this.entityToAttack = var3;
                }

                return true;
            }
            else
            {
                return true;
            }
        }
        else
        {
            return false;
        }
    }

    public void chooseType()
    {
        if (this.getType() == 0)
        {
            int var1 = this.rand.nextInt(100);
            if (var1 <= 9)
            {
                this.setType(1);
            }
            else if (var1 <= 19)
            {
                this.setType(2);
            }
            else if (var1 <= 29)
            {
                this.setType(3);
            }
            else if (var1 <= 39)
            {
                this.setType(4);
            }
            else if (var1 <= 49)
            {
                this.setType(5);
            }
            else if (var1 <= 59)
            {
                this.setType(6);
            }
            else if (var1 <= 69)
            {
                this.setType(7);
            }
            else if (var1 <= 79)
            {
                this.setType(8);
            }
            else if (var1 <= 89)
            {
                this.setType(9);
            }
            else
            {
                this.setType(10);
            }

            if (!((Boolean)mod_mocreatures.spawnpiranha.get()).booleanValue() && this.getType() == 10)
            {
                this.setType(1);
            }
        }

        if (!this.getTypeChosen())
        {
            if (this.getType() == 1)
            {
                this.texture = "/mocreatures/fishy1.png";
            }
            else if (this.getType() == 2)
            {
                this.texture = "/mocreatures/fishy2.png";
            }
            else if (this.getType() == 3)
            {
                this.texture = "/mocreatures/fishy3.png";
            }
            else if (this.getType() == 4)
            {
                this.texture = "/mocreatures/fishy4.png";
            }
            else if (this.getType() == 5)
            {
                this.texture = "/mocreatures/fishy5.png";
            }
            else if (this.getType() == 6)
            {
                this.texture = "/mocreatures/fishy6.png";
            }
            else if (this.getType() == 7)
            {
                this.texture = "/mocreatures/fishy7.png";
            }
            else if (this.getType() == 8)
            {
                this.texture = "/mocreatures/fishy8.png";
            }
            else if (this.getType() == 9)
            {
                this.texture = "/mocreatures/fishy9.png";
            }
            else if (this.getType() == 10)
            {
                this.texture = "/mocreatures/fishy10.png";
            }
        }

        this.setTypeChosen(true);
    }

    protected void dropFewItems(boolean var1, int var2)
    {
        if (this.getIsAdult())
        {
            int var3 = this.rand.nextInt(100);
            if (var3 < 70)
            {
                this.entityDropItem(new ItemStack(Item.fishRaw.shiftedIndex, 1, 0), 0.0F);
            }
            else
            {
                int var4 = this.rand.nextInt(2);

                for (int var5 = 0; var5 < var4; ++var5)
                {
                    this.entityDropItem(new ItemStack(mod_mocreatures.fishyegg, 1, 0), 0.0F);
                }
            }
        }
    }

    protected Entity findPlayerToAttack()
    {
        if (this.worldObj.difficultySetting > 0 && this.getEdad() >= 1.0F && this.getType() == 10)
        {
            EntityPlayer var1 = this.worldObj.getClosestPlayerToEntity(this, 16.0D);
            if (var1 != null && var1.inWater && !this.getIsTamed())
            {
                return var1;
            }

            if (this.rand.nextInt(30) == 0)
            {
                EntityLiving var2 = this.FindTarget(this, 16.0D);
                if (var2 != null && var2.inWater)
                {
                    return var2;
                }
            }
        }

        return null;
    }

    public EntityLiving FindTarget(Entity var1, double var2)
    {
        double var4 = -1.0D;
        EntityLiving var6 = null;
        List var7 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(var2, var2, var2));

        for (int var8 = 0; var8 < var7.size(); ++var8)
        {
            Entity var9 = (Entity)var7.get(var8);
            if (var9 instanceof EntityLiving && !(var9 instanceof MoCEntityAquatic) && !(var9 instanceof MoCEntitySharkEgg) && !(var9 instanceof MoCEntityFishyEgg) && !(var9 instanceof EntityPlayer) && (!(var9 instanceof MoCEntityHorse) || ((Boolean)mod_mocreatures.attackhorses.get()).booleanValue()) && (!(var9 instanceof EntityWolf) || ((Boolean)mod_mocreatures.attackwolves.get()).booleanValue()))
            {
                double var10 = var9.getDistanceSq(var1.posX, var1.posY, var1.posZ);
                if ((var2 < 0.0D || var10 < var2 * var2) && (var4 == -1.0D || var10 < var4) && ((EntityLiving)var9).canEntityBeSeen(var1))
                {
                    var4 = var10;
                    var6 = (EntityLiving)var9;
                }
            }
        }

        return var6;
    }

    public boolean getCanSpawnHere()
    {
        return ((Integer)mod_mocreatures.fishfreq.get()).intValue() > 0 && super.getCanSpawnHere();
    }

    public boolean getHasEaten()
    {
        return this.hasEaten;
    }

    public void onLivingUpdate()
    {
        super.onLivingUpdate();
        if (!this.worldObj.isRemote)
        {
            if (!this.getIsAdult() && this.rand.nextInt(100) == 0)
            {
                this.setEdad(this.getEdad() + 0.02F);
                if (this.getEdad() >= 1.0F)
                {
                    this.setAdult(true);
                }
            }

            if (!this.ReadyforParenting(this))
            {
                return;
            }

            int var1 = 0;
            List var2 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(4.0D, 3.0D, 4.0D));

            for (int var3 = 0; var3 < var2.size(); ++var3)
            {
                Entity var4 = (Entity)var2.get(var3);
                if (var4 instanceof MoCEntityFishy)
                {
                    ++var1;
                }
            }

            if (var1 > 1)
            {
                return;
            }

            List var10 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(4.0D, 2.0D, 4.0D));

            for (int var11 = 0; var11 < var2.size(); ++var11)
            {
                Entity var5 = (Entity)var10.get(var11);
                if (var5 instanceof MoCEntityFishy && var5 != this)
                {
                    MoCEntityFishy var6 = (MoCEntityFishy)var5;
                    if (this.ReadyforParenting(this) && this.ReadyforParenting(var6) && this.getType() == var6.getType())
                    {
                        if (this.rand.nextInt(100) == 0)
                        {
                            ++this.gestationtime;
                        }

                        if (this.gestationtime > 50)
                        {
                            int var7 = this.rand.nextInt(3) + 1;

                            for (int var8 = 0; var8 < var7; ++var8)
                            {
                                MoCEntityFishy var9 = new MoCEntityFishy(this.worldObj);
                                var9.setPosition(this.posX, this.posY, this.posZ);
                                this.worldObj.spawnEntityInWorld(var9);
                                this.worldObj.playSoundAtEntity(this, "mob.chickenplop", 1.0F, (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F);
                                this.setEaten(false);
                                var6.setEaten(false);
                                this.gestationtime = 0;
                                var6.gestationtime = 0;
                                var9.setTamed(true);
                                var9.setEdad(0.2F);
                                var9.setAdult(false);
                                var9.setType(this.getType());
                            }

                            return;
                        }
                    }
                }
            }
        }
    }

    public boolean ReadyforParenting(MoCEntityFishy var1)
    {
        return var1.getIsTamed() && var1.getHasEaten() && var1.getIsAdult();
    }

    public void setEaten(boolean var1)
    {
        this.hasEaten = var1;
    }

    public void setEntityDead()
    {
        if (!this.getIsTamed() || this.health <= 0)
        {
            super.setEntityDead();
        }
    }

    public void setTypeInt(int var1)
    {
        this.setType(var1);
        this.setTypeChosen(false);
        this.chooseType();
    }

    public void readEntityFromNBT(NBTTagCompound var1)
    {
        super.readEntityFromNBT(var1);
        this.setTamed(var1.getBoolean("Tamed"));
        this.setType(var1.getInteger("TypeInt"));
        this.setEdad(var1.getFloat("Edad"));
        this.setAdult(var1.getBoolean("Adult"));
    }

    public void writeEntityToNBT(NBTTagCompound var1)
    {
        super.writeEntityToNBT(var1);
        var1.setBoolean("Tamed", this.getIsTamed());
        var1.setInteger("TypeInt", this.getType());
        var1.setFloat("Edad", this.getEdad());
        var1.setBoolean("Adult", this.getIsAdult());
    }
}
