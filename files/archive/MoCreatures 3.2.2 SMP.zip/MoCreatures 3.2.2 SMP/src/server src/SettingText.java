package net.minecraft.src;

import net.minecraft.src.Setting;

public class SettingText extends Setting
{
    public SettingText(String var1, String var2)
    {
        this.values.put("", var2);
        this.defaultValue = var2;
        this.backendName = var1;
    }

    public void fromString(String var1, String var2)
    {
        this.values.put(var2, var1);
        /*
        if (this.displayWidget != null)
        {
            this.displayWidget.update();
        }
        */
    }

    public String get(String var1)
    {
        return this.values.get(var1) != null ? (String)this.values.get(var1) : (this.values.get("") != null ? (String)this.values.get("") : (String)this.defaultValue);
    }

    public void set(String var1, String var2)
    {
        this.values.put(var2, var1);
        if (this.parent != null)
        {
            this.parent.save(var2);
        }

        /*
        if (this.displayWidget != null)
        {
            this.displayWidget.update();
        }
        */
    }

    public String toString(String var1)
    {
        return this.get(var1);
    }

    public void set(Object var1, String var2)
    {
        this.set((String)var1, var2);
    }
}
