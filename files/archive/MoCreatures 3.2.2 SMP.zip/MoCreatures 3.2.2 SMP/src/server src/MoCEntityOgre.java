package net.minecraft.src;

import net.minecraft.src.Block;
import net.minecraft.src.DamageSource;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.MoCEntityMob;
import net.minecraft.src.MoCTools;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityOgre extends MoCEntityMob
{
    public int frequencyA;
    public float destroyForce;
    protected double attackRange;
    private boolean ogreAttack;

    public MoCEntityOgre(World var1)
    {
        super(var1);
        this.attackStrength = 3;
        this.attackRange = (double)((Integer)mod_mocreatures.ogrerange.get()).intValue();
        this.texture = "/mocreatures/ogre.png";
        this.setSize(1.5F, 4.0F);
        this.health = 35;
        this.destroyForce = ((Float)mod_mocreatures.ogreStrength.get()).floatValue();
        this.isImmuneToFire = false;
        this.frequencyA = 30;
    }

    protected void attackEntity(Entity var1, float var2)
    {
        if (this.attackTime <= 0 && var2 < 2.5F && var1.boundingBox.maxY > this.boundingBox.minY && var1.boundingBox.minY < this.boundingBox.maxY && this.worldObj.difficultySetting > 0)
        {
            this.attackTime = 20;
            var1.attackEntityFrom(DamageSource.causeMobDamage(this), this.attackStrength);
        }
    }

    public boolean attackEntityFrom(DamageSource var1, int var2)
    {
        if (super.attackEntityFrom(var1, var2))
        {
            Entity var3 = var1.getEntity();
            if (this.riddenByEntity != var3 && this.ridingEntity != var3)
            {
                if (var3 != this && this.worldObj.difficultySetting > 0)
                {
                    this.entityToAttack = var3;
                }

                return true;
            }
            else
            {
                return true;
            }
        }
        else
        {
            return false;
        }
    }

    public boolean d2()
    {
        return super.getCanSpawnHere();
    }

    public void DestroyingOgre()
    {
        if (this.deathTime <= 0)
        {
            MoCTools.DestroyBlast(this, this.posX, this.posY + 1.0D, this.posZ, this.destroyForce, this.getOgreFire());
        }
    }

    protected Entity findPlayerToAttack()
    {
        float var1 = this.getEntityBrightness(1.0F);
        if (var1 < 0.5F)
        {
            EntityPlayer var2 = this.worldObj.getClosestPlayerToEntity(this, this.attackRange);
            if (var2 != null && this.worldObj.difficultySetting > 0)
            {
                return var2;
            }
        }

        return null;
    }

    public boolean getCanSpawnHere()
    {
        return ((Integer)mod_mocreatures.ogrefreq.get()).intValue() > 0 && this.worldObj.difficultySetting >= ((Integer)mod_mocreatures.ogreSpawnDifficulty.get()).intValue() + 1 && super.getCanSpawnHere();
    }

    protected String getDeathSound()
    {
        return "ogredying";
    }

    protected int getDropItemId()
    {
        return Block.obsidian.blockID;
    }

    protected String getHurtSound()
    {
        return "ogrehurt";
    }

    protected String getLivingSound()
    {
        return "ogre";
    }

    public int getMaxSpawnedInChunk()
    {
        return 3;
    }

    public boolean getOgreAttack()
    {
        return this.ogreAttack;
    }

    public boolean getOgreFire()
    {
        return false;
    }

    public void updateStrength()
    {
        this.destroyForce = ((Float)mod_mocreatures.ogreStrength.get()).floatValue();
        this.attackRange = (double)((Integer)mod_mocreatures.ogrerange.get()).intValue();
    }

    public void onLivingUpdate()
    {
        if (!this.worldObj.isRemote)
        {
            this.updateStrength();
            if (this.entityToAttack != null && this.rand.nextInt(this.frequencyA) == 0)
            {
                this.setOgreAttack(true);
                this.attackTime = 15;
            }

            if (this.attackTime <= 0 && this.getOgreAttack())
            {
                this.setOgreAttack(false);
                this.DestroyingOgre();
            }
        }

        super.onLivingUpdate();
    }

    public void setOgreAttack(boolean var1)
    {
        this.ogreAttack = var1;
    }
}
