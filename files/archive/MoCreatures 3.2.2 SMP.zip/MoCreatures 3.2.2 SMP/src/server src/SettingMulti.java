package net.minecraft.src;

import net.minecraft.src.ModSettings;
import net.minecraft.src.Setting;

public class SettingMulti extends Setting
{
    public String[] labelValues;

    public SettingMulti(String var1, int var2, String ... var3)
    {
        if (var3.length != 0)
        {
            this.values.put("", Integer.valueOf(var2));
            this.defaultValue = Integer.valueOf(var2);
            this.labelValues = var3;
            this.backendName = var1;
        }
    }

    public SettingMulti(String var1, String ... var2)
    {
        this(var1, 0, var2);
    }

    public void fromString(String var1, String var2)
    {
        int var3 = -1;

        for (int var4 = 0; var4 < this.labelValues.length; ++var4)
        {
            if (this.labelValues[var4].equals(var1))
            {
                var3 = var4;
            }
        }

        if (var3 != -1)
        {
            this.values.put(var2, Integer.valueOf(var3));
        }
        else
        {
            this.values.put(var2, Integer.valueOf((new Float(var1)).intValue()));
        }

        ModSettings.dbgout("fromstring multi " + var1);
        /*
        if (this.displayWidget != null)
        {
            this.displayWidget.update();
        }
        */
    }

    public Integer get(String var1)
    {
        return this.values.get(var1) != null ? (Integer)this.values.get(var1) : (this.values.get("") != null ? (Integer)this.values.get("") : (Integer)this.defaultValue);
    }

    public String getLabel()
    {
        return this.labelValues[((Integer)this.get()).intValue()];
    }

    public String getLabel(String var1)
    {
        return this.labelValues[this.get(var1).intValue()];
    }

    public void next()
    {
        this.next(ModSettings.currentContext);
    }

    public void next(String var1)
    {
        int var2;
        for (var2 = this.get(var1).intValue() + 1; var2 >= this.labelValues.length; var2 -= this.labelValues.length)
        {
            ;
        }

        this.set(Integer.valueOf(var2), var1);
    }

    public void set(Integer var1, String var2)
    {
        this.values.put(var2, var1);
        if (this.parent != null)
        {
            this.parent.save(var2);
        }

        /*
        if (this.displayWidget != null)
        {
            this.displayWidget.update();
        }
        */
    }

    public void set(String var1)
    {
        this.set(var1, ModSettings.currentContext);
    }

    public void set(String var1, String var2)
    {
        int var3 = -1;

        for (int var4 = 0; var4 < this.labelValues.length; ++var4)
        {
            if (this.labelValues[var4].equals(var1))
            {
                var3 = var4;
            }
        }

        if (var3 != -1)
        {
            this.set(Integer.valueOf(var3), var2);
        }
    }

    public String toString(String var1)
    {
        return this.labelValues[this.get(var1).intValue()];
    }

    public void set(Object var1, String var2)
    {
        this.set((Integer)var1, var2);
    }
}
