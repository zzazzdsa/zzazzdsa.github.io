package net.minecraft.src;

import net.minecraft.src.EntityPlayer;
import net.minecraft.src.IInventory;
import net.minecraft.src.ItemStack;

public class MoCAnimalChest implements IInventory
{
    private String localstring;
    public ItemStack[] cheststack;

    public MoCAnimalChest(ItemStack[] var1, String var2)
    {
        this.cheststack = var1;
        this.localstring = var2;
    }

    public boolean isUseableByPlayer(EntityPlayer var1)
    {
        return true;
    }

    public void closeChest() {}

    public ItemStack decrStackSize(int var1, int var2)
    {
        if (this.cheststack[var1] != null)
        {
            ItemStack var3;
            if (this.cheststack[var1].stackSize <= var2)
            {
                var3 = this.cheststack[var1];
                this.cheststack[var1] = null;
                this.onInventoryChanged();
                return var3;
            }
            else
            {
                var3 = this.cheststack[var1].splitStack(var2);
                if (this.cheststack[var1].stackSize == 0)
                {
                    this.cheststack[var1] = null;
                }

                this.onInventoryChanged();
                return var3;
            }
        }
        else
        {
            return null;
        }
    }

    public int getInventoryStackLimit()
    {
        return 64;
    }

    public String getInvName()
    {
        return this.localstring;
    }

    public int getSizeInventory()
    {
        return 27;
    }

    public ItemStack getStackInSlot(int var1)
    {
        return this.cheststack[var1];
    }

    public void onInventoryChanged() {}

    public void openChest() {}

    public void setInventorySlotContents(int var1, ItemStack var2)
    {
        this.cheststack[var1] = var2;
        if (var2 != null && var2.stackSize > this.getInventoryStackLimit())
        {
            var2.stackSize = this.getInventoryStackLimit();
        }

        this.onInventoryChanged();
    }
}
