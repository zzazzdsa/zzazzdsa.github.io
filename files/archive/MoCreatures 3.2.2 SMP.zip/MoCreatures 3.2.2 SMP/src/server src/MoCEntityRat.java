package net.minecraft.src;

import java.util.Iterator;
import java.util.List;
import net.minecraft.src.AxisAlignedBB;
import net.minecraft.src.DamageSource;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityArrow;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.MoCEntityMob;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityRat extends MoCEntityMob
{
    private boolean textureSet;

    public MoCEntityRat(World var1)
    {
        super(var1);
        this.texture = "/mocreatures/ratb.png";
        this.textureSet = false;
        this.setSize(0.5F, 0.5F);
        this.health = 10;
        this.attackStrength = 1;
    }

    protected void attackEntity(Entity var1, float var2)
    {
        float var3 = this.getEntityBrightness(1.0F);
        if (var3 > 0.5F && this.rand.nextInt(100) == 0)
        {
            this.entityToAttack = null;
        }
        else
        {
            super.attackEntity(var1, var2);
        }
    }

    public boolean attackEntityFrom(DamageSource var1, int var2)
    {
        if (!super.attackEntityFrom(var1, var2))
        {
            return false;
        }
        else
        {
            Entity var3 = var1.getEntity();
            if (var3 instanceof EntityPlayer)
            {
                this.entityToAttack = var3;
            }

            if (var3 instanceof EntityArrow && ((EntityArrow)var3).shootingEntity != null)
            {
                var3 = ((EntityArrow)var3).shootingEntity;
            }

            if (var3 instanceof EntityLiving)
            {
                List var4 = this.worldObj.getEntitiesWithinAABB(MoCEntityRat.class, AxisAlignedBB.getBoundingBoxFromPool(this.posX, this.posY, this.posZ, this.posX + 1.0D, this.posY + 1.0D, this.posZ + 1.0D).expand(16.0D, 4.0D, 16.0D));
                Iterator var5 = var4.iterator();

                while (var5.hasNext())
                {
                    Entity var6 = (Entity)var5.next();
                    MoCEntityRat var7 = (MoCEntityRat)var6;
                    if (var7 != null && var7.entityToAttack == null)
                    {
                        var7.entityToAttack = var3;
                    }
                }
            }

            return true;
        }
    }

    public void chooseType()
    {
        if (this.getType() == 0)
        {
            int var1 = this.rand.nextInt(100);
            if (var1 <= 65)
            {
                this.setType(1);
            }
            else if (var1 <= 98)
            {
                this.setType(2);
            }
            else
            {
                this.setType(3);
            }
        }

        if (!this.getTypeChosen())
        {
            if (this.getType() == 1)
            {
                this.texture = "/mocreatures/ratb.png";
            }
            else if (this.getType() == 2)
            {
                this.texture = "/mocreatures/ratbl.png";
            }
            else if (this.getType() == 3)
            {
                this.texture = "/mocreatures/ratw.png";
            }
        }

        this.setTypeChosen(true);
    }

    public boolean climbing()
    {
        return !this.onGround && this.isOnLadder();
    }

    protected Entity findPlayerToAttack()
    {
        float var1 = this.getEntityBrightness(1.0F);
        return var1 < 0.5F ? this.worldObj.getClosestPlayerToEntity(this, 16.0D) : null;
    }

    public boolean getCanSpawnHere()
    {
        return ((Integer)mod_mocreatures.ratfreq.get()).intValue() > 0 && super.getCanSpawnHere();
    }

    protected String getDeathSound()
    {
        return "ratdying";
    }

    protected int getDropItemId()
    {
        return Item.coal.shiftedIndex;
    }

    /*
    public String getEntityTexture()
    {
        if (!this.getTypeChosen() && !this.worldObj.isRemote)
        {
            this.chooseType();
        }

        if (this.worldObj.isRemote && !this.textureSet && this.getTexture() != null && !this.getTexture().equals(""))
        {
            this.texture = this.getTexture();
        }

        return super.getEntityTexture();
    }
    */

    protected String getHurtSound()
    {
        return "rathurt";
    }

    protected String getLivingSound()
    {
        return "ratgrunt";
    }

    public int getMaxSpawnedInChunk()
    {
        return 5;
    }

    public boolean isOnLadder()
    {
        return this.isCollidedHorizontally;
    }

    public void readEntityFromNBT(NBTTagCompound var1)
    {
        super.readEntityFromNBT(var1);
        this.setType(var1.getInteger("TypeInt"));
    }

    public void writeEntityToNBT(NBTTagCompound var1)
    {
        super.writeEntityToNBT(var1);
        var1.setInteger("TypeInt", this.getType());
    }
}
