package net.minecraft.src;

import net.minecraft.src.ModSettings;
import net.minecraft.src.Setting;

public class SettingInt extends Setting
{
    public int maximumValue;
    public int minimumValue;
    public int stepValue;

    public SettingInt(String var1)
    {
        this(var1, 0, 0, 1, 100);
    }

    public SettingInt(String var1, int var2)
    {
        this(var1, var2, 0, 1, 100);
    }

    public SettingInt(String var1, int var2, int var3, int var4)
    {
        this(var1, var2, var3, 1, var4);
    }

    public SettingInt(String var1, int var2, int var3, int var4, int var5)
    {
        this.values.put("", Integer.valueOf(var2));
        this.defaultValue = Integer.valueOf(var2);
        this.minimumValue = var3;
        this.stepValue = var4;
        this.maximumValue = var5;
        this.backendName = var1;
        if (this.minimumValue > this.maximumValue)
        {
            int var6 = this.minimumValue;
            this.minimumValue = this.maximumValue;
            this.maximumValue = var6;
        }
    }

    public void fromString(String var1, String var2)
    {
        this.values.put(var2, new Integer(var1));
        /*
        if (this.displayWidget != null)
        {
            this.displayWidget.update();
        }
        */

        ModSettings.dbgout("fromstring " + var1);
    }

    public Integer get(String var1)
    {
        return this.values.get(var1) != null ? (Integer)this.values.get(var1) : (this.values.get("") != null ? (Integer)this.values.get("") : (Integer)this.defaultValue);
    }

    public void set(Integer var1, String var2)
    {
        ModSettings.dbgout("set " + var1);
        if (this.stepValue > 1)
        {
            this.values.put(var2, Integer.valueOf((int)((float)Math.round((float)var1.intValue() / (float)this.stepValue) * (float)this.stepValue)));
        }
        else
        {
            this.values.put(var2, var1);
        }

        if (this.parent != null)
        {
            this.parent.save(var2);
        }

        /*
        if (this.displayWidget != null)
        {
            this.displayWidget.update();
        }
        */
    }

    public String toString(String var1)
    {
        return "" + this.get(var1);
    }

    public void set(Object var1, String var2)
    {
        this.set((Integer)var1, var2);
    }
}
