package net.minecraft.src;

import java.util.List;
import net.minecraft.src.DamageSource;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityItem;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityMob;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.EntityWaterMob;
import net.minecraft.src.Item;
import net.minecraft.src.Material;
import net.minecraft.src.MathHelper;
import net.minecraft.src.MoCTools;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.PathEntity;
import net.minecraft.src.World;

public class MoCEntityAquatic extends EntityWaterMob
{
    private PathEntity pathEntity;
    private int outOfWater = 0;
    private int temper;
    private float edad;
    private boolean displayName;
    private boolean isAdult;
    private boolean isTamed;
    private int type;
    private String myName = "";
    private boolean chosenType;
    private int maxHealth;
    private boolean diving;
    private int divingCount;
    private boolean maJump;

    public MoCEntityAquatic(World var1)
    {
        super(var1);
        this.setTamed(false);
        if (!this.worldObj.isRemote)
        {
            this.setTemper(50);
        }
    }

    public float b(float var1, float var2, float var3)
    {
        float var4;
        for (var4 = var2 - var1; var4 < -180.0F; var4 += 360.0F)
        {
            ;
        }

        while (var4 >= 180.0F)
        {
            var4 -= 360.0F;
        }

        if (var4 > var3)
        {
            var4 = var3;
        }

        if (var4 < -var3)
        {
            var4 = -var3;
        }

        return var1 + var4;
    }

    public void faceItem(int var1, int var2, int var3, float var4)
    {
        double var5 = (double)var1 - this.posX;
        double var7 = (double)var3 - this.posZ;
        double var9 = (double)var2 - this.posY;
        double var11 = (double)MathHelper.sqrt_double(var5 * var5 + var7 * var7);
        float var13 = (float)(Math.atan2(var7, var5) * 180.0D / 3.141592741012573D) - 90.0F;
        float var14 = (float)(Math.atan2(var9, var11) * 180.0D / 3.141592741012573D);
        this.rotationPitch = -this.b(this.rotationPitch, var14, var4);
        this.rotationYaw = this.b(this.rotationYaw, var13, var4);
    }

    protected boolean canDespawn()
    {
        return !this.getIsTamed();
    }

    protected void fall(float var1)
    {
        if (!this.isInWater())
        {
            super.fall(var1);
        }
    }

    public EntityItem getClosestFish(Entity var1, double var2)
    {
        double var4 = -1.0D;
        EntityItem var6 = null;
        List var7 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(var2, var2, var2));

        for (int var8 = 0; var8 < var7.size(); ++var8)
        {
            Entity var9 = (Entity)var7.get(var8);
            if (var9 instanceof EntityItem)
            {
                EntityItem var10 = (EntityItem)var9;
                if (var10.item.itemID == Item.fishRaw.shiftedIndex && var10.isInWater())
                {
                    double var11 = var10.getDistanceSq(var1.posX, var1.posY, var1.posZ);
                    if ((var2 < 0.0D || var11 < var2 * var2) && (var4 == -1.0D || var11 < var4))
                    {
                        var4 = var11;
                        var6 = var10;
                    }
                }
            }
        }

        return var6;
    }

    public boolean getDisplayName()
    {
        return this.displayName;
    }

    public boolean getIsAdult()
    {
        return this.isAdult;
    }

    public boolean getIsTamed()
    {
        return this.isTamed;
    }

    public String getName()
    {
        return this.myName;
    }

    public String getTexture()
    {
        return this.texture;
    }

    public float getEdad()
    {
        return this.edad;
    }

    public int getType()
    {
        return this.type;
    }

    public int getTemper()
    {
        return this.temper;
    }

    public boolean getTypeChosen()
    {
        return this.chosenType;
    }

    public int getMaxHealth()
    {
        return this.maxHealth;
    }

    public void setMaxHealth(int var1)
    {
        this.maxHealth = var1;
    }

    public void setEdad(float var1)
    {
        this.edad = var1;
    }

    public void setAdult(boolean var1)
    {
        this.isAdult = var1;
    }

    public void setDisplayName(boolean var1)
    {
        this.displayName = var1;
    }

    public void setName(String var1)
    {
        this.myName = var1;
    }

    public void setTamed(boolean var1)
    {
        this.isTamed = var1;
    }

    public void setTexture(String var1)
    {
        this.texture = var1;
    }

    public void setTypeChosen(boolean var1)
    {
        this.chosenType = var1;
    }

    public void setType(int var1)
    {
        this.type = var1;
    }

    public void setTemper(int var1)
    {
        this.temper = var1;
    }

    protected String getDeathSound()
    {
        return null;
    }

    protected String getHurtSound()
    {
        return null;
    }

    protected String getLivingSound()
    {
        return null;
    }

    protected float getSoundVolume()
    {
        return 0.4F;
    }

    public boolean gettingOutOfWater()
    {
        int var1 = (int)this.posX;
        int var2 = (int)this.posY;
        int var3 = (int)this.posZ;
        boolean var4 = true;
        int var5 = this.worldObj.getBlockId(var1, var2 + 1, var3);
        return var5 == 0;
    }

    protected String getUpsetSound()
    {
        return null;
    }

    public boolean handleWaterMovement()
    {
        return this.worldObj.handleMaterialAcceleration(this.boundingBox, Material.water, this);
    }

    public void moveEntityWithHeading(float var1, float var2)
    {
        if (this.riddenByEntity != null && !this.getIsTamed() && !this.worldObj.isRemote)
        {
            if (this.rand.nextInt(5) == 0 && !this.maJump)
            {
                this.motionY += 0.4D;
                this.maJump = true;
            }

            if (this.rand.nextInt(10) == 0)
            {
                this.motionX += this.rand.nextDouble() / 30.0D;
                this.motionZ += this.rand.nextDouble() / 10.0D;
            }

            this.moveEntity(this.motionX, this.motionY, this.motionZ);
            if (this.rand.nextInt(50) == 0)
            {
                this.worldObj.playSoundAtEntity(this, this.getUpsetSound(), 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
                this.riddenByEntity.motionY += 0.9D;
                this.riddenByEntity.motionZ -= 0.3D;
                this.riddenByEntity = null;
            }

            if (this.onGround)
            {
                this.maJump = false;
            }

            if (this.rand.nextInt(this.getTemper() * 8) == 0)
            {
                this.setTamed(true);
            }
        }
        else if (this.riddenByEntity != null && this.getIsTamed())
        {
            this.boundingBox.maxY = this.riddenByEntity.boundingBox.maxY;
            this.motionX += this.riddenByEntity.motionX * (this.speed() / 10.0D);
            this.motionZ += this.riddenByEntity.motionZ * (this.speed() / 10.0D);
            if (!this.worldObj.isRemote)
            {
                this.moveEntity(this.motionX, this.motionY, this.motionZ);
            }

            this.rotationPitch = this.riddenByEntity.rotationPitch * 0.5F;
            this.prevRotationYaw = this.rotationYaw = this.riddenByEntity.rotationYaw;
            this.setRotation(this.rotationYaw, this.rotationPitch);
        }

        super.moveEntityWithHeading(var1, var2);
    }

    protected boolean MoveToNextEntity(Entity var1)
    {
        if (var1 != null)
        {
            int var2 = MathHelper.floor_double(var1.posX);
            int var3 = MathHelper.floor_double(var1.posY);
            int var4 = MathHelper.floor_double(var1.posZ);
            this.faceItem(var2, var3, var4, 30.0F);
            double var5;
            if (this.posX < (double)var2)
            {
                var5 = var1.posX - this.posX;
                if (var5 > 0.5D)
                {
                    this.motionX += 0.05D;
                }
            }
            else
            {
                var5 = this.posX - var1.posX;
                if (var5 > 0.5D)
                {
                    this.motionX -= 0.05D;
                }
            }

            if (this.posZ < (double)var4)
            {
                var5 = var1.posZ - this.posZ;
                if (var5 > 0.5D)
                {
                    this.motionZ += 0.05D;
                }
            }
            else
            {
                var5 = this.posZ - var1.posZ;
                if (var5 > 0.5D)
                {
                    this.motionZ -= 0.05D;
                }
            }

            return true;
        }
        else
        {
            return false;
        }
    }

    public double speed()
    {
        return 1.5D;
    }

    public boolean isInWater()
    {
        return false;
    }

    public boolean canBreatheUnderwater()
    {
        return true;
    }

    public boolean isDiving()
    {
        return this.diving;
    }

    protected void jump() {}

    public void floating()
    {
        float var1 = MoCTools.distanceToSurface(this);
        if (this.riddenByEntity != null)
        {
            EntityPlayer var2 = (EntityPlayer)this.riddenByEntity;
            if (var2.isJumping)
            {
                this.motionY += 0.09D;
            }
            else
            {
                this.motionY = -0.008D;
            }
        }
        else if (this.entityToAttack != null && this.entityToAttack.posY < this.posY - 0.5D && this.getDistanceToEntity(this.entityToAttack) < 10.0F)
        {
            if (this.motionY < -0.1D)
            {
                this.motionY = -0.1D;
            }
        }
        else
        {
            if (var1 >= 1.0F && !this.isDiving())
            {
                if (this.motionY < 0.0D)
                {
                    this.motionY = 0.0D;
                }

                this.motionY += 0.001D;
                if (var1 > 1.0F)
                {
                    this.motionY += (double)var1 * 0.02D;
                    if (this.motionY > 0.2D)
                    {
                        this.motionY = 0.2D;
                    }
                }
            }
            else if (this.motionY < -0.05D)
            {
                this.motionY = -0.05D;
            }
        }
    }

    public void Riding()
    {
        if (this.riddenByEntity != null && this.riddenByEntity instanceof EntityPlayer)
        {
            EntityPlayer var1 = (EntityPlayer)this.riddenByEntity;
            List var2 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(1.0D, 0.0D, 1.0D));
            if (var2 != null)
            {
                for (int var3 = 0; var3 < var2.size(); ++var3)
                {
                    Entity var4 = (Entity)var2.get(var3);
                    if (!var4.isDead)
                    {
                        var4.onCollideWithPlayer(var1);
                        if (var4 instanceof EntityMob)
                        {
                            float var5 = this.getDistanceToEntity(var4);
                            if (var5 < 2.0F && this.rand.nextInt(10) == 0)
                            {
                                this.attackEntityFrom(DamageSource.causeMobDamage((EntityLiving)var4), ((EntityMob)var4).attackStrength);
                            }
                        }
                    }
                }
            }

            if (var1.isSneaking() && !this.worldObj.isRemote)
            {
                var1.mountEntity((Entity)null);
            }
        }
    }

    protected boolean isMovementCeased()
    {
        return !this.isSwimming() && this.riddenByEntity == null;
    }

    public void onLivingUpdate()
    {
        if (this.isSwimming())
        {
            this.floating();
            this.Riding();
            this.outOfWater = 0;
        }
        else
        {
            ++this.outOfWater;
            if (this.outOfWater > 10)
            {
                this.setPathToEntity((PathEntity)null);
            }

            if (this.outOfWater > 200 && this.outOfWater % 30 == 0)
            {
                this.motionY += 0.3D;
                this.motionX = (double)((float)(Math.random() * 0.2D - 0.1D));
                this.motionZ = (double)((float)(Math.random() * 0.2D - 0.1D));
                this.attackEntityFrom(DamageSource.drown, 1);
            }
        }

        if (!this.hasPath() && this.riddenByEntity == null && !this.isMovementCeased() && this.entityToAttack == null)
        {
            this.updateWanderPath();
        }

        if (!this.diving)
        {
            if (this.riddenByEntity == null && this.entityToAttack == null && this.hasPath() && this.rand.nextInt(500) == 0)
            {
                this.diving = true;
            }
        }
        else
        {
            ++this.divingCount;
            if (this.divingCount > 100 || this.riddenByEntity != null)
            {
                this.diving = false;
                this.divingCount = 0;
            }
        }

        super.onLivingUpdate();
    }

    public boolean isSwimming()
    {
        return this.isInsideOfMaterial(Material.water);
    }

    public void readEntityFromNBT(NBTTagCompound var1)
    {
        super.readEntityFromNBT(var1);
    }

    public void writeEntityToNBT(NBTTagCompound var1)
    {
        super.writeEntityToNBT(var1);
    }
}
