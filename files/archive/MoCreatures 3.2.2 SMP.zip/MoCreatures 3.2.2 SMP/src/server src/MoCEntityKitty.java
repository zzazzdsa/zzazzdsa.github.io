package net.minecraft.src;

import java.util.List;
import net.minecraft.src.Block;
import net.minecraft.src.DamageSource;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityItem;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityMob;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.Material;
import net.minecraft.src.MathHelper;
import net.minecraft.src.MoCEntityAnimal;
import net.minecraft.src.MoCEntityDeer;
import net.minecraft.src.MoCEntityHorse;
import net.minecraft.src.MoCEntityKittyBed;
import net.minecraft.src.MoCEntityLitterBox;
import net.minecraft.src.MoCTools;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.PathEntity;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityKitty extends MoCEntityAnimal
{
    private boolean textureSet;
    private int kittytimer;
    private int madtimer;
    private boolean foundTree;
    private int[] treeCoord = new int[] { -1, -1, -1};
    private int displaycount;
    private int kittyState;
    private boolean isSleeping;
    private boolean isSwinging;
    private boolean isSitting;
    private boolean onTree;
    private boolean isHungry;
    private boolean displayEmo;

    public MoCEntityKitty(World var1)
    {
        super(var1);
        this.setSize(0.7F, 0.5F);
        this.texture = "/mocreatures/pussycata.png";
        this.textureSet = false;
        this.field_9100_aZ = true;
        this.setAdult(true);
        this.setEdad(0.4F);
        this.setKittyState(1);
        this.kittytimer = 0;
        this.health = 15;
        this.madtimer = this.rand.nextInt(5);
        this.setMaxHealth(15);
        this.foundTree = false;
    }

    protected void attackEntity(Entity var1, float var2)
    {
        if (!this.worldObj.isRemote)
        {
            if (var2 > 2.0F && var2 < 6.0F && this.rand.nextInt(30) == 0 && this.onGround)
            {
                double var3 = var1.posX - this.posX;
                double var5 = var1.posZ - this.posZ;
                float var7 = MathHelper.sqrt_double(var3 * var3 + var5 * var5);
                this.motionX = var3 / (double)var7 * 0.5D * 0.8D + this.motionX * 0.2D;
                this.motionZ = var5 / (double)var7 * 0.5D * 0.8D + this.motionZ * 0.2D;
                this.motionY = 0.4D;
            }

            if ((double)var2 < 2.0D && var1.boundingBox.maxY > this.boundingBox.minY && var1.boundingBox.minY < this.boundingBox.maxY)
            {
                this.attackTime = 20;
                if (this.getKittyState() != 18 && this.getKittyState() != 10)
                {
                    this.swingArm();
                }

                if (this.getKittyState() == 13 && var1 instanceof EntityPlayer || this.getKittyState() == 8 && var1 instanceof EntityItem || this.getKittyState() == 18 && var1 instanceof MoCEntityKitty || this.getKittyState() == 10)
                {
                    return;
                }

                var1.attackEntityFrom(DamageSource.causeMobDamage(this), 1);
            }
        }
    }

    public boolean attackEntityFrom(DamageSource var1, int var2)
    {
        if (super.attackEntityFrom(var1, var2))
        {
            Entity var3 = var1.getEntity();
            if (var3 != this)
            {
                if (this.getKittyState() == 10)
                {
                    List var4 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(16.0D, 6.0D, 16.0D));

                    for (int var5 = 0; var5 < var4.size(); ++var5)
                    {
                        Entity var6 = (Entity)var4.get(var5);
                        if (var6 instanceof MoCEntityKitty && ((MoCEntityKitty)var6).getKittyState() == 21)
                        {
                            ((MoCEntityKitty)var6).entityToAttack = var3;
                            return true;
                        }
                    }

                    return true;
                }

                if (var3 instanceof EntityPlayer)
                {
                    if (this.getKittyState() < 2)
                    {
                        this.entityToAttack = var3;
                        this.setKittyState(-1);
                    }

                    if (this.getKittyState() != 19 && this.getKittyState() != 20 && this.getKittyState() != 21)
                    {
                        if (this.getKittyState() > 1 && this.getKittyState() != 10 && this.getKittyState() != 19 && this.getKittyState() != 20 && this.getKittyState() != 21)
                        {
                            this.setKittyState(13);
                            this.setSitting(false);
                        }

                        return true;
                    }

                    this.entityToAttack = var3;
                    this.setSitting(false);
                    return true;
                }

                this.entityToAttack = var3;
            }

            return true;
        }
        else
        {
            return false;
        }
    }

    private float b(float var1, float var2, float var3)
    {
        float var4;
        for (var4 = var2 - var1; var4 < -180.0F; var4 += 360.0F)
        {
            ;
        }

        while (var4 >= 180.0F)
        {
            var4 -= 360.0F;
        }

        if (var4 > var3)
        {
            var4 = var3;
        }

        if (var4 < -var3)
        {
            var4 = -var3;
        }

        return var1 + var4;
    }

    protected boolean canDespawn()
    {
        return this.getKittyState() < 3;
    }

    private void changeKittyState(int var1)
    {
        this.setKittyState(var1);
        this.mountEntity((Entity)null);
        this.setSitting(false);
        this.kittytimer = 0;
        this.setOnTree(false);
        this.foundTree = false;
        this.entityToAttack = null;
    }

    public void chooseType()
    {
        if (this.getType() == 0)
        {
            int var1 = this.rand.nextInt(100);
            if (var1 <= 15)
            {
                this.setType(1);
            }
            else if (var1 <= 30)
            {
                this.setType(2);
            }
            else if (var1 <= 45)
            {
                this.setType(3);
            }
            else if (var1 <= 60)
            {
                this.setType(4);
            }
            else if (var1 <= 70)
            {
                this.setType(5);
            }
            else if (var1 <= 80)
            {
                this.setType(6);
            }
            else if (var1 <= 90)
            {
                this.setType(7);
            }
            else
            {
                this.setType(8);
            }
        }

        if (!this.getTypeChosen())
        {
            if (this.getType() == 1)
            {
                this.texture = "/mocreatures/pussycata.png";
            }
            else if (this.getType() == 2)
            {
                this.texture = "/mocreatures/pussycatb.png";
            }
            else if (this.getType() == 3)
            {
                this.texture = "/mocreatures/pussycatc.png";
            }
            else if (this.getType() == 4)
            {
                this.texture = "/mocreatures/pussycatd.png";
            }
            else if (this.getType() == 5)
            {
                this.texture = "/mocreatures/pussycate.png";
            }
            else if (this.getType() == 6)
            {
                this.texture = "/mocreatures/pussycatf.png";
            }
            else if (this.getType() == 7)
            {
                this.texture = "/mocreatures/pussycatg.png";
            }

            if (this.getType() == 8)
            {
                this.texture = "/mocreatures/pussycath.png";
            }
        }

        this.setTypeChosen(true);
    }

    public boolean climbingTree()
    {
        return this.getKittyState() == 16 && this.isOnLadder();
    }

    public void faceTreeTop(int var1, int var2, int var3, float var4)
    {
        double var5 = (double)var1 - this.posX;
        double var7 = (double)var3 - this.posZ;
        double var9 = (double)var2 - this.posY;
        double var11 = (double)MathHelper.sqrt_double(var5 * var5 + var7 * var7);
        float var13 = (float)(Math.atan2(var7, var5) * 180.0D / 3.141592741012573D) - 90.0F;
        float var14 = (float)(Math.atan2(var9, var11) * 180.0D / 3.141592741012573D);
        this.rotationPitch = -this.b(this.rotationPitch, var14, var4);
        this.rotationYaw = this.b(this.rotationYaw, var13, var4);
    }

    protected void fall(float var1) {}

    protected Entity findPlayerToAttack()
    {
        if (this.worldObj.difficultySetting > 0 && this.getKittyState() != 8 && this.getKittyState() != 10 && this.getKittyState() != 15 && this.getKittyState() != 18 && this.getKittyState() != 19 && !this.isMovementCeased() && this.getIsHungry())
        {
            EntityLiving var1 = this.getClosestTarget(this, 10.0D);
            return var1;
        }
        else
        {
            return null;
        }
    }

    public EntityLiving getBoogey(double var1, boolean var3)
    {
        double var4 = -1.0D;
        EntityLiving var6 = null;
        List var7 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(var1, 4.0D, var1));

        for (int var8 = 0; var8 < var7.size(); ++var8)
        {
            Entity var9 = (Entity)var7.get(var8);
            if (var9 instanceof EntityLiving && !(var9 instanceof MoCEntityDeer) && !(var9 instanceof MoCEntityHorse) && ((double)var9.width >= 0.5D || (double)var9.height >= 0.5D) && (var3 || !(var9 instanceof EntityPlayer)))
            {
                var6 = (EntityLiving)var9;
            }
        }

        return var6;
    }

    public boolean getCanSpawnHere()
    {
        return ((Integer)mod_mocreatures.kittyfreq.get()).intValue() > 0 && super.getCanSpawnHere();
    }

    public EntityLiving getClosestTarget(Entity var1, double var2)
    {
        double var4 = -1.0D;
        EntityLiving var6 = null;
        List var7 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(var2, var2, var2));

        for (int var8 = 0; var8 < var7.size(); ++var8)
        {
            Entity var9 = (Entity)var7.get(var8);
            if (var9 instanceof EntityLiving && !(var9 instanceof MoCEntityKitty) && !(var9 instanceof EntityPlayer) && !(var9 instanceof EntityMob) && !(var9 instanceof MoCEntityKittyBed) && !(var9 instanceof MoCEntityLitterBox) && ((double)var9.width <= 0.5D || (double)var9.height <= 0.5D))
            {
                double var10 = var9.getDistanceSq(var1.posX, var1.posY, var1.posZ);
                if ((var2 < 0.0D || var10 < var2 * var2) && (var4 == -1.0D || var10 < var4) && ((EntityLiving)var9).canEntityBeSeen(var1))
                {
                    var4 = var10;
                    var6 = (EntityLiving)var9;
                }
            }
        }

        return var6;
    }

    protected String getDeathSound()
    {
        return this.getKittyState() == 10 ? "kittendying" : "kittydying";
    }

    public boolean getDisplayEmo()
    {
        return this.displayEmo;
    }

    protected int getDropItemId()
    {
        return 0;
    }

    public String getEmoticon()
    {
        switch (this.getKittyState())
        {
            case -1:
                return "/mocreatures/emoticon2.png";
            case 0:
            case 1:
            case 2:
            case 6:
            case 14:
            case 15:
            default:
                return "/mocreatures/emoticon1.png";
            case 3:
                return "/mocreatures/emoticon3.png";
            case 4:
                return "/mocreatures/emoticon4.png";
            case 5:
                return "/mocreatures/emoticon5.png";
            case 7:
                return "/mocreatures/emoticon7.png";
            case 8:
                return "/mocreatures/emoticon8.png";
            case 9:
                return "/mocreatures/emoticon9.png";
            case 10:
                return "/mocreatures/emoticon10.png";
            case 11:
                return "/mocreatures/emoticon11.png";
            case 12:
                return "/mocreatures/emoticon12.png";
            case 13:
                return "/mocreatures/emoticon13.png";
            case 16:
                return "/mocreatures/emoticon16.png";
            case 17:
                return "/mocreatures/emoticon17.png";
            case 18:
                return "/mocreatures/emoticon9.png";
            case 19:
                return "/mocreatures/emoticon19.png";
            case 20:
                return "/mocreatures/emoticon19.png";
            case 21:
                return "/mocreatures/emoticon10.png";
        }
    }

    /*
    public String getEntityTexture()
    {
        if (!this.getTypeChosen() && !this.worldObj.isRemote)
        {
            this.chooseType();
        }

        if (this.worldObj.isRemote && !this.textureSet && this.getTexture() != null && !this.getTexture().equals(""))
        {
            this.texture = this.getTexture();
            this.textureSet = true;
        }

        return super.getEntityTexture();
    }
    */

    protected String getHurtSound()
    {
        return this.getKittyState() == 10 ? "kittenhurt" : "kittyhurt";
    }

    public boolean getIsHungry()
    {
        return this.isHungry;
    }

    public boolean getIsSitting()
    {
        return this.isSitting;
    }

    public boolean getIsSwinging()
    {
        return this.isSwinging;
    }

    public int getKittyState()
    {
        return this.kittyState;
    }

    public EntityLiving getKittyStuff(Entity var1, double var2, boolean var4)
    {
        double var5 = -1.0D;
        Object var7 = null;
        List var8 = this.worldObj.getEntitiesWithinAABBExcludingEntity(var1, this.boundingBox.expand(var2, var2, var2));

        for (int var9 = 0; var9 < var8.size(); ++var9)
        {
            Entity var10 = (Entity)var8.get(var9);
            double var12;
            if (var4)
            {
                if (var10 instanceof MoCEntityLitterBox)
                {
                    MoCEntityLitterBox var11 = (MoCEntityLitterBox)var10;
                    if (!var11.getUsedLitter())
                    {
                        var12 = var10.getDistanceSq(var1.posX, var1.posY, var1.posZ);
                        if ((var2 < 0.0D || var12 < var2 * var2) && (var5 == -1.0D || var12 < var5) && var11.canEntityBeSeen(var1))
                        {
                            var5 = var12;
                            var7 = var11;
                        }
                    }
                }
            }
            else if (var10 instanceof MoCEntityKittyBed)
            {
                MoCEntityKittyBed var14 = (MoCEntityKittyBed)var10;
                var12 = var10.getDistanceSq(var1.posX, var1.posY, var1.posZ);
                if ((var2 < 0.0D || var12 < var2 * var2) && (var5 == -1.0D || var12 < var5) && var14.canEntityBeSeen(var1))
                {
                    var5 = var12;
                    var7 = var14;
                }
            }
        }

        return (EntityLiving)((EntityLiving)var7);
    }

    protected String getLivingSound()
    {
        if (this.getKittyState() == 4)
        {
            if (this.ridingEntity != null)
            {
                MoCEntityKittyBed var1 = (MoCEntityKittyBed)this.ridingEntity;
                if (var1 != null && !var1.getHasMilk())
                {
                    return "kittyeatingm";
                }

                if (var1 != null && !var1.getHasFood())
                {
                    return "kittyeatingf";
                }
            }

            return null;
        }
        else
        {
            return this.getKittyState() == 6 ? "kittylitter" : (this.getKittyState() == 3 ? "kittyfood" : (this.getKittyState() == 10 ? "kittengrunt" : (this.getKittyState() == 13 ? "kittyupset" : (this.getKittyState() == 17 ? "kittytrapped" : (this.getKittyState() != 18 && this.getKittyState() != 12 ? "kittygrunt" : "kittypurr")))));
        }
    }

    public int getMaxSpawnedInChunk()
    {
        return 2;
    }

    public boolean getOnTree()
    {
        return this.onTree;
    }

    public double getYOffset()
    {
        if (this.ridingEntity instanceof EntityPlayer && !this.worldObj.isRemote)
        {
            if (this.getKittyState() == 10)
            {
                return (double)(this.yOffset - 1.1F);
            }

            if (this.upsideDown())
            {
                return (double)(this.yOffset - 1.7F);
            }

            if (this.onMaBack())
            {
                return (double)(this.yOffset - 1.5F);
            }
        }

        return (double)this.yOffset;
    }

    public boolean interact(EntityPlayer var1)
    {
        ItemStack var2 = var1.inventory.getCurrentItem();
        if (this.getKittyState() == 2 && var2 != null && var2.itemID == mod_mocreatures.medallion.shiftedIndex)
        {
            if (--var2.stackSize == 0)
            {
                var1.inventory.setInventorySlotContents(var1.inventory.currentItem, (ItemStack)null);
            }

            this.changeKittyState(3);
            this.health = this.getMaxHealth();
            //mod_mocreatures.setName((MoCEntityAnimal)this);
            return true;
        }
        else if (this.getKittyState() == 7 && var2 != null && var2.itemID == Item.cake.shiftedIndex)
        {
            if (--var2.stackSize == 0)
            {
                var1.inventory.setInventorySlotContents(var1.inventory.currentItem, (ItemStack)null);
            }

            this.worldObj.playSoundAtEntity(this, "kittyeatingf", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
            this.changeKittyState(9);
            return true;
        }
        else if (this.getKittyState() == 11 && var2 != null && var2.itemID == mod_mocreatures.woolball.shiftedIndex)
        {
            if (--var2.stackSize == 0)
            {
                var1.inventory.setInventorySlotContents(var1.inventory.currentItem, (ItemStack)null);
            }

            this.setKittyState(8);
            EntityItem var3 = new EntityItem(this.worldObj, this.posX, this.posY + 1.0D, this.posZ, new ItemStack(mod_mocreatures.woolball, 1));
            var3.delayBeforeCanPickup = 30;
            var3.age = -10000;
            this.worldObj.spawnEntityInWorld(var3);
            var3.motionY += (double)(this.worldObj.rand.nextFloat() * 0.05F);
            var3.motionX += (double)((this.worldObj.rand.nextFloat() - this.worldObj.rand.nextFloat()) * 0.3F);
            var3.motionZ += (double)((this.worldObj.rand.nextFloat() - this.worldObj.rand.nextFloat()) * 0.3F);
            this.entityToAttack = var3;
            return true;
        }
        else if (this.getKittyState() == 13 && var2 != null && (var2.itemID == Item.fishRaw.shiftedIndex || var2.itemID == Item.fishCooked.shiftedIndex))
        {
            if (--var2.stackSize == 0)
            {
                var1.inventory.setInventorySlotContents(var1.inventory.currentItem, (ItemStack)null);
            }

            this.worldObj.playSoundAtEntity(this, "kittyeatingf", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
            this.changeKittyState(7);
            return true;
        }
        else if (var2 != null && this.getKittyState() > 2 && (var2.itemID == Item.pickaxeDiamond.shiftedIndex || var2.itemID == Item.pickaxeWood.shiftedIndex || var2.itemID == Item.pickaxeStone.shiftedIndex || var2.itemID == Item.pickaxeSteel.shiftedIndex || var2.itemID == Item.pickaxeGold.shiftedIndex))
        {
            this.setDisplayName(!this.getDisplayName());
            return true;
        }
        else if (var2 != null && this.getKittyState() > 2 && (var2.itemID == mod_mocreatures.medallion.shiftedIndex || var2.itemID == Item.book.shiftedIndex))
        {
            //mod_mocreatures.setName((MoCEntityAnimal)this);
            return true;
        }
        else if (var2 != null && this.getKittyState() > 2 && this.pickable() && var2.itemID == mod_mocreatures.rope.shiftedIndex)
        {
            this.changeKittyState(14);
            this.mountEntity(var1);
            return true;
        }
        else if (var2 != null && this.getKittyState() > 2 && this.whipeable() && var2.itemID == mod_mocreatures.whip.shiftedIndex)
        {
            this.setSitting(!this.getIsSitting());
            return true;
        }
        else if (var2 == null && this.getKittyState() == 10 && this.ridingEntity != null)
        {
            this.ridingEntity = null;
            return true;
        }
        else if (var2 == null && this.getKittyState() > 2 && this.pickable())
        {
            this.changeKittyState(15);
            this.mountEntity(var1);
            return true;
        }
        else if (var2 == null && this.getKittyState() == 15)
        {
            this.changeKittyState(7);
            return true;
        }
        else
        {
            return false;
        }
    }

    protected boolean isMovementCeased()
    {
        return this.getIsSitting() || this.getKittyState() == 6 || this.getKittyState() == 16 && this.getOnTree() || this.getKittyState() == 12 || this.getKittyState() == 17 || this.getKittyState() == 14 || this.getKittyState() == 20 || this.getKittyState() == 23;
    }

    public boolean isOnLadder()
    {
        return this.getKittyState() != 16 ? super.isOnLadder() : this.isCollidedHorizontally && this.getOnTree();
    }

    public void onLivingUpdate()
    {
        if (!this.worldObj.isRemote)
        {
            if (!this.getIsAdult() && this.getKittyState() != 10)
            {
                this.setKittyState(10);
            }

            if (this.getKittyState() != 12)
            {
                super.onLivingUpdate();
            }

            if (this.rand.nextInt(200) == 0)
            {
                this.setDisplayEmo(!this.getDisplayEmo());
            }

            if (!this.getIsAdult() && this.rand.nextInt(200) == 0)
            {
                this.setEdad(this.getEdad() + 0.005F);
                if (this.getEdad() >= 1.0F)
                {
                    this.setAdult(true);
                    this.field_9100_aZ = false;
                }
            }

            if (!this.getIsHungry() && !this.getIsSitting() && this.rand.nextInt(100) == 0)
            {
                this.setHungry(true);
            }

            List var9;
            float var12;
            Entity var35;
            float var33;
            int var36;
            switch (this.getKittyState())
            {
                case -1:
                case 23:
                    break;
                case 0:
                    this.changeKittyState(1);
                    break;
                case 1:
                    if (this.rand.nextInt(10) == 0)
                    {
                        EntityLiving var1 = this.getBoogey(6.0D, true);
                        if (var1 != null)
                        {
                            this.runLikeHell(var1);
                        }
                    }
                    else if (this.getIsHungry() && this.rand.nextInt(10) == 0)
                    {
                        EntityItem var30 = this.getClosestItem(this, 10.0D, Item.fishCooked.shiftedIndex, Item.fishCooked.shiftedIndex);
                        if (var30 != null)
                        {
                            float var2 = var30.getDistanceToEntity(this);
                            if (var2 > 2.0F)
                            {
                                this.getMyOwnPath(var30, var2);
                            }

                            if (var2 < 2.0F && var30 != null && this.deathTime == 0)
                            {
                                var30.setEntityDead();
                                this.worldObj.playSoundAtEntity(this, "kittyeatingf", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
                                this.setHungry(false);
                                this.setKittyState(2);
                            }
                        }
                    }
                    break;
                case 2:
                    EntityLiving var3 = this.getBoogey(6.0D, false);
                    if (var3 != null)
                    {
                        this.runLikeHell(var3);
                    }
                    break;
                case 3:
                    ++this.kittytimer;
                    if (this.kittytimer > 500)
                    {
                        if (this.rand.nextInt(200) == 0)
                        {
                            this.changeKittyState(13);
                            break;
                        }

                        if (this.rand.nextInt(500) == 0)
                        {
                            this.changeKittyState(7);
                            break;
                        }
                    }

                    if (this.rand.nextInt(20) == 0)
                    {
                        MoCEntityKittyBed var4 = (MoCEntityKittyBed)this.getKittyStuff(this, 18.0D, false);
                        if (var4 != null && var4.riddenByEntity == null && (var4.getHasMilk() || var4.getHasFood()))
                        {
                            float var5 = var4.getDistanceToEntity(this);
                            if (var5 > 2.0F)
                            {
                                this.getMyOwnPath(var4, var5);
                            }

                            if (var5 < 2.0F)
                            {
                                this.changeKittyState(4);
                                this.mountEntity(var4);
                                this.setSitting(true);
                            }
                        }
                    }
                    break;
                case 4:
                    if (this.ridingEntity != null)
                    {
                        MoCEntityKittyBed var31 = (MoCEntityKittyBed)this.ridingEntity;
                        if (var31 != null && !var31.getHasMilk() && !var31.getHasFood())
                        {
                            this.health = this.getMaxHealth();
                            this.changeKittyState(5);
                        }
                    }
                    else
                    {
                        this.health = this.getMaxHealth();
                        this.changeKittyState(5);
                    }

                    if (this.rand.nextInt(2500) == 0)
                    {
                        this.health = this.getMaxHealth();
                        this.changeKittyState(7);
                    }
                    break;
                case 5:
                    ++this.kittytimer;
                    if (this.kittytimer > 2000 && this.rand.nextInt(1000) == 0)
                    {
                        this.changeKittyState(13);
                    }
                    else if (this.rand.nextInt(20) == 0)
                    {
                        MoCEntityLitterBox var6 = (MoCEntityLitterBox)this.getKittyStuff(this, 18.0D, true);
                        if (var6 != null && var6.riddenByEntity == null && !var6.getUsedLitter())
                        {
                            float var7 = var6.getDistanceToEntity(this);
                            if (var7 > 2.0F)
                            {
                                this.getMyOwnPath(var6, var7);
                            }

                            if (var7 < 2.0F)
                            {
                                this.changeKittyState(6);
                                this.mountEntity(var6);
                            }
                        }
                    }
                    break;
                case 6:
                    ++this.kittytimer;
                    if (this.kittytimer > 300)
                    {
                        this.worldObj.playSoundAtEntity(this, "kittypoo", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
                        MoCEntityLitterBox var8 = (MoCEntityLitterBox)this.ridingEntity;
                        if (var8 != null)
                        {
                            var8.setUsedLitter(true);
                            var8.littertime = 0;
                        }

                        this.changeKittyState(7);
                    }
                    break;
                case 7:
                    if (!this.getIsSitting())
                    {
                        if (this.rand.nextInt(20) == 0)
                        {
                            EntityPlayer var34 = this.worldObj.getClosestPlayerToEntity(this, 12.0D);
                            if (var34 != null)
                            {
                                ItemStack var37 = var34.inventory.getCurrentItem();
                                if (var37 != null && var37.itemID == mod_mocreatures.woolball.shiftedIndex)
                                {
                                    this.changeKittyState(11);
                                    return;
                                }
                            }
                        }

                        if (this.inWater && this.rand.nextInt(500) == 0)
                        {
                            this.changeKittyState(13);
                        }
                        else if (this.rand.nextInt(500) == 0 && !this.worldObj.isDaytime())
                        {
                            this.changeKittyState(12);
                        }
                        else if (this.rand.nextInt(2000) == 0)
                        {
                            this.changeKittyState(3);
                        }
                        else if (this.rand.nextInt(4000) == 0)
                        {
                            this.changeKittyState(16);
                        }
                    }
                    break;
                case 8:
                    if (this.inWater && this.rand.nextInt(200) == 0)
                    {
                        this.changeKittyState(13);
                    }
                    else
                    {
                        if (this.entityToAttack != null && this.entityToAttack instanceof EntityItem)
                        {
                            var33 = this.getDistanceToEntity(this.entityToAttack);
                            if (var33 < 1.5F)
                            {
                                this.swingArm();
                                if (this.rand.nextInt(10) == 0)
                                {
                                    this.bigsmack(this, this.entityToAttack, 0.3F);
                                }
                            }
                        }

                        if (this.entityToAttack == null || this.rand.nextInt(1000) == 0)
                        {
                            this.changeKittyState(7);
                        }
                    }
                    break;
                case 9:
                    ++this.kittytimer;
                    if (this.rand.nextInt(50) == 0)
                    {
                        var9 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(16.0D, 6.0D, 16.0D));

                        for (var36 = 0; var36 < var9.size(); ++var36)
                        {
                            var35 = (Entity)var9.get(var36);
                            if (var35 instanceof MoCEntityKitty && var35 instanceof MoCEntityKitty && ((MoCEntityKitty)var35).getKittyState() == 9)
                            {
                                this.changeKittyState(18);
                                this.entityToAttack = var35;
                                ((MoCEntityKitty)var35).changeKittyState(18);
                                ((MoCEntityKitty)var35).entityToAttack = this;
                                break;
                            }
                        }
                    }

                    if (this.kittytimer > 2000)
                    {
                        this.changeKittyState(7);
                    }
                    break;
                case 10:
                    if (this.getIsAdult())
                    {
                        this.changeKittyState(7);
                    }
                    else
                    {
                        if (this.rand.nextInt(50) == 0)
                        {
                            var9 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(16.0D, 6.0D, 16.0D));

                            for (var36 = 0; var36 < var9.size(); ++var36)
                            {
                                var35 = (Entity)var9.get(var36);
                                if (var35 instanceof MoCEntityKitty && ((MoCEntityKitty)var35).getKittyState() == 21)
                                {
                                    var12 = this.getDistanceToEntity(var35);
                                    if (var12 > 12.0F)
                                    {
                                        this.entityToAttack = var35;
                                    }
                                }
                            }
                        }

                        if (this.entityToAttack == null && this.rand.nextInt(100) == 0)
                        {
                            int var32 = this.rand.nextInt(10);
                            if (var32 < 7)
                            {
                                this.entityToAttack = this.getClosestItem(this, 10.0D, -1, -1);
                            }
                            else
                            {
                                this.entityToAttack = this.worldObj.getClosestPlayerToEntity(this, 18.0D);
                            }
                        }

                        if (this.entityToAttack != null && this.rand.nextInt(400) == 0)
                        {
                            this.entityToAttack = null;
                        }

                        if (this.entityToAttack != null && this.entityToAttack instanceof EntityItem)
                        {
                            var33 = this.getDistanceToEntity(this.entityToAttack);
                            if (var33 < 1.5F)
                            {
                                this.swingArm();
                                if (this.rand.nextInt(10) == 0)
                                {
                                    this.bigsmack(this, this.entityToAttack, 0.2F);
                                }
                            }
                        }

                        if (this.entityToAttack != null && this.entityToAttack instanceof MoCEntityKitty && this.rand.nextInt(20) == 0)
                        {
                            var33 = this.getDistanceToEntity(this.entityToAttack);
                            if (var33 < 2.0F)
                            {
                                this.swingArm();
                                this.setPathToEntity((PathEntity)null);
                            }
                        }

                        if (this.entityToAttack != null && this.entityToAttack instanceof EntityPlayer)
                        {
                            var33 = this.getDistanceToEntity(this.entityToAttack);
                            if (var33 < 2.0F && this.rand.nextInt(20) == 0)
                            {
                                this.swingArm();
                            }
                        }
                    }
                    break;
                case 11:
                    EntityPlayer var10 = this.worldObj.getClosestPlayerToEntity(this, 18.0D);
                    if (var10 != null && this.rand.nextInt(10) == 0)
                    {
                        ItemStack var11 = var10.inventory.getCurrentItem();
                        if (var11 != null && (var11 == null || var11.itemID == mod_mocreatures.woolball.shiftedIndex))
                        {
                            var12 = var10.getDistanceToEntity(this);
                            if (var12 > 5.0F)
                            {
                                this.getPathOrWalkableBlock(var10, var12);
                            }
                        }
                        else
                        {
                            this.changeKittyState(7);
                        }
                    }
                    break;
                case 12:
                    ++this.kittytimer;
                    if (!this.worldObj.isDaytime() && (this.kittytimer <= 500 || this.rand.nextInt(500) != 0))
                    {
                        this.setSitting(true);
                        if (this.rand.nextInt(80) == 0 || !this.onGround)
                        {
                            super.onLivingUpdate();
                        }
                    }
                    else
                    {
                        this.changeKittyState(7);
                    }
                    break;
                case 13:
                    this.setHungry(false);
                    this.entityToAttack = this.worldObj.getClosestPlayerToEntity(this, 18.0D);
                    if (this.entityToAttack != null)
                    {
                        float var38 = this.getDistanceToEntity(this.entityToAttack);
                        if (var38 < 1.5F)
                        {
                            this.swingArm();
                            if (this.rand.nextInt(20) == 0)
                            {
                                --this.madtimer;
                                this.entityToAttack.attackEntityFrom(DamageSource.causeMobDamage(this), 1);
                                if (this.madtimer < 1)
                                {
                                    this.changeKittyState(7);
                                    this.madtimer = this.rand.nextInt(5);
                                }
                            }
                        }

                        if (this.rand.nextInt(500) == 0)
                        {
                            this.changeKittyState(7);
                        }
                    }
                    else
                    {
                        this.changeKittyState(7);
                    }
                    break;
                case 14:
                    if (this.onGround)
                    {
                        this.changeKittyState(13);
                    }
                    else
                    {
                        if (this.rand.nextInt(50) == 0)
                        {
                            this.swingArm();
                        }

                        if (this.ridingEntity != null)
                        {
                            this.rotationYaw = this.ridingEntity.rotationYaw + 90.0F;
                            EntityPlayer var13 = (EntityPlayer)this.ridingEntity;
                            if (var13 != null)
                            {
                                ItemStack var14 = var13.inventory.getCurrentItem();
                                if (var14 != null && var14.itemID != mod_mocreatures.rope.shiftedIndex)
                                {
                                    this.changeKittyState(13);
                                }
                            }
                        }
                    }
                    break;
                case 15:
                    if (this.onGround)
                    {
                        this.changeKittyState(7);
                    }

                    if (this.ridingEntity != null)
                    {
                        this.rotationYaw = this.ridingEntity.rotationYaw + 90.0F;
                    }
                    break;
                case 16:
                    ++this.kittytimer;
                    if (this.kittytimer > 500 && !this.getOnTree())
                    {
                        this.changeKittyState(7);
                    }

                    int var17;
                    int var16;
                    if (!this.getOnTree())
                    {
                        if (!this.foundTree && this.rand.nextInt(50) == 0)
                        {
                            int[] var15 = MoCTools.ReturnNearestMaterialCoord(this, Material.wood, Double.valueOf(18.0D), Double.valueOf(4.0D));
                            if (var15[0] != -1)
                            {
                                for (var16 = 0; var16 < 20; ++var16)
                                {
                                    var17 = this.worldObj.getBlockId(var15[0], var15[1] + var16, var15[2]);
                                    if (var17 != 0 && Block.blocksList[var17].blockMaterial != Material.wood && var17 != 0 && Block.blocksList[var17].blockMaterial == Material.leaves)
                                    {
                                        this.foundTree = true;
                                        this.treeCoord[0] = var15[0];
                                        this.treeCoord[1] = var15[1];
                                        this.treeCoord[2] = var15[2];
                                        break;
                                    }
                                }
                            }
                        }

                        if (this.foundTree && this.rand.nextInt(10) == 0)
                        {
                            PathEntity var39 = this.worldObj.getEntityPathToXYZ(this, this.treeCoord[0], this.treeCoord[1], this.treeCoord[2], 24.0F);
                            if (var39 != null)
                            {
                                this.setPathToEntity(var39);
                            }

                            Double var40 = Double.valueOf(this.getDistanceSq((double)this.treeCoord[0], (double)this.treeCoord[1], (double)this.treeCoord[2]));
                            if (var40.doubleValue() < 7.0D)
                            {
                                this.setOnTree(true);
                            }
                        }
                    }
                    else if (this.getOnTree())
                    {
                        int var41 = this.treeCoord[0];
                        var16 = this.treeCoord[1];
                        var17 = this.treeCoord[2];
                        this.faceTreeTop(var41, var16, var17, 30.0F);
                        if (var16 - MathHelper.floor_double(this.posY) > 2)
                        {
                            this.motionY += 0.03D;
                        }

                        boolean var18 = false;
                        boolean var19 = false;
                        int var20;
                        int var10000;
                        if (this.posX < (double)var41)
                        {
                            var10000 = var41 - MathHelper.floor_double(this.posX);
                            this.motionX += 0.01D;
                        }
                        else
                        {
                            var20 = MathHelper.floor_double(this.posX) - var41;
                            this.motionX -= 0.01D;
                        }

                        if (this.posZ < (double)var17)
                        {
                            var10000 = var17 - MathHelper.floor_double(this.posZ);
                            this.motionZ += 0.01D;
                        }
                        else
                        {
                            var20 = MathHelper.floor_double(this.posX) - var17;
                            this.motionZ -= 0.01D;
                        }

                        if (!this.onGround && this.isCollidedHorizontally && this.isCollidedVertically)
                        {
                            for (var20 = 0; var20 < 30; ++var20)
                            {
                                int var43 = this.worldObj.getBlockId(this.treeCoord[0], this.treeCoord[1] + var20, this.treeCoord[2]);
                                if (var43 == 0)
                                {
                                    this.setLocationAndAngles((double)this.treeCoord[0], (double)(this.treeCoord[1] + var20), (double)this.treeCoord[2], this.rotationYaw, this.rotationPitch);
                                    this.changeKittyState(17);
                                    this.treeCoord[0] = -1;
                                    this.treeCoord[1] = -1;
                                    this.treeCoord[2] = -1;
                                    return;
                                }
                            }
                        }
                    }
                    break;
                case 17:
                    EntityPlayer var21 = this.worldObj.getClosestPlayerToEntity(this, 2.0D);
                    if (var21 != null)
                    {
                        this.changeKittyState(7);
                    }
                    break;
                case 18:
                    if (this.entityToAttack != null && this.entityToAttack instanceof MoCEntityKitty)
                    {
                        MoCEntityKitty var22 = (MoCEntityKitty)this.entityToAttack;
                        if (var22 != null && var22.getKittyState() == 18)
                        {
                            if (this.rand.nextInt(50) == 0)
                            {
                                this.swingArm();
                            }

                            float var42 = this.getDistanceToEntity(var22);
                            if (var42 < 5.0F)
                            {
                                ++this.kittytimer;
                            }

                            if (this.kittytimer > 500 && this.rand.nextInt(50) == 0)
                            {
                                ((MoCEntityKitty)this.entityToAttack).changeKittyState(7);
                                this.changeKittyState(19);
                            }
                        }
                        else
                        {
                            this.changeKittyState(9);
                        }
                    }
                    else
                    {
                        this.changeKittyState(9);
                    }
                    break;
                case 19:
                    if (this.rand.nextInt(20) == 0)
                    {
                        MoCEntityKittyBed var23 = (MoCEntityKittyBed)this.getKittyStuff(this, 18.0D, false);
                        if (var23 != null && var23.riddenByEntity == null)
                        {
                            float var24 = var23.getDistanceToEntity(this);
                            if (var24 > 2.0F)
                            {
                                this.getMyOwnPath(var23, var24);
                            }

                            if (var24 < 2.0F)
                            {
                                this.changeKittyState(20);
                                this.mountEntity(var23);
                            }
                        }
                    }
                    break;
                case 20:
                    if (this.ridingEntity == null)
                    {
                        this.changeKittyState(19);
                    }
                    else
                    {
                        this.rotationYaw = 180.0F;
                        ++this.kittytimer;
                        if (this.kittytimer > 1000)
                        {
                            int var25 = this.rand.nextInt(3) + 1;

                            for (int var45 = 0; var45 < var25; ++var45)
                            {
                                MoCEntityKitty var44 = new MoCEntityKitty(this.worldObj);
                                var44.setPosition(this.posX, this.posY, this.posZ);
                                this.worldObj.spawnEntityInWorld(var44);
                                this.worldObj.playSoundAtEntity(this, "mob.chickenplop", 1.0F, (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F);
                                var44.setAdult(false);
                                var44.changeKittyState(10);
                            }

                            this.changeKittyState(21);
                        }
                    }
                    break;
                case 21:
                    ++this.kittytimer;
                    if (this.kittytimer > 2000)
                    {
                        List var26 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(24.0D, 8.0D, 24.0D));
                        int var27 = 0;

                        for (int var28 = 0; var28 < var26.size(); ++var28)
                        {
                            Entity var29 = (Entity)var26.get(var28);
                            if (var29 instanceof MoCEntityKitty && ((MoCEntityKitty)var29).getKittyState() == 10)
                            {
                                ++var27;
                            }
                        }

                        if (var27 < 1)
                        {
                            this.changeKittyState(7);
                            break;
                        }

                        this.kittytimer = 1000;
                    }

                    if (this.entityToAttack != null && this.entityToAttack instanceof EntityPlayer && this.rand.nextInt(300) == 0)
                    {
                        this.entityToAttack = null;
                    }
                    break;
                case 22:
                default:
                    this.changeKittyState(7);
            }
        }
        else
        {
            super.onLivingUpdate();
        }
    }

    public boolean onMaBack()
    {
        return this.getKittyState() == 15;
    }

    public void onUpdate()
    {
        super.onUpdate();
        if (this.getIsSwinging())
        {
            this.swingProgress += 0.2F;
            if (this.swingProgress > 2.0F)
            {
                this.setSwinging(false);
                this.swingProgress = 0.0F;
            }
        }
    }

    private boolean pickable()
    {
        return this.getKittyState() != 13 && this.getKittyState() != 14 && this.getKittyState() != 15 && this.getKittyState() != 19 && this.getKittyState() != 20 && this.getKittyState() != 21;
    }

    public boolean renderName()
    {
        return this.getDisplayName() && this.getKittyState() != 14 && this.getKittyState() != 15 && this.getKittyState() > 1;
    }

    public void setDisplayEmo(boolean var1)
    {
        this.displayEmo = var1;
    }

    public void setEntityDead()
    {
        if (this.getKittyState() <= 2 || this.health <= 0)
        {
            super.setEntityDead();
        }
    }

    public void setHungry(boolean var1)
    {
        this.isHungry = var1;
    }

    public void setKittyState(int var1)
    {
        this.kittyState = var1;
    }

    public void setOnTree(boolean var1)
    {
        this.onTree = var1;
    }

    public void setSitting(boolean var1)
    {
        this.isSitting = var1;
    }

    public void setSwinging(boolean var1)
    {
        this.isSwinging = var1;
    }

    public void setTypeInt(int var1)
    {
        this.setType(var1);
        this.setTypeChosen(false);
        this.chooseType();
    }

    public void swingArm()
    {
        if (!this.getIsSwinging())
        {
            this.setSwinging(true);
            this.swingProgress = 0.0F;
        }
    }

    public boolean upsideDown()
    {
        return this.getKittyState() == 14;
    }

    public boolean whipeable()
    {
        return this.getKittyState() != 13;
    }

    public void readEntityFromNBT(NBTTagCompound var1)
    {
        super.readEntityFromNBT(var1);
        this.setAdult(var1.getBoolean("Adult"));
        this.setType(var1.getInteger("TypeInt"));
        this.setEdad(var1.getFloat("Edad"));
        this.setSitting(var1.getBoolean("Sitting"));
        this.setKittyState(var1.getInteger("KittyState"));
        this.setName(var1.getString("Name"));
        this.setDisplayName(var1.getBoolean("DisplayName"));
    }

    public void writeEntityToNBT(NBTTagCompound var1)
    {
        super.writeEntityToNBT(var1);
        var1.setInteger("TypeInt", this.getType());
        var1.setBoolean("Adult", this.getIsAdult());
        var1.setBoolean("Sitting", this.getIsSitting());
        var1.setFloat("Edad", this.getEdad());
        var1.setInteger("KittyState", this.getKittyState());
        var1.setString("Name", this.getName());
        var1.setBoolean("DisplayName", this.getDisplayName());
    }
}
