package net.minecraft.src;

import java.util.List;
import net.minecraft.src.DamageSource;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityCow;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityMob;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.EntityWolf;
import net.minecraft.src.Item;
import net.minecraft.src.MathHelper;
import net.minecraft.src.MoCEntityBear;
import net.minecraft.src.MoCEntityBigCat;
import net.minecraft.src.MoCEntityHorse;
import net.minecraft.src.MoCEntityMob;
import net.minecraft.src.MoCTools;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityWWolf extends MoCEntityMob
{
    public MoCEntityWWolf(World var1)
    {
        super(var1);
        this.texture = "/mocreatures/wolfa.png";
        this.setSize(0.9F, 1.3F);
        this.attackStrength = 1;
    }

    protected void entityInit()
    {
        if (this.worldObj.difficultySetting == 1)
        {
            this.attackStrength = 3;
        }
        else if (this.worldObj.difficultySetting > 1)
        {
            this.attackStrength = 5;
        }

        super.entityInit();
    }

    protected void attackEntity(Entity var1, float var2)
    {
        if (this.attackTime <= 0 && (double)var2 < 2.5D && var1.boundingBox.maxY > this.boundingBox.minY && var1.boundingBox.minY < this.boundingBox.maxY)
        {
            this.attackTime = 20;
            var1.attackEntityFrom(DamageSource.causeMobDamage(this), this.attackStrength);
            if (!(var1 instanceof EntityPlayer))
            {
                MoCTools.destroyDrops(this, 3.0D);
            }
        }
    }

    protected Entity findPlayerToAttack()
    {
        float var1 = this.getEntityBrightness(1.0F);
        if (var1 < 0.5F)
        {
            double var4 = 16.0D;
            return this.worldObj.getClosestPlayerToEntity(this, var4);
        }
        else if (this.rand.nextInt(80) == 0)
        {
            EntityLiving var2 = this.getClosestTarget(this, 10.0D);
            return var2;
        }
        else
        {
            return null;
        }
    }

    public boolean getCanSpawnHere()
    {
        return this.worldObj.canBlockSeeTheSky(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ)) && ((Integer)mod_mocreatures.wwolffreq.get()).intValue() > 0 && super.getCanSpawnHere();
    }

    public EntityLiving getClosestTarget(Entity var1, double var2)
    {
        double var4 = -1.0D;
        EntityLiving var6 = null;
        List var7 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(var2, var2, var2));

        for (int var8 = 0; var8 < var7.size(); ++var8)
        {
            Entity var9 = (Entity)var7.get(var8);
            if (var9 instanceof EntityLiving && var9 != var1 && var9 != var1.riddenByEntity && var9 != var1.ridingEntity && !(var9 instanceof EntityPlayer) && !(var9 instanceof EntityMob) && !(var9 instanceof MoCEntityBigCat) && !(var9 instanceof MoCEntityBear) && !(var9 instanceof EntityCow) && (!(var9 instanceof EntityWolf) || ((Boolean)mod_mocreatures.attackwolves.get()).booleanValue()) && (!(var9 instanceof MoCEntityHorse) || ((Boolean)mod_mocreatures.attackhorses.get()).booleanValue()))
            {
                double var10 = var9.getDistanceSq(var1.posX, var1.posY, var1.posZ);
                if ((var2 < 0.0D || var10 < var2 * var2) && (var4 == -1.0D || var10 < var4) && ((EntityLiving)var9).canEntityBeSeen(var1))
                {
                    var4 = var10;
                    var6 = (EntityLiving)var9;
                }
            }
        }

        return var6;
    }

    protected String getDeathSound()
    {
        return "wolfdeath";
    }

    protected int getDropItemId()
    {
        return Item.leather.shiftedIndex;
    }

    protected String getHurtSound()
    {
        return "wolfhurt";
    }

    protected String getLivingSound()
    {
        return "wolfgrunt";
    }

    public int getMaxSpawnedInChunk()
    {
        return 6;
    }
}
