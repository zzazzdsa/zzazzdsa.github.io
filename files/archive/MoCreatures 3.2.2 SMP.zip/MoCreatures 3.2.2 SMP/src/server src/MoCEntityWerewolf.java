package net.minecraft.src;

import net.minecraft.src.DamageSource;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.MathHelper;
import net.minecraft.src.MoCEntityMob;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityWerewolf extends MoCEntityMob
{
    public boolean wereboolean = false;
    private boolean transforming;
    private boolean humanForm;
    private boolean hunched;
    private int tcounter;

    public MoCEntityWerewolf(World var1)
    {
        super(var1);
        this.texture = "/mocreatures/werehuman.png";
        this.setSize(0.9F, 1.3F);
        this.health = 15;
        this.transforming = false;
        this.tcounter = 0;
        this.setHumanForm(true);
    }

    protected void attackEntity(Entity var1, float var2)
    {
        if (this.getIsHumanForm())
        {
            this.entityToAttack = null;
        }
        else
        {
            if (var2 > 2.0F && var2 < 6.0F && this.rand.nextInt(15) == 0)
            {
                if (this.onGround)
                {
                    this.setHunched(true);
                    double var3 = var1.posX - this.posX;
                    double var5 = var1.posZ - this.posZ;
                    float var7 = MathHelper.sqrt_double(var3 * var3 + var5 * var5);
                    this.motionX = var3 / (double)var7 * 0.5D * 0.800000011920929D + this.motionX * 0.2000000029802322D;
                    this.motionZ = var5 / (double)var7 * 0.5D * 0.800000011920929D + this.motionZ * 0.2000000029802322D;
                    this.motionY = 0.4000000059604645D;
                }
            }
            else
            {
                super.attackEntity(var1, var2);
            }
        }
    }

    public boolean attackEntityFrom(DamageSource var1, int var2)
    {
        Entity var3 = var1.getEntity();
        if (!this.getIsHumanForm() && var3 != null && var3 instanceof EntityPlayer)
        {
            EntityPlayer var4 = (EntityPlayer)var3;
            ItemStack var5 = var4.getCurrentEquippedItem();
            if (var5 != null)
            {
                var2 = 1;
                if (var5.itemID == Item.hoeGold.shiftedIndex)
                {
                    var2 = 6;
                }

                if (var5.itemID == Item.shovelGold.shiftedIndex)
                {
                    var2 = 7;
                }

                if (var5.itemID == Item.pickaxeGold.shiftedIndex)
                {
                    var2 = 8;
                }

                if (var5.itemID == Item.axeGold.shiftedIndex)
                {
                    var2 = 9;
                }

                if (var5.itemID == Item.swordGold.shiftedIndex)
                {
                    var2 = 10;
                }
            }
        }

        return super.attackEntityFrom(var1, var2);
    }

    protected Entity findPlayerToAttack()
    {
        if (this.getIsHumanForm())
        {
            return null;
        }
        else
        {
            EntityPlayer var1 = this.worldObj.getClosestPlayerToEntity(this, 16.0D);
            return var1 != null && this.canEntityBeSeen(var1) ? var1 : null;
        }
    }

    public boolean getCanSpawnHere()
    {
        return ((Integer)mod_mocreatures.werewolffreq.get()).intValue() > 0 && this.worldObj.difficultySetting >= ((Integer)mod_mocreatures.wereSpawnDifficulty.get()).intValue() + 1 && super.getCanSpawnHere();
    }

    protected String getDeathSound()
    {
        return this.getIsHumanForm() ? "werehumandying" : "werewolfdying";
    }

    protected int getDropItemId()
    {
        int var1 = this.rand.nextInt(12);
        if (this.getIsHumanForm())
        {
            switch (var1)
            {
                case 0:
                    return Item.shovelWood.shiftedIndex;
                case 1:
                    return Item.axeWood.shiftedIndex;
                case 2:
                    return Item.swordWood.shiftedIndex;
                case 3:
                    return Item.hoeWood.shiftedIndex;
                case 4:
                    return Item.pickaxeWood.shiftedIndex;
                default:
                    return Item.stick.shiftedIndex;
            }
        }
        else
        {
            switch (var1)
            {
                case 0:
                    return Item.hoeSteel.shiftedIndex;
                case 1:
                    return Item.shovelSteel.shiftedIndex;
                case 2:
                    return Item.axeSteel.shiftedIndex;
                case 3:
                    return Item.pickaxeSteel.shiftedIndex;
                case 4:
                    return Item.swordSteel.shiftedIndex;
                case 5:
                    return Item.hoeStone.shiftedIndex;
                case 6:
                    return Item.shovelStone.shiftedIndex;
                case 7:
                    return Item.axeStone.shiftedIndex;
                case 8:
                    return Item.pickaxeStone.shiftedIndex;
                case 9:
                    return Item.swordStone.shiftedIndex;
                default:
                    return Item.appleGold.shiftedIndex;
            }
        }
    }

    protected String getHurtSound()
    {
        return this.getIsHumanForm() ? "werehumanhurt" : "werewolfhurt";
    }

    public boolean getIsHumanForm()
    {
        return this.humanForm;
    }

    public boolean getIsHunched()
    {
        return this.hunched;
    }

    public boolean getIsUndead()
    {
        return true;
    }

    protected String getLivingSound()
    {
        return this.getIsHumanForm() ? "werehumangrunt" : "werewolfgrunt";
    }

    public int getMaxSpawnedInChunk()
    {
        return 1;
    }

    public boolean IsNight()
    {
        return !this.worldObj.isDaytime();
    }

    public void moveEntityWithHeading(float var1, float var2)
    {
        if (!this.getIsHumanForm() && this.onGround)
        {
            this.motionX *= 1.2D;
            this.motionZ *= 1.2D;
        }

        super.moveEntityWithHeading(var1, var2);
    }

    public void onDeath(DamageSource var1)
    {
        Entity var2 = var1.getEntity();
        if (this.scoreValue > 0 && var2 != null)
        {
            var2.addToPlayerScore(this, this.scoreValue);
        }

        if (var2 != null)
        {
            var2.onKillEntity(this);
        }

        this.field_9100_aZ = true;
        if (!this.worldObj.isRemote)
        {
            for (int var3 = 0; var3 < 2; ++var3)
            {
                int var4 = this.getDropItemId();
                if (var4 > 0)
                {
                    this.dropItem(var4, 1);
                }
            }
        }

        // this.worldObj.getSkyColor(this, 3.0F);
    }

    public void onLivingUpdate()
    {
        super.onLivingUpdate();
        if (!this.worldObj.isRemote)
        {
            if ((this.IsNight() && this.getIsHumanForm() || !this.IsNight() && !this.getIsHumanForm()) && this.rand.nextInt(250) == 0)
            {
                this.transforming = true;
            }

            if (this.getIsHumanForm() && this.entityToAttack != null)
            {
                this.entityToAttack = null;
            }

            if (this.entityToAttack != null && !this.getIsHumanForm() && this.entityToAttack.posX - this.posX > 3.0D && this.entityToAttack.posZ - this.posZ > 3.0D)
            {
                this.setHunched(true);
            }

            if (this.getIsHunched() && this.rand.nextInt(50) == 0)
            {
                this.setHunched(false);
            }

            if (this.transforming && this.rand.nextInt(3) == 0)
            {
                ++this.tcounter;
                if (this.tcounter % 2 == 0)
                {
                    this.posX += 0.3D;
                    this.posY += (double)(this.tcounter / 30);
                    this.attackEntityFrom(DamageSource.causeMobDamage(this), 1);
                }

                if (this.tcounter % 2 != 0)
                {
                    this.posX -= 0.3D;
                }

                if (this.tcounter == 10)
                {
                    this.worldObj.playSoundAtEntity(this, "weretransform", 1.0F, (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F);
                }

                if (this.tcounter > 30)
                {
                    this.Transform();
                    this.tcounter = 0;
                    this.transforming = false;
                }
            }

            if (this.rand.nextInt(300) == 0)
            {
                this.entityAge -= 100 * this.worldObj.difficultySetting;
                if (this.entityAge < 0)
                {
                    this.entityAge = 0;
                }
            }
        }
    }

    public void readEntityFromNBT(NBTTagCompound var1)
    {
        super.readEntityFromNBT(var1);
        this.setHumanForm(var1.getBoolean("HumanForm"));
    }

    public void setHumanForm(boolean var1)
    {
        this.humanForm = var1;
    }

    public void setHunched(boolean var1)
    {
        this.hunched = var1;
    }

    private void Transform()
    {
        if (this.deathTime <= 0)
        {
            int var1 = MathHelper.floor_double(this.posX);
            int var2 = MathHelper.floor_double(this.boundingBox.minY) + 1;
            int var3 = MathHelper.floor_double(this.posZ);
            float var4 = 0.1F;

            for (int var5 = 0; var5 < 30; ++var5)
            {
                double var6 = (double)((float)var1 + this.worldObj.rand.nextFloat());
                double var8 = (double)((float)var2 + this.worldObj.rand.nextFloat());
                double var10 = (double)((float)var3 + this.worldObj.rand.nextFloat());
                double var12 = var6 - (double)var1;
                double var14 = var8 - (double)var2;
                double var16 = var10 - (double)var3;
                double var18 = (double)MathHelper.sqrt_double(var12 * var12 + var14 * var14 + var16 * var16);
                var12 /= var18;
                var14 /= var18;
                var16 /= var18;
                double var20 = 0.5D / (var18 / (double)var4 + 0.1D);
                var20 *= (double)(this.worldObj.rand.nextFloat() * this.worldObj.rand.nextFloat() + 0.3F);
                var12 *= var20;
                var14 *= var20;
                var16 *= var20;
                this.worldObj.spawnParticle("explode", (var6 + (double)var1 * 1.0D) / 2.0D, (var8 + (double)var2 * 1.0D) / 2.0D, (var10 + (double)var3 * 1.0D) / 2.0D, var12, var14, var16);
            }

            if (this.getIsHumanForm())
            {
                this.setHumanForm(false);
                this.health = 40;
                this.transforming = false;
            }
            else
            {
                this.setHumanForm(true);
                this.health = 15;
                this.transforming = false;
            }
        }
    }

    protected void updateEntityActionState()
    {
        if (!this.transforming)
        {
            super.updateEntityActionState();
        }
    }

    public void writeEntityToNBT(NBTTagCompound var1)
    {
        super.writeEntityToNBT(var1);
        var1.setBoolean("HumanForm", this.getIsHumanForm());
    }
}
