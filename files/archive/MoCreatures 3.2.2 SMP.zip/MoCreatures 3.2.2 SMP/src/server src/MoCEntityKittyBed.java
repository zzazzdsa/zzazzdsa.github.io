package net.minecraft.src;

import net.minecraft.src.Entity;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.Vec3D;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityKittyBed extends EntityLiving
{
    public float milklevel;
    private boolean hasFood;
    private boolean hasMilk;
    private int sheetColor;
    private boolean pickedUp;

    public MoCEntityKittyBed(World var1)
    {
        super(var1);
        this.setSize(1.0F, 0.3F);
        this.milklevel = 0.0F;
        this.texture = "/mocreatures/kittybed.png";
    }

    public MoCEntityKittyBed(World var1, double var2, double var4, double var6)
    {
        super(var1);
        this.setSize(1.0F, 0.3F);
        this.milklevel = 0.0F;
        this.texture = "/mocreatures/kittybed.png";
    }

    public MoCEntityKittyBed(World var1, int var2)
    {
        this(var1);
        this.setSheetColor(var2);
    }

    public boolean attackEntityFrom(Entity var1, int var2)
    {
        return false;
    }

    public boolean canBeCollidedWith()
    {
        return !this.isDead;
    }

    public boolean canBePushed()
    {
        return !this.isDead;
    }

    public boolean canBreatheUnderwater()
    {
        return true;
    }

    protected boolean canDespawn()
    {
        return false;
    }

    public boolean canEntityBeSeen(Entity var1)
    {
        return this.worldObj.rayTraceBlocks(Vec3D.createVector(this.posX, this.posY + (double)this.getEyeHeight(), this.posZ), Vec3D.createVector(var1.posX, var1.posY + (double)var1.getEyeHeight(), var1.posZ)) == null;
    }

    protected void fall(float var1) {}

    protected String getDeathSound()
    {
        return null;
    }

    public String getEntityTexture()
    {
        return "/mocreatures/kittybed.png";
    }

    public boolean getHasFood()
    {
        return this.hasFood;
    }

    public boolean getHasMilk()
    {
        return this.hasMilk;
    }

    protected String getHurtSound()
    {
        return null;
    }

    protected String getLivingSound()
    {
        return null;
    }

    public boolean getPickedUp()
    {
        return this.pickedUp;
    }

    public int getSheetColor()
    {
        return this.sheetColor;
    }

    protected float getSoundVolume()
    {
        return 0.0F;
    }

    public double getYOffset()
    {
        if (this.ridingEntity instanceof EntityPlayer && !this.worldObj.isRemote)
        {
            this.setPickedUp(true);
            return (double)(this.yOffset - 1.15F);
        }
        else
        {
            return (double)this.yOffset;
        }
    }

    public void handleHealthUpdate(byte var1) {}

    public boolean interact(EntityPlayer var1)
    {
        ItemStack var2 = var1.inventory.getCurrentItem();
        if (var2 != null && var2.itemID == Item.bucketMilk.shiftedIndex)
        {
            this.worldObj.playSoundAtEntity(this, "pouringmilk", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
            this.setHasMilk(true);
            this.setHasFood(false);
            return true;
        }
        else if (var2 != null && var2.itemID == mod_mocreatures.petfood.shiftedIndex)
        {
            if (--var2.stackSize == 0)
            {
                var1.inventory.setInventorySlotContents(var1.inventory.currentItem, (ItemStack)null);
            }

            this.worldObj.playSoundAtEntity(this, "pouringfood", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
            this.setHasMilk(false);
            this.setHasFood(true);
            return true;
        }
        else if (var2 != null && (var2.itemID == Item.pickaxeStone.shiftedIndex || var2.itemID == Item.pickaxeWood.shiftedIndex || var2.itemID == Item.pickaxeSteel.shiftedIndex || var2.itemID == Item.pickaxeGold.shiftedIndex || var2.itemID == Item.pickaxeDiamond.shiftedIndex))
        {
            var1.inventory.addItemStackToInventory(new ItemStack(mod_mocreatures.kittybed, 1, this.getSheetColor()));
            this.worldObj.playSoundAtEntity(this, "random.pop", 0.2F, ((this.rand.nextFloat() - this.rand.nextFloat()) * 0.7F + 1.0F) * 2.0F);
            this.setEntityDead();
            return true;
        }
        else
        {
            this.rotationYaw = var1.rotationYaw;
            if (!this.worldObj.isRemote)
            {
                this.mountEntity(var1);
            }

            this.worldObj.playSoundAtEntity(this, "mob.chickenplop", 1.0F, (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F);
            return true;
        }
    }

    public void moveEntity(double var1, double var3, double var5)
    {
        if ((this.ridingEntity != null || !this.onGround || !((Boolean)mod_mocreatures.staticbed.get()).booleanValue()) && !this.worldObj.isRemote)
        {
            super.moveEntity(var1, var3, var5);
        }
    }

    public void onUpdate()
    {
        super.onUpdate();
        if (this.onGround)
        {
            this.setPickedUp(false);
        }

        if ((this.getHasMilk() || this.getHasFood()) && this.riddenByEntity != null)
        {
            this.milklevel += 0.003F;
            if (this.milklevel > 2.0F)
            {
                this.milklevel = 0.0F;
                this.setHasMilk(false);
                this.setHasFood(false);
            }
        }
    }

    public void setHasFood(boolean var1)
    {
        this.hasFood = var1;
    }

    public void setHasMilk(boolean var1)
    {
        this.hasMilk = var1;
    }

    public void setPickedUp(boolean var1)
    {
        this.pickedUp = var1;
    }

    public void setSheetColor(int var1)
    {
        this.sheetColor = var1;
    }

    protected void updateEntityActionState() {}

    public void readEntityFromNBT(NBTTagCompound var1)
    {
        this.setHasMilk(var1.getBoolean("HasMilk"));
        this.setSheetColor(var1.getInteger("SheetColour"));
        this.setHasFood(var1.getBoolean("HasFood"));
        this.milklevel = var1.getFloat("MilkLevel");
    }

    public void writeEntityToNBT(NBTTagCompound var1)
    {
        var1.setBoolean("HasMilk", this.getHasMilk());
        var1.setInteger("SheetColour", this.getSheetColor());
        var1.setBoolean("HasFood", this.getHasFood());
        var1.setFloat("MilkLevel", this.milklevel);
    }

    public int getMaxHealth()
    {
        return 20;
    }
}
