package net.minecraft.src;

import net.minecraft.src.EntityLiving;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.MoCEntityHorse;

public class MoCItemHorseSaddle extends Item
{
    public MoCItemHorseSaddle(int var1)
    {
        super(var1);
        this.maxStackSize = 32;
    }

    public void useItemOnEntity(ItemStack var1, EntityLiving var2)
    {
        if (var2 instanceof MoCEntityHorse)
        {
            MoCEntityHorse var3 = (MoCEntityHorse)var2;
            if (!var3.getIsRideable() && var3.getIsAdult())
            {
                var3.setRideable(true);
                --var1.stackSize;
            }
        }
    }
}
