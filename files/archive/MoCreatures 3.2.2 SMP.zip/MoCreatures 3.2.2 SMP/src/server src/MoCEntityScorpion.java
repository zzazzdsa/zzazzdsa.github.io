package net.minecraft.src;

import net.minecraft.src.DamageSource;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.Material;
import net.minecraft.src.MathHelper;
import net.minecraft.src.MoCEntityMob;
import net.minecraft.src.MoCTools;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.Potion;
import net.minecraft.src.PotionEffect;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityScorpion extends MoCEntityMob
{
    private boolean isSwinging;
    private boolean isPoisoning;
    private int poisontimer;
    public boolean textureSet;
    private boolean isPicked;

    public MoCEntityScorpion(World var1)
    {
        super(var1);
        this.texture = "/mocreatures/scorpions.png";
        this.setSize(1.4F, 0.9F);
        this.moveSpeed = 0.8F;
        this.health = 15;
        this.poisontimer = 0;
        this.textureSet = false;
        this.setAdult(true);
        this.setEdad(0.2F);
    }

    public boolean isOnLadder()
    {
        return this.isCollidedHorizontally;
    }

    public boolean climbing()
    {
        return !this.onGround && this.isOnLadder();
    }

    public void chooseType()
    {
        if (this.getType() == 0)
        {
            int var1 = this.rand.nextInt(50);
            if (var1 <= 25)
            {
                this.setType(1);
            }
            else if (var1 <= 50)
            {
                this.setType(2);
            }
        }

        if (!this.getTypeChosen())
        {
            if (this.getType() == 1)
            {
                this.texture = "/mocreatures/scorpiona.png";
            }
            else if (this.getType() == 2)
            {
                this.texture = "/mocreatures/scorpionb.png";
            }
            else if (this.getType() == 3)
            {
                this.texture = "/mocreatures/scorpionc.png";
            }
            else if (this.getType() == 4)
            {
                this.texture = "/mocreatures/scorpiond.png";
            }
        }

        this.setTypeChosen(true);
    }

    /*
    public String getEntityTexture()
    {
        if (!this.getTypeChosen() && !mod_mocreatures.mc.isMultiplayerWorld())
        {
            this.chooseType();
        }

        if (mod_mocreatures.mc.isMultiplayerWorld() && !this.textureSet && this.getTexture() != null && !this.getTexture().equals(""))
        {
            this.texture = this.getTexture();
            this.textureSet = true;
        }

        return super.getEntityTexture();
    }
    */

    public void onLivingUpdate()
    {
        if (!this.onGround && this.ridingEntity != null)
        {
            this.rotationYaw = this.ridingEntity.rotationYaw;
        }

        if (this.getIsAdult() && this.fleeingTick > 0)
        {
            this.fleeingTick = 0;
        }

        if (this.getIsPoisoning())
        {
            ++this.poisontimer;
            if (this.poisontimer == 1)
            {
                this.worldObj.playSoundAtEntity(this, "scorpionsting", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
            }

            if (this.poisontimer > 50)
            {
                this.poisontimer = 0;
                this.setPoisoning(false);
            }
        }

        if (this.rand.nextInt(50) == 0)
        {
            this.swingArm();
        }

        if (!this.getIsAdult() && this.rand.nextInt(200) == 0)
        {
            this.setEdad(this.getEdad() + 0.01F);
            if (this.getEdad() >= 1.2F)
            {
                this.setAdult(true);
            }
        }

        super.onLivingUpdate();
    }

    public boolean attackEntityFrom(DamageSource var1, int var2)
    {
        if (super.attackEntityFrom(var1, var2))
        {
            Entity var3 = var1.getEntity();
            if (var3 != null && var3 instanceof EntityPlayer && this.getIsTamed())
            {
                return false;
            }
            else
            {
                if (var3 != null && var3 != this && this.worldObj.difficultySetting > 0 && this.getIsAdult())
                {
                    this.entityToAttack = var3;
                }

                return true;
            }
        }
        else
        {
            return false;
        }
    }

    protected Entity findPlayerToAttack()
    {
        if (this.worldObj.difficultySetting > 0 && !this.worldObj.isDaytime() && this.getIsAdult())
        {
            if (!this.getIsTamed())
            {
                EntityPlayer var1 = this.worldObj.getClosestPlayerToEntity(this, 12.0D);
                if (var1 != null && this.getIsAdult())
                {
                    return var1;
                }
            }
            else if (this.rand.nextInt(80) == 0)
            {
                EntityLiving var2 = this.getClosestEntityLiving(this, 10.0D);
                return var2;
            }
        }

        return null;
    }

    public boolean entitiesToIgnore(Entity var1)
    {
        return super.entitiesToIgnore(var1) || this.getIsTamed() && var1 instanceof MoCEntityScorpion && ((MoCEntityScorpion)var1).getIsTamed();
    }

    protected void attackEntity(Entity var1, float var2)
    {
        if (var2 > 2.0F && var2 < 6.0F && this.rand.nextInt(50) == 0)
        {
            if (this.onGround)
            {
                double var8 = var1.posX - this.posX;
                double var5 = var1.posZ - this.posZ;
                float var7 = MathHelper.sqrt_double(var8 * var8 + var5 * var5);
                this.motionX = var8 / (double)var7 * 0.5D * 0.8D + this.motionX * 0.2D;
                this.motionZ = var5 / (double)var7 * 0.5D * 0.8D + this.motionZ * 0.2D;
                this.motionY = 0.4D;
            }
        }
        else if (this.attackTime <= 0 && (double)var2 < 3.0D && var1.boundingBox.maxY > this.boundingBox.minY && var1.boundingBox.minY < this.boundingBox.maxY)
        {
            this.attackTime = 20;
            boolean var3 = var1 instanceof EntityPlayer;
            if (!this.getIsPoisoning() && this.rand.nextInt(8) == 0)
            {
                this.setPoisoning(true);
                if (this.getType() <= 2)
                {
                    if (var3)
                    {
                        mod_mocreatures.poisoned = true;
                    }

                    ((EntityLiving)var1).addPotionEffect(new PotionEffect(Potion.poison.id, 70, 0));
                }
                else if (this.getType() == 4)
                {
                    if (var3)
                    {
                        mod_mocreatures.freezed = true;
                    }
                }
                else if (this.getType() == 3)
                {
                    if (var3)
                    {
                        mod_mocreatures.burned = true;
                    }

                    ((EntityLiving)var1).setFire(15);
                }
            }
            else
            {
                var1.attackEntityFrom(DamageSource.causeMobDamage(this), 1);
                this.swingArm();
            }
        }
    }

    public void swingArm()
    {
        if (!this.getIsSwinging())
        {
            this.setSwinging(true);
            this.swingProgress = 0.0F;
        }
    }

    public void onUpdate()
    {
        if (this.getIsSwinging())
        {
            this.swingProgress += 0.2F;
            if ((double)this.swingProgress == 0.6D)
            {
                this.worldObj.playSoundAtEntity(this, "scorpionclaw", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
            }

            if (this.swingProgress > 1.2F)
            {
                this.setSwinging(false);
                this.swingProgress = 0.0F;
            }
        }

        super.onUpdate();
    }

    public boolean getIsSwinging()
    {
        return this.isSwinging;
    }

    public void setSwinging(boolean var1)
    {
        this.isSwinging = var1;
    }

    public boolean getIsPoisoning()
    {
        return this.isPoisoning;
    }

    public void setPoisoning(boolean var1)
    {
        this.isPoisoning = var1;
    }

    public boolean swingingTail()
    {
        return this.getIsPoisoning() && this.poisontimer < 15;
    }

    public void onDeath(DamageSource var1)
    {
        super.onDeath(var1);
        if (this.getIsAdult() && this.rand.nextInt(5) == 0)
        {
            int var2 = this.rand.nextInt(5);

            for (int var3 = 0; var3 < var2; ++var3)
            {
                MoCEntityScorpion var4 = new MoCEntityScorpion(this.worldObj);
                var4.setPosition(this.posX, this.posY, this.posZ);
                var4.setAdult(false);
                var4.setType(this.getType());
                this.worldObj.spawnEntityInWorld(var4);
                this.worldObj.playSoundAtEntity(this, "mob.chickenplop", 1.0F, (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F);
            }
        }
    }

    public void setTypeInt(int var1)
    {
        this.setType(var1);
        this.setTypeChosen(false);
        this.chooseType();
    }

    public void readEntityFromNBT(NBTTagCompound var1)
    {
        super.readEntityFromNBT(var1);
        this.setType(var1.getInteger("TypeInt"));
        this.setEdad(var1.getFloat("Edad"));
        this.setAdult(var1.getBoolean("Adult"));
        this.setTamed(var1.getBoolean("Tamed"));
    }

    public void writeEntityToNBT(NBTTagCompound var1)
    {
        super.writeEntityToNBT(var1);
        var1.setInteger("TypeInt", this.getType());
        var1.setFloat("Edad", this.getEdad());
        var1.setBoolean("Adult", this.getIsAdult());
        var1.setBoolean("Tamed", this.getIsTamed());
    }

    protected String getDeathSound()
    {
        return "scorpiondying";
    }

    protected String getHurtSound()
    {
        return "scorpionhurt";
    }

    protected String getLivingSound()
    {
        return "scorpiongrunt";
    }

    protected int getDropItemId()
    {
        return Item.silk.shiftedIndex;
    }

    public double getYOffset()
    {
        return this.ridingEntity instanceof EntityPlayer && !this.worldObj.isRemote ? (double)(this.yOffset - 1.7F) : (double)this.yOffset;
    }

    public boolean interact(EntityPlayer var1)
    {
        this.rotationYaw = var1.rotationYaw;
        if (!this.worldObj.isRemote && !this.getIsAdult())
        {
            this.mountEntity(var1);
        }

        if (this.ridingEntity != null)
        {
            this.setPicked(true);
            this.setTamed(true);
        }
        else
        {
            this.worldObj.playSoundAtEntity(this, "mob.chickenplop", 1.0F, (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F);
            this.setPicked(false);
        }

        this.motionX = var1.motionX * 5.0D;
        this.motionY = var1.motionY / 2.0D + 0.5D;
        this.motionZ = var1.motionZ * 5.0D;
        return true;
    }

    public boolean getIsPicked()
    {
        return this.isPicked;
    }

    public void setPicked(boolean var1)
    {
        this.isPicked = var1;
    }

    public boolean getCanSpawnHere()
    {
        if (MoCTools.isNearTorch(this))
        {
            return false;
        }
        else
        {
            byte var1 = 0;
            if (MoCTools.NearMaterialWithDistance(this, Double.valueOf(1.0D), Material.snow))
            {
                var1 = 4;
            }
            else if (this.worldObj.worldProvider.isHellWorld)
            {
                var1 = 3;
            }

            this.setType(var1);
            return ((Integer)mod_mocreatures.scorpionfreq.get()).intValue() > 0 && this.getCanSpawnHereLiving() && this.getCanSpawnHereCreature();
        }
    }
}
