package net.minecraft.src;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import net.minecraft.src.BiomeGenBase;
import net.minecraft.src.BiomeGenEnd;
import net.minecraft.src.BiomeGenHell;
import net.minecraft.src.ChunkCoordIntPair;
import net.minecraft.src.ChunkCoordinates;
import net.minecraft.src.ChunkPosition;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityChicken;
import net.minecraft.src.EntityCow;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityPig;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.EntitySheep;
import net.minecraft.src.EntitySquid;
import net.minecraft.src.EntityWolf;
import net.minecraft.src.EnumCreatureType;
import net.minecraft.src.Material;
import net.minecraft.src.MathHelper;
import net.minecraft.src.SpawnListEntry;
import net.minecraft.src.World;

public final class CustomSpawner
{
    private int maxAnimals = 40;
    private int maxMobs = 60;
    private int maxAquatic = 10;
    public BiomeGenBase[] standardBiomes;
    public List biomeList = new ArrayList();
    public List[] entityClasses;
    protected List[] customMobSpawnList;
    protected List[] customCreatureSpawnList;
    protected List[] customAquaticSpawnList;
    private static HashMap eligibleChunksForSpawning = new HashMap();
    private List vanillaClassList;

    public CustomSpawner()
    {
        try
        {
            Field[] var1 = BiomeGenBase.class.getDeclaredFields();
            LinkedList var2 = new LinkedList();

            for (int var3 = 0; var3 < var1.length; ++var3)
            {
                Class var4 = var1[var3].getType();
                if ((var1[var3].getModifiers() & 8) != 0 && var4.isAssignableFrom(BiomeGenBase.class))
                {
                    BiomeGenBase var5 = (BiomeGenBase)var1[var3].get((Object)null);
                    this.biomeList.add(var5.biomeName);
                    if (!(var5 instanceof BiomeGenHell) && !(var5 instanceof BiomeGenEnd))
                    {
                        var2.add(var5);
                    }
                }
            }

            this.standardBiomes = (BiomeGenBase[])((BiomeGenBase[])var2.toArray(new BiomeGenBase[0]));
            this.customCreatureSpawnList = new List[this.biomeList.size()];
            this.customMobSpawnList = new List[this.biomeList.size()];
            this.customAquaticSpawnList = new List[this.biomeList.size()];
            this.entityClasses = new List[3];
            this.vanillaClassList = new ArrayList();
            this.vanillaClassList.add(EntityChicken.class);
            this.vanillaClassList.add(EntityCow.class);
            this.vanillaClassList.add(EntityPig.class);
            this.vanillaClassList.add(EntitySheep.class);
            this.vanillaClassList.add(EntityWolf.class);
            this.vanillaClassList.add(EntitySquid.class);
            this.clearLists();
        }
        catch (IllegalAccessException var6)
        {
            throw new RuntimeException(var6);
        }
    }

    protected ChunkPosition getRandomSpawningPointInChunk2(World var1, int var2, int var3)
    {
        int var4 = var2 + var1.rand.nextInt(16);
        var1.getClass();
        int var5 = var1.rand.nextInt(128);
        int var6 = var3 + var1.rand.nextInt(16);
        return new ChunkPosition(var4, var5, var6);
    }

    protected static ChunkPosition getRandomSpawningPointInChunk(World var0, int var1, int var2)
    {
        int var3 = var1 + var0.rand.nextInt(16);
        int var4 = var0.rand.nextInt(var0.worldHeight);
        int var5 = var2 + var0.rand.nextInt(16);
        return new ChunkPosition(var3, var4, var5);
    }

    public void clearLists()
    {
        int var1;
        for (var1 = 0; var1 < this.biomeList.size(); ++var1)
        {
            this.customCreatureSpawnList[var1] = new ArrayList();
            this.customMobSpawnList[var1] = new ArrayList();
            this.customAquaticSpawnList[var1] = new ArrayList();
        }

        for (var1 = 0; var1 < 3; ++var1)
        {
            this.entityClasses[var1] = new ArrayList();
        }
    }

    public final int doSpecificSpawning(World var1, Class var2, int var3, EnumCreatureType var4)
    {
        eligibleChunksForSpawning.clear();

        int var5;
        int var11;
        for (var5 = 0; var5 < var1.playerEntities.size(); ++var5)
        {
            EntityPlayer var7 = (EntityPlayer)var1.playerEntities.get(var5);
            int var8 = MathHelper.floor_double(var7.posX / 16.0D);
            int var6 = MathHelper.floor_double(var7.posZ / 16.0D);
            byte var9 = 8;

            for (int var10 = -var9; var10 <= var9; ++var10)
            {
                for (var11 = -var9; var11 <= var9; ++var11)
                {
                    boolean var12 = var10 == -var9 || var10 == var9 || var11 == -var9 || var11 == var9;
                    ChunkCoordIntPair var13 = new ChunkCoordIntPair(var10 + var8, var11 + var6);
                    if (!var12)
                    {
                        eligibleChunksForSpawning.put(var13, Boolean.valueOf(false));
                    }
                    else if (!eligibleChunksForSpawning.containsKey(var13))
                    {
                        eligibleChunksForSpawning.put(var13, Boolean.valueOf(true));
                    }
                }
            }
        }

        var5 = 0;
        ChunkCoordinates var31 = var1.getSpawnPoint();
        Iterator var32 = eligibleChunksForSpawning.keySet().iterator();

        label74:
        while (var32.hasNext())
        {
            ChunkCoordIntPair var33 = (ChunkCoordIntPair)var32.next();
            ChunkPosition var34 = getRandomSpawningPointInChunk(var1, var33.chunkXPos * 16, var33.chunkZPos * 16);
            var11 = var34.x;
            int var35 = var34.y;
            int var36 = var34.z;
            if (!var1.isBlockNormalCube(var11, var35, var36) && var1.getBlockMaterial(var11, var35, var36) == var4.getCreatureMaterial())
            {
                int var14 = 0;

                for (int var15 = 0; var15 < 3; ++var15)
                {
                    int var16 = var11;
                    int var17 = var35;
                    int var18 = var36;
                    byte var19 = 6;

                    for (int var20 = 0; var20 < 4; ++var20)
                    {
                        var16 += var1.rand.nextInt(var19) - var1.rand.nextInt(var19);
                        var17 += var1.rand.nextInt(1) - var1.rand.nextInt(1);
                        var18 += var1.rand.nextInt(var19) - var1.rand.nextInt(var19);
                        if (this.canCreatureTypeSpawnAtLocation(var4, var1, var16, var17, var18))
                        {
                            float var21 = (float)var16 + 0.5F;
                            float var22 = (float)var17;
                            float var23 = (float)var18 + 0.5F;
                            if (var1.getClosestPlayer((double)var21, (double)var22, (double)var23, 24.0D) == null)
                            {
                                float var24 = var21 - (float)var31.posX;
                                float var25 = var22 - (float)var31.posY;
                                float var26 = var23 - (float)var31.posZ;
                                float var27 = var24 * var24 + var25 * var25 + var26 * var26;
                                if (var27 >= 576.0F)
                                {
                                    EntityLiving var28;
                                    try
                                    {
                                        var28 = (EntityLiving)var2.getConstructor(new Class[] {World.class}).newInstance(new Object[] {var1});
                                    }
                                    catch (Exception var30)
                                    {
                                        var30.printStackTrace();
                                        return var5;
                                    }

                                    var28.setLocationAndAngles((double)var21, (double)var22, (double)var23, var1.rand.nextFloat() * 360.0F, 0.0F);
                                    if (var28.getCanSpawnHere())
                                    {
                                        ++var14;
                                        var5 += var14;
                                        if (var5 > var3)
                                        {
                                            return var5;
                                        }

                                        var1.spawnEntityInWorld(var28);
                                        if (var14 >= var28.getMaxSpawnedInChunk())
                                        {
                                            continue label74;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        return var5;
    }

    public final int doCustomSpawning(World var1, boolean var2, boolean var3)
    {
        if (!var2 && !var3)
        {
            return 0;
        }
        else
        {
            eligibleChunksForSpawning.clear();

            int var4;
            int var5;
            int var10;
            ChunkCoordIntPair var12;
            for (var4 = 0; var4 < var1.playerEntities.size(); ++var4)
            {
                EntityPlayer var6 = (EntityPlayer)var1.playerEntities.get(var4);
                int var7 = MathHelper.floor_double(var6.posX / 16.0D);
                var5 = MathHelper.floor_double(var6.posZ / 16.0D);
                byte var8 = 8;

                for (int var9 = -var8; var9 <= var8; ++var9)
                {
                    for (var10 = -var8; var10 <= var8; ++var10)
                    {
                        boolean var11 = var9 == -var8 || var9 == var8 || var10 == -var8 || var10 == var8;
                        var12 = new ChunkCoordIntPair(var9 + var7, var10 + var5);
                        if (!var11)
                        {
                            eligibleChunksForSpawning.put(var12, Boolean.valueOf(false));
                        }
                        else if (!eligibleChunksForSpawning.containsKey(var12))
                        {
                            eligibleChunksForSpawning.put(var12, Boolean.valueOf(true));
                        }
                    }
                }
            }

            var4 = 0;
            ChunkCoordinates var41 = var1.getSpawnPoint();
            EnumCreatureType[] var42 = EnumCreatureType.values();
            var5 = var42.length;

            for (int var43 = 0; var43 < var5; ++var43)
            {
                EnumCreatureType var44 = var42[var43];
                var10 = this.countSpawnedEntities(var1, var44);
                if ((!var44.getPeacefulCreature() || var3) && (var44.getPeacefulCreature() || var2) && var10 < this.getMax(var44))
                {
                    Iterator var45 = eligibleChunksForSpawning.keySet().iterator();

                    label129:
                    while (var45.hasNext())
                    {
                        var12 = (ChunkCoordIntPair)var45.next();
                        BiomeGenBase var13 = var1.getWorldChunkManager().getBiomeGenAtChunkCoord(var12);
                        List var14 = this.getCustomBiomeSpawnList(this.getCustomSpawnableList(var44), var13);
                        if (var14 != null && !var14.isEmpty())
                        {
                            int var15 = 0;

                            SpawnListEntry var16;
                            for (Iterator var17 = var14.iterator(); var17.hasNext(); var15 += var16.itemWeight)
                            {
                                var16 = (SpawnListEntry)var17.next();
                            }

                            int var46 = var1.rand.nextInt(var15);
                            var16 = (SpawnListEntry)var14.get(0);
                            Iterator var18 = var14.iterator();

                            while (var18.hasNext())
                            {
                                SpawnListEntry var19 = (SpawnListEntry)var18.next();
                                var46 -= var19.itemWeight;
                                if (var46 < 0)
                                {
                                    var16 = var19;
                                    break;
                                }
                            }

                            int var47 = var16.maxGroupCount;
                            if (var47 > 0)
                            {
                                Class var20 = var16.entityClass;
                                if (var20 != null && var47 > this.countEntities(var20, var1))
                                {
                                    continue;
                                }
                            }

                            ChunkPosition var48 = getRandomSpawningPointInChunk(var1, var12.chunkXPos * 16, var12.chunkZPos * 16);
                            int var21 = var48.x;
                            int var22 = var48.y;
                            int var23 = var48.z;
                            if (!var1.isBlockNormalCube(var21, var22, var23) && var1.getBlockMaterial(var21, var22, var23) == var44.getCreatureMaterial())
                            {
                                int var24 = 0;

                                for (int var25 = 0; var25 < 3; ++var25)
                                {
                                    int var26 = var21;
                                    int var27 = var22;
                                    int var28 = var23;
                                    byte var29 = 6;

                                    for (int var30 = 0; var30 < 4; ++var30)
                                    {
                                        var26 += var1.rand.nextInt(var29) - var1.rand.nextInt(var29);
                                        var27 += var1.rand.nextInt(1) - var1.rand.nextInt(1);
                                        var28 += var1.rand.nextInt(var29) - var1.rand.nextInt(var29);
                                        if (this.canCreatureTypeSpawnAtLocation(var44, var1, var26, var27, var28))
                                        {
                                            float var31 = (float)var26 + 0.5F;
                                            float var32 = (float)var27;
                                            float var33 = (float)var28 + 0.5F;
                                            if (var1.getClosestPlayer((double)var31, (double)var32, (double)var33, 24.0D) == null)
                                            {
                                                float var34 = var31 - (float)var41.posX;
                                                float var35 = var32 - (float)var41.posY;
                                                float var36 = var33 - (float)var41.posZ;
                                                float var37 = var34 * var34 + var35 * var35 + var36 * var36;
                                                if (var37 >= 576.0F)
                                                {
                                                    EntityLiving var38;
                                                    try
                                                    {
                                                        var38 = (EntityLiving)var16.entityClass.getConstructor(new Class[] {World.class}).newInstance(new Object[] {var1});
                                                    }
                                                    catch (Exception var40)
                                                    {
                                                        var40.printStackTrace();
                                                        return var4;
                                                    }

                                                    var38.setLocationAndAngles((double)var31, (double)var32, (double)var33, var1.rand.nextFloat() * 360.0F, 0.0F);
                                                    if (var38.getCanSpawnHere())
                                                    {
                                                        var10 = this.countSpawnedEntities(var1, var44);
                                                        if (var10 >= this.getMax(var44))
                                                        {
                                                            continue label129;
                                                        }

                                                        ++var24;
                                                        var4 += var24;
                                                        var1.spawnEntityInWorld(var38);
                                                        if (var24 >= var38.getMaxSpawnedInChunk())
                                                        {
                                                            continue label129;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            return var4;
        }
    }

    public void AddCustomSpawn(Class var1, int var2, int var3, EnumCreatureType var4)
    {
        this.AddCustomSpawn(var1, var2, -1, var3, var4, (BiomeGenBase[])null);
    }

    public void AddCustomSpawn(Class var1, int var2, EnumCreatureType var3)
    {
        this.AddCustomSpawn(var1, var2, -1, -1, var3, (BiomeGenBase[])null);
    }

    public void AddCustomSpawn(Class var1, int var2, int var3, EnumCreatureType var4, BiomeGenBase[] var5)
    {
        this.AddCustomSpawn(var1, var2, -1, var3, var4, var5);
    }

    public void AddCustomSpawn(Class var1, int var2, EnumCreatureType var3, BiomeGenBase[] var4)
    {
        this.AddCustomSpawn(var1, var2, -1, -1, var3, var4);
    }

    public void AddCustomSpawn(Class var1, int var2, int var3, int var4, EnumCreatureType var5)
    {
        this.AddCustomSpawn(var1, var2, var3, var4, var5, (BiomeGenBase[])null);
    }

    public void AddCustomSpawn(Class var1, int var2, int var3, int var4, EnumCreatureType var5, BiomeGenBase[] var6)
    {
        if (var1 == null)
        {
            throw new IllegalArgumentException("entityClass cannot be null");
        }
        else if (var5 == null)
        {
            throw new IllegalArgumentException("spawnList cannot be null");
        }
        else
        {
            if (var6 == null)
            {
                var6 = this.standardBiomes;
            }

            int var7 = this.getEnumIndex(var5);
            boolean var8 = false;
            Iterator var9 = this.entityClasses[var7].iterator();

            while (var9.hasNext())
            {
                if (var9 != null)
                {
                    Class var10 = (Class)var9.next();
                    if (var10 == var1)
                    {
                        var8 = true;
                        break;
                    }
                }
            }

            if (!var8)
            {
                this.entityClasses[var7].add(var1);
            }

            for (int var15 = 0; var15 < var6.length; ++var15)
            {
                List[] var14 = this.getCustomSpawnableList(var5);
                if (var14 != null)
                {
                    int var16 = this.biomeList.indexOf(var6[var15].biomeName);
                    boolean var11 = false;
                    Iterator var12 = var14[var16].iterator();

                    while (var12.hasNext())
                    {
                        if (var12 != null)
                        {
                            SpawnListEntry var13 = (SpawnListEntry)var12.next();
                            if (var13.entityClass == var1)
                            {
                                var13.itemWeight = var2;
                                var13.minGroupCount = var3;
                                var13.maxGroupCount = var4;
                                var11 = true;
                                break;
                            }
                        }
                    }

                    if (!var11)
                    {
                        var14[var16].add(new SpawnListEntry(var1, var2, var3, var4));
                    }
                }
            }
        }
    }

    public void RemoveCustomSpawn(Class var1, EnumCreatureType var2)
    {
        this.RemoveCustomSpawn(var1, var2, (BiomeGenBase[])null);
    }

    public void RemoveCustomSpawn(Class var1, EnumCreatureType var2, BiomeGenBase[] var3)
    {
        if (var1 == null)
        {
            throw new IllegalArgumentException("entityClass cannot be null");
        }
        else if (var2 == null)
        {
            throw new IllegalArgumentException("spawnList cannot be null");
        }
        else
        {
            if (var3 == null)
            {
                var3 = this.standardBiomes;
            }

            for (int var4 = 0; var4 < var3.length; ++var4)
            {
                List[] var5 = this.getCustomSpawnableList(var2);
                if (var5 != null)
                {
                    int var6 = this.biomeList.indexOf(var3[var4].biomeName);
                    Iterator var7 = var5[var6].iterator();

                    while (var7.hasNext())
                    {
                        if (var7 != null)
                        {
                            SpawnListEntry var8 = (SpawnListEntry)var7.next();
                            if (var8.entityClass == var1)
                            {
                                var7.remove();
                            }
                        }
                    }
                }
            }
        }
    }

    private int getEnumIndex(EnumCreatureType var1)
    {
        return var1 == EnumCreatureType.monster ? 0 : (var1 == EnumCreatureType.creature ? 1 : (var1 == EnumCreatureType.waterCreature ? 2 : -1));
    }

    public int countSpawnedEntities(World var1, EnumCreatureType var2)
    {
        int var3 = this.getEnumIndex(var2);
        int var4 = 0;
        boolean var5 = false;
        Iterator var6 = this.entityClasses[var3].iterator();

        while (var6.hasNext())
        {
            if (var6 != null)
            {
                Class var7 = (Class)var6.next();
                if (var7 != null)
                {
                    var4 += var1.countEntities(var7);
                }
            }
        }

        return var4;
    }

    private List[] getCustomSpawnableList(EnumCreatureType var1)
    {
        return var1 == EnumCreatureType.monster ? this.customMobSpawnList : (var1 == EnumCreatureType.creature ? this.customCreatureSpawnList : (var1 == EnumCreatureType.waterCreature ? this.customAquaticSpawnList : null));
    }

    private List getCustomBiomeSpawnList(List[] var1, BiomeGenBase var2)
    {
        int var3 = this.biomeList.indexOf(var2.biomeName);
        return var3 >= 0 ? var1[var3] : null;
    }

    private int getMax(EnumCreatureType var1)
    {
        return var1 == EnumCreatureType.monster ? this.getMaxMobs() : (var1 == EnumCreatureType.creature ? this.getMaxAnimals() : (var1 == EnumCreatureType.waterCreature ? this.getMaxAquatic() : -1));
    }

    public int getMaxAnimals()
    {
        return this.maxAnimals;
    }

    public void setMaxAnimals(int var1)
    {
        this.maxAnimals = var1;
    }

    public int getMaxMobs()
    {
        return this.maxMobs;
    }

    public void setMaxMobs(int var1)
    {
        this.maxMobs = var1;
    }

    public int getMaxAquatic()
    {
        return this.maxAquatic;
    }

    public void setMaxAquatic(int var1)
    {
        this.maxAquatic = var1;
    }

    private boolean canCreatureTypeSpawnAtLocation(EnumCreatureType var1, World var2, int var3, int var4, int var5)
    {
        return var1.getCreatureMaterial() == Material.water ? var2.getBlockMaterial(var3, var4, var5).isLiquid() && !var2.isBlockNormalCube(var3, var4 + 1, var5) : var2.isBlockNormalCube(var3, var4 - 1, var5) && !var2.isBlockNormalCube(var3, var4, var5) && !var2.getBlockMaterial(var3, var4, var5).isLiquid() && !var2.isBlockNormalCube(var3, var4 + 1, var5);
    }

    protected final int entityDespawnCheck(World var1, EntityLiving var2)
    {
        if (var2 instanceof EntityWolf && ((EntityWolf)var2).isTamed())
        {
            return 0;
        }
        else
        {
            EntityPlayer var3 = var1.getClosestPlayerToEntity(var2, -1.0D);
            if (var3 != null)
            {
                double var4 = var3.posX - var2.posX;
                double var6 = var3.posY - var2.posY;
                double var8 = var3.posZ - var2.posZ;
                double var10 = var4 * var4 + var6 * var6 + var8 * var8;
                if (var10 > 16384.0D)
                {
                    var2.setEntityDead();
                    return 1;
                }

                if (var2.entityAge > 600 && var1.rand.nextInt(800) == 0)
                {
                    if (var10 >= 1024.0D)
                    {
                        var2.setEntityDead();
                        return 1;
                    }

                    var2.entityAge = 0;
                }
            }

            return 0;
        }
    }

    public final int countEntities(Class var1, World var2)
    {
        int var3 = 0;

        for (int var4 = 0; var4 < var2.loadedEntityList.size(); ++var4)
        {
            Entity var5 = (Entity)var2.loadedEntityList.get(var4);
            if (var1.isAssignableFrom(var5.getClass()))
            {
                ++var3;
            }
        }

        return var3;
    }

    public final int despawnVanillaAnimals(World var1)
    {
        int var2 = 0;

        for (int var3 = 0; var3 < var1.loadedEntityList.size(); ++var3)
        {
            Entity var4 = (Entity)var1.loadedEntityList.get(var3);
            if (var4 instanceof EntityLiving && (var4 instanceof EntityCow || var4 instanceof EntitySheep || var4 instanceof EntityPig || var4 instanceof EntityChicken || var4 instanceof EntitySquid || var4 instanceof EntityWolf))
            {
                var2 += this.entityDespawnCheck(var1, (EntityLiving)var4);
            }
        }

        return var2;
    }

    public final int despawnMob(World var1)
    {
        Object var2 = null;
        return this.despawnMob(var1, (List)var2);
    }

    public final int despawnMob(World var1, Class ... var2)
    {
        ArrayList var3 = new ArrayList();

        for (int var4 = 0; var4 < var2.length; ++var4)
        {
            var3.add(var2[var4]);
        }

        return this.despawnMob(var1, (List)var3);
    }

    public final int despawnMob(World var1, List var2)
    {
        int var3 = 0;
        if (var2 == null)
        {
            var2 = this.vanillaClassList;
        }

        for (int var4 = 0; var4 < var1.loadedEntityList.size(); ++var4)
        {
            Entity var5 = (Entity)var1.loadedEntityList.get(var4);
            if (var5 instanceof EntityLiving)
            {
                Iterator var6 = var2.iterator();

                while (var6.hasNext())
                {
                    if (var6 != null)
                    {
                        Class var7 = (Class)var6.next();
                        if (var7 == var5.getClass())
                        {
                            var3 += this.entityDespawnCheck(var1, (EntityLiving)var5);
                        }
                    }
                }
            }
        }

        return var3;
    }

    public final int despawnMobWithMinimum(World var1, Class var2, int var3)
    {
        int var4 = 0;
        int var5 = this.countEntities(var2, var1);

        for (int var6 = 0; var6 < var1.loadedEntityList.size(); ++var6)
        {
            if (var5 - var4 <= var3)
            {
                var1.updateEntities();
                return var4;
            }

            Entity var7 = (Entity)var1.loadedEntityList.get(var6);
            if (var7 instanceof EntityLiving && var2 == var7.getClass())
            {
                var4 += this.entityDespawnCheck(var1, (EntityLiving)var7);
            }
        }

        var1.updateEntities();
        return var4;
    }
}
