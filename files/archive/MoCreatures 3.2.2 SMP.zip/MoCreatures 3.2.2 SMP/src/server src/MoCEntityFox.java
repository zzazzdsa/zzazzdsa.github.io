package net.minecraft.src;

import java.util.List;
import net.minecraft.src.DamageSource;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityMob;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.MoCEntityAnimal;
import net.minecraft.src.MoCTools;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityFox extends MoCEntityAnimal
{
    protected double attackRange;
    protected int force;

    public MoCEntityFox(World var1)
    {
        super(var1);
        this.texture = "/mocreatures/fox.png";
        this.setSize(0.9F, 1.3F);
        this.health = 15;
        this.force = 2;
        this.attackRange = 4.0D;
    }

    protected void attackEntity(Entity var1, float var2)
    {
        if (this.attackTime <= 0 && (double)var2 < 2.0D && var1.boundingBox.maxY > this.boundingBox.minY && var1.boundingBox.minY < this.boundingBox.maxY)
        {
            this.attackTime = 20;
            var1.attackEntityFrom(DamageSource.causeMobDamage(this), this.force);
            if (!(var1 instanceof EntityPlayer))
            {
                MoCTools.destroyDrops(this, 3.0D);
            }
        }
    }

    public boolean attackEntityFrom(DamageSource var1, int var2)
    {
        if (super.attackEntityFrom(var1, var2))
        {
            Entity var3 = var1.getEntity();
            if (this.riddenByEntity != var3 && this.ridingEntity != var3)
            {
                if (var3 != this && this.worldObj.difficultySetting > 0)
                {
                    this.entityToAttack = var3;
                }

                return true;
            }
            else
            {
                return true;
            }
        }
        else
        {
            return false;
        }
    }

    public boolean isNotScared()
    {
        return true;
    }

    protected Entity findPlayerToAttack()
    {
        if (this.rand.nextInt(80) == 0 && this.worldObj.difficultySetting > 0)
        {
            EntityLiving var1 = this.getClosestTarget(this, 8.0D);
            return var1;
        }
        else
        {
            return null;
        }
    }

    public boolean getCanSpawnHere()
    {
        return MoCTools.isNearTorch(this) ? false : ((Integer)mod_mocreatures.foxfreq.get()).intValue() > 0 && super.getCanSpawnHere();
    }

    public EntityLiving getClosestTarget(Entity var1, double var2)
    {
        double var4 = -1.0D;
        EntityLiving var6 = null;
        List var7 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(var2, var2, var2));

        for (int var8 = 0; var8 < var7.size(); ++var8)
        {
            Entity var9 = (Entity)var7.get(var8);
            if (var9 instanceof EntityLiving && var9 != var1 && var9 != var1.riddenByEntity && var9 != var1.ridingEntity && !(var9 instanceof EntityPlayer) && !(var9 instanceof EntityMob) && this.height > var9.height && this.width > var9.width)
            {
                double var10 = var9.getDistanceSq(var1.posX, var1.posY, var1.posZ);
                if ((var2 < 0.0D || var10 < var2 * var2) && (var4 == -1.0D || var10 < var4) && ((EntityLiving)var9).canEntityBeSeen(var1))
                {
                    var4 = var10;
                    var6 = (EntityLiving)var9;
                }
            }
        }

        return var6;
    }

    protected String getDeathSound()
    {
        return "foxdying";
    }

    protected int getDropItemId()
    {
        return Item.leather.shiftedIndex;
    }

    protected String getHurtSound()
    {
        return "foxhurt";
    }

    protected String getLivingSound()
    {
        return "foxcall";
    }

    public int getMaxSpawnedInChunk()
    {
        return 1;
    }

    protected float getSoundVolume()
    {
        return 0.3F;
    }

    public void onLivingUpdate()
    {
        super.onLivingUpdate();
    }

    public void readEntityFromNBT(NBTTagCompound var1)
    {
        super.readEntityFromNBT(var1);
    }

    public void setEntityDead()
    {
        super.setEntityDead();
    }

    public void writeEntityToNBT(NBTTagCompound var1)
    {
        super.writeEntityToNBT(var1);
    }
}
