package net.minecraft.src;

import java.util.*;
import net.minecraft.server.MinecraftServer;

public class mod_mocreatures extends BaseModMp
{
    public static MinecraftServer mc = ModLoader.getMinecraftServerInstance();
    static mod_mocreatures inst;
    private static CustomSpawner myCustomSpawner;
    private long sTime;
    public static HashMap mocEntities;
    public static int min = 4;
    public static int max = 5;
    public static long lastTickRun = 0L;
    public static boolean inMenu = false;
    public static Item horsesaddle = (new MoCItemHorseSaddle(3772)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/hsaddle.png")).setItemName("HorseSaddle");
    public static Item haystack = (new MoCItemHayStack(3775)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/haystack.png")).setItemName("HayStack");
    public static Item sugarlump = (new MoCItemSugarLump(3776)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/sugarlump.png")).setItemName("SugarLump");
    public static Item sharkteeth = (new Item(3774)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/sharkteeth.png")).setItemName("sharkteeth");
    public static Item sharkegg = (new MoCItemSharkEgg(3773)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/sharkegg.png")).setItemName("sharkegg");
    public static Item fishyegg = (new MoCItemFishyEgg(3777)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/fishyegg.png")).setItemName("fishyegg");
    public static Item bigcatclaw = (new Item(3778)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/bigcatclaw.png")).setItemName("bigcatclaw");
    public static Item whip = (new MoCItemWhip(3779)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/whip.png")).setItemName("whip");
    public static Item medallion = (new Item(3783)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/medallion.png")).setItemName("medallion");
    public static Item kittybed = (new MoCItemKittyBed(3784, 0)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/bedkitty.png")).setItemName("kittybed");
    public static Item litterbox = (new MoCItemLitterBox(3785)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/boxlitter.png")).setItemName("litterbox");
    public static Item woolball = (new Item(3786)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/woolball.png")).setItemName("woolball");
    public static Item rope = (new Item(3787)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/rope.png")).setItemName("rope");
    public static Item petfood = (new Item(3788)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/petfood.png")).setItemName("petfood");
    public static Item crochide = (new Item(3790)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/crochide.png")).setItemName("crochide");
    public static Item plateCroc = (new ItemArmor(3791, EnumArmorMaterial.CLOTH, ModLoader.AddArmor("croc"), 1)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/crocplate.png")).setItemName("plateCroc");
    public static Item helmetCroc = (new ItemArmor(3792, EnumArmorMaterial.CLOTH, ModLoader.AddArmor("croc"), 0)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/crochelmet.png")).setItemName("helmetCroc");
    public static Item legsCroc = (new ItemArmor(3793, EnumArmorMaterial.CLOTH, ModLoader.AddArmor("croc"), 2)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/croclegs.png")).setItemName("legsCroc");
    public static Item bootsCroc = (new ItemArmor(3794, EnumArmorMaterial.CLOTH, ModLoader.AddArmor("croc"), 3)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/crocboots.png")).setItemName("bootsCroc");
    //public static Achievement Indiana = (new Achievement(77, "indiana", -4, -4, whip, AchievementList.openInventory)).registerAchievement();
    //public static Achievement BunnyKilla = (new Achievement(78, "bunnykilla", -5, -5, whip, AchievementList.openInventory)).registerAchievement();
    public static boolean poisoned = false;
    public static boolean freezed = false;
    public static boolean burned = false;
    public static int poisoncounter = 0;
    public static int freezedcounter = 0;
    
    public static SettingInt maxMobsS;
    //public static WidgetInt maxMobsW;
    public static SettingInt maxAnimalsS;
    //public static WidgetInt maxAnimalsW;
    public static SettingInt maxWaterMobsS;
    //public static WidgetInt maxWaterMobsW;
    public static SettingBoolean spawnpiranha;
    public static SettingInt horsefreq;
    public static SettingInt birdfreq;
    public static SettingInt lionfreq;
    public static SettingInt bearfreq;
    public static SettingInt pbearfreq;
    public static SettingInt wwolffreq;
    public static SettingInt duckfreq;
    public static SettingInt boarfreq;
    public static SettingInt bunnyfreq;
    public static SettingInt wraithfreq;
    public static SettingInt fwraithfreq;
    public static SettingInt ogrefreq;
    public static SettingInt cogrefreq;
    public static SettingInt fogrefreq;
    public static SettingInt werewolffreq;
    public static SettingInt foxfreq;
    public static SettingInt sharkfreq;
    public static SettingInt squidfreq;
    public static SettingInt dolphinfreq;
    public static SettingInt fishfreq;
    public static SettingInt deerfreq;
    public static SettingInt kittyfreq;
    public static SettingInt micefreq;
    public static SettingInt ratfreq;
    public static SettingInt hellratfreq;
    public static SettingInt scorpionfreq;
    public static SettingInt turtlefreq;
    public static SettingInt crocfreq;
    public static SettingInt rayfreq;
    public static SettingInt jellyfishfreq;
    public static SettingInt snakefreq;
    public static SettingInt goatfreq;
    /*
    public static WidgetInt horsefreqW;
    public static WidgetInt birdfreqW;
    public static WidgetInt lionfreqW;
    public static WidgetInt bearfreqW;
    public static WidgetInt pbearfreqW;
    public static WidgetInt wwolffreqW;
    public static WidgetInt duckfreqW;
    public static WidgetInt boarfreqW;
    public static WidgetInt bunnyfreqW;
    public static WidgetInt wraithfreqW;
    public static WidgetInt fwraithfreqW;
    public static WidgetInt ogrefreqW;
    public static WidgetInt cogrefreqW;
    public static WidgetInt fogrefreqW;
    public static WidgetInt werewolffreqW;
    public static WidgetInt foxfreqW;
    public static WidgetInt sharkfreqW;
    public static WidgetInt squidfreqW;
    public static WidgetInt dolphinfreqW;
    public static WidgetInt fishfreqW;
    public static WidgetInt deerfreqW;
    public static WidgetInt kittyfreqW;
    public static WidgetInt micefreqW;
    public static WidgetInt ratfreqW;
    public static WidgetInt hellratfreqW;
    public static WidgetInt scorpionfreqW;
    public static WidgetInt turtlefreqW;
    public static WidgetInt crocfreqW;
    public static WidgetInt rayfreqW;
    public static WidgetInt jellyfishfreqW;
    public static WidgetInt snakefreqW;
    public static WidgetInt goatfreqW;
    */
    public static SettingBoolean displayname;
    //public static WidgetBoolean displaynameW;
    public static SettingBoolean displayhealth;
    //public static WidgetBoolean displayhealthW;
    public static SettingBoolean displayemo;
    //public static WidgetBoolean displayemoW;
    public static SettingBoolean staticbed;
    //public static WidgetBoolean staticbedW;
    public static SettingBoolean staticlitter;
    //public static WidgetBoolean staticlitterW;
    public static SettingBoolean attackdolphins;
    //public static WidgetBoolean attackdolphinsW;
    public static SettingBoolean attackhorses;
    //public static WidgetBoolean attackhorsesW;
    public static SettingBoolean attackwolves;
    //public static WidgetBoolean attackwolvesW;
    public static SettingBoolean destroyitems;
    //public static WidgetBoolean destroyitemsW;
    //public static WidgetBoolean spawnpiranhaW;
    public static SettingInt pegasusChanceS;
    //public static WidgetInt pegasusChanceW;
    public static SettingBoolean easybreeding;
    //public static WidgetBoolean easybreedingW;
    public static SettingInt ogrerange;
    public static SettingFloat ogreStrength;
    public static SettingFloat fogreStrength;
    public static SettingFloat cogreStrength;
    //public static WidgetFloat ogreStrengthW;
    //public static WidgetFloat fogreStrengthW;
    //public static WidgetFloat cogreStrengthW;
    //public static WidgetInt ogrerangeW;
    public static SettingMulti ogreSpawnDifficulty;
    public static SettingMulti cogreSpawnDifficulty;
    public static SettingMulti fogreSpawnDifficulty;
    //public static WidgetMulti ogreSpawnDifficultyW;
    //public static WidgetMulti cogreSpawnDifficultyW;
    //public static WidgetMulti fogreSpawnDifficultyW;
    public static SettingMulti wereSpawnDifficulty;
    public static SettingMulti wraithSpawnDifficulty;
    public static SettingMulti fwraithSpawnDifficulty;
    //public static WidgetMulti wereSpawnDifficultyW;
    //public static WidgetMulti wraithSpawnDifficultyW;
    //public static WidgetMulti fwraithSpawnDifficultyW;
    public static SettingMulti sharkSpawnDifficulty;
    //public static WidgetMulti sharkSpawnDifficultyW;
    public String modName;
    public ModSettings MoCSettings;
    /*
    public ModSettingScreen MoCScreen;
    public WidgetSimplewindow spawnwindow;
    public WidgetSimplewindow animalwindow;
    public WidgetSimplewindow hunterwindow;
    public WidgetSimplewindow mobwindow;
    public WidgetSimplewindow watermobwindow;
    public WidgetSimplewindow displaytagwindow;
    public WidgetSimplewindow vanillamobwindow;
    */
    public static SettingBoolean despawnVanilla;
    //public static WidgetBoolean despawnVanillaW;
    public static SettingBoolean modifyVanillaSpawns;
    //public static WidgetBoolean modifyVanillaSpawnsW;
    public static SettingBoolean isOldWorld;
    //public static WidgetBoolean isOldWorldW;
    public static SettingInt cowfreq;
    //public static WidgetInt cowfreqW;
    public static SettingInt sheepfreq;
    //public static WidgetInt sheepfreqW;
    public static SettingInt pigfreq;
    //public static WidgetInt pigfreqW;
    public static SettingInt chickenfreq;
    //public static WidgetInt chickenfreqW;
    public static SettingInt zombiefreq;
    //public static WidgetInt zombiefreqW;
    public static SettingInt skeletonfreq;
    //public static WidgetInt skeletonfreqW;
    public static SettingInt spiderfreq;
    //public static WidgetInt spiderfreqW;
    public static SettingInt creeperfreq;
    //public static WidgetInt creeperfreqW;
    public static SettingInt enderfreq;
    //public static WidgetInt enderfreqW;
    public static SettingInt wolffreq;
    //public static WidgetInt wolffreqW;
    //public static WidgetInt basefreqW;

    private boolean loaded = false;
    
    public mod_mocreatures()
    {    	
    	load();
    }

    public String getVersion()
    {
        return "v3.2.2 (MC 1.1)";
    }

    public void load()
    {
    	if (loaded) return;
    	loaded = true;
    	
        ModLoader.SetInGameHook(this, true, false);
        //ModLoader.SetInGUIHook(this, true, false);
        inst = this;
        mocEntities = new HashMap();
        myCustomSpawner = new CustomSpawner();
        this.modName = "DrZhark\'s Mo\'Creatures";
        // this.AddNames();
        this.RegisterEntities();
        this.AddRecipes();
        // this.AddAchievements();
        this.GUIApiInit();
        updateSettings();
    }

    public void OnTickInGame(MinecraftServer mc)
    {
        if (mc.worldMngr[0].worldInfo.getWorldTime() % 200L == 0L)
        {
            int var3 = myCustomSpawner.doCustomSpawning(mc.worldMngr[0], mc.worldMngr[0].difficultySetting > 0, mc.worldMngr[0].isDaytime());
            System.out.println("Mo\'Creatures Spawned " + var3 + " Mo\'Creatures");
            if (((Boolean)despawnVanilla.get()).booleanValue())
            {
                int var4 = myCustomSpawner.despawnMob(mc.worldMngr[0]);
                System.out.println("Mo\'Creatures DeSpawned " + var4 + " Vanilla Creatures");
            }
        }

        if (inMenu)
        {
            if (lastTickRun > 10L)
            {
                updateSettings();
                inMenu = false;
            }

            ++lastTickRun;
        }

        // TODO: Player States? Naaah
        /*
        EntityPlayerSP var5 = var2.thePlayer;
        if (poisoned)
        {
            ++poisoncounter;
            if (!var5.isPotionActive(Potion.poison) || var5.isDead)
            {
                poisoncounter = 0;
                poisoned = false;
            }

            renderHaze(0.2F, "/mocreatures/maskgreen.png");
            MoCTools.disorientEntity(var5);
            if (poisoncounter % 20 == 0)
            {
                mc.theWorld.spawnParticle("slime", var5.posX, var5.posY + 0.5D, var5.posZ, 0.0D, 0.5D, 0.0D);
            }
        }

        if (freezed)
        {
            ++freezedcounter;
            if (freezedcounter > 200 || var5.isDead)
            {
                freezedcounter = 0;
                freezed = false;
            }

            renderHaze(0.2F, "/mocreatures/maskblue.png");
            MoCTools.slowEntity(var5);
            if (freezedcounter % 20 == 0)
            {
                mc.theWorld.spawnParticle("bubble", var5.posX, var5.posY + 0.5D, var5.posZ, 0.0D, 0.5D, 0.0D);
                var5.attackEntityFrom(DamageSource.magic, 1);
            }
        }

        if (burned)
        {
            if (var5.isDead || !var5.isBurning())
            {
                burned = false;
            }

            renderHaze(0.2F, "/mocreatures/maskred.png");
        }
        */
    }

    public static void updateSettings()
    {
    	inst.load();
    	
        myCustomSpawner.setMaxMobs(Integer.valueOf(((Integer)maxMobsS.get()).intValue()).intValue());
        myCustomSpawner.setMaxAnimals(Integer.valueOf(((Integer)maxAnimalsS.get()).intValue()).intValue());
        myCustomSpawner.setMaxAquatic(Integer.valueOf(((Integer)maxWaterMobsS.get()).intValue()).intValue());
        myCustomSpawner.clearLists();
        PopulatemyCustomSpawner();
        if (((Boolean)isOldWorld.get()).booleanValue())
        {
            PopulatemyCustomSpawnerOldWorlds();
        }

        if (((Boolean)modifyVanillaSpawns.get()).booleanValue())
        {
            ClearVanillaSpawnLists();
            ClearVanillaMobSpawns();
            PopulateVanillaSpawnLists();
        }

        System.out.println("Mo\'Creatures is updating settings");
    }

    /*
    public boolean OnTickInGUI(float var1, Minecraft var2, GuiScreen var3)
    {
        if (mc.thePlayer != null && var3 instanceof GuiIngameMenu)
        {
            inMenu = true;
            lastTickRun = 0L;
        }

        return true;
    }
    */

    public static void PopulatemyCustomSpawnerOldWorlds()
    {
        if (((Integer)horsefreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityHorse.class, ((Integer)horsefreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.ocean});
        }

        if (((Integer)boarfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityBoar.class, ((Integer)boarfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.ocean});
        }

        if (((Integer)bearfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityBear.class, ((Integer)bearfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.ocean});
        }

        if (((Integer)duckfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityDuck.class, ((Integer)duckfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.ocean});
        }

        if (((Integer)lionfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityBigCat.class, ((Integer)lionfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.ocean});
        }

        if (((Integer)pbearfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityPolarBear.class, ((Integer)pbearfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.ocean});
        }

        if (((Integer)bunnyfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityBunny.class, ((Integer)bunnyfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.ocean});
        }

        if (((Integer)birdfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityBird.class, ((Integer)birdfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.ocean});
        }

        if (((Integer)deerfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityDeer.class, ((Integer)deerfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.ocean});
        }

        if (((Integer)foxfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityFox.class, ((Integer)foxfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.ocean});
        }

        if (((Integer)kittyfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityKitty.class, ((Integer)kittyfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.ocean});
        }

        if (((Integer)micefreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityMouse.class, ((Integer)micefreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.ocean});
        }

        if (((Integer)turtlefreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityTurtle.class, ((Integer)turtlefreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.ocean});
        }

        if (((Integer)crocfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityCrocodile.class, ((Integer)crocfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.ocean});
        }

        if (((Integer)goatfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityGoat.class, ((Integer)goatfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.ocean});
        }
    }

    public static void PopulatemyCustomSpawner()
    {
        if (((Integer)horsefreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityHorse.class, ((Integer)horsefreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.plains, BiomeGenBase.taiga});
        }

        if (((Integer)ogrefreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityOgre.class, ((Integer)ogrefreq.get()).intValue(), EnumCreatureType.monster);
        }

        if (((Integer)fogrefreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityFireOgre.class, ((Integer)fogrefreq.get()).intValue(), EnumCreatureType.monster, new BiomeGenBase[] {BiomeGenBase.hell});
            myCustomSpawner.AddCustomSpawn(MoCEntityFireOgre.class, ((Integer)fogrefreq.get()).intValue(), EnumCreatureType.monster);
        }

        if (((Integer)cogrefreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityCaveOgre.class, ((Integer)cogrefreq.get()).intValue(), EnumCreatureType.monster);
        }

        if (((Integer)boarfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityBoar.class, ((Integer)boarfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.plains, BiomeGenBase.taiga});
        }

        if (((Integer)bearfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityBear.class, ((Integer)bearfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.plains, BiomeGenBase.taiga});
        }

        if (((Integer)duckfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityDuck.class, ((Integer)duckfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.extremeHills, BiomeGenBase.plains, BiomeGenBase.swampland, BiomeGenBase.taiga});
        }

        if (((Integer)lionfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityBigCat.class, ((Integer)lionfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.extremeHills, BiomeGenBase.plains, BiomeGenBase.taiga, BiomeGenBase.iceMountains, BiomeGenBase.icePlains});
        }

        if (((Integer)wwolffreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityWWolf.class, ((Integer)wwolffreq.get()).intValue(), EnumCreatureType.monster);
        }

        if (((Integer)pbearfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityPolarBear.class, ((Integer)pbearfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.iceMountains, BiomeGenBase.icePlains});
        }

        if (((Integer)wraithfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityWraith.class, ((Integer)wraithfreq.get()).intValue(), EnumCreatureType.monster);
        }

        if (((Integer)fwraithfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityFlameWraith.class, ((Integer)fwraithfreq.get()).intValue(), EnumCreatureType.monster, new BiomeGenBase[] {BiomeGenBase.hell});
            myCustomSpawner.AddCustomSpawn(MoCEntityFlameWraith.class, ((Integer)fwraithfreq.get()).intValue(), EnumCreatureType.monster);
        }

        if (((Integer)hellratfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityHellRat.class, ((Integer)hellratfreq.get()).intValue(), EnumCreatureType.monster, new BiomeGenBase[] {BiomeGenBase.hell});
        }

        if (((Integer)bunnyfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityBunny.class, ((Integer)bunnyfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.extremeHills, BiomeGenBase.plains, BiomeGenBase.taiga});
        }

        if (((Integer)birdfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityBird.class, ((Integer)birdfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.extremeHills, BiomeGenBase.plains, BiomeGenBase.taiga});
        }

        if (((Integer)deerfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityDeer.class, ((Integer)deerfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.plains, BiomeGenBase.taiga});
        }

        if (((Integer)foxfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityFox.class, ((Integer)foxfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.extremeHills, BiomeGenBase.plains, BiomeGenBase.taiga});
        }

        if (((Integer)kittyfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityKitty.class, ((Integer)kittyfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.extremeHills, BiomeGenBase.plains, BiomeGenBase.taiga});
        }

        if (((Integer)micefreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityMouse.class, ((Integer)micefreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.extremeHills, BiomeGenBase.plains, BiomeGenBase.taiga});
        }

        if (((Integer)turtlefreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityTurtle.class, ((Integer)turtlefreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.swampland, BiomeGenBase.river});
        }

        if (((Integer)crocfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityCrocodile.class, ((Integer)crocfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.swampland});
        }

        if (((Integer)werewolffreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityWerewolf.class, ((Integer)werewolffreq.get()).intValue(), EnumCreatureType.monster);
        }

        if (((Integer)ratfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityRat.class, ((Integer)ratfreq.get()).intValue(), EnumCreatureType.monster);
        }

        if (((Integer)scorpionfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityScorpion.class, ((Integer)scorpionfreq.get()).intValue(), EnumCreatureType.monster);
        }

        if (((Integer)scorpionfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityScorpion.class, ((Integer)scorpionfreq.get()).intValue(), EnumCreatureType.monster, new BiomeGenBase[] {BiomeGenBase.hell});
        }

        if (((Integer)sharkfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityShark.class, ((Integer)sharkfreq.get()).intValue(), EnumCreatureType.waterCreature, new BiomeGenBase[] {BiomeGenBase.ocean, BiomeGenBase.river});
        }

        if (((Integer)dolphinfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityDolphin.class, ((Integer)dolphinfreq.get()).intValue(), EnumCreatureType.waterCreature, new BiomeGenBase[] {BiomeGenBase.ocean, BiomeGenBase.river});
        }

        if (((Integer)fishfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityFishy.class, ((Integer)fishfreq.get()).intValue(), EnumCreatureType.waterCreature, new BiomeGenBase[] {BiomeGenBase.ocean, BiomeGenBase.river, BiomeGenBase.swampland});
        }

        if (((Integer)rayfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityRay.class, ((Integer)rayfreq.get()).intValue(), EnumCreatureType.waterCreature, new BiomeGenBase[] {BiomeGenBase.ocean, BiomeGenBase.river, BiomeGenBase.swampland, BiomeGenBase.forest, BiomeGenBase.taiga});
        }

        if (((Integer)jellyfishfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityJellyFish.class, ((Integer)jellyfishfreq.get()).intValue(), EnumCreatureType.waterCreature, new BiomeGenBase[] {BiomeGenBase.ocean, BiomeGenBase.swampland, BiomeGenBase.forest, BiomeGenBase.taiga});
        }

        if (((Integer)goatfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityGoat.class, ((Integer)goatfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.extremeHills, BiomeGenBase.plains});
        }
    }

    private void RegisterEntities()
    {
        ModLoader.RegisterEntityID(MoCEntityHorse.class, "Horse", 98);
        ModLoader.RegisterEntityID(MoCEntityOgre.class, "Ogre", 99);
        ModLoader.RegisterEntityID(MoCEntityFireOgre.class, "FireOgre", 100);
        ModLoader.RegisterEntityID(MoCEntityCaveOgre.class, "CaveOgre", 101);
        ModLoader.RegisterEntityID(MoCEntityBoar.class, "Boar", 102);
        ModLoader.RegisterEntityID(MoCEntityBear.class, "Bear", 103);
        ModLoader.RegisterEntityID(MoCEntityDuck.class, "Duck", 104);
        ModLoader.RegisterEntityID(MoCEntityBigCat.class, "BigCat", 105);
        ModLoader.RegisterEntityID(MoCEntityDeer.class, "Deer", 106);
        ModLoader.RegisterEntityID(MoCEntityWWolf.class, "WildWolf", 107);
        ModLoader.RegisterEntityID(MoCEntityPolarBear.class, "PolarBear", 108);
        ModLoader.RegisterEntityID(MoCEntityWraith.class, "Wraith", 109);
        ModLoader.RegisterEntityID(MoCEntityFlameWraith.class, "FlameWraith", 110);
        ModLoader.RegisterEntityID(MoCEntityBunny.class, "Bunny", 111);
        ModLoader.RegisterEntityID(MoCEntityBird.class, "Bird", 112);
        ModLoader.RegisterEntityID(MoCEntityFox.class, "Fox", 113);
        ModLoader.RegisterEntityID(MoCEntityWerewolf.class, "Werewolf", 114);
        ModLoader.RegisterEntityID(MoCEntityShark.class, "Shark", 115);
        ModLoader.RegisterEntityID(MoCEntityDolphin.class, "Dolphin", 116);
        ModLoader.RegisterEntityID(MoCEntityFishy.class, "Fishy", 117);
        ModLoader.RegisterEntityID(MoCEntityKitty.class, "Kitty", 118);
        ModLoader.RegisterEntityID(MoCEntityRat.class, "Rat", 119);
        ModLoader.RegisterEntityID(MoCEntityMouse.class, "Mouse", 120);
        ModLoader.RegisterEntityID(MoCEntityHellRat.class, "HellRat", 121);
        ModLoader.RegisterEntityID(MoCEntityScorpion.class, "Scorpion", 122);
        ModLoader.RegisterEntityID(MoCEntityTurtle.class, "Turtle", 123);
        ModLoader.RegisterEntityID(MoCEntityCrocodile.class, "Crocodile", 124);
        ModLoader.RegisterEntityID(MoCEntityRay.class, "Ray", 125);
        ModLoader.RegisterEntityID(MoCEntityJellyFish.class, "JellyFish", 126);
        ModLoader.RegisterEntityID(MoCEntityGoat.class, "Goat", 127);
        
        ModLoaderMp.RegisterEntityTrackerEntry(MoCEntityKittyBed.class, 200);
        ModLoaderMp.RegisterEntityTrackerEntry(MoCEntityLitterBox.class, 201);
        ModLoaderMp.RegisterEntityTrackerEntry(MoCEntitySharkEgg.class, 202);
        ModLoaderMp.RegisterEntityTrackerEntry(MoCEntityFishyEgg.class, 203);
        ModLoaderMp.RegisterEntityTracker(MoCEntityKittyBed.class, 160, 5);
        ModLoaderMp.RegisterEntityTracker(MoCEntityLitterBox.class, 160, 5);
        ModLoaderMp.RegisterEntityTracker(MoCEntitySharkEgg.class, 160, 5);
        ModLoaderMp.RegisterEntityTracker(MoCEntityFishyEgg.class, 160, 5);
    }

    /*
    private void AddNames()
    {
        ModLoader.AddName(horsesaddle, "Horse Saddle");
        ModLoader.AddName(sharkteeth, "Shark Teeth");
        ModLoader.AddName(sharkegg, "Shark Egg");
        ModLoader.AddName(haystack, "Hay Stack");
        ModLoader.AddName(sugarlump, "Sugar Lump");
        ModLoader.AddName(fishyegg, "Fish Egg");
        ModLoader.AddName(bigcatclaw, "BigCat Claw");
        ModLoader.AddName(whip, "Whip");
        ModLoader.AddName(medallion, "Medallion");
        ModLoader.AddName(kittybed, "Kitty Bed");
        ModLoader.AddName(litterbox, "Litter Box");
        ModLoader.AddName(woolball, "Wool Ball");
        ModLoader.AddName(petfood, "Pet Food");
        ModLoader.AddName(rope, "Rope");
        ModLoader.AddName(crochide, "Croc Hide");
        ModLoader.AddName(plateCroc, "Croc Plate");
        ModLoader.AddName(helmetCroc, "Croc Helmet");
        ModLoader.AddName(bootsCroc, "Croc Boots");
        ModLoader.AddName(legsCroc, "Croc Legs");
    }
    */

    private void AddRecipes()
    {
        ModLoader.AddRecipe(new ItemStack(rope, 1), new Object[] {"# #", " # ", "# #", Character.valueOf('#'), Item.silk});
        ModLoader.AddShapelessRecipe(new ItemStack(petfood, 4), new Object[] {new ItemStack(Item.fishRaw, 1), new ItemStack(Item.porkRaw, 1)});
        ModLoader.AddRecipe(new ItemStack(woolball, 1), new Object[] {" # ", "# #", " # ", Character.valueOf('#'), Item.silk});
        ModLoader.AddRecipe(new ItemStack(litterbox, 1), new Object[] {"###", "#X#", "###", Character.valueOf('#'), Block.planks, Character.valueOf('X'), Block.sand});
        ModLoader.AddRecipe(new ItemStack(medallion, 1), new Object[] {"# #", "XZX", " X ", Character.valueOf('#'), Item.leather, Character.valueOf('Z'), Item.diamond, Character.valueOf('X'), Item.ingotGold});
        ModLoader.AddRecipe(new ItemStack(medallion, 1), new Object[] {"# #", " X ", Character.valueOf('#'), Item.leather, Character.valueOf('X'), Item.ingotGold});
        ModLoader.AddRecipe(new ItemStack(whip, 1), new Object[] {"#X#", "X X", "# Z", Character.valueOf('#'), bigcatclaw, Character.valueOf('X'), Item.leather, Character.valueOf('Z'), Item.ingotIron});
        ModLoader.AddRecipe(new ItemStack(horsesaddle, 1), new Object[] {"XXX", "X#X", "# #", Character.valueOf('#'), Item.ingotIron, Character.valueOf('X'), Item.leather});
        ModLoader.AddRecipe(new ItemStack(haystack, 1), new Object[] {"XXX", "XXX", Character.valueOf('X'), Item.wheat});
        ModLoader.AddRecipe(new ItemStack(Item.wheat, 6), new Object[] {"X", Character.valueOf('X'), haystack});
        ModLoader.AddRecipe(new ItemStack(sugarlump, 1), new Object[] {"XX", "##", Character.valueOf('X'), Item.sugar, Character.valueOf('#'), Item.sugar});
        ModLoader.AddRecipe(new ItemStack(horsesaddle, 1), new Object[] {"X", "#", Character.valueOf('X'), Item.saddle, Character.valueOf('#'), Item.ingotIron});
        ModLoader.AddRecipe(new ItemStack(Item.plateChain, 1), new Object[] {"X X", "XXX", "XXX", Character.valueOf('X'), sharkteeth});
        ModLoader.AddRecipe(new ItemStack(Item.helmetChain, 1), new Object[] {"XXX", "X X", Character.valueOf('X'), sharkteeth});
        ModLoader.AddRecipe(new ItemStack(Item.legsChain, 1), new Object[] {"XXX", "X X", "X X", Character.valueOf('X'), sharkteeth});
        ModLoader.AddRecipe(new ItemStack(Item.bootsChain, 1), new Object[] {"X X", "X X", Character.valueOf('X'), sharkteeth});
        ModLoader.AddRecipe(new ItemStack(plateCroc, 1), new Object[] {"X X", "XXX", "XXX", Character.valueOf('X'), crochide});
        ModLoader.AddRecipe(new ItemStack(helmetCroc, 1), new Object[] {"XXX", "X X", Character.valueOf('X'), crochide});
        ModLoader.AddRecipe(new ItemStack(legsCroc, 1), new Object[] {"XXX", "X X", "X X", Character.valueOf('X'), crochide});
        ModLoader.AddRecipe(new ItemStack(bootsCroc, 1), new Object[] {"X X", "X X", Character.valueOf('X'), crochide});

        for (int var1 = 0; var1 < 16; ++var1)
        {
            ModLoader.AddShapelessRecipe(new ItemStack(kittybed, 1, var1), new Object[] {new ItemStack(Item.dyePowder, 1, var1), new ItemStack(kittybed, 1)});
            ModLoader.AddRecipe(new ItemStack(kittybed, 1, var1), new Object[] {"###", "#X#", "Z  ", Character.valueOf('#'), Block.planks, Character.valueOf('X'), new ItemStack(Item.itemsList[Block.cloth.blockID], 1, MoCTools.colorize(var1)), Character.valueOf('Z'), Item.ingotIron});
            String var2 = ItemDye.dyeColorNames[var1];
            var2 = var2.substring(0, 1).toUpperCase() + var2.substring(1);
            // ModLoader.AddName(new ItemStack(kittybed, 1, var1), var2 + " Kitty Bed");
        }
    }

    /*
    private void AddAchievements()
    {
        ModLoader.AddAchievementDesc(Indiana, "Indiana, Master of the BigCats", "Using a whip, command at least 7 tamed BigCats at once");
        ModLoader.AddAchievementDesc(BunnyKilla, "Da Bunny Killa", "using the bunny-kill-o-matic, euthanize at least 69 promiscuous bunnies at once");
    }

    public void AddRenderer(Map var1)
    {
        var1.put(MoCEntityHorse.class, new MoCRenderHorse(new MoCModelHorse2(), new MoCModelHorse1()));
        var1.put(MoCEntityFireOgre.class, new MoCRenderFireOgre(new MoCModelOgre2(), new MoCModelOgre1(), 1.5F));
        var1.put(MoCEntityCaveOgre.class, new MoCRenderCaveOgre(new MoCModelOgre2(), new MoCModelOgre1(), 1.5F));
        var1.put(MoCEntityOgre.class, new MoCRenderOgre(new MoCModelOgre2(), new MoCModelOgre1(), 1.5F));
        var1.put(MoCEntityBoar.class, new RenderPig(new ModelPig(), new ModelPig(0.5F), 0.7F));
        var1.put(MoCEntityBear.class, new MoCRenderBear(new MoCModelBear2(), new MoCModelBear1(), 0.7F));
        var1.put(MoCEntityDuck.class, new RenderChicken(new ModelChicken(), 0.3F));
        var1.put(MoCEntityBigCat.class, new MoCRenderBigCat(new MoCModelBigCat2(), new MoCModelBigCat1(), 0.7F));
        var1.put(MoCEntityDeer.class, new MoCRenderDeer(new MoCModelDeer(), 0.5F));
        var1.put(MoCEntityWWolf.class, new MoCRenderWWolf(new MoCModelWolf2(), new MoCModelWolf1(), 0.7F));
        var1.put(MoCEntityPolarBear.class, new MoCRenderPolarBear(new MoCModelBear2(), new MoCModelBear1(), 0.7F));
        var1.put(MoCEntityWraith.class, new MoCRenderWraith(new MoCModelWraith(), 0.5F));
        var1.put(MoCEntityFlameWraith.class, new MoCRenderWraith(new MoCModelWraith(), 0.5F));
        var1.put(MoCEntityBunny.class, new MoCRenderBunny(new MoCModelBunny(), 0.3F));
        var1.put(MoCEntityBird.class, new MoCRenderBird(new MoCModelBird(), 0.3F));
        var1.put(MoCEntityFox.class, new MoCRenderFox(new MoCModelFox()));
        var1.put(MoCEntityWerewolf.class, new MoCRenderWerewolf(new MoCModelWereHuman(), new MoCModelWerewolf(), 0.7F));
        var1.put(MoCEntityShark.class, new MoCRenderShark(new MoCModelShark(), 0.6F));
        var1.put(MoCEntitySharkEgg.class, new MoCRenderSharkEgg(new MoCModelSharkEgg(), 0.1F));
        var1.put(MoCEntityDolphin.class, new MoCRenderDolphin(new MoCModelDolphin(), 0.6F));
        var1.put(MoCEntityFishy.class, new MoCRenderFishy(new MoCModelFishy(), 0.2F));
        var1.put(MoCEntityFishyEgg.class, new MoCRenderFishyEgg(new MoCModelSharkEgg(), 0.1F));
        var1.put(MoCEntityKitty.class, new MoCRenderKitty(new MoCModelKitty(0.0F, 15.0F), 0.4F));
        var1.put(MoCEntityKittyBed.class, new MoCRenderKittyBed(new MoCModelKittyBed(), new MoCModelKittyBed2(), 0.3F));
        var1.put(MoCEntityLitterBox.class, new MoCRenderLitterBox(new MoCModelLitterBox(), 0.3F));
        var1.put(MoCEntityRat.class, new MoCRenderRat(new MoCModelRat(), 0.2F));
        var1.put(MoCEntityMouse.class, new MoCRenderMouse(new MoCModelMouse(), 0.1F));
        var1.put(MoCEntityHellRat.class, new MoCRenderHellRat(new MoCModelRat(), 0.4F));
        var1.put(MoCEntityScorpion.class, new MoCRenderScorpion(new MoCModelScorpion(), 0.6F));
        var1.put(MoCEntityTurtle.class, new MoCRenderTurtle(new MoCModelTurtle(), 0.4F));
        var1.put(MoCEntityCrocodile.class, new MoCRenderCrocodile(new MoCModelCrocodile(), 0.5F));
        var1.put(MoCEntityRay.class, new MoCRenderRay(new MoCModelRay(), 0.4F));
        var1.put(MoCEntityJellyFish.class, new MoCRenderJellyFish(new MoCModelJellyFish(), 0.1F));
        var1.put(MoCEntityGoat.class, new MoCRenderGoat(new MoCModelGoat(), 0.3F));
    }
    */

    private void GUIApiInit()
    {
        this.MoCSettings = new ModSettings("mocreatures");

        this.MoCSettings.append(maxMobsS = new SettingInt("MobsSpawnLimit", 60, 1, 1, 1000));

        this.MoCSettings.append(maxAnimalsS = new SettingInt("AnimalsSpawnLimit", 50, 1, 1, 1000));

        this.MoCSettings.append(maxWaterMobsS = new SettingInt("WaterMobSpawnLimit", 25, 1, 1, 1000));

        this.MoCSettings.append(horsefreq = new SettingInt("FreqHorse", 6, 0, 1, 10));

        this.MoCSettings.append(easybreeding = new SettingBoolean("EasyHorseBreeding", Boolean.valueOf(false)));

        this.MoCSettings.append(pegasusChanceS = new SettingInt("PegasusSpawningP", 1, 1, 1, 3));

        this.MoCSettings.append(birdfreq = new SettingInt("FreqBird", 5, 0, 1, 10));

        this.MoCSettings.append(bunnyfreq = new SettingInt("FreqBunny", 6, 0, 1, 10));

        this.MoCSettings.append(duckfreq = new SettingInt("FreqDuck", 6, 0, 1, 10));

        this.MoCSettings.append(deerfreq = new SettingInt("FreqDeer", 6, 0, 1, 10));

        this.MoCSettings.append(kittyfreq = new SettingInt("FreqKitty", 4, 0, 1, 10));

        this.MoCSettings.append(micefreq = new SettingInt("FreqMice", 7, 0, 1, 10));

        this.MoCSettings.append(turtlefreq = new SettingInt("FreqTurtle", 6, 0, 1, 10));

        this.MoCSettings.append(goatfreq = new SettingInt("FreqGoat", 5, 0, 1, 10));

        this.MoCSettings.append(attackhorses = new SettingBoolean("HuntersAttackHorses", Boolean.valueOf(false)));

        this.MoCSettings.append(attackwolves = new SettingBoolean("HuntersAttackWolves", Boolean.valueOf(false)));

        this.MoCSettings.append(destroyitems = new SettingBoolean("HuntersDestroyDrops", Boolean.valueOf(true)));

        this.MoCSettings.append(lionfreq = new SettingInt("FreqLion", 3, 0, 1, 10));

        this.MoCSettings.append(bearfreq = new SettingInt("FreqBear", 4, 0, 1, 10));

        this.MoCSettings.append(pbearfreq = new SettingInt("FreqPBear", 3, 0, 1, 10));

        this.MoCSettings.append(boarfreq = new SettingInt("FreqBoar", 4, 0, 1, 10));

        this.MoCSettings.append(foxfreq = new SettingInt("FreqFox", 4, 0, 1, 10));

        this.MoCSettings.append(crocfreq = new SettingInt("CrocFreq", 8, 0, 1, 10));

        this.MoCSettings.append(ogrefreq = new SettingInt("FreqOgre", 6, 0, 1, 10));
        
        this.MoCSettings.append(ogreSpawnDifficulty = new SettingMulti("ogreSpawnDifficulty", 1, new String[] {"Easy", "Normal", "Hard"}));

        this.MoCSettings.append(ogreStrength = new SettingFloat("OgreStrength", 2.5F, 0.1F, 0.1F, 5.0F));

        this.MoCSettings.append(fogrefreq = new SettingInt("FreqFOgre", 2, 0, 1, 10));

        this.MoCSettings.append(fogreSpawnDifficulty = new SettingMulti("FireOgreSpawnDifficulty", 2, new String[] {"Easy", "Normal", "Hard"}));

        this.MoCSettings.append(fogreStrength = new SettingFloat("FireOgreStrength", 2.0F, 0.1F, 0.1F, 5.0F));

        this.MoCSettings.append(cogrefreq = new SettingInt("FreqCOgre", 3, 0, 1, 10));

        this.MoCSettings.append(cogreSpawnDifficulty = new SettingMulti("CaveOgreSpawnDifficulty", 1, new String[] {"Easy", "Normal", "Hard"}));

        this.MoCSettings.append(cogreStrength = new SettingFloat("CaveOgreStrength", 3.0F, 0.1F, 0.1F, 5.0F));

        this.MoCSettings.append(ogrerange = new SettingInt("OgreRange", 12, 1, 1, 24));

        this.MoCSettings.append(werewolffreq = new SettingInt("FreqWereWolf", 6, 0, 1, 10));

        this.MoCSettings.append(wereSpawnDifficulty = new SettingMulti("wereSpawnDifficulty", 1, new String[] {"Easy", "Normal", "Hard"}));

        this.MoCSettings.append(wraithfreq = new SettingInt("FreqWraith", 5, 0, 1, 10));

        this.MoCSettings.append(wraithSpawnDifficulty = new SettingMulti("wraithSpawnDifficulty", 1, new String[] {"Easy", "Normal", "Hard"}));

        this.MoCSettings.append(fwraithfreq = new SettingInt("FreqFWraith", 2, 0, 1, 10));

        this.MoCSettings.append(fwraithSpawnDifficulty = new SettingMulti("flameWraithSpawnDifficulty", 2, new String[] {"Easy", "Normal", "Hard"}));

        this.MoCSettings.append(wwolffreq = new SettingInt("FreqWildWolf", 6, 0, 1, 10));

        this.MoCSettings.append(ratfreq = new SettingInt("FreqRat", 8, 0, 1, 10));

        this.MoCSettings.append(hellratfreq = new SettingInt("FreqHellRat", 7, 0, 1, 10));

        this.MoCSettings.append(scorpionfreq = new SettingInt("ScorpionFreq", 6, 0, 1, 10));

        this.MoCSettings.append(sharkfreq = new SettingInt("FreqShark", 2, 0, 1, 10));

        this.MoCSettings.append(sharkSpawnDifficulty = new SettingMulti("sharkSpawnDifficulty", 0, new String[] {"Easy", "Normal", "Hard"}));

        this.MoCSettings.append(dolphinfreq = new SettingInt("FreqDolphin", 4, 0, 1, 10));

        this.MoCSettings.append(attackdolphins = new SettingBoolean("DolphinsAttackSharks", Boolean.valueOf(true)));

        this.MoCSettings.append(fishfreq = new SettingInt("FreqFishy", 15, 0, 1, 20));

        this.MoCSettings.append(spawnpiranha = new SettingBoolean("SpawnPiranhas", Boolean.valueOf(true)));

        this.MoCSettings.append(rayfreq = new SettingInt("FreqRays", 15, 0, 1, 20));

        this.MoCSettings.append(jellyfishfreq = new SettingInt("FreqJellyFish", 15, 0, 1, 20));

        this.MoCSettings.append(displayname = new SettingBoolean("DisplayPetNames", Boolean.valueOf(true)));

        this.MoCSettings.append(displayhealth = new SettingBoolean("DisplayPetHealth", Boolean.valueOf(true)));

        this.MoCSettings.append(displayemo = new SettingBoolean("DisplayPetEmotions", Boolean.valueOf(true)));

        this.MoCSettings.append(staticbed = new SettingBoolean("StaticKBeds", Boolean.valueOf(true)));

        this.MoCSettings.append(staticlitter = new SettingBoolean("StaticLitter", Boolean.valueOf(true)));

        this.MoCSettings.append(despawnVanilla = new SettingBoolean("DespawnVanilla", Boolean.valueOf(true)));

        this.MoCSettings.append(modifyVanillaSpawns = new SettingBoolean("ChangeVanillaSpawns", Boolean.valueOf(false)));

        this.MoCSettings.append(isOldWorld = new SettingBoolean("isOldWorld", Boolean.valueOf(false)));

        this.MoCSettings.append(cowfreq = new SettingInt("CowFreq", 3, 0, 1, 10));

        this.MoCSettings.append(sheepfreq = new SettingInt("SheepFreq", 5, 0, 1, 10));

        this.MoCSettings.append(pigfreq = new SettingInt("PigFreq", 4, 0, 1, 10));

        this.MoCSettings.append(chickenfreq = new SettingInt("ChickenFreq", 4, 0, 1, 10));

        this.MoCSettings.append(wolffreq = new SettingInt("WolfFreq", 5, 0, 1, 3));

        this.MoCSettings.append(squidfreq = new SettingInt("FreqSquid", 3, 0, 1, 3));

        this.MoCSettings.append(zombiefreq = new SettingInt("ZombieFreq", 4, 0, 1, 10));

        this.MoCSettings.append(skeletonfreq = new SettingInt("SkeletonFreq", 4, 0, 1, 10));

        this.MoCSettings.append(spiderfreq = new SettingInt("SpiderFreq", 4, 0, 1, 10));

        this.MoCSettings.append(creeperfreq = new SettingInt("CreeperFreq", 4, 0, 1, 10));

        this.MoCSettings.append(enderfreq = new SettingInt("EnderFreq", 2, 0, 1, 10));

        this.MoCSettings.load();
    }
    
    /*
    public void spawnlimits()
    {
        if (this.spawnwindow == null)
        {
            WidgetClassicTwocolumn var1 = new WidgetClassicTwocolumn(new Widget[0]);
            var1.add(maxMobsW);
            var1.add(maxAnimalsW);
            var1.add(maxWaterMobsW);
            var1.add(isOldWorldW);
            this.spawnwindow = new WidgetSimplewindow(var1, "Spawn Settings");
        }

        GuiModScreen.show((Widget)this.spawnwindow);
    }

    public void animalsettings()
    {
        if (this.animalwindow == null)
        {
            WidgetClassicTwocolumn var1 = new WidgetClassicTwocolumn(new Widget[0]);
            var1.add(birdfreqW);
            var1.add(bunnyfreqW);
            var1.add(duckfreqW);
            var1.add(horsefreqW);
            var1.add(easybreedingW);
            var1.add(pegasusChanceW);
            var1.add(deerfreqW);
            var1.add(kittyfreqW);
            var1.add(micefreqW);
            var1.add(turtlefreqW);
            var1.add(goatfreqW);
            this.animalwindow = new WidgetSimplewindow(var1, "Pacific Creatures Settings");
        }

        GuiModScreen.show((Widget)this.animalwindow);
    }

    public void displaytagsettings()
    {
        if (this.displaytagwindow == null)
        {
            WidgetClassicTwocolumn var1 = new WidgetClassicTwocolumn(new Widget[0]);
            var1.add(displaynameW);
            var1.add(displayhealthW);
            var1.add(displayemoW);
            var1.add(staticbedW);
            var1.add(staticlitterW);
            this.displaytagwindow = new WidgetSimplewindow(var1, "Other Settings");
        }

        GuiModScreen.show((Widget)this.displaytagwindow);
    }

    public void huntersettings()
    {
        if (this.hunterwindow == null)
        {
            WidgetClassicTwocolumn var1 = new WidgetClassicTwocolumn(new Widget[0]);
            var1.add(attackhorsesW);
            var1.add(attackwolvesW);
            var1.add(destroyitemsW);
            var1.add(lionfreqW);
            var1.add(bearfreqW);
            var1.add(pbearfreqW);
            var1.add(boarfreqW);
            var1.add(foxfreqW);
            var1.add(crocfreqW);
            this.hunterwindow = new WidgetSimplewindow(var1, "Hunter Creatures Settings");
        }

        GuiModScreen.show((Widget)this.hunterwindow);
    }

    public void mobsettings()
    {
        if (this.mobwindow == null)
        {
            WidgetClassicTwocolumn var1 = new WidgetClassicTwocolumn(new Widget[0]);
            var1.add(ogrefreqW);
            var1.add(ogreSpawnDifficultyW);
            var1.add(ogreStrengthW);
            var1.add(fogrefreqW);
            var1.add(fogreSpawnDifficultyW);
            var1.add(fogreStrengthW);
            var1.add(cogrefreqW);
            var1.add(cogreSpawnDifficultyW);
            var1.add(cogreStrengthW);
            var1.add(ogrerangeW);
            var1.add(wwolffreqW);
            var1.add(wraithfreqW);
            var1.add(wraithSpawnDifficultyW);
            var1.add(fwraithfreqW);
            var1.add(fwraithSpawnDifficultyW);
            var1.add(werewolffreqW);
            var1.add(wereSpawnDifficultyW);
            var1.add(ratfreqW);
            var1.add(hellratfreqW);
            var1.add(scorpionfreqW);
            this.mobwindow = new WidgetSimplewindow(var1, "Hostile Mob Settings");
        }

        GuiModScreen.show((Widget)this.mobwindow);
    }

    public void vanillamobs()
    {
        if (this.vanillamobwindow == null)
        {
            WidgetClassicTwocolumn var1 = new WidgetClassicTwocolumn(new Widget[0]);
            var1.add(despawnVanillaW);
            var1.add(modifyVanillaSpawnsW);
            var1.add(cowfreqW);
            var1.add(pigfreqW);
            var1.add(sheepfreqW);
            var1.add(chickenfreqW);
            var1.add(wolffreqW);
            var1.add(squidfreqW);
            var1.add(zombiefreqW);
            var1.add(skeletonfreqW);
            var1.add(spiderfreqW);
            var1.add(creeperfreqW);
            var1.add(enderfreqW);
            this.vanillamobwindow = new WidgetSimplewindow(var1, "Vanilla Mobs Settings");
        }

        GuiModScreen.show((Widget)this.vanillamobwindow);
    }

    public void watermobsettings()
    {
        if (this.watermobwindow == null)
        {
            WidgetClassicTwocolumn var1 = new WidgetClassicTwocolumn(new Widget[0]);
            var1.add(sharkfreqW);
            var1.add(sharkSpawnDifficultyW);
            var1.add(dolphinfreqW);
            var1.add(attackdolphinsW);
            var1.add(fishfreqW);
            var1.add(spawnpiranhaW);
            var1.add(rayfreqW);
            var1.add(jellyfishfreqW);
            this.watermobwindow = new WidgetSimplewindow(var1, "Water Mobs Settings");
        }

        GuiModScreen.show((Widget)this.watermobwindow);
    }
    */

    /*
    public static void setName(MoCEntityAnimal var0)
    {
        var0.setDisplayName(true);
        mc.displayGuiScreen(new MoCGUI(var0, var0.getName()));
    }

    public static void setName(MoCEntityDolphin var0)
    {
        var0.setDisplayName(true);
        mc.displayGuiScreen(new MoCGUI(var0, var0.getName()));
    }

    public static void setName(MoCEntityShark var0)
    {
        var0.setDisplayName(true);
        mc.displayGuiScreen(new MoCGUI(var0, var0.getName()));
    }
    */

    public static void sendNameInfo(int var0, String var1) {}

    public static void ClearVanillaSpawnLists()
    {
        ModLoader.RemoveSpawn(EntityCow.class, EnumCreatureType.creature);
        ModLoader.RemoveSpawn(EntityPig.class, EnumCreatureType.creature);
        ModLoader.RemoveSpawn(EntitySheep.class, EnumCreatureType.creature);
        ModLoader.RemoveSpawn(EntityChicken.class, EnumCreatureType.creature);
        ModLoader.RemoveSpawn(EntityWolf.class, EnumCreatureType.creature);
        ModLoader.RemoveSpawn(EntitySquid.class, EnumCreatureType.waterCreature);
    }

    public static void ClearVanillaMobSpawns()
    {
        ModLoader.RemoveSpawn(EntityCreeper.class, EnumCreatureType.monster);
        ModLoader.RemoveSpawn(EntitySkeleton.class, EnumCreatureType.monster);
        ModLoader.RemoveSpawn(EntityZombie.class, EnumCreatureType.monster);
        ModLoader.RemoveSpawn(EntitySpider.class, EnumCreatureType.monster);
        ModLoader.RemoveSpawn(EntityEnderman.class, EnumCreatureType.monster);
        ModLoader.RemoveSpawn(EntityCaveSpider.class, EnumCreatureType.monster);
        ModLoader.RemoveSpawn(EntityGhast.class, EnumCreatureType.monster);
        ModLoader.RemoveSpawn(EntityPigZombie.class, EnumCreatureType.monster);
    }

    public static void PopulateVanillaSpawnLists()
    {
        if (((Integer)cowfreq.get()).intValue() > 0)
        {
            ModLoader.AddSpawn(EntityCow.class, ((Integer)cowfreq.get()).intValue(), min, max, EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.extremeHills, BiomeGenBase.plains, BiomeGenBase.taiga, BiomeGenBase.swampland, BiomeGenBase.icePlains, BiomeGenBase.iceMountains, BiomeGenBase.ocean});
        }

        if (((Integer)pigfreq.get()).intValue() > 0)
        {
            ModLoader.AddSpawn(EntityPig.class, ((Integer)pigfreq.get()).intValue(), min, max, EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.extremeHills, BiomeGenBase.plains, BiomeGenBase.taiga, BiomeGenBase.swampland, BiomeGenBase.icePlains, BiomeGenBase.iceMountains, BiomeGenBase.ocean});
        }

        if (((Integer)sheepfreq.get()).intValue() > 0)
        {
            ModLoader.AddSpawn(EntitySheep.class, ((Integer)sheepfreq.get()).intValue(), min, max, EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.extremeHills, BiomeGenBase.plains, BiomeGenBase.taiga, BiomeGenBase.swampland, BiomeGenBase.icePlains, BiomeGenBase.iceMountains, BiomeGenBase.ocean});
        }

        if (((Integer)chickenfreq.get()).intValue() > 0)
        {
            ModLoader.AddSpawn(EntityChicken.class, ((Integer)chickenfreq.get()).intValue(), min, max, EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.extremeHills, BiomeGenBase.plains, BiomeGenBase.taiga, BiomeGenBase.swampland, BiomeGenBase.icePlains, BiomeGenBase.iceMountains, BiomeGenBase.ocean});
        }

        if (((Integer)wolffreq.get()).intValue() > 0)
        {
            ModLoader.AddSpawn(EntityWolf.class, ((Integer)wolffreq.get()).intValue(), min, max, EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.taiga, BiomeGenBase.icePlains, BiomeGenBase.iceMountains, BiomeGenBase.ocean});
        }

        if (((Integer)zombiefreq.get()).intValue() > 0)
        {
            ModLoader.AddSpawn(EntityZombie.class, ((Integer)zombiefreq.get()).intValue(), min, max, EnumCreatureType.monster);
        }

        if (((Integer)skeletonfreq.get()).intValue() > 0)
        {
            ModLoader.AddSpawn(EntitySkeleton.class, ((Integer)skeletonfreq.get()).intValue(), min, max, EnumCreatureType.monster);
        }

        if (((Integer)spiderfreq.get()).intValue() > 0)
        {
            ModLoader.AddSpawn(EntitySpider.class, ((Integer)spiderfreq.get()).intValue(), min, max, EnumCreatureType.monster);
        }

        if (((Integer)creeperfreq.get()).intValue() > 0)
        {
            ModLoader.AddSpawn(EntityCreeper.class, ((Integer)creeperfreq.get()).intValue(), min, max, EnumCreatureType.monster);
        }

        if (((Integer)enderfreq.get()).intValue() > 0)
        {
            ModLoader.AddSpawn(EntityEnderman.class, ((Integer)enderfreq.get()).intValue(), min, max, EnumCreatureType.monster);
        }

        if (((Integer)squidfreq.get()).intValue() > 0)
        {
            ModLoader.AddSpawn(EntitySquid.class, ((Integer)squidfreq.get()).intValue(), min, max, EnumCreatureType.waterCreature, new BiomeGenBase[] {BiomeGenBase.ocean, BiomeGenBase.river});
        }
    }
}
