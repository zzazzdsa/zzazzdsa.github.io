package net.minecraft.src;

import java.util.List;
import net.minecraft.src.Block;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.MoCEntityBigCat;
import net.minecraft.src.MoCEntityBunny;
import net.minecraft.src.MoCEntityHorse;
import net.minecraft.src.MoCEntityKitty;
import net.minecraft.src.TileEntitySign;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCItemWhip extends Item
{
    public MoCItemWhip(int var1)
    {
        super(var1);
        this.maxStackSize = 1;
        this.setMaxDamage(24);
    }

    public boolean isFull3D()
    {
        return true;
    }

    public ItemStack onItemRightClick2(ItemStack var1, World var2, EntityPlayer var3)
    {
        return var1;
    }

    public boolean onItemUse(ItemStack var1, EntityPlayer var2, World var3, int var4, int var5, int var6, int var7)
    {
        int var8 = 0;
        int var9 = var3.getBlockId(var4, var5, var6);
        int var10 = var3.getBlockId(var4, var5 + 1, var6);
        int var12;
        if (var7 != 0 && var10 == 0 && var9 != 0 && var9 != Block.signPost.blockID)
        {
            this.whipFX(var3, var4, var5, var6);
            var3.playSoundAtEntity(var2, "whip", 0.5F, 0.4F / (itemRand.nextFloat() * 0.4F + 0.8F));
            var1.damageItem(1, var2);
            List var17 = var3.getEntitiesWithinAABBExcludingEntity(var2, var2.boundingBox.expand(12.0D, 12.0D, 12.0D));

            for (var12 = 0; var12 < var17.size(); ++var12)
            {
                Entity var18 = (Entity)var17.get(var12);
                if (var18 instanceof MoCEntityBigCat)
                {
                    MoCEntityBigCat var19 = (MoCEntityBigCat)var18;
                    if (var19.getIsTamed())
                    {
                        var19.setSitting(!var19.getIsSitting());
                        ++var8;
                    }
                    else if (var3.difficultySetting > 0 && var19.getIsAdult())
                    {
                        var19.entityToAttack = var2;
                    }
                }

                if (var18 instanceof MoCEntityHorse)
                {
                    MoCEntityHorse var20 = (MoCEntityHorse)var18;
                    if (var20.getIsTamed())
                    {
                        var20.eatinghaystack = !var20.eatinghaystack;
                    }
                }

                if (var18 instanceof MoCEntityKitty)
                {
                    MoCEntityKitty var22 = (MoCEntityKitty)var18;
                    if (var22.getKittyState() > 2 && var22.whipeable())
                    {
                        var22.setSitting(!var22.getIsSitting());
                    }
                }
            }

            if (var8 > 6)
            {
                //var2.triggerAchievement(mod_mocreatures.Indiana);
            }

            return true;
        }
        else
        {
            if (var7 != 0 && (var10 == Block.signPost.blockID || var9 == Block.signPost.blockID) && var9 != 0)
            {
                TileEntitySign var11 = (TileEntitySign)var3.getBlockTileEntity(var4, var5 + 1, var6);
                if (var11 == null)
                {
                    var11 = (TileEntitySign)var3.getBlockTileEntity(var4, var5, var6);
                }

                if (var11 != null)
                {
                    var12 = 0;
                    List var13 = var3.loadedEntityList;

                    for (int var14 = 0; var14 < var13.size(); ++var14)
                    {
                        Entity var15 = (Entity)var13.get(var14);
                        if (var15 instanceof MoCEntityBunny)
                        {
                            MoCEntityBunny var16 = (MoCEntityBunny)var15;
                            ++var12;
                            var16.setEntityDead();
                        }
                    }

                    String var21 = String.valueOf(var12);
                    var11.signText[0] = "";
                    var11.signText[1] = "R.I.P.";
                    var11.signText[2] = var21 + " Bunnies";
                    var11.signText[3] = "";
                    if (var12 > 69)
                    {
                        //var2.triggerAchievement(mod_mocreatures.BunnyKilla);
                    }

                    this.whipFX(var3, var4, var5, var6);
                    var3.playSoundAtEntity(var2, "swhip", 0.5F, 0.4F / (itemRand.nextFloat() * 0.4F + 0.8F));
                    var1.damageItem(1, var2);
                    return true;
                }
            }

            return false;
        }
    }

    public void whipFX(World var1, int var2, int var3, int var4)
    {
        double var5 = (double)((float)var2 + 0.5F);
        double var7 = (double)((float)var3 + 1.0F);
        double var9 = (double)((float)var4 + 0.5F);
        double var11 = 0.2199999988079071D;
        double var13 = 0.27000001072883606D;
        var1.spawnParticle("smoke", var5 - var13, var7 + var11, var9, 0.0D, 0.0D, 0.0D);
        var1.spawnParticle("flame", var5 - var13, var7 + var11, var9, 0.0D, 0.0D, 0.0D);
        var1.spawnParticle("smoke", var5 + var13, var7 + var11, var9, 0.0D, 0.0D, 0.0D);
        var1.spawnParticle("flame", var5 + var13, var7 + var11, var9, 0.0D, 0.0D, 0.0D);
        var1.spawnParticle("smoke", var5, var7 + var11, var9 - var13, 0.0D, 0.0D, 0.0D);
        var1.spawnParticle("flame", var5, var7 + var11, var9 - var13, 0.0D, 0.0D, 0.0D);
        var1.spawnParticle("smoke", var5, var7 + var11, var9 + var13, 0.0D, 0.0D, 0.0D);
        var1.spawnParticle("flame", var5, var7 + var11, var9 + var13, 0.0D, 0.0D, 0.0D);
        var1.spawnParticle("smoke", var5, var7, var9, 0.0D, 0.0D, 0.0D);
        var1.spawnParticle("flame", var5, var7, var9, 0.0D, 0.0D, 0.0D);
    }
}
