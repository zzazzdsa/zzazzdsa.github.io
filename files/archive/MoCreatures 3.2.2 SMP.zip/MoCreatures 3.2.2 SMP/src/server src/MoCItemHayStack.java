package net.minecraft.src;

import net.minecraft.src.Item;

public class MoCItemHayStack extends Item
{
    public MoCItemHayStack(int var1)
    {
        super(var1);
        this.maxStackSize = 16;
    }
}
