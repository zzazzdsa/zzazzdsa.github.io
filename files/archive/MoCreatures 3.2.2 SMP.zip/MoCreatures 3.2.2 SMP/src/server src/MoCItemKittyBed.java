package net.minecraft.src;

import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.MoCEntityKittyBed;
import net.minecraft.src.World;

public class MoCItemKittyBed extends Item
{
    public int itemcolor;

    public MoCItemKittyBed(int var1)
    {
        super(var1);
        this.maxStackSize = 8;
        this.setHasSubtypes(true);
    }

    public MoCItemKittyBed(int var1, int var2)
    {
        this(var1);
        this.itemcolor = var2;
    }

    public String getItemNameIS(ItemStack var1)
    {
        return super.getItemName() + "." + var1.getItemDamage();
    }

    public ItemStack onItemRightClick(ItemStack var1, World var2, EntityPlayer var3)
    {
        --var1.stackSize;
        if (!var2.isRemote)
        {
            MoCEntityKittyBed var4 = new MoCEntityKittyBed(var2, var1.getItemDamage());
            var4.setPosition(var3.posX, var3.posY, var3.posZ);
            var2.spawnEntityInWorld(var4);
            var4.motionY += (double)(var2.rand.nextFloat() * 0.05F);
            var4.motionX += (double)((var2.rand.nextFloat() - var2.rand.nextFloat()) * 0.3F);
            var4.motionZ += (double)((var2.rand.nextFloat() - var2.rand.nextFloat()) * 0.3F);
        }

        return var1;
    }
}
