package net.minecraft.src;

import java.util.List;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityMob;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.EntityWolf;
import net.minecraft.src.EnumSkyBlock;
import net.minecraft.src.MathHelper;
import net.minecraft.src.MoCEntityAnimal;
import net.minecraft.src.MoCEntityHorse;
import net.minecraft.src.MoCEntityKittyBed;
import net.minecraft.src.MoCEntityLitterBox;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityMob extends EntityMob
{
    private boolean textureSet;
    public boolean isTamed;
    private boolean isAdult;
    private boolean chosenType;
    protected int maxHealth;
    private float edad;
    private String myName = "";
    private boolean displayName;
    private int type;

    public MoCEntityMob(World var1)
    {
        super(var1);
        this.setTamed(false);
    }

    protected void entityInit()
    {
        super.entityInit();
    }

    public boolean getDisplayName()
    {
        return this.displayName;
    }

    public boolean getIsAdult()
    {
        return this.isAdult;
    }

    public boolean getIsTamed()
    {
        return this.isTamed;
    }

    public String getName()
    {
        return this.myName;
    }

    public String getTexture()
    {
        return this.texture;
    }

    public boolean getTypeChosen()
    {
        return this.chosenType;
    }

    public int getType()
    {
        return this.type;
    }

    public float getEdad()
    {
        return this.edad;
    }

    public void setEdad(float var1)
    {
        this.edad = var1;
    }

    public void setType(int var1)
    {
        this.type = var1;
    }

    public void setAdult(boolean var1)
    {
        this.isAdult = var1;
    }

    public void setDisplayName(boolean var1)
    {
        this.displayName = var1;
    }

    public void setName(String var1)
    {
        this.myName = var1;
    }

    public void setTamed(boolean var1)
    {
        this.isTamed = var1;
    }

    public void setTexture(String var1)
    {
        this.texture = var1;
    }

    public void setTypeChosen(boolean var1)
    {
        this.chosenType = var1;
    }

    public boolean getCanSpawnHereLiving()
    {
        return this.worldObj.checkIfAABBIsClear(this.boundingBox) && this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox).size() == 0 && !this.worldObj.isAnyLiquid(this.boundingBox);
    }

    public boolean getCanSpawnHereCreature()
    {
        int var1 = MathHelper.floor_double(this.posX);
        int var2 = MathHelper.floor_double(this.boundingBox.minY);
        int var3 = MathHelper.floor_double(this.posZ);
        return this.getBlockPathWeight(var1, var2, var3) >= 0.0F;
    }

    public boolean getCanSpawnHereMob()
    {
        int var1 = MathHelper.floor_double(this.posX);
        int var2 = MathHelper.floor_double(this.boundingBox.minY);
        int var3 = MathHelper.floor_double(this.posZ);
        if (this.worldObj.getSavedLightValue(EnumSkyBlock.Sky, var1, var2, var3) > this.rand.nextInt(32))
        {
            return false;
        }
        else
        {
            int var4 = this.worldObj.getBlockLightValue(var1, var2, var3);
            if (this.worldObj.isThundering())
            {
                int var5 = this.worldObj.skylightSubtracted;
                this.worldObj.skylightSubtracted = 10;
                var4 = this.worldObj.getBlockLightValue(var1, var2, var3);
                this.worldObj.skylightSubtracted = var5;
            }

            return var4 <= this.rand.nextInt(8);
        }
    }

    protected EntityLiving getClosestEntityLiving(Entity var1, double var2)
    {
        double var4 = -1.0D;
        EntityLiving var6 = null;
        List var7 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(var2, var2, var2));

        for (int var8 = 0; var8 < var7.size(); ++var8)
        {
            Entity var9 = (Entity)var7.get(var8);
            if (!this.entitiesToIgnore(var9))
            {
                double var10 = var9.getDistanceSq(var1.posX, var1.posY, var1.posZ);
                if ((var2 < 0.0D || var10 < var2 * var2) && (var4 == -1.0D || var10 < var4) && ((EntityLiving)var9).canEntityBeSeen(var1))
                {
                    var4 = var10;
                    var6 = (EntityLiving)var9;
                }
            }
        }

        return var6;
    }

    public boolean entitiesToIgnore(Entity var1)
    {
        return !(var1 instanceof EntityLiving) || var1 instanceof EntityPlayer && this.getIsTamed() || var1 instanceof MoCEntityKittyBed || var1 instanceof MoCEntityLitterBox || this.getIsTamed() && var1 instanceof MoCEntityAnimal && ((MoCEntityAnimal)var1).getIsTamed() || var1 instanceof EntityWolf && !((Boolean)mod_mocreatures.attackwolves.get()).booleanValue() || var1 instanceof MoCEntityHorse && !((Boolean)mod_mocreatures.attackhorses.get()).booleanValue();
    }

    public int getMaxHealth()
    {
        return 20;
    }
}
