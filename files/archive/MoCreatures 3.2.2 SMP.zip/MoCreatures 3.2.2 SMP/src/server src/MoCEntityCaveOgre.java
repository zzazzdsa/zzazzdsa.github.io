package net.minecraft.src;

import net.minecraft.src.IMob;
import net.minecraft.src.Item;
import net.minecraft.src.MathHelper;
import net.minecraft.src.MoCEntityOgre;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityCaveOgre extends MoCEntityOgre implements IMob
{
    public MoCEntityCaveOgre(World var1)
    {
        super(var1);
        this.attackStrength = 3;
        this.attackRange = (double)((Integer)mod_mocreatures.ogrerange.get()).intValue();
        this.texture = "/mocreatures/caveogre.png";
        this.setSize(1.5F, 4.0F);
        this.health = 50;
        this.destroyForce = ((Float)mod_mocreatures.cogreStrength.get()).floatValue();
        this.isImmuneToFire = false;
        this.frequencyA = 35;
    }

    public boolean getCanSpawnHere()
    {
        return ((Integer)mod_mocreatures.cogrefreq.get()).intValue() > 0 && this.worldObj.difficultySetting >= ((Integer)mod_mocreatures.cogreSpawnDifficulty.get()).intValue() + 1 && !this.worldObj.canBlockSeeTheSky(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ)) && this.posY < 50.0D && super.d2();
    }

    protected int getDropItemId()
    {
        return Item.diamond.shiftedIndex;
    }

    public void onLivingUpdate()
    {
        if (!this.worldObj.isRemote && this.worldObj.isDaytime())
        {
            float var1 = this.getEntityBrightness(1.0F);
            if (var1 > 0.5F && this.worldObj.canBlockSeeTheSky(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ)) && this.rand.nextFloat() * 30.0F < (var1 - 0.4F) * 2.0F)
            {
                this.health -= 5;
            }
        }

        super.onLivingUpdate();
    }

    public void updateStrength()
    {
        this.destroyForce = ((Float)mod_mocreatures.cogreStrength.get()).floatValue();
        this.attackRange = (double)((Integer)mod_mocreatures.ogrerange.get()).intValue();
    }
}
