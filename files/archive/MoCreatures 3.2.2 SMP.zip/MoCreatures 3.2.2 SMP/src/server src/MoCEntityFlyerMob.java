package net.minecraft.src;

import net.minecraft.src.Block;
import net.minecraft.src.DamageSource;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.MathHelper;
import net.minecraft.src.MoCEntityMob;
import net.minecraft.src.PathEntity;
import net.minecraft.src.Vec3D;
import net.minecraft.src.World;

public class MoCEntityFlyerMob extends MoCEntityMob
{
    protected int attackStrength;
    private PathEntity entitypath;
    public double speedModifier;

    public MoCEntityFlyerMob(World var1)
    {
        super(var1);
        this.isCollidedVertically = false;
        this.speedModifier = 0.03D;
        this.setSize(1.5F, 1.5F);
        this.attackStrength = 3;
        this.health = 10;
    }

    protected void attackEntity(Entity var1, float var2)
    {
        if (this.attackTime <= 0 && (double)var2 < 2.5D && var1.boundingBox.maxY > this.boundingBox.minY && var1.boundingBox.minY < this.boundingBox.maxY)
        {
            this.attackTime = 20;
            var1.attackEntityFrom(DamageSource.causeMobDamage(this), this.attackStrength);
        }
    }

    protected void fall(float var1) {}

    protected Entity findPlayerToAttack()
    {
        EntityPlayer var1 = this.worldObj.getClosestPlayerToEntity(this, 20.0D);
        return var1 != null && this.canEntityBeSeen(var1) ? var1 : null;
    }

    public boolean getCanSpawnHere()
    {
        return super.getCanSpawnHere();
    }

    public boolean isOnLadder()
    {
        return false;
    }

    public void moveEntityWithHeading(float var1, float var2)
    {
        double var3;
        if (this.handleWaterMovement())
        {
            var3 = this.posY;
            this.moveFlying(var1, var2, 0.02F);
            this.moveEntity(this.motionX, this.motionY, this.motionZ);
            this.motionX *= 0.800000011920929D;
            this.motionY *= 0.800000011920929D;
            this.motionZ *= 0.800000011920929D;
        }
        else if (this.handleLavaMovement())
        {
            var3 = this.posY;
            this.moveFlying(var1, var2, 0.02F);
            this.moveEntity(this.motionX, this.motionY, this.motionZ);
            this.motionX *= 0.5D;
            this.motionY *= 0.5D;
            this.motionZ *= 0.5D;
        }
        else
        {
            float var8 = 0.91F;
            if (this.onGround)
            {
                var8 = 0.5460001F;
                int var4 = this.worldObj.getBlockId(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.boundingBox.minY) - 1, MathHelper.floor_double(this.posZ));
                if (var4 > 0)
                {
                    var8 = Block.blocksList[var4].slipperiness * 0.91F;
                }
            }

            float var9 = 0.162771F / (var8 * var8 * var8);
            this.moveFlying(var1, var2, this.onGround ? 0.1F * var9 : 0.02F);
            var8 = 0.91F;
            if (this.onGround)
            {
                var8 = 0.5460001F;
                int var5 = this.worldObj.getBlockId(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.boundingBox.minY) - 1, MathHelper.floor_double(this.posZ));
                if (var5 > 0)
                {
                    var8 = Block.blocksList[var5].slipperiness * 0.91F;
                }
            }

            this.moveEntity(this.motionX, this.motionY, this.motionZ);
            this.motionX *= (double)var8;
            this.motionY *= (double)var8;
            this.motionZ *= (double)var8;
            if (this.isCollidedHorizontally)
            {
                this.motionY = 0.2D;
            }

            if (this.rand.nextInt(30) == 0)
            {
                this.motionY = -0.25D;
            }
        }

        this.field_9142_bc = this.field_9141_bd;
        var3 = this.posX - this.prevPosX;
        double var10 = this.posZ - this.prevPosZ;
        float var7 = MathHelper.sqrt_double(var3 * var3 + var10 * var10) * 4.0F;
        if (var7 > 1.0F)
        {
            var7 = 1.0F;
        }

        this.field_9141_bd += (var7 - this.field_9141_bd) * 0.4F;
        this.field_386_ba += this.field_9141_bd;
    }

    protected void updateEntityActionState()
    {
        this.hasAttacked = false;
        float var1 = 16.0F;
        if (this.entityToAttack == null)
        {
            this.entityToAttack = this.findPlayerToAttack();
            if (this.entityToAttack != null)
            {
                this.entitypath = this.worldObj.getPathToEntity(this, this.entityToAttack, var1);
            }
        }
        else if (!this.entityToAttack.isEntityAlive())
        {
            this.entityToAttack = null;
        }
        else
        {
            float var2 = this.entityToAttack.getDistanceToEntity(this);
            if (this.canEntityBeSeen(this.entityToAttack))
            {
                this.attackEntity(this.entityToAttack, var2);
            }
        }

        if (!this.hasAttacked && this.entityToAttack != null && (this.entitypath == null || this.rand.nextInt(10) == 0))
        {
            this.entitypath = this.worldObj.getPathToEntity(this, this.entityToAttack, var1);
        }
        else if (this.entitypath == null && this.rand.nextInt(80) == 0 || this.rand.nextInt(80) == 0)
        {
            boolean var20 = false;
            int var3 = -1;
            int var4 = -1;
            int var5 = -1;
            float var6 = -99999.0F;

            for (int var7 = 0; var7 < 10; ++var7)
            {
                int var8 = MathHelper.floor_double(this.posX + (double)this.rand.nextInt(13) - 6.0D);
                int var9 = MathHelper.floor_double(this.posY + (double)this.rand.nextInt(7) - 3.0D);
                int var10 = MathHelper.floor_double(this.posZ + (double)this.rand.nextInt(13) - 6.0D);
                float var11 = this.getBlockPathWeight(var8, var9, var10);
                if (var11 > var6)
                {
                    var6 = var11;
                    var3 = var8;
                    var4 = var9;
                    var5 = var10;
                    var20 = true;
                }
            }

            if (var20)
            {
                this.entitypath = this.worldObj.getEntityPathToXYZ(this, var3, var4, var5, 10.0F);
            }
        }

        int var21 = MathHelper.floor_double(this.boundingBox.minY);
        boolean var22 = this.handleWaterMovement();
        boolean var23 = this.handleLavaMovement();
        this.rotationPitch = 0.0F;
        if (this.entitypath != null && this.rand.nextInt(100) != 0)
        {
            Vec3D var24 = this.entitypath.getPosition(this);
            double var25 = (double)(this.width * 2.0F);

            while (var24 != null && var24.squareDistanceTo(this.posX, var24.yCoord, this.posZ) < var25 * var25)
            {
                this.entitypath.incrementPathIndex();
                if (this.entitypath.isFinished())
                {
                    var24 = null;
                    this.entitypath = null;
                }
                else
                {
                    var24 = this.entitypath.getPosition(this);
                }
            }

            this.isJumping = false;
            if (var24 != null)
            {
                var25 = var24.xCoord - this.posX;
                double var26 = var24.zCoord - this.posZ;
                double var27 = var24.yCoord - (double)var21;
                float var12 = (float)(Math.atan2(var26, var25) * 180.0D / 3.141592741012573D) - 90.0F;
                float var13 = var12 - this.rotationYaw;

                for (this.moveForward = this.moveSpeed; var13 < -180.0F; var13 += 360.0F)
                {
                    ;
                }

                while (var13 >= 180.0F)
                {
                    var13 -= 360.0F;
                }

                if (var13 > 30.0F)
                {
                    var13 = 30.0F;
                }

                if (var13 < -30.0F)
                {
                    var13 = -30.0F;
                }

                this.rotationYaw += var13;
                if (this.hasAttacked && this.entityToAttack != null)
                {
                    double var14 = this.entityToAttack.posX - this.posX;
                    double var16 = this.entityToAttack.posZ - this.posZ;
                    float var18 = this.rotationYaw;
                    this.rotationYaw = (float)(Math.atan2(var16, var14) * 180.0D / 3.141592741012573D) - 90.0F;
                    float var19 = (var18 - this.rotationYaw + 90.0F) * 3.141593F / 180.0F;
                    this.moveStrafing = -MathHelper.sin(var19) * this.moveForward * 1.0F;
                    this.moveForward = MathHelper.cos(var19) * this.moveForward * 1.0F;
                }

                if (var27 > 0.0D)
                {
                    this.isJumping = true;
                }
            }

            if (this.entityToAttack != null)
            {
                this.faceEntity(this.entityToAttack, 30.0F, 30.0F);
            }

            if (this.isCollidedHorizontally)
            {
                this.isJumping = true;
            }

            if (this.rand.nextFloat() < 0.8F && (var22 || var23))
            {
                this.isJumping = true;
            }
        }
        else
        {
            super.updateEntityActionState();
            this.entitypath = null;
        }
    }
}
