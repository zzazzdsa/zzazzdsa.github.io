package net.minecraft.src;

import java.util.List;
import net.minecraft.src.Block;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityCreeper;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityMob;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.MoCEntityOgre;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityLitterBox extends EntityLiving
{
    public int littertime;
    private boolean usedLitter;
    private boolean pickedUp;

    public MoCEntityLitterBox(World var1)
    {
        super(var1);
        this.setSize(1.0F, 0.3F);
        this.texture = "/mocreatures/litterbox.png";
    }

    public MoCEntityLitterBox(World var1, double var2, double var4, double var6)
    {
        super(var1);
        this.setSize(1.0F, 0.3F);
        this.texture = "/mocreatures/litterbox.png";
    }

    public boolean attackEntityFrom(Entity var1, int var2)
    {
        return false;
    }

    public boolean canBeCollidedWith()
    {
        return !this.isDead;
    }

    public boolean canBePushed()
    {
        return !this.isDead;
    }

    public boolean canBreatheUnderwater()
    {
        return true;
    }

    protected boolean canDespawn()
    {
        return false;
    }

    protected void fall(float var1) {}

    protected String getDeathSound()
    {
        return null;
    }

    public String getEntityTexture()
    {
        return "/mocreatures/litterbox.png";
    }

    protected String getHurtSound()
    {
        return null;
    }

    protected String getLivingSound()
    {
        return null;
    }

    public boolean getPickedUp()
    {
        return this.pickedUp;
    }

    protected float getSoundVolume()
    {
        return 0.0F;
    }

    public boolean getUsedLitter()
    {
        return this.usedLitter;
    }

    public double getYOffset()
    {
        if (this.ridingEntity instanceof EntityPlayer && !this.worldObj.isRemote)
        {
            this.setPickedUp(true);
            return (double)(this.yOffset - 1.15F);
        }
        else
        {
            return (double)this.yOffset;
        }
    }

    public void handleHealthUpdate(byte var1) {}

    public boolean interact(EntityPlayer var1)
    {
        ItemStack var2 = var1.inventory.getCurrentItem();
        if (var2 != null && (var2.itemID == Item.pickaxeStone.shiftedIndex || var2.itemID == Item.pickaxeWood.shiftedIndex || var2.itemID == Item.pickaxeSteel.shiftedIndex || var2.itemID == Item.pickaxeGold.shiftedIndex || var2.itemID == Item.pickaxeDiamond.shiftedIndex))
        {
            var1.inventory.addItemStackToInventory(new ItemStack(mod_mocreatures.litterbox));
            this.worldObj.playSoundAtEntity(this, "random.pop", 0.2F, ((this.rand.nextFloat() - this.rand.nextFloat()) * 0.7F + 1.0F) * 2.0F);
            this.setEntityDead();
            return true;
        }
        else if (var2 != null && var2.itemID == Block.sand.blockID)
        {
            if (--var2.stackSize == 0)
            {
                var1.inventory.setInventorySlotContents(var1.inventory.currentItem, (ItemStack)null);
            }

            this.setUsedLitter(false);
            this.littertime = 0;
            return true;
        }
        else
        {
            this.rotationYaw = var1.rotationYaw;
            if (!this.worldObj.isRemote)
            {
                this.mountEntity(var1);
            }

            this.worldObj.playSoundAtEntity(this, "mob.chickenplop", 1.0F, (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F);
            return true;
        }
    }

    public void moveEntity(double var1, double var3, double var5)
    {
        if ((this.ridingEntity != null || !this.onGround || !((Boolean)mod_mocreatures.staticlitter.get()).booleanValue()) && !this.worldObj.isRemote)
        {
            super.moveEntity(var1, var3, var5);
        }
    }

    public void onUpdate()
    {
        super.onUpdate();
        if (this.onGround)
        {
            this.setPickedUp(false);
        }

        if (this.getUsedLitter())
        {
            ++this.littertime;
            this.worldObj.spawnParticle("smoke", this.posX, this.posY, this.posZ, 0.0D, 0.0D, 0.0D);
            List var1 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(12.0D, 4.0D, 12.0D));

            for (int var2 = 0; var2 < var1.size(); ++var2)
            {
                Entity var3 = (Entity)var1.get(var2);
                if (var3 instanceof EntityMob)
                {
                    EntityMob var4 = (EntityMob)var3;
                    var4.entityToAttack = this;
                    if (var4 instanceof EntityCreeper)
                    {
                        ((EntityCreeper)var4).timeSinceIgnited = 5;
                    }

                    if (var4 instanceof MoCEntityOgre)
                    {
                        ((MoCEntityOgre)var4).setOgreAttack(false);
                    }
                }
            }
        }

        if (this.littertime > 5000)
        {
            this.setUsedLitter(false);
            this.littertime = 0;
        }
    }

    public void readEntityFromNBT(NBTTagCompound var1)
    {
        this.setUsedLitter(var1.getBoolean("UsedLitter"));
    }

    public void setPickedUp(boolean var1)
    {
        this.pickedUp = var1;
    }

    public void setUsedLitter(boolean var1)
    {
        this.usedLitter = var1;
    }

    protected void updateEntityActionState() {}

    public void writeEntityToNBT(NBTTagCompound var1)
    {
        var1.setBoolean("UsedLitter", this.getUsedLitter());
    }

    public int getMaxHealth()
    {
        return 20;
    }
}
