package net.minecraft.src;

import net.minecraft.src.DamageSource;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.MoCEntityAnimal;
import net.minecraft.src.MoCEntityBigCat;
import net.minecraft.src.MoCTools;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityBear extends MoCEntityAnimal
{
    protected double attackRange;
    protected int force;

    public MoCEntityBear(World var1)
    {
        super(var1);
        this.texture = "/mocreatures/bear.png";
        this.setSize(0.9F, 1.3F);
        this.health = 25;
        this.force = 5;
        this.attackRange = 16.0D;
        this.setTamed(false);
    }

    protected void attackEntity(Entity var1, float var2)
    {
        if (this.attackTime <= 0 && (double)var2 < 2.5D && var1.boundingBox.maxY > this.boundingBox.minY && var1.boundingBox.minY < this.boundingBox.maxY)
        {
            this.attackTime = 20;
            var1.attackEntityFrom(DamageSource.causeMobDamage(this), this.force);
            if (!(var1 instanceof EntityPlayer))
            {
                MoCTools.destroyDrops(this, 3.0D);
            }
        }
    }

    public boolean attackEntityFrom(DamageSource var1, int var2)
    {
        if (super.attackEntityFrom(var1, var2))
        {
            Entity var3 = var1.getEntity();
            if (this.riddenByEntity != var3 && this.ridingEntity != var3)
            {
                if (var3 != this && this.worldObj.difficultySetting > 0)
                {
                    this.entityToAttack = var3;
                }

                return true;
            }
            else
            {
                return true;
            }
        }
        else
        {
            return false;
        }
    }

    public boolean isNotScared()
    {
        return true;
    }

    protected Entity findPlayerToAttack()
    {
        if (this.worldObj.difficultySetting > 0)
        {
            float var1 = this.getEntityBrightness(1.0F);
            if (var1 < 0.0F)
            {
                EntityPlayer var2 = this.worldObj.getClosestPlayerToEntity(this, this.attackRange);
                if (var2 != null)
                {
                    return var2;
                }
            }

            if (this.rand.nextInt(80) == 0)
            {
                EntityLiving var3 = this.getClosestEntityLiving(this, 10.0D);
                return var3;
            }
        }

        return null;
    }

    public boolean getCanSpawnHere()
    {
        return MoCTools.isNearTorch(this) ? false : ((Integer)mod_mocreatures.bearfreq.get()).intValue() > 0 && super.getCanSpawnHere();
    }

    public boolean getCanSpawnHere2()
    {
        return super.getCanSpawnHere();
    }

    public boolean entitiesToIgnore(Entity var1)
    {
        return super.entitiesToIgnore(var1) || var1 instanceof MoCEntityBear || var1 instanceof MoCEntityBigCat || var1 instanceof EntityPlayer;
    }

    protected String getDeathSound()
    {
        return "beardying";
    }

    protected int getDropItemId()
    {
        return Item.fishRaw.shiftedIndex;
    }

    protected String getHurtSound()
    {
        return "bearhurt";
    }

    protected String getLivingSound()
    {
        return "beargrunt";
    }

    public int getMaxSpawnedInChunk()
    {
        return 2;
    }
}
