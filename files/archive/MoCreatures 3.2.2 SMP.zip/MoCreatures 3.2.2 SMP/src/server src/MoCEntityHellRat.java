package net.minecraft.src;

import net.minecraft.src.Item;
import net.minecraft.src.MoCEntityRat;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityHellRat extends MoCEntityRat
{
    public MoCEntityHellRat(World var1)
    {
        super(var1);
        this.texture = "/mocreatures/rath.png";
        this.setSize(0.7F, 0.7F);
        this.health = 20;
        this.attackStrength = 2;
        this.isImmuneToFire = true;
    }

    public boolean getCanSpawnHere()
    {
        return ((Integer)mod_mocreatures.hellratfreq.get()).intValue() > 0 && super.getCanSpawnHere();
    }

    protected int getDropItemId()
    {
        return Item.redstone.shiftedIndex;
    }
}
