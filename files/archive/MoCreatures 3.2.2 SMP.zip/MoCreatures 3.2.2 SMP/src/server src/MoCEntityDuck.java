package net.minecraft.src;

import net.minecraft.src.EntityChicken;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityDuck extends EntityChicken
{
    public MoCEntityDuck(World var1)
    {
        super(var1);
        this.texture = "/mocreatures/duck.png";
        this.setSize(0.3F, 0.4F);
        this.health = 4;
        this.timeUntilNextEgg = this.rand.nextInt(6000) + 6000;
    }

    public boolean getCanSpawnHere()
    {
        return ((Integer)mod_mocreatures.duckfreq.get()).intValue() > 0 && super.getCanSpawnHere();
    }

    protected String getDeathSound()
    {
        return "duckhurt";
    }

    protected String getHurtSound()
    {
        return "duckhurt";
    }

    protected String getLivingSound()
    {
        return "duck";
    }

    protected boolean canDespawn()
    {
        return true;
    }
}
