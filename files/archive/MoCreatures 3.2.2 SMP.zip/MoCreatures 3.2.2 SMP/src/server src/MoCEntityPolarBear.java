package net.minecraft.src;

import net.minecraft.src.Entity;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.MoCEntityBear;
import net.minecraft.src.MoCTools;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityPolarBear extends MoCEntityBear
{
    public MoCEntityPolarBear(World var1)
    {
        super(var1);
        this.texture = "/mocreatures/polarbear.png";
        this.attackRange = 1.0D;
        this.health = 30;
    }

    protected void entityInit()
    {
        if (this.worldObj.difficultySetting == 1)
        {
            this.attackRange = 5.0D;
            this.force = 3;
        }
        else if (this.worldObj.difficultySetting > 1)
        {
            this.attackRange = 8.0D;
            this.force = 5;
        }

        super.entityInit();
    }

    protected Entity findPlayerToAttack()
    {
        if (this.worldObj.difficultySetting > 0)
        {
            EntityPlayer var1 = this.worldObj.getClosestPlayerToEntity(this, this.attackRange);
            if (var1 != null && this.worldObj.difficultySetting > 0)
            {
                return var1;
            }

            if (this.rand.nextInt(20) == 0)
            {
                EntityLiving var2 = this.getClosestEntityLiving(this, 8.0D);
                return var2;
            }
        }

        return null;
    }

    public boolean getCanSpawnHere()
    {
        return MoCTools.isNearTorch(this) ? false : ((Integer)mod_mocreatures.pbearfreq.get()).intValue() > 0 && super.getCanSpawnHere2();
    }

    public int getMaxSpawnedInChunk()
    {
        return 2;
    }
}
