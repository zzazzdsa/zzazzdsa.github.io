package net.minecraft.src;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import net.minecraft.src.AxisAlignedBB;
import net.minecraft.src.BiomeGenBase;
import net.minecraft.src.Block;
import net.minecraft.src.BlockFluid;
import net.minecraft.src.ChunkCoordIntPair;
import net.minecraft.src.ChunkPosition;
import net.minecraft.src.DamageSource;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityChicken;
import net.minecraft.src.EntityCow;
import net.minecraft.src.EntityCreature;
import net.minecraft.src.EntityItem;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityPig;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.EntitySheep;
import net.minecraft.src.EntitySquid;
import net.minecraft.src.EntityWolf;
import net.minecraft.src.EnumCreatureType;
import net.minecraft.src.Material;
import net.minecraft.src.MathHelper;
import net.minecraft.src.MoCEntityOgre;
import net.minecraft.src.PathEntity;
import net.minecraft.src.Vec3D;
import net.minecraft.src.World;
import net.minecraft.src.WorldChunkManager;
import net.minecraft.src.mod_mocreatures;

public class MoCTools
{
    public static boolean NearMaterialWithDistance(Entity var0, Double var1, Material var2)
    {
        AxisAlignedBB var3 = var0.boundingBox.expand(var1.doubleValue(), var1.doubleValue(), var1.doubleValue());
        int var4 = MathHelper.floor_double(var3.minX);
        int var5 = MathHelper.floor_double(var3.maxX + 1.0D);
        int var6 = MathHelper.floor_double(var3.minY);
        int var7 = MathHelper.floor_double(var3.maxY + 1.0D);
        int var8 = MathHelper.floor_double(var3.minZ);
        int var9 = MathHelper.floor_double(var3.maxZ + 1.0D);

        for (int var10 = var4; var10 < var5; ++var10)
        {
            for (int var11 = var6; var11 < var7; ++var11)
            {
                for (int var12 = var8; var12 < var9; ++var12)
                {
                    int var13 = var0.worldObj.getBlockId(var10, var11, var12);
                    if (var13 != 0 && Block.blocksList[var13].blockMaterial == var2)
                    {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    public static boolean isNearTorch(Entity var0)
    {
        return isNearBlockName(var0, Double.valueOf(8.0D), "tile.torch");
    }

    public static boolean isNearTorch(Entity var0, Double var1)
    {
        return isNearBlockName(var0, var1, "tile.torch");
    }

    public static boolean isNearBlockName(Entity var0, Double var1, String var2)
    {
        AxisAlignedBB var3 = var0.boundingBox.expand(var1.doubleValue(), var1.doubleValue() / 2.0D, var1.doubleValue());
        int var4 = MathHelper.floor_double(var3.minX);
        int var5 = MathHelper.floor_double(var3.maxX + 1.0D);
        int var6 = MathHelper.floor_double(var3.minY);
        int var7 = MathHelper.floor_double(var3.maxY + 1.0D);
        int var8 = MathHelper.floor_double(var3.minZ);
        int var9 = MathHelper.floor_double(var3.maxZ + 1.0D);

        for (int var10 = var4; var10 < var5; ++var10)
        {
            for (int var11 = var6; var11 < var7; ++var11)
            {
                for (int var12 = var8; var12 < var9; ++var12)
                {
                    int var13 = var0.worldObj.getBlockId(var10, var11, var12);
                    if (var13 != 0)
                    {
                        String var14 = "";
                        var14 = Block.blocksList[var13].getBlockName();
                        if (var14 != null && var14 != "" && var14.equals(var2))
                        {
                            return true;
                        }
                    }
                }
            }
        }

        return false;
    }

    public static void checkForTwistedEntities(Entity crocEnt)
    {
        boolean var0 = false;

        for (int var1 = 0; var1 < crocEnt.worldObj.loadedEntityList.size(); ++var1)
        {
            Entity var2 = (Entity)crocEnt.worldObj.loadedEntityList.get(var1);
            if (var2 instanceof EntityLiving)
            {
                EntityLiving var3 = (EntityLiving)var2;
                if (var3.deathTime > 0 && var3.ridingEntity == null && var3.health > 0)
                {
                    var3.deathTime = 0;
                }
            }
        }
    }

    public static double getSqDistanceTo(Entity var0, int var1, int var2, int var3)
    {
        double var4 = var0.posX - (double)var1;
        double var6 = var0.posY - (double)var2;
        double var8 = var0.posZ - (double)var3;
        return Math.sqrt(var4 * var4 + var6 * var6 + var8 * var8);
    }

    public static int[] ReturnNearestMaterialCoord(Entity var0, Material var1, Double var2, Double var3)
    {
        double var4 = -1.0D;
        double var6 = 0.0D;
        int var8 = -9999;
        int var9 = -1;
        int var10 = -1;
        AxisAlignedBB var11 = var0.boundingBox.expand(var2.doubleValue(), var3.doubleValue(), var2.doubleValue());
        int var12 = MathHelper.floor_double(var11.minX);
        int var13 = MathHelper.floor_double(var11.maxX + 1.0D);
        int var14 = MathHelper.floor_double(var11.minY);
        int var15 = MathHelper.floor_double(var11.maxY + 1.0D);
        int var16 = MathHelper.floor_double(var11.minZ);
        int var17 = MathHelper.floor_double(var11.maxZ + 1.0D);

        for (int var18 = var12; var18 < var13; ++var18)
        {
            for (int var19 = var14; var19 < var15; ++var19)
            {
                for (int var20 = var16; var20 < var17; ++var20)
                {
                    int var21 = var0.worldObj.getBlockId(var18, var19, var20);
                    if (var21 != 0 && Block.blocksList[var21].blockMaterial == var1)
                    {
                        var6 = getSqDistanceTo(var0, var18, var19, var20);
                        if (var4 == -1.0D)
                        {
                            var8 = var18;
                            var9 = var19;
                            var10 = var20;
                            var4 = var6;
                        }

                        if (var6 < var4)
                        {
                            var8 = var18;
                            var9 = var19;
                            var10 = var20;
                            var4 = var6;
                        }
                    }
                }
            }
        }

        if (var0.posX > (double)var8)
        {
            var8 -= 2;
        }
        else
        {
            var8 += 2;
        }

        if (var0.posZ > (double)var10)
        {
            var10 -= 2;
        }
        else
        {
            var10 += 2;
        }

        return new int[] {var8, var9, var10};
    }

    public static void MoveCreatureToXYZ(EntityCreature var0, int var1, int var2, int var3, float var4)
    {
        PathEntity var5 = var0.worldObj.getEntityPathToXYZ(var0, var1, var2, var3, var4);
        if (var5 != null)
        {
            var0.setPathToEntity(var5);
        }
    }

    public static void MoveToWater(EntityCreature var0)
    {
        int[] var1 = ReturnNearestMaterialCoord(var0, Material.water, Double.valueOf(20.0D), Double.valueOf(2.0D));
        if (var1[0] > -1000)
        {
            MoveCreatureToXYZ(var0, var1[0], var1[1], var1[2], 24.0F);
        }
    }

    public static float realAngle(float var0)
    {
        return var0 % 360.0F;
    }

    public static void SlideEntityToXYZ(Entity var0, int var1, int var2, int var3)
    {
        if (var0 != null)
        {
            if (var0.posY < (double)var2)
            {
                var0.motionY += 0.15D;
            }

            double var4;
            if (var0.posX < (double)var1)
            {
                var4 = (double)var1 - var0.posX;
                if (var4 > 0.5D)
                {
                    var0.motionX += 0.05D;
                }
            }
            else
            {
                var4 = var0.posX - (double)var1;
                if (var4 > 0.5D)
                {
                    var0.motionX -= 0.05D;
                }
            }

            if (var0.posZ < (double)var3)
            {
                var4 = (double)var3 - var0.posZ;
                if (var4 > 0.5D)
                {
                    var0.motionZ += 0.05D;
                }
            }
            else
            {
                var4 = var0.posZ - (double)var3;
                if (var4 > 0.5D)
                {
                    var0.motionZ -= 0.05D;
                }
            }
        }
    }

    public static void destroyDrops(Entity var0, double var1)
    {
        if (((Boolean)mod_mocreatures.destroyitems.get()).booleanValue())
        {
            List var3 = var0.worldObj.getEntitiesWithinAABBExcludingEntity(var0, var0.boundingBox.expand(var1, var1, var1));

            for (int var4 = 0; var4 < var3.size(); ++var4)
            {
                Entity var5 = (Entity)var3.get(var4);
                if (var5 instanceof EntityItem)
                {
                    EntityItem var6 = (EntityItem)var5;
                    if (var6 != null && var6.age < 50)
                    {
                        var6.setEntityDead();
                    }
                }
            }
        }
    }

    public static float distanceToSurface(Entity var0)
    {
        int var1 = MathHelper.floor_double(var0.posX);
        int var2 = MathHelper.floor_double(var0.posY);
        int var3 = MathHelper.floor_double(var0.posZ);
        int var4 =var0.worldObj.getBlockId(var1, var2, var3);
        if (var4 != 0 && Block.blocksList[var4].blockMaterial == Material.water)
        {
            for (int var5 = 1; var5 < 64; ++var5)
            {
                var4 = var0.worldObj.getBlockId(var1, var2 + var5, var3);
                if (var4 == 0 || Block.blocksList[var4].blockMaterial != Material.water)
                {
                    return (float)var5;
                }
            }
        }

        return 0.0F;
    }

    public boolean isInsideOfMaterial(Material var1, Entity var2)
    {
        double var3 = var2.posY + (double)var2.getEyeHeight();
        int var5 = MathHelper.floor_double(var2.posX);
        int var6 = MathHelper.floor_float((float)MathHelper.floor_double(var3));
        int var7 = MathHelper.floor_double(var2.posZ);
        int var8 = var2.worldObj.getBlockId(var5, var6, var7);
        if (var8 != 0 && Block.blocksList[var8].blockMaterial == var1)
        {
            float var9 = BlockFluid.getFluidHeightPercent(var2.worldObj.getBlockMetadata(var5, var6, var7)) - 0.1111111F;
            float var10 = (float)(var6 + 1) - var9;
            return var3 < (double)var10;
        }
        else
        {
            return false;
        }
    }

    public static void DestroyBlast(Entity var0, double var1, double var3, double var5, float var7, boolean var8)
    {
    	var0.worldObj.playSoundEffect(var1, var3, var5, "destroy", 4.0F, (1.0F + (var0.worldObj.rand.nextFloat() - var0.worldObj.rand.nextFloat()) * 0.2F) * 0.7F);
        HashSet var9 = new HashSet();
        float var10 = var7;
        byte var11 = 16;

        int var12;
        int var13;
        int var14;
        double var24;
        double var26;
        double var28;
        for (var12 = 0; var12 < var11; ++var12)
        {
            for (var13 = 0; var13 < var11; ++var13)
            {
                for (var14 = 0; var14 < var11; ++var14)
                {
                    if (var12 == 0 || var12 == var11 - 1 || var13 == 0 || var13 == var11 - 1 || var14 == 0 || var14 == var11 - 1)
                    {
                        double var15 = (double)((float)var12 / ((float)var11 - 1.0F) * 2.0F - 1.0F);
                        double var17 = (double)((float)var13 / ((float)var11 - 1.0F) * 2.0F - 1.0F);
                        double var19 = (double)((float)var14 / ((float)var11 - 1.0F) * 2.0F - 1.0F);
                        double var21 = Math.sqrt(var15 * var15 + var17 * var17 + var19 * var19);
                        var15 /= var21;
                        var17 /= var21;
                        var19 /= var21;
                        float var23 = var7 * (0.7F + var0.worldObj.rand.nextFloat() * 0.6F);
                        var24 = var1;
                        var26 = var3;
                        var28 = var5;
                        float var30 = 0.3F;

                        for (float var31 = 5.0F; var23 > 0.0F; var23 -= var30 * 0.75F)
                        {
                            int var32 = MathHelper.floor_double(var24);
                            int var33 = MathHelper.floor_double(var26);
                            int var34 = MathHelper.floor_double(var28);
                            int var35 = var0.worldObj.getBlockId(var32, var33, var34);
                            if (var35 > 0)
                            {
                                var31 = Block.blocksList[var35].blockHardness;
                                var23 -= (Block.blocksList[var35].getExplosionResistance(var0) + 0.3F) * (var30 / 10.0F);
                            }

                            if (var23 > 0.0F && var26 > var0.posY && var31 < 3.0F)
                            {
                                var9.add(new ChunkPosition(var32, var33, var34));
                            }

                            var24 += var15 * (double)var30;
                            var26 += var17 * (double)var30;
                            var28 += var19 * (double)var30;
                        }
                    }
                }
            }
        }

        var7 *= 2.0F;
        var12 = MathHelper.floor_double(var1 - (double)var7 - 1.0D);
        var13 = MathHelper.floor_double(var1 + (double)var7 + 1.0D);
        var14 = MathHelper.floor_double(var3 - (double)var7 - 1.0D);
        int var44 = MathHelper.floor_double(var3 + (double)var7 + 1.0D);
        int var16 = MathHelper.floor_double(var5 - (double)var7 - 1.0D);
        int var45 = MathHelper.floor_double(var5 + (double)var7 + 1.0D);
        List var18 = var0.worldObj.getEntitiesWithinAABBExcludingEntity(var0, AxisAlignedBB.getBoundingBoxFromPool((double)var12, (double)var14, (double)var16, (double)var13, (double)var44, (double)var45));
        Vec3D var47 = Vec3D.createVector(var1, var3, var5);

        double var55;
        double var54;
        double var56;
        for (int var20 = 0; var20 < var18.size(); ++var20)
        {
            Entity var49 = (Entity)var18.get(var20);
            double var22 = var49.getDistance(var1, var3, var5) / (double)var7;
            if (var22 <= 1.0D)
            {
                var24 = var49.posX - var1;
                var26 = var49.posY - var3;
                var28 = var49.posZ - var5;
                var54 = (double)MathHelper.sqrt_double(var24 * var24 + var26 * var26 + var28 * var28);
                var24 /= var54;
                var26 /= var54;
                var28 /= var54;
                var55 = (double)var0.worldObj.func_494_a(var47, var49.boundingBox);
                var56 = (1.0D - var22) * var55;
                if (!(var49 instanceof MoCEntityOgre))
                {
                    var49.attackEntityFrom(DamageSource.explosion, (int)((var56 * var56 + var56) / 2.0D * 3.0D * (double)var7 + 1.0D));
                    var49.motionX += var24 * var56;
                    var49.motionY += var26 * var56;
                    var49.motionZ += var28 * var56;
                }
            }
        }

        var7 = var10;
        ArrayList var46 = new ArrayList();
        var46.addAll(var9);

        int var25;
        int var51;
        int var50;
        ChunkPosition var48;
        int var53;
        int var52;
        for (var50 = var46.size() - 1; var50 >= 0; --var50)
        {
            var48 = (ChunkPosition)var46.get(var50);
            var52 = var48.x;
            var51 = var48.y;
            var25 = var48.z;
            var53 = var0.worldObj.getBlockId(var52, var51, var25);

            for (int var27 = 0; var27 < 5; ++var27)
            {
                var28 = (double)((float)var52 + var0.worldObj.rand.nextFloat());
                var54 = (double)((float)var51 + var0.worldObj.rand.nextFloat());
                var55 = (double)((float)var25 + var0.worldObj.rand.nextFloat());
                var56 = var28 - var1;
                double var36 = var54 - var3;
                double var38 = var55 - var5;
                double var40 = (double)MathHelper.sqrt_double(var56 * var56 + var36 * var36 + var38 * var38);
                var56 /= var40;
                var36 /= var40;
                var38 /= var40;
                double var42 = 0.5D / (var40 / (double)var7 + 0.1D);
                var42 *= (double)(var0.worldObj.rand.nextFloat() * var0.worldObj.rand.nextFloat() + 0.3F);
                --var42;
                var56 *= var42;
                var36 *= var42 - 1.0D;
                var38 *= var42;
                var0.worldObj.spawnParticle("explode", (var28 + var1 * 1.0D) / 2.0D, (var54 + var3 * 1.0D) / 2.0D, (var55 + var5 * 1.0D) / 2.0D, var56, var36, var38);
                var0.motionX -= 0.001000000047497451D;
                var0.motionY -= 0.001000000047497451D;
            }

            if (var53 > 0)
            {
                Block.blocksList[var53].dropBlockAsItemWithChance(var0.worldObj, var52, var51, var25, var0.worldObj.getBlockMetadata(var52, var51, var25), 0.3F, 1);
                var0.worldObj.setBlockWithNotify(var52, var51, var25, 0);
                Block.blocksList[var53].onBlockDestroyedByExplosion(var0.worldObj, var52, var51, var25);
            }
        }

        if (var8)
        {
            for (var50 = var46.size() - 1; var50 >= 0; --var50)
            {
                var48 = (ChunkPosition)var46.get(var50);
                var52 = var48.x;
                var51 = var48.y;
                var25 = var48.z;
                var53 = var0.worldObj.getBlockId(var52, var51, var25);
                if (var53 == 0 && var0.worldObj.rand.nextInt(8) == 0)
                {
                    var0.worldObj.setBlockWithNotify(var52, var51, var25, Block.fire.blockID);
                }
            }
        }
    }

    public static void disorientEntity(Entity var0)
    {
        double var1 = 0.0D;
        double var3 = 0.0D;
        double var5 = var0.worldObj.rand.nextGaussian();
        double var7 = 0.1D * var5;
        var3 = 0.2D * var7 + 0.8D * var3;
        var0.motionX += var3;
        var0.motionZ += var3;
        double var9 = 0.78D * var5;
        var1 = 0.125D * var9 + 0.875D * var1;
        var0.rotationYaw = (float)((double)var0.rotationYaw + var1);
        var0.rotationPitch = (float)((double)var0.rotationPitch + var1);
    }

    public static void slowEntity(Entity var0)
    {
        var0.motionX *= 0.8D;
        var0.motionZ *= 0.8D;
    }

    public static int colorize(int var0)
    {
        return ~var0 & 15;
    }

    protected static int entityDespawnCheck(World var0, EntityLiving var1)
    {
        int var2 = 0;
        EntityPlayer var3 = var0.getClosestPlayerToEntity(var1, -1.0D);
        if (var3 != null)
        {
            double var4 = var3.posX - var1.posX;
            double var6 = var3.posY - var1.posY;
            double var8 = var3.posZ - var1.posZ;
            double var10 = var4 * var4 + var6 * var6 + var8 * var8;
            if (var10 > 16384.0D)
            {
                var1.setEntityDead();
                ++var2;
            }

            if (var1.entityAge > 600 && var0.rand.nextInt(800) == 0)
            {
                if (var10 < 1024.0D)
                {
                    var1.entityAge = 0;
                }
                else
                {
                    var1.setEntityDead();
                    ++var2;
                }
            }
        }

        return var2;
    }

    public int countEntities(Class var1, World var2)
    {
        int var3 = 0;

        for (int var4 = 0; var4 < var2.loadedEntityList.size(); ++var4)
        {
            Entity var5 = (Entity)var2.loadedEntityList.get(var4);
            if (var1.isAssignableFrom(var5.getClass()))
            {
                ++var3;
            }
        }

        return var3;
    }

    public static int despawnVanillaAnimals(World var0)
    {
        return despawnVanillaAnimals(var0, (List[])null);
    }

    public static int despawnVanillaAnimals(World var0, List[] var1)
    {
        int var2 = 0;

        for (int var3 = 0; var3 < var0.loadedEntityList.size(); ++var3)
        {
            Entity var4 = (Entity)var0.loadedEntityList.get(var3);
            if (var4 instanceof EntityLiving && (var4 instanceof EntityCow || var4 instanceof EntitySheep || var4 instanceof EntityPig || var4 instanceof EntityChicken || var4 instanceof EntitySquid || var4 instanceof EntityWolf))
            {
                var2 += entityDespawnCheck(var0, (EntityLiving)var4);
            }
        }

        return var2;
    }

    public static List spawnList(World worldObj, EnumCreatureType var0, int var1, int var2, int var3)
    {
        WorldChunkManager var4 = worldObj.getWorldChunkManager();
        if (var4 == null)
        {
            return null;
        }
        else
        {
            BiomeGenBase var5 = var4.getBiomeGenAtChunkCoord(new ChunkCoordIntPair(var1 >> 4, var3 >> 4));
            return var5 == null ? null : var5.getSpawnableList(var0);
        }
    }

    public static BiomeGenBase whatBiome(Entity caller, int var0, int var1, int var2)
    {
    	WorldChunkManager var3 = caller.worldObj.getWorldChunkManager();
        if (var3 == null)
        {
            return null;
        }
        else
        {
            BiomeGenBase var4 = var3.getBiomeGenAtChunkCoord(new ChunkCoordIntPair(var0 >> 4, var2 >> 4));
            return var4 == null ? null : var4;
        }
    }

    public static float distToPlayer(Entity var0)
    {
        return 0.0F;
    }

    public static String BiomeName(Entity caller, int var0, int var1, int var2)
    {
        WorldChunkManager var3 = caller.worldObj.getWorldChunkManager();
        if (var3 == null)
        {
            return null;
        }
        else
        {
            BiomeGenBase var4 = var3.getBiomeGenAtChunkCoord(new ChunkCoordIntPair(var0 >> 4, var2 >> 4));
            return var4 == null ? null : var4.biomeName;
        }
    }
}
