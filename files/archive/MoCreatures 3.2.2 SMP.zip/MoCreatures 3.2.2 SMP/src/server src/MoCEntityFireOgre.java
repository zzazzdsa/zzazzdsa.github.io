package net.minecraft.src;

import net.minecraft.src.Block;
import net.minecraft.src.IMob;
import net.minecraft.src.MathHelper;
import net.minecraft.src.MoCEntityOgre;
import net.minecraft.src.MoCTools;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityFireOgre extends MoCEntityOgre implements IMob
{
    public MoCEntityFireOgre(World var1)
    {
        super(var1);
        this.attackStrength = 3;
        this.attackRange = (double)((Integer)mod_mocreatures.ogrerange.get()).intValue();
        this.texture = "/mocreatures/fireogre.png";
        this.setSize(1.5F, 4.0F);
        this.health = 35;
        this.destroyForce = ((Float)mod_mocreatures.fogreStrength.get()).floatValue();
        this.isImmuneToFire = true;
        this.frequencyA = 35;
    }

    public boolean getCanSpawnHere()
    {
        return ((Integer)mod_mocreatures.fogrefreq.get()).intValue() > 0 && this.worldObj.difficultySetting >= ((Integer)mod_mocreatures.fogreSpawnDifficulty.get()).intValue() + 1 && super.d2();
    }

    protected int getDropItemId()
    {
        return Block.fire.blockID;
    }

    public int getMaxSpawnedInChunk()
    {
        return 2;
    }

    public void onLivingUpdate()
    {
        if (!this.worldObj.isRemote && this.worldObj.isDaytime())
        {
            float var1 = this.getEntityBrightness(1.0F);
            if (var1 > 0.5F && this.worldObj.canBlockSeeTheSky(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ)) && this.rand.nextFloat() * 30.0F < (var1 - 0.4F) * 2.0F)
            {
                this.health -= 5;
            }
        }

        super.onLivingUpdate();
    }

    public void updateStrength()
    {
        this.destroyForce = ((Float)mod_mocreatures.fogreStrength.get()).floatValue();
        this.attackRange = (double)((Integer)mod_mocreatures.ogrerange.get()).intValue();
    }

    public boolean getOgreFire()
    {
        return true;
    }

    public void DestroyingOgre()
    {
        if (this.deathTime <= 0)
        {
            MoCTools.DestroyBlast(this, this.posX, this.posY + 1.0D, this.posZ, this.destroyForce, true);
        }
    }
}
