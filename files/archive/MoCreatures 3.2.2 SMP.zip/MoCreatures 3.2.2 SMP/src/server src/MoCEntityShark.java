package net.minecraft.src;

import java.util.List;
import net.minecraft.src.DamageSource;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.EntityWolf;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.Material;
import net.minecraft.src.MoCEntityAquatic;
import net.minecraft.src.MoCEntityDolphin;
import net.minecraft.src.MoCEntityHorse;
import net.minecraft.src.MoCEntitySharkEgg;
import net.minecraft.src.MoCTools;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityShark extends MoCEntityAquatic
{
    public MoCEntityShark(World var1)
    {
        super(var1);
        this.texture = "/mocreatures/shark.png";
        this.setSize(1.5F, 0.8F);
        this.setEdad(1.0F + this.rand.nextFloat());
        this.health = 25;
        this.setMaxHealth(25);
    }

    protected void attackEntity(Entity var1, float var2)
    {
        if (var1.isInsideOfMaterial(Material.water) && (double)var2 < 3.5D && var1.boundingBox.maxY > this.boundingBox.minY && var1.boundingBox.minY < this.boundingBox.maxY && this.getEdad() >= 1.0F)
        {
            this.attackTime = 20;
            var1.attackEntityFrom(DamageSource.causeMobDamage(this), 5);
            if (!(var1 instanceof EntityPlayer))
            {
                MoCTools.destroyDrops(this, 3.0D);
            }
        }
    }

    public boolean attackEntityFrom(DamageSource var1, int var2)
    {
        if (super.attackEntityFrom(var1, var2) && this.worldObj.difficultySetting > 0)
        {
            Entity var3 = var1.getEntity();
            if (this.riddenByEntity != var3 && this.ridingEntity != var3)
            {
                if (var3 != this)
                {
                    this.entityToAttack = var3;
                }

                return true;
            }
            else
            {
                return true;
            }
        }
        else
        {
            return false;
        }
    }

    protected void dropFewItems(boolean var1, int var2)
    {
        int var3 = this.rand.nextInt(100);
        int var4;
        int var5;
        if (var3 < 90)
        {
            var4 = this.rand.nextInt(3) + 1;

            for (var5 = 0; var5 < var4; ++var5)
            {
                this.entityDropItem(new ItemStack(mod_mocreatures.sharkteeth, 1, 0), 0.0F);
            }
        }
        else if (this.worldObj.difficultySetting > 0 && this.getEdad() > 1.5F)
        {
            var4 = this.rand.nextInt(3) + 1;

            for (var5 = 0; var5 < var4; ++var5)
            {
                this.entityDropItem(new ItemStack(mod_mocreatures.sharkegg, 1, 0), 0.0F);
            }
        }
    }

    protected Entity findPlayerToAttack()
    {
        if (this.worldObj.difficultySetting > 0 && this.getEdad() >= 1.0F)
        {
            EntityPlayer var1 = this.worldObj.getClosestPlayerToEntity(this, 16.0D);
            if (var1 != null && var1.inWater && !this.getIsTamed())
            {
                return var1;
            }

            if (this.rand.nextInt(30) == 0)
            {
                EntityLiving var2 = this.FindTarget(this, 16.0D);
                if (var2 != null && var2.inWater)
                {
                    return var2;
                }
            }
        }

        return null;
    }

    public EntityLiving FindTarget(Entity var1, double var2)
    {
        double var4 = -1.0D;
        EntityLiving var6 = null;
        List var7 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(var2, var2, var2));

        for (int var8 = 0; var8 < var7.size(); ++var8)
        {
            Entity var9 = (Entity)var7.get(var8);
            if (var9 instanceof EntityLiving && !(var9 instanceof MoCEntityAquatic) && !(var9 instanceof MoCEntitySharkEgg) && !(var9 instanceof EntityPlayer) && (!(var9 instanceof EntityWolf) || ((Boolean)mod_mocreatures.attackwolves.get()).booleanValue()) && (!(var9 instanceof MoCEntityHorse) || ((Boolean)mod_mocreatures.attackhorses.get()).booleanValue()) && (!(var9 instanceof MoCEntityDolphin) || !this.getIsTamed() && ((Boolean)mod_mocreatures.attackdolphins.get()).booleanValue()))
            {
                double var10 = var9.getDistanceSq(var1.posX, var1.posY, var1.posZ);
                if ((var2 < 0.0D || var10 < var2 * var2) && (var4 == -1.0D || var10 < var4) && ((EntityLiving)var9).canEntityBeSeen(var1))
                {
                    var4 = var10;
                    var6 = (EntityLiving)var9;
                }
            }
        }

        return var6;
    }

    public boolean getCanSpawnHere()
    {
        return ((Integer)mod_mocreatures.sharkfreq.get()).intValue() > 0 && this.worldObj.difficultySetting >= ((Integer)mod_mocreatures.sharkSpawnDifficulty.get()).intValue() + 1 && super.getCanSpawnHere();
    }

    public boolean interact(EntityPlayer var1)
    {
        ItemStack var2 = var1.inventory.getCurrentItem();
        if (var2 != null && this.getIsTamed() && (var2.itemID == mod_mocreatures.medallion.shiftedIndex || var2.itemID == Item.book.shiftedIndex))
        {
            //mod_mocreatures.setName(this);
            return true;
        }
        else if (var2 != null && this.getIsTamed() && (var2.itemID == Item.pickaxeDiamond.shiftedIndex || var2.itemID == Item.pickaxeWood.shiftedIndex || var2.itemID == Item.pickaxeStone.shiftedIndex || var2.itemID == Item.pickaxeSteel.shiftedIndex || var2.itemID == Item.pickaxeGold.shiftedIndex))
        {
            this.setDisplayName(!this.getDisplayName());
            return true;
        }
        else
        {
            return false;
        }
    }

    public void onLivingUpdate()
    {
        super.onLivingUpdate();
        if (!this.worldObj.isRemote && !this.getIsAdult() && this.rand.nextInt(50) == 0)
        {
            this.setEdad(this.getEdad() + 0.01F);
            if (this.getEdad() >= 2.0F)
            {
                this.setAdult(true);
            }
        }
    }

    public boolean renderName()
    {
        return this.getDisplayName();
    }

    public void setEntityDead()
    {
        if (this.worldObj.isRemote || !this.getIsTamed() || this.health <= 0)
        {
            super.setEntityDead();
        }
    }

    public void readEntityFromNBT(NBTTagCompound var1)
    {
        super.readEntityFromNBT(var1);
        this.setTamed(var1.getBoolean("Tamed"));
        this.setAdult(var1.getBoolean("Adult"));
        this.setEdad(var1.getFloat("Edad"));
        this.setName(var1.getString("Name"));
        this.setDisplayName(var1.getBoolean("DisplayName"));
    }

    public void writeEntityToNBT(NBTTagCompound var1)
    {
        super.writeEntityToNBT(var1);
        var1.setBoolean("Tamed", this.getIsTamed());
        var1.setBoolean("Adult", this.getIsAdult());
        var1.setFloat("Edad", this.getEdad());
        var1.setString("Name", this.getName());
        var1.setBoolean("DisplayName", this.getDisplayName());
    }
}
