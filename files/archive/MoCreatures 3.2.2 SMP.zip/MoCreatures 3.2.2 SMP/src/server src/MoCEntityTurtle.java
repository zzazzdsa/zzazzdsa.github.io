package net.minecraft.src;

import net.minecraft.src.Block;
import net.minecraft.src.DamageSource;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityItem;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.Material;
import net.minecraft.src.MathHelper;
import net.minecraft.src.MoCEntityAnimal;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.PathEntity;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityTurtle extends MoCEntityAnimal
{
    private boolean upsidedown;
    private boolean isHiding;
    private boolean isSwinging;
    private boolean twistright;
    private int flopcounter;

    public MoCEntityTurtle(World var1)
    {
        super(var1);
        this.texture = "/mocreatures/turtle.png";
        this.setSize(0.6F, 0.4F);
        this.moveSpeed = 0.3F;
        this.health = 15;
        this.setMaxHealth(15);
        this.setAdult(false);
        this.setEdad(1.1F);
    }

    public double getYOffset()
    {
        return this.ridingEntity instanceof EntityPlayer && !this.worldObj.isRemote ? (double)(this.yOffset - (1.0F + this.getEdad() / 6.0F)) : (double)this.yOffset;
    }

    public boolean interact(EntityPlayer var1)
    {
        if (this.getIsTamed())
        {
            ItemStack var2 = var1.inventory.getCurrentItem();
            if (this.getIsUpsideDown())
            {
                this.flipflop(false);
                return true;
            }
            else if (var2 != null && (var2.itemID == mod_mocreatures.medallion.shiftedIndex || var2.itemID == Item.book.shiftedIndex))
            {
                //mod_mocreatures.setName((MoCEntityAnimal)this);
                return true;
            }
            else
            {
                if (var2 != null && (var2.itemID == Item.melon.shiftedIndex || var2.itemID == Item.reed.shiftedIndex))
                {
                    if (--var2.stackSize == 0)
                    {
                        var1.inventory.setInventorySlotContents(var1.inventory.currentItem, (ItemStack)null);
                    }

                    this.heal(10);
                    this.worldObj.playSoundAtEntity(this, "turtleeating", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
                }

                if (var2 != null && (var2.itemID == Item.pickaxeDiamond.shiftedIndex || var2.itemID == Item.pickaxeWood.shiftedIndex || var2.itemID == Item.pickaxeStone.shiftedIndex || var2.itemID == Item.pickaxeSteel.shiftedIndex || var2.itemID == Item.pickaxeGold.shiftedIndex))
                {
                    this.setDisplayName(!this.getDisplayName());
                    return true;
                }
                else
                {
                    if (this.ridingEntity == null && !this.worldObj.isRemote)
                    {
                        this.rotationYaw = var1.rotationYaw;
                        this.worldObj.playSoundAtEntity(this, "mob.chickenplop", 1.0F, (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F);
                        this.mountEntity(var1);
                    }
                    else
                    {
                        this.mountEntity((Entity)null);
                        this.motionX = var1.motionX * 5.0D;
                        this.motionY = var1.motionY / 2.0D + 0.2D;
                        this.motionZ = var1.motionZ * 5.0D;
                    }

                    return true;
                }
            }
        }
        else
        {
            this.flipflop(!this.getIsUpsideDown());
            return true;
        }
    }

    protected void jump()
    {
        if (this.isInsideOfMaterial(Material.water))
        {
            this.motionY = 0.3D;
            if (this.isSprinting())
            {
                float var1 = this.rotationYaw * 0.01745329F;
                this.motionX -= (double)(MathHelper.sin(var1) * 0.2F);
                this.motionZ += (double)(MathHelper.cos(var1) * 0.2F);
            }

            this.isAirBorne = true;
        }
    }

    public boolean isNotScared()
    {
        return true;
    }

    public void onLivingUpdate()
    {
        if (!this.getIsUpsideDown() && !this.getIsTamed())
        {
            EntityLiving var1 = this.getClosestEntityLiving(this, 4.0D);
            if (var1 != null && this.canEntityBeSeen(var1))
            {
                if (!this.getIsHiding())
                {
                    this.worldObj.playSoundAtEntity(this, "turtlehissing", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
                    this.setIsHiding(true);
                }

                this.setPathToEntity((PathEntity)null);
            }
            else
            {
                this.setIsHiding(false);
                if (!this.hasPath() && this.rand.nextInt(50) == 0)
                {
                    EntityItem var2 = this.getClosestItem(this, 10.0D, Item.melon.shiftedIndex, Item.reed.shiftedIndex);
                    if (var2 != null)
                    {
                        float var3 = var2.getDistanceToEntity(this);
                        if (var3 > 2.0F)
                        {
                            this.getMyOwnPath(var2, var3);
                        }

                        if (var3 < 2.0F && var2 != null && this.deathTime == 0)
                        {
                            var2.setEntityDead();
                            this.worldObj.playSoundAtEntity(this, "turtleeating", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
                            this.setTamed(true);
                            //mod_mocreatures.setName((MoCEntityAnimal)this);
                        }
                    }
                }
            }
        }

        if (!this.getIsUpsideDown() && this.getIsTamed() && this.rand.nextInt(20) == 0)
        {
            EntityPlayer var4 = this.worldObj.getClosestPlayerToEntity(this, 12.0D);
            if (var4 != null)
            {
                PathEntity var5 = this.worldObj.getPathToEntity(this, var4, 16.0F);
                this.setPathToEntity(var5);
            }
        }

        super.onLivingUpdate();
    }

    public boolean swimmerEntity()
    {
        return true;
    }

    public boolean canBreatheUnderwater()
    {
        return true;
    }

    public boolean attackEntityFrom(DamageSource var1, int var2)
    {
        if (this.getIsHiding())
        {
            if (this.rand.nextInt(10) == 0)
            {
                this.flipflop(true);
            }

            return false;
        }
        else
        {
            boolean var3 = super.attackEntityFrom(var1, var2);
            if (this.rand.nextInt(3) == 0)
            {
                this.flipflop(true);
            }

            return var3;
        }
    }

    public void flipflop(boolean var1)
    {
        this.fleeingTick = 0;
        this.setIsUpsideDown(var1);
        this.setIsHiding(false);
        this.setPathToEntity((PathEntity)null);
    }

    protected void updateEntityActionState()
    {
        if (this.ridingEntity != null && this.ridingEntity instanceof EntityPlayer)
        {
            EntityPlayer var1 = (EntityPlayer)this.ridingEntity;
            if (var1 != null)
            {
                this.rotationYaw = var1.rotationYaw;
            }
        }
        else
        {
            super.updateEntityActionState();
        }
    }

    public boolean entitiesToIgnore(Entity var1)
    {
        return var1 instanceof MoCEntityTurtle || var1.height <= this.height && var1.width <= this.width || super.entitiesToIgnore(var1);
    }

    public void onUpdate()
    {
        if (this.getIsTamed() && this.getEdad() < 3.0F && this.rand.nextInt(800) == 0)
        {
            this.setEdad(this.getEdad() + 0.001F);
        }

        if (this.getIsUpsideDown() && this.ridingEntity == null && this.rand.nextInt(20) == 0)
        {
            this.setSwinging(true);
            ++this.flopcounter;
        }

        if (this.getIsSwinging())
        {
            this.swingProgress += 0.2F;
            boolean var1 = this.flopcounter > this.rand.nextInt(3) + 8;
            if (this.swingProgress > 2.0F && (!var1 || this.rand.nextInt(20) == 0))
            {
                this.setSwinging(false);
                this.swingProgress = 0.0F;
                if (this.rand.nextInt(2) == 0)
                {
                    this.twistright = !this.twistright;
                }
            }
            else if (this.swingProgress > 9.0F && var1)
            {
                this.setSwinging(false);
                this.swingProgress = 0.0F;
                this.worldObj.playSoundAtEntity(this, "mob.chickenplop", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
                this.setIsUpsideDown(false);
                this.flopcounter = 0;
            }
        }

        super.onUpdate();
    }

    public boolean getIsSwinging()
    {
        return this.isSwinging;
    }

    public void setSwinging(boolean var1)
    {
        this.isSwinging = var1;
    }

    protected boolean isMovementCeased()
    {
        return this.getIsUpsideDown() || this.getIsHiding();
    }

    public boolean renderName()
    {
        return this.getDisplayName() && this.ridingEntity == null;
    }

    public boolean getIsHiding()
    {
        return this.isHiding;
    }

    public void setIsHiding(boolean var1)
    {
        this.isHiding = var1;
    }

    public boolean getIsUpsideDown()
    {
        return this.upsidedown;
    }

    public void setIsUpsideDown(boolean var1)
    {
        this.upsidedown = var1;
    }

    public int getFlipDirection()
    {
        return this.twistright ? 1 : -1;
    }

    public void readEntityFromNBT(NBTTagCompound var1)
    {
        super.readEntityFromNBT(var1);
        this.setTamed(var1.getBoolean("Tamed"));
        this.setEdad(var1.getFloat("Edad"));
        this.setIsUpsideDown(var1.getBoolean("UpsideDown"));
        this.setName(var1.getString("Name"));
        this.setDisplayName(var1.getBoolean("DisplayName"));
    }

    public void writeEntityToNBT(NBTTagCompound var1)
    {
        super.writeEntityToNBT(var1);
        var1.setBoolean("Tamed", this.getIsTamed());
        var1.setFloat("Edad", this.getEdad());
        var1.setBoolean("UpsideDown", this.getIsUpsideDown());
        var1.setString("Name", this.getName());
        var1.setBoolean("DisplayName", this.getDisplayName());
    }

    protected String getHurtSound()
    {
        return "turtlehurt";
    }

    protected String getLivingSound()
    {
        return "turtlegrunt";
    }

    protected String getDeathSound()
    {
        return "turtledying";
    }

    protected int getDropItemId()
    {
        return Block.chest.blockID;
    }

    public boolean getCanSpawnHere()
    {
        return ((Integer)mod_mocreatures.turtlefreq.get()).intValue() > 0 && this.getCanSpawnHereAquatic();
    }

    public int getMaxSpawnedInChunk()
    {
        return 6;
    }
}
