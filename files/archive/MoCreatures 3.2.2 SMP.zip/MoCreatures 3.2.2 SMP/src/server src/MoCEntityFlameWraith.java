package net.minecraft.src;

import net.minecraft.src.DamageSource;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.IMob;
import net.minecraft.src.Item;
import net.minecraft.src.MathHelper;
import net.minecraft.src.MoCEntityWraith;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityFlameWraith extends MoCEntityWraith implements IMob
{
    protected int burningTime;

    public MoCEntityFlameWraith(World var1)
    {
        super(var1);
        this.texture = "/mocreatures/flamewraith.png";
        this.setSize(1.5F, 1.5F);
        this.isImmuneToFire = true;
        this.burningTime = 30;
        this.health = 15;
        this.moveSpeed = 1.1F;
    }

    protected void attackEntity(Entity var1, float var2)
    {
        if (this.attackTime <= 0 && (double)var2 < 2.5D && var1.boundingBox.maxY > this.boundingBox.minY && var1.boundingBox.minY < this.boundingBox.maxY)
        {
            this.attackTime = 20;
            var1.attackEntityFrom(DamageSource.causeMobDamage(this), 2);
            ((EntityLiving)var1).setFire(this.burningTime);
        }
    }

    public boolean getCanSpawnHere()
    {
        return ((Integer)mod_mocreatures.fwraithfreq.get()).intValue() > 0 && this.worldObj.difficultySetting >= ((Integer)mod_mocreatures.fwraithSpawnDifficulty.get()).intValue() + 1 && super.d2();
    }

    protected int getDropItemId()
    {
        return Item.redstone.shiftedIndex;
    }

    public void onLivingUpdate()
    {
        if (!this.worldObj.isRemote)
        {
            if (this.rand.nextInt(40) == 0)
            {
                this.setFire(2);
            }

            if (this.worldObj.isDaytime())
            {
                float var1 = this.getEntityBrightness(1.0F);
                if (var1 > 0.5F && this.worldObj.canBlockSeeTheSky(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ)) && this.rand.nextFloat() * 30.0F < (var1 - 0.4F) * 2.0F)
                {
                    this.health -= 2;
                }
            }
        }

        super.onLivingUpdate();
    }
}
