package net.minecraft.src;

import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.MoCEntityFishyEgg;
import net.minecraft.src.World;

public class MoCItemFishyEgg extends Item
{
    public MoCItemFishyEgg(int var1)
    {
        super(var1);
        this.maxStackSize = 16;
    }

    public ItemStack onItemRightClick(ItemStack var1, World var2, EntityPlayer var3)
    {
        --var1.stackSize;
        if (!var2.isRemote)
        {
            MoCEntityFishyEgg var4 = new MoCEntityFishyEgg(var2);
            var4.setPosition(var3.posX, var3.posY, var3.posZ);
            var2.spawnEntityInWorld(var4);
            var4.motionY += (double)(var2.rand.nextFloat() * 0.05F);
            var4.motionX += (double)((var2.rand.nextFloat() - var2.rand.nextFloat()) * 0.3F);
            var4.motionZ += (double)((var2.rand.nextFloat() - var2.rand.nextFloat()) * 0.3F);
        }

        return var1;
    }
}
