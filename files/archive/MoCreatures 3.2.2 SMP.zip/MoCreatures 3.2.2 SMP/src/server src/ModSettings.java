package net.minecraft.src;

import java.io.*;
import java.lang.reflect.Field;
import java.security.InvalidParameterException;
import java.util.*;
import net.minecraft.server.MinecraftServer;


public class ModSettings
{
    public static ArrayList all = new ArrayList();
    public static HashMap contextDatadirs = new HashMap();
    public static String currentContext = "";
    public static final boolean debug = false;
    private static MinecraftServer minecraftInstance;
    public String backendname;
    public ArrayList Settings;
    public boolean settingsLoaded = false;

    public static void dbgout(String var0) {}

    public static File getAppDir(String var0)
    {
        return ModLoader.getMinecraftServerInstance().getFile(var0);
    }

    public static MinecraftServer getMcinst()
    {
        if (minecraftInstance != null)
        {
            return minecraftInstance;
        }
        else
        {
        	return ModLoader.getMinecraftServerInstance();
        }
    }

    public static void loadAll(String var0)
    {
        for (int var1 = 0; var1 < all.size(); ++var1)
        {
            ((ModSettings)all.get(var1)).load(var0);
        }
    }

    public static void presetMcint(MinecraftServer var0)
    {
        minecraftInstance = var0;
    }

    public static void setContext(String var0, String var1)
    {
        if (var0 != null)
        {
            contextDatadirs.put(var0, var1);
            currentContext = var0;
            if (!var0.equals(""))
            {
                loadAll(currentContext);
            }
        }
        else
        {
            currentContext = "";
        }
    }

    public ModSettings(String var1)
    {
        this.backendname = var1;
        this.Settings = new ArrayList();
        all.add(this);
    }

    /*
    public SettingBoolean addSetting(ModSettingScreen var1, String var2, String var3, boolean var4)
    {
        SettingBoolean var5 = new SettingBoolean(var3, Boolean.valueOf(var4));
        WidgetBoolean var6 = new WidgetBoolean(var5, var2);
        var1.append(var6);
        this.append(var5);
        return var5;
    }

    public SettingBoolean addSetting(ModSettingScreen var1, String var2, String var3, boolean var4, String var5, String var6)
    {
        SettingBoolean var7 = new SettingBoolean(var3, Boolean.valueOf(var4));
        WidgetBoolean var8 = new WidgetBoolean(var7, var2, var5, var6);
        var1.append(var8);
        this.append(var7);
        return var7;
    }

    public SettingFloat addSetting(ModSettingScreen var1, String var2, String var3, float var4)
    {
        SettingFloat var5 = new SettingFloat(var3, var4);
        WidgetFloat var6 = new WidgetFloat(var5, var2);
        var1.append(var6);
        this.append(var5);
        return var5;
    }

    public SettingFloat addSetting(ModSettingScreen var1, String var2, String var3, float var4, float var5, float var6, float var7)
    {
        SettingFloat var8 = new SettingFloat(var3, var4, var5, var6, var7);
        WidgetFloat var9 = new WidgetFloat(var8, var2);
        var1.append(var9);
        this.append(var8);
        return var8;
    }

    public SettingKey addSetting(ModSettingScreen var1, String var2, String var3, int var4)
    {
        SettingKey var5 = new SettingKey(var3, var4);
        WidgetKeybinding var6 = new WidgetKeybinding(var5, var2);
        var1.append(var6);
        this.append(var5);
        return var5;
    }

    public SettingInt addSetting(ModSettingScreen var1, String var2, String var3, int var4, int var5, int var6)
    {
        SettingInt var7 = new SettingInt(var3, var4, var5, 1, var6);
        WidgetInt var8 = new WidgetInt(var7, var2);
        var1.append(var8);
        this.append(var7);
        return var7;
    }

    public SettingInt addSetting(ModSettingScreen var1, String var2, String var3, int var4, int var5, int var6, int var7)
    {
        SettingInt var8 = new SettingInt(var3, var4, var5, var6, var7);
        WidgetInt var9 = new WidgetInt(var8, var2);
        var1.append(var9);
        this.append(var8);
        return var8;
    }

    public SettingMulti addSetting(ModSettingScreen var1, String var2, String var3, int var4, String ... var5)
    {
        SettingMulti var6 = new SettingMulti(var3, var4, var5);
        WidgetMulti var7 = new WidgetMulti(var6, var2);
        var1.append(var7);
        this.append(var6);
        return var6;
    }

    public SettingText addSetting(ModSettingScreen var1, String var2, String var3, String var4)
    {
        SettingText var5 = new SettingText(var3, var4);
        WidgetText var6 = new WidgetText(var5, var2);
        var1.append(var6);
        this.append(var5);
        return var5;
    }

    public SettingBoolean addSetting(Widget var1, String var2, String var3, boolean var4)
    {
        SettingBoolean var5 = new SettingBoolean(var3, Boolean.valueOf(var4));
        WidgetBoolean var6 = new WidgetBoolean(var5, var2);
        var1.add(var6);
        this.append(var5);
        return var5;
    }

    public SettingBoolean addSetting(Widget var1, String var2, String var3, boolean var4, String var5, String var6)
    {
        SettingBoolean var7 = new SettingBoolean(var3, Boolean.valueOf(var4));
        WidgetBoolean var8 = new WidgetBoolean(var7, var2, var5, var6);
        var1.add(var8);
        this.append(var7);
        return var7;
    }

    public SettingFloat addSetting(Widget var1, String var2, String var3, float var4)
    {
        SettingFloat var5 = new SettingFloat(var3, var4);
        WidgetFloat var6 = new WidgetFloat(var5, var2);
        var1.add(var6);
        this.append(var5);
        return var5;
    }

    public SettingFloat addSetting(Widget var1, String var2, String var3, float var4, float var5, float var6, float var7)
    {
        SettingFloat var8 = new SettingFloat(var3, var4, var5, var6, var7);
        WidgetFloat var9 = new WidgetFloat(var8, var2);
        var1.add(var9);
        this.append(var8);
        return var8;
    }

    public SettingKey addSetting(Widget var1, String var2, String var3, int var4)
    {
        SettingKey var5 = new SettingKey(var3, var4);
        WidgetKeybinding var6 = new WidgetKeybinding(var5, var2);
        var1.add(var6);
        this.append(var5);
        return var5;
    }

    public SettingInt addSetting(Widget var1, String var2, String var3, int var4, int var5, int var6)
    {
        SettingInt var7 = new SettingInt(var3, var4, var5, 1, var6);
        WidgetInt var8 = new WidgetInt(var7, var2);
        var1.add(var8);
        this.append(var7);
        return var7;
    }

    public SettingInt addSetting(Widget var1, String var2, String var3, int var4, int var5, int var6, int var7)
    {
        SettingInt var8 = new SettingInt(var3, var4, var5, var6, var7);
        WidgetInt var9 = new WidgetInt(var8, var2);
        var1.add(var9);
        this.append(var8);
        return var8;
    }

    public SettingMulti addSetting(Widget var1, String var2, String var3, int var4, String ... var5)
    {
        SettingMulti var6 = new SettingMulti(var3, var4, var5);
        WidgetMulti var7 = new WidgetMulti(var6, var2);
        var1.add(var7);
        this.append(var6);
        return var6;
    }

    public SettingList addSetting(Widget var1, String var2, String var3, String ... var4)
    {
        ArrayList var5 = new ArrayList();

        for (int var6 = 0; var6 < var4.length; ++var6)
        {
            var5.add(var4[var6]);
        }

        SettingList var8 = new SettingList(var3, var5);
        WidgetList var7 = new WidgetList(var8, var2);
        var1.add(var7);
        this.append(var8);
        return var8;
    }

    public SettingText addSetting(Widget var1, String var2, String var3, String var4)
    {
        SettingText var5 = new SettingText(var3, var4);
        WidgetText var6 = new WidgetText(var5, var2);
        var1.add(var6);
        this.append(var5);
        return var5;
    }
    */

    public void append(Setting var1)
    {
        this.Settings.add(var1);
        var1.parent = this;
    }

    public void copyContextAll(String var1, String var2)
    {
        for (int var3 = 0; var3 < this.Settings.size(); ++var3)
        {
            ((Setting)this.Settings.get(var3)).copyContext(var1, var2);
        }
    }

    public ArrayList getAllBooleanSettings()
    {
        return this.getAllBooleanSettings(currentContext);
    }

    public ArrayList getAllBooleanSettings(String var1)
    {
        ArrayList var2 = new ArrayList();
        Iterator var3 = this.Settings.iterator();

        while (var3.hasNext())
        {
            Setting var4 = (Setting)var3.next();
            if (SettingBoolean.class.isAssignableFrom(var4.getClass()))
            {
                var2.add((SettingBoolean)var4);
            }
        }

        return var2;
    }

    public ArrayList getAllFloatSettings()
    {
        return this.getAllFloatSettings(currentContext);
    }

    public ArrayList getAllFloatSettings(String var1)
    {
        ArrayList var2 = new ArrayList();
        Iterator var3 = this.Settings.iterator();

        while (var3.hasNext())
        {
            Setting var4 = (Setting)var3.next();
            if (SettingFloat.class.isAssignableFrom(var4.getClass()))
            {
                var2.add((SettingFloat)var4);
            }
        }

        return var2;
    }

    public ArrayList getAllIntSettings()
    {
        return this.getAllIntSettings(currentContext);
    }

    public ArrayList getAllIntSettings(String var1)
    {
        ArrayList var2 = new ArrayList();
        Iterator var3 = this.Settings.iterator();

        while (var3.hasNext())
        {
            Setting var4 = (Setting)var3.next();
            if (SettingInt.class.isAssignableFrom(var4.getClass()))
            {
                var2.add((SettingInt)var4);
            }
        }

        return var2;
    }
    
    /*
    public ArrayList getAllKeySettings()
    {
        return this.getAllKeySettings(currentContext);
    }

    public ArrayList getAllKeySettings(String var1)
    {
        ArrayList var2 = new ArrayList();
        Iterator var3 = this.Settings.iterator();

        while (var3.hasNext())
        {
            Setting var4 = (Setting)var3.next();
            if (SettingKey.class.isAssignableFrom(var4.getClass()))
            {
                var2.add((SettingKey)var4);
            }
        }

        return var2;
    }
    */

    public ArrayList getAllMultiSettings()
    {
        return this.getAllMultiSettings(currentContext);
    }

    public ArrayList getAllMultiSettings(String var1)
    {
        ArrayList var2 = new ArrayList();
        Iterator var3 = this.Settings.iterator();

        while (var3.hasNext())
        {
            Setting var4 = (Setting)var3.next();
            if (SettingMulti.class.isAssignableFrom(var4.getClass()))
            {
                var2.add((SettingMulti)var4);
            }
        }

        return var2;
    }

    public ArrayList getAllTextSettings()
    {
        return this.getAllTextSettings(currentContext);
    }

    public ArrayList getAllTextSettings(String var1)
    {
        ArrayList var2 = new ArrayList();
        Iterator var3 = this.Settings.iterator();

        while (var3.hasNext())
        {
            Setting var4 = (Setting)var3.next();
            if (SettingText.class.isAssignableFrom(var4.getClass()))
            {
                var2.add((SettingText)var4);
            }
        }

        return var2;
    }

    public Boolean getBooleanSettingValue(String var1)
    {
        return this.getBooleanSettingValue(var1, currentContext);
    }

    public Boolean getBooleanSettingValue(String var1, String var2)
    {
        return this.getSettingBoolean(var1).get(var2);
    }

    public Float getFloatSettingValue(String var1)
    {
        return this.getFloatSettingValue(var1, currentContext);
    }

    public Float getFloatSettingValue(String var1, String var2)
    {
        return this.getSettingFloat(var1).get(var2);
    }

    public Integer getIntSettingValue(String var1)
    {
        return this.getIntSettingValue(var1, currentContext);
    }

    public Integer getIntSettingValue(String var1, String var2)
    {
        return this.getSettingInt(var1).get(var2);
    }

    /*
    public Integer getKeySettingValue(String var1)
    {
        return this.getKeySettingValue(var1, currentContext);
    }

    public Integer getKeySettingValue(String var1, String var2)
    {
        return this.getSettingKey(var1).get(var2);
    }
    */

    public String getMultiSettingLabel(String var1)
    {
        return this.getMultiSettingLabel(var1, currentContext);
    }

    public String getMultiSettingLabel(String var1, String var2)
    {
        SettingMulti var3 = this.getSettingMulti(var1);
        return var3.labelValues[var3.get(var2).intValue()];
    }

    public Integer getMultiSettingValue(String var1)
    {
        return this.getMultiSettingValue(var1, currentContext);
    }

    public Integer getMultiSettingValue(String var1, String var2)
    {
        return this.getSettingMulti(var1).get(var2);
    }

    public SettingBoolean getSettingBoolean(String var1)
    {
        Iterator var2 = this.Settings.iterator();

        Setting var3;
        do
        {
            if (!var2.hasNext())
            {
                throw new InvalidParameterException("SettingBoolean \'" + var1 + "\' not found.");
            }

            var3 = (Setting)var2.next();
        }
        while (!SettingBoolean.class.isAssignableFrom(var3.getClass()) || !var3.backendName.equals(var1));

        return (SettingBoolean)var3;
    }

    public SettingFloat getSettingFloat(String var1)
    {
        Iterator var2 = this.Settings.iterator();

        Setting var3;
        do
        {
            if (!var2.hasNext())
            {
                throw new InvalidParameterException("SettingFloat \'" + var1 + "\' not found.");
            }

            var3 = (Setting)var2.next();
        }
        while (!SettingFloat.class.isAssignableFrom(var3.getClass()) || !var3.backendName.equals(var1));

        return (SettingFloat)var3;
    }

    public SettingInt getSettingInt(String var1)
    {
        Iterator var2 = this.Settings.iterator();

        Setting var3;
        do
        {
            if (!var2.hasNext())
            {
                throw new InvalidParameterException("SettingInt \'" + var1 + "\' not found.");
            }

            var3 = (Setting)var2.next();
        }
        while (!SettingInt.class.isAssignableFrom(var3.getClass()) || !var3.backendName.equals(var1));

        return (SettingInt)var3;
    }

    /*
    public SettingKey getSettingKey(String var1)
    {
        Iterator var2 = this.Settings.iterator();

        Setting var3;
        do
        {
            if (!var2.hasNext())
            {
                throw new InvalidParameterException("SettingKey \'" + var1 + "\' not found.");
            }

            var3 = (Setting)var2.next();
        }
        while (!SettingKey.class.isAssignableFrom(var3.getClass()) || !var3.backendName.equals(var1));

        return (SettingKey)var3;
    }
    */

    public SettingDictionary getSettingList(String var1)
    {
        Iterator var2 = this.Settings.iterator();

        Setting var3;
        do
        {
            if (!var2.hasNext())
            {
                throw new InvalidParameterException("SettingList \'" + var1 + "\' not found.");
            }

            var3 = (Setting)var2.next();
        }
        while (!SettingDictionary.class.isAssignableFrom(var3.getClass()) || !var3.backendName.equals(var1));

        return (SettingDictionary)var3;
    }

    public SettingMulti getSettingMulti(String var1)
    {
        Iterator var2 = this.Settings.iterator();

        Setting var3;
        do
        {
            if (!var2.hasNext())
            {
                throw new InvalidParameterException("SettingMulti \'" + var1 + "\' not found.");
            }

            var3 = (Setting)var2.next();
        }
        while (!SettingMulti.class.isAssignableFrom(var3.getClass()) || !var3.backendName.equals(var1));

        return (SettingMulti)var3;
    }

    public SettingText getSettingText(String var1)
    {
        Iterator var2 = this.Settings.iterator();

        Setting var3;
        do
        {
            if (!var2.hasNext())
            {
                throw new InvalidParameterException("SettingText \'" + var1 + "\' not found.");
            }

            var3 = (Setting)var2.next();
        }
        while (!SettingText.class.isAssignableFrom(var3.getClass()) || !var3.backendName.equals(var1));

        return (SettingText)var3;
    }

    public String getTextSettingValue(String var1)
    {
        return this.getTextSettingValue(var1, currentContext);
    }

    public String getTextSettingValue(String var1, String var2)
    {
        return this.getSettingText(var1).get(var2);
    }

    public void load()
    {
        this.load("");
        this.settingsLoaded = true;
    }

    public void load(String var1)
    {
        try
        {
            if (contextDatadirs.get(var1) != null)
            {
                File var2 = getAppDir((String)contextDatadirs.get(var1) + "/" + this.backendname + "/");
                if (var2.exists())
                {
                    File var3 = new File(var2, "guiconfig.properties");
                    if (var3.exists())
                    {
                        Properties var4 = new Properties();
                        var4.load(new FileInputStream(var3));

                        for (int var5 = 0; var5 < this.Settings.size(); ++var5)
                        {
                            dbgout("setting load");
                            Setting var6 = (Setting)this.Settings.get(var5);
                            if (var4.containsKey(var6.backendName))
                            {
                                dbgout("setting " + (String)var4.get(var6.backendName));
                                var6.fromString((String)var4.get(var6.backendName), var1);
                            }
                        }
                    }
                }
            }
        }
        catch (Exception var7)
        {
            System.out.println(var7);
        }
    }

    public void remove(Setting var1)
    {
        this.Settings.remove(var1);
        var1.parent = null;
    }

    public void resetAll()
    {
        this.resetAll(currentContext);
    }

    public void resetAll(String var1)
    {
        for (int var2 = 0; var2 < this.Settings.size(); ++var2)
        {
            ((Setting)this.Settings.get(var2)).reset(var1);
        }
    }

    public void save(String var1)
    {
        if (this.settingsLoaded)
        {
            try
            {
                File var2 = getAppDir((String)contextDatadirs.get(var1) + "/" + this.backendname + "/");
                dbgout("saving context " + var1 + " (" + var2.getAbsolutePath() + " [" + (String)contextDatadirs.get(var1) + "])");
                if (!var2.exists())
                {
                    var2.mkdirs();
                }

                File var3 = new File(var2, "guiconfig.properties");
                Properties var4 = new Properties();

                for (int var5 = 0; var5 < this.Settings.size(); ++var5)
                {
                    Setting var6 = (Setting)this.Settings.get(var5);
                    var4.put(var6.backendName, var6.toString(var1));
                }

                FileOutputStream var8 = new FileOutputStream(var3);
                var4.store(var8, "");
            }
            catch (Exception var7)
            {
                var7.printStackTrace();
            }
        }
    }

    public int size()
    {
        return this.Settings.size();
    }

    static
    {
        contextDatadirs.put("", "mods");
    }
}
