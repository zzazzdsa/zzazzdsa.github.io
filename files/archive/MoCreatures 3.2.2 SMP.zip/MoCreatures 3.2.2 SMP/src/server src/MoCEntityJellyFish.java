package net.minecraft.src;

import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.MoCEntityAquatic;
import net.minecraft.src.MoCTools;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.Potion;
import net.minecraft.src.PotionEffect;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityJellyFish extends MoCEntityAquatic
{
    public float pulsingSize;
    private int poisoncounter;

    public MoCEntityJellyFish(World var1)
    {
        super(var1);
        this.texture = "/mocreatures/jellyfish6.png";
        this.setSize(0.3F, 0.5F);
        this.health = 6;
        this.setMaxHealth(6);
        this.setEdad(0.5F + this.rand.nextFloat() / 2.0F);
        this.moveSpeed = 0.1F;
    }

    public void chooseType()
    {
        if (this.getType() == 0)
        {
            int var1 = this.rand.nextInt(100);
            if (var1 <= 20)
            {
                this.setType(1);
            }
            else if (var1 <= 40)
            {
                this.setType(2);
            }
            else if (var1 <= 65)
            {
                this.setType(3);
            }
            else if (var1 <= 80)
            {
                this.setType(4);
            }
            else
            {
                this.setType(5);
            }
        }

        if (!this.getTypeChosen())
        {
            if (this.getType() == 1)
            {
                this.texture = "/mocreatures/jellyfish1.png";
            }
            else if (this.getType() == 2)
            {
                this.texture = "/mocreatures/jellyfish2.png";
            }
            else if (this.getType() == 3)
            {
                this.texture = "/mocreatures/jellyfish3.png";
            }
            else if (this.getType() == 4)
            {
                this.texture = "/mocreatures/jellyfish4.png";
            }
            else if (this.getType() == 5)
            {
                this.texture = "/mocreatures/jellyfish5.png";
            }
        }

        this.setTypeChosen(true);
    }

    /*
    public String getEntityTexture()
    {
        if (!this.getTypeChosen() && !this.worldObj.isRemote)
        {
            this.chooseType();
        }

        if (this.worldObj.isRemote)
        {
            if (this.getTexture() == null || this.getTexture().equals(""))
            {
                return super.getEntityTexture();
            }

            this.texture = this.getTexture();
        }

        return super.getEntityTexture();
    }
    */

    public void onLivingUpdate()
    {
        super.onLivingUpdate();
        if (!this.worldObj.isRemote)
        {
            ++this.poisoncounter;
            if (this.poisoncounter > 250 && this.worldObj.difficultySetting > 0)
            {
                EntityPlayer var1 = this.worldObj.getClosestPlayer(this.posX, this.posY, this.posZ, 2.0D);
                if (var1 != null)
                {
                    mod_mocreatures.poisoned = true;
                    var1.addPotionEffect(new PotionEffect(Potion.poison.id, 120, 0));
                    this.poisoncounter = 0;
                }
            }

            if (this.rand.nextInt(2) == 0)
            {
                this.pulsingSize += 0.02F;
            }

            if (this.pulsingSize > 0.3F)
            {
                this.pulsingSize = 0.0F;
            }
        }
    }

    public boolean isGlowing()
    {
        return !this.worldObj.isDaytime();
    }

    public void floating()
    {
        float var1 = MoCTools.distanceToSurface(this);
        if (this.motionY < -0.004D)
        {
            this.motionY = -0.004D;
        }

        if (var1 > 1.0F && this.pulsingSize == 0.0F)
        {
            this.motionY += 0.15D;
        }
    }

    protected int getDropItemId()
    {
        return Item.slimeBall.shiftedIndex;
    }

    public void readEntityFromNBT(NBTTagCompound var1)
    {
        super.readEntityFromNBT(var1);
        this.setEdad(var1.getFloat("Edad"));
        this.setType(var1.getInteger("TypeInt"));
    }

    public void writeEntityToNBT(NBTTagCompound var1)
    {
        super.writeEntityToNBT(var1);
        var1.setFloat("Edad", this.getEdad());
        var1.setInteger("TypeInt", this.getType());
    }

    public boolean getCanSpawnHere()
    {
        return ((Integer)mod_mocreatures.jellyfishfreq.get()).intValue() > 0 && super.getCanSpawnHere();
    }
}
