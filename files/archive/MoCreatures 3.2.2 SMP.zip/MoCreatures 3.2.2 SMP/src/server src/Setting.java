package net.minecraft.src;

import java.util.HashMap;

public abstract class Setting // extends Widget
{
    public String backendName;
    public Object defaultValue;
    // public WidgetSetting displayWidget = null;
    public ModSettings parent = null;
    public HashMap values = new HashMap();

    public void copyContext(String var1, String var2)
    {
        this.values.put(var2, this.values.get(var1));
    }

    public abstract void fromString(String var1, String var2);

    public Object get()
    {
        return this.get(ModSettings.currentContext);
    }

    public abstract Object get(String var1);

    public void reset()
    {
        this.reset(ModSettings.currentContext);
    }

    public void reset(String var1)
    {
        this.set(this.defaultValue, var1);
    }

    public void set(Object var1)
    {
        this.set(var1, ModSettings.currentContext);
    }

    public abstract void set(Object var1, String var2);

    public abstract String toString(String var1);
}
