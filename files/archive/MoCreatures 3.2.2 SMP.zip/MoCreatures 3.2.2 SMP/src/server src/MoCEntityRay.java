package net.minecraft.src;

import net.minecraft.src.DamageSource;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.MathHelper;
import net.minecraft.src.MoCEntityAquatic;
import net.minecraft.src.MoCTools;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.Potion;
import net.minecraft.src.PotionEffect;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityRay extends MoCEntityAquatic
{
    public boolean attacking;
    private int poisoncounter;

    public MoCEntityRay(World var1)
    {
        super(var1);
        this.texture = "/mocreatures/mantray.png";
        this.setSize(1.8F, 0.5F);
        this.health = 20;
        this.setEdad(0.5F + this.rand.nextFloat());
        this.moveSpeed = 0.3F;
    }

    public boolean interact(EntityPlayer var1)
    {
        if (this.riddenByEntity == null && this.getType() == 1)
        {
            var1.rotationYaw = this.rotationYaw;
            var1.rotationPitch = this.rotationPitch;
            var1.posY = this.posY;
            if (!this.worldObj.isRemote)
            {
                var1.mountEntity(this);
            }
        }
        else
        {
            var1.mountEntity((Entity)null);
        }

        return true;
    }

    public void chooseType()
    {
        if (this.getType() == 0)
        {
            int var1 = this.rand.nextInt(100);
            if (var1 <= 35)
            {
                this.setType(1);
                this.setEdad(0.8F + this.rand.nextFloat());
            }
            else
            {
                this.setType(2);
                this.setEdad(0.7F);
            }
        }

        if (!this.getTypeChosen())
        {
            if (this.getType() == 1)
            {
                this.texture = "/mocreatures/mantray.png";
                this.setMaxHealth(20);
                this.setSize(1.8F, 0.5F);
            }
            else if (this.getType() == 2)
            {
                this.texture = "/mocreatures/stingray.png";
                this.setMaxHealth(10);
                this.setSize(0.6F, 0.5F);
            }
        }

        this.setTypeChosen(true);
    }

    /*
    public String getEntityTexture()
    {
        if (!this.getTypeChosen() && !this.worldObj.isRemote)
        {
            this.chooseType();
        }

        if (this.worldObj.isRemote)
        {
            if (this.getTexture() == null || this.getTexture().equals(""))
            {
                return super.getEntityTexture();
            }

            this.texture = this.getTexture();
        }

        return super.getEntityTexture();
    }
    */

    public void onLivingUpdate()
    {
        super.onLivingUpdate();
        if (!this.worldObj.isRemote)
        {
            if (!this.getIsAdult() && this.rand.nextInt(50) == 0)
            {
                this.setEdad(this.getEdad() + 0.01F);
                if (this.getType() == 1 && this.getEdad() >= 1.8F || this.getType() > 1 && this.getEdad() >= 0.9F)
                {
                    this.setAdult(true);
                }
            }

            ++this.poisoncounter;
            if (this.poisoncounter > 100)
            {
                this.attacking = false;
            }

            if (this.getType() > 1 && this.poisoncounter > 250 && this.worldObj.difficultySetting > 0)
            {
                EntityPlayer var1 = this.worldObj.getClosestPlayer(this.posX, this.posY, this.posZ, 2.0D);
                if (var1 != null)
                {
                    mod_mocreatures.poisoned = true;
                    var1.addPotionEffect(new PotionEffect(Potion.poison.id, 120, 0));
                    this.poisoncounter = 0;
                    this.attacking = true;
                }
            }
        }
    }

    public boolean attackEntityFrom(DamageSource var1, int var2)
    {
        if (super.attackEntityFrom(var1, var2))
        {
            if (this.getType() != 1 && this.worldObj.difficultySetting != 0)
            {
                Entity var3 = var1.getEntity();
                if (var3 != this)
                {
                    this.entityToAttack = var3;
                }

                return true;
            }
            else
            {
                return true;
            }
        }
        else
        {
            return false;
        }
    }

    public void readEntityFromNBT(NBTTagCompound var1)
    {
        super.readEntityFromNBT(var1);
        this.setEdad(var1.getFloat("Edad"));
        this.setType(var1.getInteger("TypeInt"));
    }

    public void writeEntityToNBT(NBTTagCompound var1)
    {
        super.writeEntityToNBT(var1);
        var1.setFloat("Edad", this.getEdad());
        var1.setInteger("TypeInt", this.getType());
    }

    public boolean getCanSpawnHere()
    {
        int var1 = MathHelper.floor_double(this.posX);
        int var2 = MathHelper.floor_double(this.boundingBox.minY);
        int var3 = MathHelper.floor_double(this.posZ);
        String var4 = MoCTools.BiomeName(this, var1, var2, var3);
        if (var4 != "Ocean")
        {
            this.setType(2);
        }

        return ((Integer)mod_mocreatures.rayfreq.get()).intValue() > 0 && super.getCanSpawnHere();
    }
}
