package net.minecraft.src;

import net.minecraft.src.Item;
import net.minecraft.src.MathHelper;
import net.minecraft.src.MoCEntityFlyerMob;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityWraith extends MoCEntityFlyerMob
{
    public MoCEntityWraith(World var1)
    {
        super(var1);
        this.texture = "/mocreatures/wraith.png";
        this.setSize(1.5F, 1.5F);
        this.isImmuneToFire = false;
        this.attackStrength = 2;
        this.health = 10;
        this.moveSpeed = 1.3F;
    }

    public void entityInit()
    {
        if (this.worldObj.difficultySetting == 1)
        {
            this.attackStrength = 2;
        }
        else if (this.worldObj.difficultySetting > 1)
        {
            this.attackStrength = 3;
        }

        super.entityInit();
    }

    public boolean d2()
    {
        return super.getCanSpawnHere();
    }

    public boolean getCanSpawnHere()
    {
        return ((Integer)mod_mocreatures.wraithfreq.get()).intValue() > 0 && this.worldObj.difficultySetting >= ((Integer)mod_mocreatures.wraithSpawnDifficulty.get()).intValue() + 1 && super.getCanSpawnHere();
    }

    protected String getDeathSound()
    {
        return "wraithdying";
    }

    protected int getDropItemId()
    {
        return Item.gunpowder.shiftedIndex;
    }

    protected String getHurtSound()
    {
        return "wraithhurt";
    }

    protected String getLivingSound()
    {
        return "wraith";
    }

    public void onLivingUpdate()
    {
        if (!this.worldObj.isRemote && this.worldObj.isDaytime())
        {
            float var1 = this.getEntityBrightness(1.0F);
            if (var1 > 0.5F && this.worldObj.canBlockSeeTheSky(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY), MathHelper.floor_double(this.posZ)) && this.rand.nextFloat() * 30.0F < (var1 - 0.4F) * 2.0F)
            {
                this.setFire(15);
            }
        }

        super.onLivingUpdate();
    }
}
