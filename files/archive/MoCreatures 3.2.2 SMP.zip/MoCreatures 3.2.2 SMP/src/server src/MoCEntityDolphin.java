package net.minecraft.src;

import java.util.List;
import net.minecraft.src.DamageSource;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityItem;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.MoCEntityAquatic;
import net.minecraft.src.MoCEntityShark;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityDolphin extends MoCEntityAquatic
{
    private boolean textureSet;
    private double dolphinspeed;
    private boolean eaten;
    public int gestationtime;
    private boolean isHungry;

    public MoCEntityDolphin(World var1)
    {
        super(var1);
        this.texture = "/mocreatures/dolphin.png";
        this.setSize(1.5F, 0.8F);
        this.setEdad(0.8F + this.rand.nextFloat());
        this.dolphinspeed = 1.3D;
        this.setMaxHealth(30);
        this.health = 30;
        this.field_9100_aZ = true;
        this.textureSet = false;
    }

    protected void attackEntity(Entity var1, float var2)
    {
        if (this.attackTime <= 0 && (double)var2 < 3.5D && var1.boundingBox.maxY > this.boundingBox.minY && var1.boundingBox.minY < this.boundingBox.maxY && this.getEdad() >= 1.0F)
        {
            this.attackTime = 20;
            var1.attackEntityFrom(DamageSource.causeMobDamage(this), 5);
        }
    }

    public boolean attackEntityFrom(DamageSource var1, int var2)
    {
        if (super.attackEntityFrom(var1, var2) && this.worldObj.difficultySetting > 0)
        {
            Entity var3 = var1.getEntity();
            if (this.riddenByEntity != var3 && this.ridingEntity != var3)
            {
                if (var3 != this)
                {
                    this.entityToAttack = var3;
                }

                return true;
            }
            else
            {
                return true;
            }
        }
        else
        {
            return false;
        }
    }

    public boolean canBeCollidedWith()
    {
        return this.riddenByEntity == null;
    }

    public void chooseType()
    {
        if (this.getType() == 0)
        {
            int var1 = this.rand.nextInt(100);
            if (var1 <= 35)
            {
                this.setType(1);
            }
            else if (var1 <= 60)
            {
                this.setType(2);
            }
            else if (var1 <= 85)
            {
                this.setType(3);
            }
            else if (var1 <= 96)
            {
                this.setType(4);
            }
            else if (var1 <= 98)
            {
                this.setType(5);
            }
            else
            {
                this.setType(6);
            }
        }

        if (!this.getTypeChosen())
        {
            if (this.getType() == 1)
            {
                this.texture = "/mocreatures/dolphin.png";
                this.dolphinspeed = 1.5D;
                this.setTemper(50);
            }
            else if (this.getType() == 2)
            {
                this.texture = "/mocreatures/dolphin2.png";
                this.dolphinspeed = 2.5D;
                this.setTemper(100);
            }
            else if (this.getType() == 3)
            {
                this.texture = "/mocreatures/dolphin3.png";
                this.dolphinspeed = 3.5D;
                this.setTemper(150);
            }
            else if (this.getType() == 4)
            {
                this.texture = "/mocreatures/dolphin4.png";
                this.dolphinspeed = 4.5D;
                this.setTemper(200);
            }
            else if (this.getType() == 5)
            {
                this.texture = "/mocreatures/dolphin5.png";
                this.dolphinspeed = 5.5D;
                this.setTemper(250);
            }
            else if (this.getType() == 6)
            {
                this.texture = "/mocreatures/dolphin6.png";
                this.dolphinspeed = 6.5D;
                this.setTemper(300);
            }
        }

        this.setTypeChosen(true);
    }

    protected Entity findPlayerToAttack()
    {
        if (this.worldObj.difficultySetting > 0 && this.getEdad() >= 1.0F && ((Boolean)mod_mocreatures.attackdolphins.get()).booleanValue() && this.rand.nextInt(50) == 0)
        {
            EntityLiving var1 = this.FindTarget(this, 12.0D);
            if (var1 != null && var1.inWater)
            {
                return var1;
            }
        }

        return null;
    }

    public EntityLiving FindTarget(Entity var1, double var2)
    {
        double var4 = -1.0D;
        EntityLiving var6 = null;
        List var7 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(var2, var2, var2));

        for (int var8 = 0; var8 < var7.size(); ++var8)
        {
            Entity var9 = (Entity)var7.get(var8);
            if (var9 instanceof MoCEntityShark && (!(var9 instanceof MoCEntityShark) || !((MoCEntityShark)var9).getIsTamed()))
            {
                double var10 = var9.getDistanceSq(var1.posX, var1.posY, var1.posZ);
                if ((var2 < 0.0D || var10 < var2 * var2) && (var4 == -1.0D || var10 < var4) && ((EntityLiving)var9).canEntityBeSeen(var1))
                {
                    var4 = var10;
                    var6 = (EntityLiving)var9;
                }
            }
        }

        return var6;
    }

    private int Genetics(MoCEntityDolphin var1, MoCEntityDolphin var2)
    {
        if (var1.getType() == var2.getType())
        {
            return var1.getType();
        }
        else
        {
            int var3 = var1.getType() + var2.getType();
            boolean var4 = this.rand.nextInt(3) == 0;
            boolean var5 = this.rand.nextInt(10) == 0;
            return var3 < 5 && var4 ? var3 : ((var3 == 5 || var3 == 6) && var5 ? var3 : 0);
        }
    }

    public boolean getCanSpawnHere()
    {
        return ((Integer)mod_mocreatures.dolphinfreq.get()).intValue() > 0 && super.getCanSpawnHere();
    }

    protected String getDeathSound()
    {
        return "dolphindying";
    }

    protected int getDropItemId()
    {
        return Item.fishRaw.shiftedIndex;
    }

    /*
    public String getEntityTexture()
    {
        if (!this.getTypeChosen() && !this.worldObj.isRemote)
        {
            this.chooseType();
        }

        if (this.worldObj.isRemote && !this.textureSet)
        {
            if (this.getTexture() == null || this.getTexture().equals(""))
            {
                return super.getEntityTexture();
            }

            this.texture = this.getTexture();
            if (this.getType() == 1)
            {
                this.dolphinspeed = 1.5D;
            }
            else if (this.getType() == 2)
            {
                this.dolphinspeed = 2.5D;
            }
            else if (this.getType() == 3)
            {
                this.dolphinspeed = 3.5D;
            }
            else if (this.getType() == 4)
            {
                this.dolphinspeed = 4.5D;
            }
            else if (this.getType() == 5)
            {
                this.dolphinspeed = 5.5D;
            }
            else if (this.getType() == 6)
            {
                this.dolphinspeed = 6.5D;
            }
        }

        return super.getEntityTexture();
    }
    */

    protected String getHurtSound()
    {
        return "dolphinhurt";
    }

    public boolean getIsHungry()
    {
        return this.isHungry;
    }

    protected String getLivingSound()
    {
        return "dolphin";
    }

    protected float getSoundVolume()
    {
        return 0.4F;
    }

    protected String getUpsetSound()
    {
        return "dolphinupset";
    }

    public boolean interact(EntityPlayer var1)
    {
        ItemStack var2 = var1.inventory.getCurrentItem();
        if (var2 != null && var2.itemID == Item.fishRaw.shiftedIndex)
        {
            if (--var2.stackSize == 0)
            {
                var1.inventory.setInventorySlotContents(var1.inventory.currentItem, (ItemStack)null);
            }

            if (!this.worldObj.isRemote)
            {
                this.setTemper(this.getTemper() - 25);
                if (this.getTemper() < 1)
                {
                    this.setTemper(1);
                }
            }

            if ((this.health += 15) > this.getMaxHealth())
            {
                this.health = this.getMaxHealth();
            }

            this.worldObj.playSoundAtEntity(this, "eating", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
            if (!this.getIsAdult())
            {
                this.setEdad(this.getEdad() + 0.01F);
            }

            return true;
        }
        else if (var2 != null && var2.itemID == Item.fishCooked.shiftedIndex && this.getIsTamed() && this.getIsAdult())
        {
            if (--var2.stackSize == 0)
            {
                var1.inventory.setInventorySlotContents(var1.inventory.currentItem, (ItemStack)null);
            }

            if ((this.health += 25) > this.getMaxHealth())
            {
                this.health = this.getMaxHealth();
            }

            this.eaten = true;
            this.worldObj.playSoundAtEntity(this, "eating", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
            return true;
        }
        else if (var2 != null && this.getIsTamed() && (var2.itemID == mod_mocreatures.medallion.shiftedIndex || var2.itemID == Item.book.shiftedIndex))
        {
            //mod_mocreatures.setName(this);
            return true;
        }
        else if (var2 != null && this.getIsTamed() && (var2.itemID == Item.pickaxeDiamond.shiftedIndex || var2.itemID == Item.pickaxeWood.shiftedIndex || var2.itemID == Item.pickaxeStone.shiftedIndex || var2.itemID == Item.pickaxeSteel.shiftedIndex || var2.itemID == Item.pickaxeGold.shiftedIndex))
        {
            this.setDisplayName(!this.getDisplayName());
            return true;
        }
        else if (this.riddenByEntity == null)
        {
            var1.rotationYaw = this.rotationYaw;
            var1.rotationPitch = this.rotationPitch;
            var1.posY = this.posY;
            if (!this.worldObj.isRemote)
            {
                // var1.mountEntity(this);
            }

            return true;
        }
        else
        {
            return false;
        }
    }

    public void onLivingUpdate()
    {
        super.onLivingUpdate();
        if (!this.worldObj.isRemote)
        {
            if (!this.getIsAdult() && this.rand.nextInt(50) == 0)
            {
                this.setEdad(this.getEdad() + 0.01F);
                if (this.getEdad() >= 1.5F)
                {
                    this.setAdult(true);
                }
            }

            if (!this.getIsHungry() && this.rand.nextInt(100) == 0)
            {
                this.setIsHungry(true);
            }

            if (this.riddenByEntity == null && this.deathTime == 0 && (!this.getIsTamed() || this.getIsHungry()))
            {
                EntityItem var1 = this.getClosestFish(this, 12.0D);
                if (var1 != null)
                {
                    this.MoveToNextEntity(var1);
                    EntityItem var2 = this.getClosestFish(this, 2.0D);
                    if (this.rand.nextInt(20) == 0 && var2 != null && this.deathTime == 0)
                    {
                        var2.setEntityDead();
                        this.setTemper(this.getTemper() - 25);
                        if (this.getTemper() < 1)
                        {
                            this.setTemper(1);
                        }

                        this.health = this.getMaxHealth();
                    }
                }
            }

            if (!this.ReadyforParenting(this))
            {
                return;
            }

            int var9 = 0;
            List var10 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(8.0D, 2.0D, 8.0D));

            for (int var3 = 0; var3 < var10.size(); ++var3)
            {
                Entity var4 = (Entity)var10.get(var3);
                if (var4 instanceof MoCEntityDolphin)
                {
                    ++var9;
                }
            }

            if (var9 > 1)
            {
                return;
            }

            List var11 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(4.0D, 2.0D, 4.0D));

            for (int var12 = 0; var12 < var10.size(); ++var12)
            {
                Entity var5 = (Entity)var11.get(var12);
                if (var5 instanceof MoCEntityDolphin && var5 != this)
                {
                    MoCEntityDolphin var6 = (MoCEntityDolphin)var5;
                    if (this.ReadyforParenting(this) && this.ReadyforParenting(var6))
                    {
                        if (this.rand.nextInt(100) == 0)
                        {
                            ++this.gestationtime;
                        }

                        if (this.gestationtime > 50)
                        {
                            MoCEntityDolphin var7 = new MoCEntityDolphin(this.worldObj);
                            var7.setPosition(this.posX, this.posY, this.posZ);
                            this.worldObj.spawnEntityInWorld(var7);
                            this.worldObj.playSoundAtEntity(this, "mob.chickenplop", 1.0F, (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F);
                            this.eaten = false;
                            var6.eaten = false;
                            this.gestationtime = 0;
                            var6.gestationtime = 0;
                            int var8 = this.Genetics(this, var6);
                            var7.setEdad(0.35F);
                            var7.setAdult(false);
                            var7.setTypeInt(var8);
                            break;
                        }
                    }
                }
            }
        }
    }

    public boolean ReadyforParenting(MoCEntityDolphin var1)
    {
        return var1.riddenByEntity == null && var1.ridingEntity == null && var1.getIsTamed() && var1.eaten && var1.getIsAdult();
    }

    public boolean renderName()
    {
        return this.getDisplayName() && this.riddenByEntity == null;
    }

    public void setEntityDead()
    {
        if (this.worldObj.isRemote || !this.getIsTamed() || this.health <= 0)
        {
            super.setEntityDead();
        }
    }

    public void setIsHungry(boolean var1)
    {
        this.isHungry = var1;
    }

    public void setTypeInt(int var1)
    {
        this.setType(var1);
        this.setTypeChosen(false);
        this.chooseType();
    }

    public double speed()
    {
        return this.dolphinspeed;
    }

    public void readEntityFromNBT(NBTTagCompound var1)
    {
        super.readEntityFromNBT(var1);
        this.setType(var1.getInteger("TypeInt"));
        this.setTamed(var1.getBoolean("Tamed"));
        this.setName(var1.getString("Name"));
        this.setDisplayName(var1.getBoolean("DisplayName"));
        this.setAdult(var1.getBoolean("Adult"));
        this.setEdad(var1.getFloat("Edad"));
    }

    public void writeEntityToNBT(NBTTagCompound var1)
    {
        super.writeEntityToNBT(var1);
        var1.setBoolean("Tamed", this.getIsTamed());
        var1.setInteger("TypeInt", this.getType());
        var1.setBoolean("Adult", this.getIsAdult());
        var1.setFloat("Edad", this.getEdad());
        var1.setString("Name", this.getName());
        var1.setBoolean("DisplayName", this.getDisplayName());
    }
}
