package net.minecraft.src;

import net.minecraft.src.DamageSource;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityItem;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.MathHelper;
import net.minecraft.src.MoCEntityAnimal;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.PathEntity;
import net.minecraft.src.Potion;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityGoat extends MoCEntityAnimal
{
    private boolean charging;
    private boolean swingLeg;
    private boolean swingEar;
    private boolean swingTail;
    private boolean bleat;
    private boolean eating;
    private boolean hungry;
    private int bleatcount;
    private int attacking;
    private boolean upset;
    public int movecount;
    private int chargecount;
    private int tailcount;
    private int earcount;
    private int eatcount;
    public EntityLiving roper;

    public MoCEntityGoat(World var1)
    {
        super(var1);
        this.texture = "/mocreatures/goat.png";
        this.setSize(1.5F, 0.9F);
        this.health = 12;
        this.setMaxHealth(12);
        this.setEdad(0.5F);
    }

    /*
    public String getEntityTexture()
    {
        if (!this.getTypeChosen() && !this.worldObj.isRemote)
        {
            this.chooseType();
        }

        if (this.worldObj.isRemote && !this.textureSet && this.getTexture() != null && !this.getTexture().equals(""))
        {
            this.texture = this.getTexture();
            this.textureSet = true;
        }

        return super.getEntityTexture();
    }
    */

    public void chooseType()
    {
        if (this.getType() == 0)
        {
            int var1 = this.rand.nextInt(100);
            if (var1 <= 15)
            {
                this.setType(1);
                this.setEdad(0.5F);
            }
            else if (var1 <= 30)
            {
                this.setType(2);
                this.setEdad(0.7F);
            }
            else if (var1 <= 45)
            {
                this.setType(3);
                this.setEdad(0.7F);
            }
            else if (var1 <= 60)
            {
                this.setType(4);
                this.setEdad(0.7F);
            }
            else if (var1 <= 75)
            {
                this.setType(5);
                this.setEdad(0.9F);
            }
            else if (var1 <= 90)
            {
                this.setType(6);
                this.setEdad(0.9F);
            }
            else
            {
                this.setType(7);
                this.setEdad(0.9F);
            }
        }

        if (!this.getTypeChosen())
        {
            if (this.getType() == 1)
            {
                this.texture = "/mocreatures/goat1.png";
            }
            else if (this.getType() == 2)
            {
                this.texture = "/mocreatures/goat2.png";
            }
            else if (this.getType() == 3)
            {
                this.texture = "/mocreatures/goat3.png";
            }
            else if (this.getType() == 4)
            {
                this.texture = "/mocreatures/goat4.png";
            }
            else if (this.getType() == 5)
            {
                this.texture = "/mocreatures/goat5.png";
            }
            else if (this.getType() == 6)
            {
                this.texture = "/mocreatures/goat6.png";
            }
            else if (this.getType() == 7)
            {
                this.texture = "/mocreatures/goat1.png";
            }
        }

        this.setTypeChosen(true);
    }

    public void setTypeInt(int var1)
    {
        this.setType(var1);
        this.setTypeChosen(false);
        this.chooseType();
    }

    public void calm()
    {
        this.entityToAttack = null;
        this.setUpset(false);
        this.setCharging(false);
        this.moveSpeed = 0.7F;
        this.attacking = 0;
        this.chargecount = 0;
    }

    protected void jump()
    {
        if (this.getType() == 1)
        {
            this.motionY = 0.41D;
        }
        else if (this.getType() < 5)
        {
            this.motionY = 0.45D;
        }
        else
        {
            this.motionY = 0.5D;
        }

        if (this.isPotionActive(Potion.jump))
        {
            this.motionY += (double)((float)(this.getActivePotionEffect(Potion.jump).getAmplifier() + 1) * 0.1F);
        }

        if (this.isSprinting())
        {
            float var1 = this.rotationYaw * 0.01745329F;
            this.motionX -= (double)(MathHelper.sin(var1) * 0.2F);
            this.motionZ += (double)(MathHelper.cos(var1) * 0.2F);
        }

        this.isAirBorne = true;
    }

    public void onLivingUpdate()
    {
        super.onLivingUpdate();
        if (this.rand.nextInt(100) == 0)
        {
            this.setSwingEar(true);
        }

        if (this.rand.nextInt(80) == 0)
        {
            this.setSwingTail(true);
        }

        if (this.rand.nextInt(50) == 0)
        {
            this.setEating(true);
        }

        if (this.hungry && this.rand.nextInt(20) == 0)
        {
            this.hungry = false;
        }

        if (this.getBleating())
        {
            ++this.bleatcount;
            if (this.bleatcount > 15)
            {
                this.bleatcount = 0;
                this.setBleating(false);
            }
        }

        if ((this.getEdad() < 0.9F || this.getType() > 4 && this.getEdad() < 1.0F) && this.rand.nextInt(500) == 0)
        {
            this.setEdad(this.getEdad() + 0.005F);
            if (this.getType() == 1 && this.getEdad() > 0.7F)
            {
                int var1 = this.rand.nextInt(6) + 2;
                this.setTypeInt(var1);
            }
        }

        if (this.getUpset())
        {
            this.attacking += this.rand.nextInt(4) + 2;
            if (this.attacking > 75)
            {
                this.attacking = 75;
            }

            if (this.rand.nextInt(500) == 0 || this.entityToAttack == null)
            {
                this.calm();
            }

            if (!this.getCharging() && this.rand.nextInt(35) == 0)
            {
                this.swingLeg();
            }

            if (!this.getCharging())
            {
                this.setPathToEntity((PathEntity)null);
            }

            if (this.entityToAttack != null)
            {
                this.faceEntity(this.entityToAttack, 10.0F, 10.0F);
                if (this.rand.nextInt(80) == 0)
                {
                    this.setCharging(true);
                }
            }
        }

        if (this.getCharging())
        {
            ++this.chargecount;
            if (this.chargecount > 120)
            {
                this.chargecount = 0;
                this.moveSpeed = 0.7F;
            }
            else
            {
                this.moveSpeed = 1.0F;
            }

            if (this.entityToAttack == null)
            {
                this.calm();
            }
        }

        if (!this.getUpset() && !this.getCharging())
        {
            if (this.getIsTamed() && this.roper != null)
            {
                float var7 = this.roper.getDistanceToEntity(this);
                if (var7 > 5.0F)
                {
                    this.getPathOrWalkableBlock(this.roper, var7);
                    return;
                }
            }

            EntityPlayer var8 = this.worldObj.getClosestPlayerToEntity(this, 24.0D);
            if (var8 != null)
            {
                EntityItem var2 = this.getClosestEntityItem(this, 10.0D);
                if (var2 != null)
                {
                    float var3 = var2.getDistanceToEntity(this);
                    if (var3 > 2.0F)
                    {
                        int var11 = MathHelper.floor_double(var2.posX);
                        int var12 = MathHelper.floor_double(var2.posY);
                        int var6 = MathHelper.floor_double(var2.posZ);
                        this.faceLocation(var11, var12, var6, 30.0F);
                        this.getMyOwnPath(var2, var3);
                        return;
                    }

                    if (var3 < 2.0F && var2 != null && this.deathTime == 0 && this.rand.nextInt(50) == 0)
                    {
                        this.worldObj.playSoundAtEntity(this, "goateating", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
                        this.setEating(true);
                        var2.setEntityDead();
                        return;
                    }
                }

                ItemStack var9 = var8.inventory.getCurrentItem();
                Item var4 = null;
                if (var9 != null)
                {
                    var4 = var9.getItem();
                }

                if (var4 != null && this.isItemEdible(var4))
                {
                    PathEntity var10 = this.worldObj.getPathToEntity(this, var8, 16.0F);
                    this.setPathToEntity(var10);
                    this.hungry = true;
                    return;
                }

                if (this.getType() > 4 && this.rand.nextInt(200) == 0)
                {
                    MoCEntityGoat var5 = (MoCEntityGoat)this.getClosestEntityLiving(this, 14.0D);
                    if (var5 != null)
                    {
                        this.setUpset(true);
                        this.entityToAttack = var5;
                        var5.setUpset(true);
                        var5.entityToAttack = this;
                    }
                }
            }
        }
    }

    public int getTalkInterval()
    {
        return this.hungry ? 20 : 120;
    }

    public boolean entitiesToIgnore(Entity var1)
    {
        return !(var1 instanceof MoCEntityGoat) || ((MoCEntityGoat)var1).getType() < 5 || ((MoCEntityGoat)var1).roper != null;
    }

    protected boolean isMovementCeased()
    {
        return this.getUpset() && !this.getCharging();
    }

    protected void attackEntity(Entity var1, float var2)
    {
        if (this.attackTime <= 0 && (double)var2 < 3.0D && var1.boundingBox.maxY > this.boundingBox.minY && var1.boundingBox.minY < this.boundingBox.maxY && this.attacking > 70)
        {
            this.attackTime = 30;
            this.attacking = 30;
            this.worldObj.playSoundAtEntity(this, "goatsmack", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
            if (var1 instanceof MoCEntityGoat)
            {
                this.bigsmack(this, var1, 0.4F);
                if (this.rand.nextInt(10) == 0)
                {
                    this.calm();
                    ((MoCEntityGoat)var1).calm();
                }
            }
            else
            {
                var1.attackEntityFrom(DamageSource.causeMobDamage(this), 3);
                this.bigsmack(this, var1, 0.8F);
                if (this.rand.nextInt(3) == 0)
                {
                    this.calm();
                }
            }
        }
    }

    public boolean isNotScared()
    {
        return this.getType() > 4;
    }

    private void swingLeg()
    {
        if (!this.getSwingLeg())
        {
            this.setSwingLeg(true);
            this.movecount = 0;
        }
    }

    public boolean getCharging()
    {
        return this.charging;
    }

    public void setCharging(boolean var1)
    {
        this.charging = var1;
    }

    public boolean getUpset()
    {
        return this.upset;
    }

    public void setUpset(boolean var1)
    {
        this.upset = var1;
    }

    public boolean getSwingLeg()
    {
        return this.swingLeg;
    }

    public void setSwingLeg(boolean var1)
    {
        this.swingLeg = var1;
    }

    public boolean getSwingEar()
    {
        return this.swingEar;
    }

    public void setSwingEar(boolean var1)
    {
        this.swingEar = var1;
    }

    public boolean getSwingTail()
    {
        return this.swingTail;
    }

    public void setSwingTail(boolean var1)
    {
        this.swingTail = var1;
    }

    public boolean getEating()
    {
        return this.eating;
    }

    public void setEating(boolean var1)
    {
        this.eating = var1;
    }

    public boolean attackEntityFrom(DamageSource var1, int var2)
    {
        if (super.attackEntityFrom(var1, var2))
        {
            Entity var3 = var1.getEntity();
            if (var3 != this && this.worldObj.difficultySetting > 0 && this.getType() > 4)
            {
                this.entityToAttack = var3;
                this.setUpset(true);
            }

            return true;
        }
        else
        {
            return false;
        }
    }

    public void onUpdate()
    {
        if (this.getSwingLeg())
        {
            this.movecount += 5;
            if (this.movecount == 30)
            {
                this.worldObj.playSoundAtEntity(this, "goatdigg", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
            }

            if (this.movecount > 100)
            {
                this.setSwingLeg(false);
                this.movecount = 0;
            }
        }

        if (this.getSwingEar())
        {
            this.earcount += 5;
            if (this.earcount > 40)
            {
                this.setSwingEar(false);
                this.earcount = 0;
            }
        }

        if (this.getSwingTail())
        {
            this.tailcount += 15;
            if (this.tailcount > 135)
            {
                this.setSwingTail(false);
                this.tailcount = 0;
            }
        }

        if (this.getEating())
        {
            ++this.eatcount;
            if (this.eatcount == 2)
            {
                EntityPlayer var1 = this.worldObj.getClosestPlayerToEntity(this, 3.0D);
                if (var1 != null)
                {
                    this.worldObj.playSoundAtEntity(this, "goateating", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
                }
            }

            if (this.eatcount > 25)
            {
                this.setEating(false);
                this.eatcount = 0;
            }
        }

        super.onUpdate();
    }

    public int legMovement()
    {
        return !this.getSwingLeg() ? 0 : (this.movecount < 21 ? this.movecount * -1 : (this.movecount < 70 ? this.movecount - 40 : -this.movecount + 100));
    }

    public int earMovement()
    {
        return !this.getSwingEar() ? 0 : (this.earcount < 11 ? this.earcount + 30 : (this.earcount < 31 ? -this.earcount + 50 : this.earcount - 10));
    }

    public int tailMovement()
    {
        return !this.getSwingTail() ? 90 : this.tailcount - 45;
    }

    public int mouthMovement()
    {
        return !this.getEating() ? 0 : (this.eatcount < 6 ? this.eatcount : (this.eatcount < 16 ? -this.eatcount + 10 : this.eatcount - 20));
    }

    protected void fall(float var1) {}

    public boolean interact(EntityPlayer var1)
    {
        ItemStack var2 = var1.inventory.getCurrentItem();
        if (var2 != null && var2.itemID == Item.bucketEmpty.shiftedIndex)
        {
            if (this.getType() > 4)
            {
                this.setUpset(true);
                this.entityToAttack = var1;
                return false;
            }
            else if (this.getType() == 1)
            {
                return false;
            }
            else
            {
                var1.inventory.setInventorySlotContents(var1.inventory.currentItem, new ItemStack(Item.bucketMilk));
                return true;
            }
        }
        else
        {
            if (this.getIsTamed())
            {
                if (var2 != null && (var2.itemID == mod_mocreatures.medallion.shiftedIndex || var2.itemID == Item.book.shiftedIndex))
                {
                    //mod_mocreatures.setName((MoCEntityAnimal)this);
                    return true;
                }

                if (var2 != null && this.isItemEdible(var2.getItem()))
                {
                    if (--var2.stackSize == 0)
                    {
                        var1.inventory.setInventorySlotContents(var1.inventory.currentItem, (ItemStack)null);
                    }

                    this.heal(10);
                    this.worldObj.playSoundAtEntity(this, "goateating", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
                }

                if (var2 != null && (var2.itemID == Item.pickaxeDiamond.shiftedIndex || var2.itemID == Item.pickaxeWood.shiftedIndex || var2.itemID == Item.pickaxeStone.shiftedIndex || var2.itemID == Item.pickaxeSteel.shiftedIndex || var2.itemID == Item.pickaxeGold.shiftedIndex))
                {
                    this.setDisplayName(!this.getDisplayName());
                    return true;
                }

                if (var2 != null && this.riddenByEntity == null && this.roper == null && var2.itemID == mod_mocreatures.rope.shiftedIndex)
                {
                    if (--var2.stackSize == 0)
                    {
                        var1.inventory.setInventorySlotContents(var1.inventory.currentItem, (ItemStack)null);
                    }

                    this.worldObj.playSoundAtEntity(this, "roping", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
                    this.roper = var1;
                    return true;
                }

                if (this.roper != null)
                {
                    var1.inventory.addItemStackToInventory(new ItemStack(mod_mocreatures.rope));
                    this.worldObj.playSoundAtEntity(this, "roping", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
                    this.roper = null;
                    return true;
                }
            }

            if (!this.getIsTamed() && var2 != null && this.isItemEdible(var2.getItem()))
            {
                this.setTamed(true);
                //mod_mocreatures.setName((MoCEntityAnimal)this);
            }

            return super.interact(var1);
        }
    }

    public boolean getBleating()
    {
        return this.bleat && this.getAttacking() == 0;
    }

    public void setBleating(boolean var1)
    {
        this.bleat = var1;
    }

    public int getAttacking()
    {
        return this.attacking;
    }

    public void setAttacking(int var1)
    {
        this.attacking = var1;
    }

    public boolean renderName()
    {
        return this.getDisplayName();
    }

    protected String getHurtSound()
    {
        return "goathurt";
    }

    protected String getLivingSound()
    {
        this.setBleating(true);
        return this.getType() == 1 ? "goatkid" : (this.getType() > 2 && this.getType() < 5 ? "goatfemale" : "goatgrunt");
    }

    protected String getDeathSound()
    {
        return "goatdying";
    }

    protected int getDropItemId()
    {
        return Item.leather.shiftedIndex;
    }

    public void readEntityFromNBT(NBTTagCompound var1)
    {
        super.readEntityFromNBT(var1);
        this.setType(var1.getInteger("TypeInt"));
        this.setName(var1.getString("Name"));
        this.setDisplayName(var1.getBoolean("DisplayName"));
    }

    public void writeEntityToNBT(NBTTagCompound var1)
    {
        super.writeEntityToNBT(var1);
        var1.setInteger("TypeInt", this.getType());
        var1.setString("Name", this.getName());
        var1.setBoolean("DisplayName", this.getDisplayName());
    }

    public boolean getCanSpawnHere()
    {
        return ((Integer)mod_mocreatures.goatfreq.get()).intValue() > 0 && super.getCanSpawnHere();
    }
}
