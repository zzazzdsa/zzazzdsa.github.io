package net.minecraft.src;

import net.minecraft.src.DamageSource;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.Material;
import net.minecraft.src.MathHelper;
import net.minecraft.src.MoCEntityAnimal;
import net.minecraft.src.MoCTools;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.PathEntity;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityCrocodile extends MoCEntityAnimal
{
    private boolean isBiting;
    private boolean isResting;
    private boolean caughtPrey;
    public float biteProgress;
    public float spin;
    public int spinInt;
    private boolean waterbound;
    private int hunting;

    public MoCEntityCrocodile(World var1)
    {
        super(var1);
        this.texture = "/mocreatures/crocodile.png";
        this.setSize(2.0F, 0.6F);
        this.moveSpeed = 0.5F;
        this.health = 25;
        this.setEdad(0.5F + this.rand.nextFloat());
        this.setTamed(false);
    }

    protected void jump()
    {
        if (this.isInsideOfMaterial(Material.water))
        {
            if (this.caughtPrey || this.entityToAttack == null && this.rand.nextInt(20) != 0)
            {
                return;
            }

            this.motionY = 0.3D;
            if (this.isSprinting())
            {
                float var1 = this.rotationYaw * 0.01745329F;
                this.motionX -= (double)(MathHelper.sin(var1) * 0.2F);
                this.motionZ += (double)(MathHelper.cos(var1) * 0.2F);
            }

            this.isAirBorne = true;
        }
        else if (this.entityToAttack != null || this.caughtPrey)
        {
            super.jump();
        }
    }

    protected boolean isMovementCeased()
    {
        return this.getIsResting();
    }

    protected void updateEntityActionState()
    {
        if (!this.getIsResting())
        {
            super.updateEntityActionState();
        }
    }

    public boolean swimmerEntity()
    {
        return true;
    }

    public void onLivingUpdate()
    {
        if (this.getIsResting())
        {
            this.rotationPitch = -5.0F;
            if (!this.isInsideOfMaterial(Material.water) && this.biteProgress < 0.3F && this.rand.nextInt(5) == 0)
            {
                this.biteProgress += 0.005F;
            }

            this.entityToAttack = this.findPlayerToAttack();
            if (this.entityToAttack != null)
            {
                this.setIsResting(false);
                this.getMyOwnPath(this.entityToAttack, 16.0F);
            }

            if (this.entityToAttack != null || this.caughtPrey || this.rand.nextInt(500) == 0)
            {
                this.setIsResting(false);
                this.biteProgress = 0.0F;
                this.hunting = 1;
            }
        }
        else if (this.rand.nextInt(500) == 0 && this.entityToAttack == null && !this.caughtPrey)
        {
            this.setIsResting(true);
            this.setPathToEntity((PathEntity)null);
        }

        if (this.isInsideOfMaterial(Material.water))
        {
            this.moveSpeed = 0.8F;
        }
        else
        {
            this.moveSpeed = 0.4F;
        }

        if (this.hunting > 0)
        {
            ++this.hunting;
            if (this.hunting > 120)
            {
                this.hunting = 0;
                this.moveSpeed = 0.5F;
            }
            else
            {
                this.moveSpeed = 1.0F;
            }

            if (this.entityToAttack == null)
            {
                this.hunting = 0;
                this.moveSpeed = 0.5F;
            }
        }

        if (this.rand.nextInt(80) == 0 && !this.caughtPrey && !this.getIsResting())
        {
            this.crocBite();
        }

        if (this.rand.nextInt(500) == 0 && !this.waterbound && !this.getIsResting() && !this.isInsideOfMaterial(Material.water))
        {
            MoCTools.MoveToWater(this);
        }

        if (this.getEdad() < 1.5F && this.rand.nextInt(200) == 0)
        {
            this.setEdad(this.getEdad() + 0.005F);
            if (this.getEdad() >= 0.9F)
            {
                this.setAdult(true);
            }
        }

        if (this.waterbound)
        {
            if (!this.isInsideOfMaterial(Material.water))
            {
                MoCTools.MoveToWater(this);
            }
            else
            {
                this.waterbound = false;
            }
        }

        if (this.caughtPrey)
        {
            if (this.riddenByEntity != null)
            {
                this.entityToAttack = null;
                this.biteProgress = 0.4F;
                this.setIsResting(false);
                if (!this.isInsideOfMaterial(Material.water))
                {
                    this.waterbound = true;
                    if (this.riddenByEntity instanceof EntityLiving && ((EntityLiving)this.riddenByEntity).health > 0)
                    {
                        ((EntityLiving)this.riddenByEntity).deathTime = 0;
                    }

                    if (this.rand.nextInt(50) == 0)
                    {
                        this.riddenByEntity.attackEntityFrom(DamageSource.causeMobDamage(this), 2);
                        if (!(this.riddenByEntity instanceof EntityPlayer))
                        {
                            MoCTools.destroyDrops(this, 3.0D);
                        }
                    }
                }
            }
            else
            {
                this.caughtPrey = false;
                this.biteProgress = 0.0F;
                this.waterbound = false;
            }

            if (this.isSpinning())
            {
                this.spinInt += 3;
                if (this.spinInt % 20 == 0)
                {
                    this.worldObj.playSoundAtEntity(this, "crocroll", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
                }

                if (this.spinInt > 80)
                {
                    this.spinInt = 0;
                    this.riddenByEntity.attackEntityFrom(DamageSource.causeMobDamage(this), 4);
                    if (!(this.riddenByEntity instanceof EntityPlayer))
                    {
                        MoCTools.destroyDrops(this, 3.0D);
                    }
                }

                /*
                if (!this.worldObj.isRemote && this.riddenByEntity != null && this.riddenByEntity instanceof EntityPlayer)
                {
                    mod_mocreatures.mc.gameSettings.thirdPersonView = 1;
                }
                */
            }
        }

        super.onLivingUpdate();
    }

    public boolean isNotScared()
    {
        return true;
    }

    public boolean getIsSitting()
    {
        double var1 = 0.01D;
        return this.getIsResting() || this.motionX < var1 && this.motionX > -var1 && this.motionZ < var1 && this.motionZ > -var1;
    }

    public void crocBite()
    {
        if (!this.getIsBiting())
        {
            this.setBiting(true);
            this.biteProgress = 0.0F;
        }
    }

    public void onUpdate()
    {
        if (this.getIsBiting() && !this.caughtPrey)
        {
            this.biteProgress += 0.1F;
            if (this.biteProgress == 0.4F)
            {
                this.worldObj.playSoundAtEntity(this, "crocjawsnap", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
            }

            if (this.biteProgress > 0.6F)
            {
                this.setBiting(false);
                this.biteProgress = 0.0F;
            }
        }

        super.onUpdate();
    }

    protected void attackEntity(Entity var1, float var2)
    {
        if (!this.caughtPrey)
        {
            if (this.attackTime <= 0 && var2 < 3.0F && var1.boundingBox.maxY > this.boundingBox.minY && var1.boundingBox.minY < this.boundingBox.maxY)
            {
                this.attackTime = 20;
                if (var1.ridingEntity == null && this.rand.nextInt(3) == 0)
                {
                    var1.mountEntity(this);
                    this.caughtPrey = true;
                }
                else
                {
                    var1.attackEntityFrom(DamageSource.causeMobDamage(this), 2);
                    if (!(var1 instanceof EntityPlayer))
                    {
                        MoCTools.destroyDrops(this, 3.0D);
                    }

                    this.crocBite();
                    this.caughtPrey = false;
                }
            }
        }
    }

    public boolean attackEntityFrom(DamageSource var1, int var2)
    {
        Entity var3;
        if (this.riddenByEntity != null)
        {
            var3 = var1.getEntity();
            if (var3 != null && this.riddenByEntity == var3)
            {
                if (this.rand.nextInt(10) != 0)
                {
                    return false;
                }

                this.unMount();
            }
        }

        if (super.attackEntityFrom(var1, var2))
        {
            var3 = var1.getEntity();
            if (this.riddenByEntity != null && this.riddenByEntity == var3 && var3 != this && this.worldObj.difficultySetting > 0)
            {
                this.entityToAttack = var3;
            }

            return true;
        }
        else
        {
            return false;
        }
    }

    protected Entity findPlayerToAttack()
    {
        if (this.caughtPrey)
        {
            return null;
        }
        else
        {
            if (this.worldObj.difficultySetting > 0)
            {
                EntityLiving var1;
                if (this.getIsResting())
                {
                    var1 = this.getClosestEntityLiving(this, 6.0D);
                    return var1;
                }

                if (this.rand.nextInt(80) == 0)
                {
                    var1 = this.getClosestEntityLiving(this, 12.0D);
                    return var1;
                }
            }

            return null;
        }
    }

    public boolean entitiesToIgnore(Entity var1)
    {
        return super.entitiesToIgnore(var1) || var1 instanceof MoCEntityCrocodile || var1.height < this.height && var1.width < this.width;
    }

    public void updateRiderPosition()
    {
        if (this.riddenByEntity != null)
        {
            boolean var1 = true;
            double var2 = (double)(this.getEdad() + this.riddenByEntity.width) - 0.4D;
            double var4 = this.posX - var2 * Math.cos((double)(MoCTools.realAngle(this.rotationYaw - 90.0F) / 57.29578F));
            double var6 = this.posZ - var2 * Math.sin((double)(MoCTools.realAngle(this.rotationYaw - 90.0F) / 57.29578F));
            this.riddenByEntity.setPosition(var4, this.posY + this.getMountedYOffset() + this.riddenByEntity.getYOffset(), var6);
            byte var8;
            if (this.spinInt > 40)
            {
                var8 = -1;
            }
            else
            {
                var8 = 1;
            }

            ((EntityLiving)this.riddenByEntity).renderYawOffset = this.rotationYaw * (float)var8;
            ((EntityLiving)this.riddenByEntity).prevRenderYawOffset = this.rotationYaw * (float)var8;
        }
    }

    public double getMountedYOffset()
    {
        return (double)this.height * 0.35D;
    }

    public void floating()
    {
        if (this.entityToAttack != null && this.entityToAttack.posY < this.posY - 0.5D && this.getDistanceToEntity(this.entityToAttack) < 10.0F)
        {
            if (this.motionY < -0.1D)
            {
                this.motionY = -0.1D;
            }
        }
        else
        {
            super.floating();
        }
    }

    public boolean getIsBiting()
    {
        return this.isBiting;
    }

    public void setBiting(boolean var1)
    {
        this.isBiting = var1;
    }

    public boolean getIsResting()
    {
        return this.isResting;
    }

    public void setIsResting(boolean var1)
    {
        this.isResting = var1;
    }

    public void readEntityFromNBT(NBTTagCompound var1)
    {
        super.readEntityFromNBT(var1);
        this.setEdad(var1.getFloat("Edad"));
        this.setAdult(var1.getBoolean("Adult"));
    }

    public void writeEntityToNBT(NBTTagCompound var1)
    {
        super.writeEntityToNBT(var1);
        var1.setFloat("Edad", this.getEdad());
        var1.setBoolean("Adult", this.getIsAdult());
    }

    protected String getDeathSound()
    {
        return "crocdying";
    }

    protected String getHurtSound()
    {
        return "crochurt";
    }

    protected String getLivingSound()
    {
        return this.getIsResting() ? "crocresting" : "crocgrunt";
    }

    protected int getDropItemId()
    {
        return mod_mocreatures.crochide.shiftedIndex;
    }

    public boolean isSpinning()
    {
        return this.caughtPrey && this.riddenByEntity != null && this.isInsideOfMaterial(Material.water);
    }

    public void onDeath(DamageSource var1)
    {
        this.unMount();
        MoCTools.checkForTwistedEntities(this);
        super.onDeath(var1);
    }

    public void unMount()
    {
        if (this.riddenByEntity != null)
        {
            if (this.riddenByEntity instanceof EntityLiving && ((EntityLiving)this.riddenByEntity).health > 0)
            {
                ((EntityLiving)this.riddenByEntity).deathTime = 0;
            }

            this.riddenByEntity.mountEntity((Entity)null);
            this.caughtPrey = false;
        }
    }

    public int getMaxSpawnedInChunk()
    {
        return 6;
    }

    public int getTalkInterval()
    {
        return 120;
    }

    public boolean getCanSpawnHere()
    {
        return MoCTools.isNearTorch(this) ? false : ((Integer)mod_mocreatures.crocfreq.get()).intValue() > 0 && super.getCanSpawnHere();
    }
}
