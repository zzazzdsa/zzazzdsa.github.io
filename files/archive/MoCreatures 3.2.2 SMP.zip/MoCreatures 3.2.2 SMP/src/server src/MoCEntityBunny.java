package net.minecraft.src;

import java.util.List;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityMob;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.MoCEntityAnimal;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityBunny extends MoCEntityAnimal
{
    public boolean preventEntitySpawning;
    public int breedingCounter;
    public int breedCheckTicker;
    public int bunnyLimit = 12;
    public boolean textureSet;

    public MoCEntityBunny(World var1)
    {
        super(var1);
        this.setAdult(true);
        this.setTamed(false);
        this.setEdad(0.5F);
        this.moveSpeed = 1.5F;
        this.texture = "/mocreatures/bunny.png";
        this.yOffset = -0.16F;
        this.setSize(0.4F, 0.4F);
        this.health = 4;
        this.breedingCounter = this.rand.nextInt(64);
        this.breedCheckTicker = 0;
        this.textureSet = false;
        this.field_9100_aZ = true;
    }

    protected boolean canDespawn()
    {
        return !this.getIsTamed();
    }

    public void chooseType()
    {
        if (this.getType() == 0)
        {
            int var1 = this.rand.nextInt(100);
            if (var1 <= 25)
            {
                this.setType(1);
            }
            else if (var1 <= 50)
            {
                this.setType(2);
            }
            else if (var1 <= 75)
            {
                this.setType(3);
            }
            else
            {
                this.setType(4);
            }
        }

        if (!this.getTypeChosen())
        {
            if (this.getType() == 1)
            {
                this.texture = "/mocreatures/bunny.png";
            }
            else if (this.getType() == 2)
            {
                this.texture = "/mocreatures/bunnyb.png";
            }
            else if (this.getType() == 3)
            {
                this.texture = "/mocreatures/bunnyc.png";
            }
            else if (this.getType() == 4)
            {
                this.texture = "/mocreatures/bunnyd.png";
            }
        }

        this.setTypeChosen(true);
    }

    protected void fall(float var1) {}

    public boolean getCanSpawnHere()
    {
        return ((Integer)mod_mocreatures.bunnyfreq.get()).intValue() > 0 && super.getCanSpawnHere();
    }

    protected String getDeathSound()
    {
        return "rabbitdeath";
    }

    /*
    public String getEntityTexture()
    {
        if (!this.getTypeChosen() && !mod_mocreatures.mc.isMultiplayerWorld())
        {
            this.chooseType();
        }

        if (mod_mocreatures.mc.isMultiplayerWorld() && !this.textureSet && this.getTexture() != null && !this.getTexture().equals(""))
        {
            this.texture = this.getTexture();
            this.textureSet = true;
        }

        return super.getEntityTexture();
    }
    */

    protected String getHurtSound()
    {
        return "rabbithurt";
    }

    protected String getLivingSound()
    {
        return null;
    }

    public double getYOffset()
    {
        return (this.ridingEntity instanceof EntityPlayer) && !this.worldObj.isRemote ? (double)(this.yOffset - 1.15F) : (double)this.yOffset;
    }

    public boolean interact(EntityPlayer var1)
    {
        this.rotationYaw = var1.rotationYaw;
        if (!this.worldObj.isRemote)
        {
            this.mountEntity(var1);
        }

        if (this.ridingEntity == null)
        {
            this.preventEntitySpawning = true;
        }
        else
        {
            this.worldObj.playSoundAtEntity(this, "rabbitlift", 1.0F, (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F);
        }

        this.motionX = var1.motionX * 5.0D;
        this.motionY = var1.motionY / 2.0D + 0.5D;
        this.motionZ = var1.motionZ * 5.0D;
        this.setTamed(true);
        return true;
    }

    public void knockBack(Entity var1, int var2, double var3, double var5)
    {
        super.knockBack(var1, var2, var3, var5);
    }

    public void onLivingUpdate()
    {
        if (!this.getIsAdult() && this.rand.nextInt(200) == 0)
        {
            this.setEdad(this.getEdad() + 0.01F);
            if (this.getEdad() >= 1.0F)
            {
                this.setAdult(true);
            }
        }

        super.onLivingUpdate();
    }

    public void onUpdate()
    {
        super.onUpdate();
        if (!this.worldObj.isRemote)
        {
            if (!this.getIsTamed() || !this.getIsAdult() || this.ridingEntity != null || this.worldObj.countEntities(this.getClass()) > this.bunnyLimit)
            {
                return;
            }

            if (this.breedingCounter < 1023)
            {
                ++this.breedingCounter;
            }
            else if (this.breedCheckTicker < 127)
            {
                ++this.breedCheckTicker;
            }
            else
            {
                List var1 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(4.0D, 4.0D, 4.0D));
                boolean var2 = false;

                for (int var3 = 0; var3 < var1.size(); ++var3)
                {
                    Entity var4 = (Entity)var1.get(var3);
                    if (var4 instanceof MoCEntityBunny && var4 != this)
                    {
                        MoCEntityBunny var5 = (MoCEntityBunny)var4;
                        if (var5.ridingEntity == null && var5.breedingCounter >= 1023 && var5.getIsAdult())
                        {
                            MoCEntityBunny var6 = new MoCEntityBunny(this.worldObj);
                            var6.setPosition(this.posX, this.posY, this.posZ);
                            var6.setAdult(false);
                            this.worldObj.spawnEntityInWorld(var6);
                            this.worldObj.playSoundAtEntity(this, "mob.chickenplop", 1.0F, (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F);
                            this.proceed();
                            var5.proceed();
                            var2 = true;
                            break;
                        }
                    }
                }
            }
        }
    }

    public void proceed()
    {
        this.breedCheckTicker = 0;
        this.breedingCounter = this.rand.nextInt(64);
    }

    public void setEntityDead()
    {
        super.setEntityDead();
    }

    public void setTypeInt(int var1)
    {
        this.setType(var1);
        this.setTypeChosen(false);
        this.chooseType();
    }

    protected void updateEntityActionState()
    {
        if (this.onGround && (this.motionX > 0.05D || this.motionZ > 0.05D || this.motionX < -0.05D || this.motionZ < -0.05D))
        {
            this.motionY = 0.45D;
        }

        if (!this.preventEntitySpawning)
        {
            super.updateEntityActionState();
        }
        else if (this.onGround)
        {
            this.preventEntitySpawning = false;
            this.worldObj.playSoundAtEntity(this, "rabbitland", 1.0F, (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F);
            List var1 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(12.0D, 12.0D, 12.0D));

            for (int var2 = 0; var2 < var1.size(); ++var2)
            {
                Entity var3 = (Entity)var1.get(var2);
                if (var3 instanceof EntityMob)
                {
                    EntityMob var4 = (EntityMob)var3;
                    var4.entityToAttack = this;
                }
            }
        }
    }

    public void readEntityFromNBT(NBTTagCompound var1)
    {
        super.readEntityFromNBT(var1);
        this.setType(var1.getInteger("TypeInt"));
        this.setEdad(var1.getFloat("Edad"));
        this.setTamed(var1.getBoolean("Tamed"));
        this.setAdult(var1.getBoolean("Adult"));
    }

    public void writeEntityToNBT(NBTTagCompound var1)
    {
        super.writeEntityToNBT(var1);
        var1.setInteger("TypeInt", this.getType());
        var1.setBoolean("Tamed", this.getIsTamed());
        var1.setFloat("Edad", this.getEdad());
        var1.setBoolean("Adult", this.getIsAdult());
    }
}
