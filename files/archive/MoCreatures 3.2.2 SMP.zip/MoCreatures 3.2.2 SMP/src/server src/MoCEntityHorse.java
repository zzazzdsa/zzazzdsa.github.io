package net.minecraft.src;

import java.util.List;
import net.minecraft.src.Block;
import net.minecraft.src.DamageSource;
import net.minecraft.src.Entity;
import net.minecraft.src.EntityCreature;
import net.minecraft.src.EntityItem;
import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.EntityWolf;
import net.minecraft.src.IInventory;
import net.minecraft.src.Item;
import net.minecraft.src.ItemStack;
import net.minecraft.src.MathHelper;
import net.minecraft.src.MoCAnimalChest;
import net.minecraft.src.MoCEntityAnimal;
import net.minecraft.src.NBTTagCompound;
import net.minecraft.src.NBTTagList;
import net.minecraft.src.StepSound;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntityHorse extends MoCEntityAnimal
{
    private int nextStepDistance;
    private boolean textureSet;
    private int gestationtime;
    private int temper;
    private double HorseSpeed;
    private double HorseJump;
    private IInventory localhorsechest;
    public boolean eatenpumpkin;
    private boolean chested;
    private boolean wasBred;
    private boolean hasReproduced;
    private int nightmareInt;
    private boolean isRidable;
    private boolean isjumping;
    public float fwingb;
    public float fwingc;
    public float fwingd;
    public float fwinge;
    public float fwingh;
    public ItemStack[] localstack;
    public boolean eatinghaystack;
    public EntityLiving roper;

    public MoCEntityHorse(World var1)
    {
        super(var1);
        this.setSize(1.4F, 1.6F);
        this.health = 20;
        this.isjumping = false;
        this.texture = "/mocreatures/horseb.png";
        this.HorseSpeed = 0.8D;
        this.HorseJump = 0.4D;
        this.fwingb = 0.0F;
        this.fwingc = 0.0F;
        this.fwingh = 1.0F;
        this.localstack = new ItemStack[27];
        this.gestationtime = 0;
        this.eatenpumpkin = false;
        this.nightmareInt = 0;
        this.isImmuneToFire = false;
        this.setEdad(0.35F);
        this.roper = null;
        this.textureSet = false;
        this.field_9100_aZ = true;
        if (!this.worldObj.isRemote)
        {
            this.setTemper(100);
            this.setAdult(true);
            this.setMaxHealth(20);
        }
    }

    public boolean attackEntityFrom(DamageSource var1, int var2)
    {
        Entity var3 = var1.getEntity();
        if (this.riddenByEntity != null && var3 == this.riddenByEntity)
        {
            return false;
        }
        else if (var3 instanceof EntityWolf)
        {
            EntityCreature var4 = (EntityCreature)var3;
            var4.entityToAttack = null;
            return false;
        }
        else
        {
            return super.attackEntityFrom(var1, var2);
        }
    }

    public boolean canBeCollidedWith()
    {
        return this.riddenByEntity == null;
    }

    public void chooseType()
    {
        boolean var1 = false;
        if (this.getType() == 0)
        {
            var1 = true;
            if (this.rand.nextInt(5) == 0)
            {
                this.setAdult(false);
            }

            int var2 = this.rand.nextInt(100);
            int var3 = ((Integer)mod_mocreatures.pegasusChanceS.get()).intValue();
            if (var2 <= 51 - var3)
            {
                this.setType(1);
            }
            else if (var2 <= 86 - var3)
            {
                this.setType(2);
            }
            else if (var2 <= 95 - var3)
            {
                this.setType(3);
            }
            else if (var2 <= 99 - var3)
            {
                this.setType(4);
            }
            else
            {
                this.setType(5);
            }
        }

        if (!this.getTypeChosen())
        {
            if (this.getType() == 1)
            {
                this.HorseSpeed = 0.9D;
                this.texture = "/mocreatures/horseb.png";
                this.setMaxHealth(25);
            }
            else if (this.getType() == 2)
            {
                this.HorseSpeed = 1.0D;
                this.setTemper(200);
                this.HorseJump = 0.5D;
                this.texture = "/mocreatures/horsebrownb.png";
                this.setMaxHealth(30);
            }
            else if (this.getType() == 3)
            {
                this.HorseSpeed = 1.1D;
                this.setTemper(300);
                this.HorseJump = 0.6D;
                this.texture = "/mocreatures/horseblackb.png";
                this.setMaxHealth(35);
            }
            else if (this.getType() == 4)
            {
                this.HorseSpeed = 1.3D;
                this.HorseJump = 0.6D;
                this.setTemper(400);
                this.texture = "/mocreatures/horsegoldb.png";
                this.setMaxHealth(40);
            }
            else if (this.getType() == 5)
            {
                this.HorseSpeed = 1.2D;
                this.setTemper(500);
                this.texture = "/mocreatures/horsewhiteb.png";
                this.setMaxHealth(40);
            }
            else if (this.getType() == 6)
            {
                this.HorseSpeed = 0.9D;
                this.setTemper(600);
                this.texture = "/mocreatures/horsepackb.png";
                this.setMaxHealth(40);
            }
            else if (this.getType() == 7)
            {
                this.HorseSpeed = 1.3D;
                this.setTemper(700);
                this.HorseJump = 0.6D;
                this.texture = "/mocreatures/horsenightb.png";
                this.setMaxHealth(50);
                this.isImmuneToFire = true;
            }
            else if (this.getType() == 8)
            {
                this.HorseSpeed = 1.3D;
                this.setTemper(800);
                this.texture = "/mocreatures/horsebpb.png";
                this.setMaxHealth(50);
                this.isImmuneToFire = true;
            }
        }

        if (var1)
        {
            var1 = false;
            this.health = this.getMaxHealth();
        }

        this.setTypeChosen(true);
    }

    protected void fall(float var1)
    {
        int var2 = (int)Math.ceil((double)(var1 - 3.0F));
        if (var2 > 0 && this.getType() != 5 && this.getType() != 8)
        {
            if (this.getType() >= 3)
            {
                var2 /= 3;
            }

            if (var2 > 0)
            {
                this.attackEntityFrom(DamageSource.fall, var2);
            }

            if (this.riddenByEntity != null && var2 > 0)
            {
                this.riddenByEntity.attackEntityFrom(DamageSource.fall, var2);
            }

            if (this.getType() == 5 || this.getType() == 8)
            {
                return;
            }

            int var3 = this.worldObj.getBlockId(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.posY - 0.2000000029802322D - (double)this.prevRotationPitch), MathHelper.floor_double(this.posZ));
            if (var3 > 0)
            {
                StepSound var4 = Block.blocksList[var3].stepSound;
                this.worldObj.playSoundAtEntity(this, var4.getStepSound(), var4.getVolume() * 0.5F, var4.getPitch() * 0.75F);
            }
        }
    }

    public boolean getCanSpawnHere()
    {
        return ((Integer)mod_mocreatures.horsefreq.get()).intValue() > 0 && super.getCanSpawnHere();
    }

    public boolean getChestedHorse()
    {
        return this.chested;
    }

    protected String getDeathSound()
    {
        return "horsedying";
    }

    protected int getDropItemId()
    {
        return Item.leather.shiftedIndex;
    }

    /*
    public String getEntityTexture()
    {
        if (!this.getTypeChosen() && !this.worldObj.isRemote)
        {
            this.chooseType();
        }

        if (this.worldObj.isRemote && !this.textureSet)
        {
            if (this.getTexture() == null || this.getTexture().equals(""))
            {
                return super.getEntityTexture();
            }

            this.texture = this.getTexture();
            this.textureSet = true;
            if (this.getType() == 1)
            {
                this.HorseSpeed = 0.9D;
            }
            else if (this.getType() == 2)
            {
                this.HorseSpeed = 1.0D;
                this.HorseJump = 0.5D;
            }
            else if (this.getType() == 3)
            {
                this.HorseSpeed = 1.1D;
                this.HorseJump = 0.6D;
            }
            else if (this.getType() == 4)
            {
                this.HorseSpeed = 1.3D;
                this.HorseJump = 0.6D;
            }
            else if (this.getType() == 5)
            {
                this.HorseSpeed = 1.2D;
            }
            else if (this.getType() == 6)
            {
                this.HorseSpeed = 0.9D;
            }
            else if (this.getType() == 7)
            {
                this.HorseSpeed = 1.3D;
                this.HorseJump = 0.6D;
                this.isImmuneToFire = true;
            }
            else if (this.getType() == 8)
            {
                this.HorseSpeed = 1.3D;
                this.isImmuneToFire = true;
            }

            this.temper = this.getTemper();
        }

        return super.getEntityTexture();
    }
    */

    public boolean getHasBred()
    {
        return this.wasBred;
    }

    public boolean getHasReproduced()
    {
        return this.hasReproduced;
    }

    protected String getHurtSound()
    {
        return "horsehurt";
    }

    public boolean getIsHorseJumping()
    {
        return this.isjumping;
    }

    public boolean getIsRideable()
    {
        return this.isRidable;
    }

    public boolean getIsRoped()
    {
        return this.roper != null;
    }

    protected String getLivingSound()
    {
        return "horsegrunt";
    }

    public int getMaxSpawnedInChunk()
    {
        return 6;
    }

    public int getNightmareInt()
    {
        return this.nightmareInt;
    }

    protected float getSoundVolume()
    {
        return 0.4F;
    }

    public int getTemper()
    {
        return this.temper;
    }

    private int HorseGenetics(MoCEntityHorse var1, MoCEntityHorse var2)
    {
        if (var1.getType() == var2.getType())
        {
            return var1.getType();
        }
        else
        {
            int var3 = var1.getType() + var2.getType();
            boolean var4 = ((Boolean)mod_mocreatures.easybreeding.get()).booleanValue();
            boolean var5 = this.rand.nextInt(3) == 0;
            return var3 == 7 && (var4 || var5) ? 6 : (var3 == 9 && (var4 || var5) ? 7 : (var3 == 10 && (var4 || var5) ? 5 : (var3 == 12 && (var4 || var5) ? 8 : 0)));
        }
    }

    public void HorseRemoval(World var1, int var2, int var3, int var4)
    {
        if (this.localstack != null)
        {
            this.localhorsechest = new MoCAnimalChest(this.localstack, "HorseChest");

            for (int var5 = 0; var5 < this.localhorsechest.getSizeInventory(); ++var5)
            {
                ItemStack var6 = this.localhorsechest.getStackInSlot(var5);
                if (var6 != null)
                {
                    float var7 = this.rand.nextFloat() * 0.8F + 0.1F;
                    float var8 = this.rand.nextFloat() * 0.8F + 0.1F;
                    float var9 = this.rand.nextFloat() * 0.8F + 0.1F;

                    while (var6.stackSize > 0)
                    {
                        int var10 = this.rand.nextInt(21) + 10;
                        if (var10 > var6.stackSize)
                        {
                            var10 = var6.stackSize;
                        }

                        var6.stackSize -= var10;
                        EntityItem var11 = new EntityItem(this.worldObj, (double)((float)var2 + var7), (double)((float)var3 + var8), (double)((float)var4 + var9), new ItemStack(var6.itemID, var10, var6.getItemDamage()));
                        float var12 = 0.05F;
                        var11.motionX = (double)((float)this.rand.nextGaussian() * var12);
                        var11.motionY = (double)((float)this.rand.nextGaussian() * var12 + 0.2F);
                        var11.motionZ = (double)((float)this.rand.nextGaussian() * var12);
                        this.worldObj.spawnEntityInWorld(var11);
                    }
                }
            }
        }
    }

    public boolean interact(EntityPlayer var1)
    {
        ItemStack var2 = var1.inventory.getCurrentItem();
        if (var2 != null && var2.itemID == Item.wheat.shiftedIndex)
        {
            if (--var2.stackSize == 0)
            {
                var1.inventory.setInventorySlotContents(var1.inventory.currentItem, (ItemStack)null);
            }

            if (!this.worldObj.isRemote)
            {
                this.setTemper(this.getTemper() - 25);
                if (this.getTemper() < 25)
                {
                    this.setTemper(25);
                }
            }

            if ((this.health += 5) > this.getMaxHealth())
            {
                this.health = this.getMaxHealth();
            }

            this.worldObj.playSoundAtEntity(this, "eating", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
            if (!this.getIsAdult() && this.getEdad() < 1.0F)
            {
                this.setEdad(this.getEdad() + 0.01F);
            }

            return true;
        }
        else if (var2 != null && var2.itemID == mod_mocreatures.sugarlump.shiftedIndex)
        {
            if (--var2.stackSize == 0)
            {
                var1.inventory.setInventorySlotContents(var1.inventory.currentItem, (ItemStack)null);
            }

            if (!this.worldObj.isRemote)
            {
                this.setTemper(this.getTemper() - 50);
                if (this.getTemper() < 25)
                {
                    this.setTemper(25);
                }
            }

            if ((this.health += 10) > this.getMaxHealth())
            {
                this.health = this.getMaxHealth();
            }

            this.worldObj.playSoundAtEntity(this, "eating", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
            if (!this.getIsAdult() && this.getEdad() < 1.0F)
            {
                this.setEdad(this.getEdad() + 0.02F);
            }

            return true;
        }
        else if (var2 != null && var2.itemID == Item.bread.shiftedIndex)
        {
            if (--var2.stackSize == 0)
            {
                var1.inventory.setInventorySlotContents(var1.inventory.currentItem, (ItemStack)null);
            }

            if (!this.worldObj.isRemote)
            {
                this.setTemper(this.getTemper() - 100);
                if (this.getTemper() < 25)
                {
                    this.setTemper(25);
                }
            }

            if ((this.health += 20) > this.getMaxHealth())
            {
                this.health = this.getMaxHealth();
            }

            this.worldObj.playSoundAtEntity(this, "eating", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
            if (!this.getIsAdult() && this.getEdad() < 1.0F)
            {
                this.setEdad(this.getEdad() + 0.03F);
            }

            return true;
        }
        else if (var2 != null && (var2.itemID == Item.appleRed.shiftedIndex || var2.itemID == Item.appleGold.shiftedIndex))
        {
            if (--var2.stackSize == 0)
            {
                var1.inventory.setInventorySlotContents(var1.inventory.currentItem, (ItemStack)null);
            }

            this.setTamed(true);
            this.health = this.getMaxHealth();
            this.worldObj.playSoundAtEntity(this, "eating", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
            if (!this.getIsAdult() && this.getEdad() < 1.0F)
            {
                this.setEdad(this.getEdad() + 0.05F);
            }

            //mod_mocreatures.setName((MoCEntityAnimal)this);
            return true;
        }
        else if (var2 != null && this.getIsTamed() && var2.itemID == Block.chest.blockID && (this.getType() == 6 || this.getType() == 8))
        {
            if (this.getChestedHorse())
            {
                return false;
            }
            else
            {
                if (--var2.stackSize == 0)
                {
                    var1.inventory.setInventorySlotContents(var1.inventory.currentItem, (ItemStack)null);
                }

                this.setChestedHorse(true);
                this.worldObj.playSoundAtEntity(this, "mob.chickenplop", 1.0F, (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F);
                return true;
            }
        }
        else if (var2 != null && this.getIsTamed() && var2.itemID == mod_mocreatures.haystack.shiftedIndex)
        {
            if (--var2.stackSize == 0)
            {
                var1.inventory.setInventorySlotContents(var1.inventory.currentItem, (ItemStack)null);
            }

            this.eatinghaystack = true;
            this.worldObj.playSoundAtEntity(this, "eating", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
            this.health = this.getMaxHealth();
            return true;
        }
        else if (var2 != null && (var2.itemID == Item.shovelStone.shiftedIndex || var2.itemID == Block.torchWood.blockID) && this.getChestedHorse())
        {
            this.localhorsechest = new MoCAnimalChest(this.localstack, "HorseChest");
            var1.displayGUIChest(this.localhorsechest);
            return true;
        }
        else if (var2 != null && (var2.itemID == Block.pumpkin.blockID || var2.itemID == Item.bowlSoup.shiftedIndex || var2.itemID == Item.cake.shiftedIndex))
        {
            if (!this.getHasReproduced() && this.getIsAdult())
            {
                if (var2.itemID == Item.bowlSoup.shiftedIndex)
                {
                    if (--var2.stackSize == 0)
                    {
                        var1.inventory.setInventorySlotContents(var1.inventory.currentItem, new ItemStack(Item.bowlEmpty));
                    }
                    else
                    {
                        var1.inventory.addItemStackToInventory(new ItemStack(Item.bowlEmpty));
                    }
                }
                else if (--var2.stackSize == 0)
                {
                    var1.inventory.setInventorySlotContents(var1.inventory.currentItem, (ItemStack)null);
                }

                this.eatenpumpkin = true;
                this.health = this.getMaxHealth();
                this.worldObj.playSoundAtEntity(this, "eating", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
                return true;
            }
            else
            {
                return false;
            }
        }
        else if (var2 != null && this.getIsTamed() && var2.itemID == Item.redstone.shiftedIndex && this.getType() == 7)
        {
            if (this.getNightmareInt() > 500)
            {
                return false;
            }
            else
            {
                if (--var2.stackSize == 0)
                {
                    var1.inventory.setInventorySlotContents(var1.inventory.currentItem, (ItemStack)null);
                }

                this.setNightmareInt(500);
                this.worldObj.playSoundAtEntity(this, "eating", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
                return true;
            }
        }
        else if (var2 != null && var2.itemID == mod_mocreatures.whip.shiftedIndex && this.getIsTamed() && this.riddenByEntity == null)
        {
            this.eatinghaystack = !this.eatinghaystack;
            return true;
        }
        else if (var2 != null && this.riddenByEntity == null && this.roper == null && this.getIsTamed() && var2.itemID == mod_mocreatures.rope.shiftedIndex)
        {
            if (--var2.stackSize == 0)
            {
                var1.inventory.setInventorySlotContents(var1.inventory.currentItem, (ItemStack)null);
            }

            this.worldObj.playSoundAtEntity(this, "roping", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
            this.roper = var1;
            return true;
        }
        else if (this.roper != null && this.getIsTamed())
        {
            var1.inventory.addItemStackToInventory(new ItemStack(mod_mocreatures.rope));
            this.worldObj.playSoundAtEntity(this, "roping", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
            this.roper = null;
            return true;
        }
        else if (var2 != null && this.getIsTamed() && (var2.itemID == mod_mocreatures.medallion.shiftedIndex || var2.itemID == Item.book.shiftedIndex))
        {
            //mod_mocreatures.setName((MoCEntityAnimal)this);
            return true;
        }
        else if (var2 != null && this.getIsTamed() && (var2.itemID == Item.pickaxeDiamond.shiftedIndex || var2.itemID == Item.pickaxeWood.shiftedIndex || var2.itemID == Item.pickaxeStone.shiftedIndex || var2.itemID == Item.pickaxeSteel.shiftedIndex || var2.itemID == Item.pickaxeGold.shiftedIndex))
        {
            this.setDisplayName(!this.getDisplayName());
            return true;
        }
        else if (this.getIsRideable() && this.getIsAdult() && this.riddenByEntity == null)
        {
            var1.rotationYaw = this.rotationYaw;
            var1.rotationPitch = this.rotationPitch;
            this.eatinghaystack = false;
            if (!this.worldObj.isRemote)
            {
                var1.mountEntity(this);
            }

            this.gestationtime = 0;
            return true;
        }
        else
        {
            return false;
        }
    }

    protected boolean isMovementCeased()
    {
        return this.eatinghaystack || this.riddenByEntity != null;
    }

    public void moveEntityWithHeading(float var1, float var2)
    {
        EntityPlayer var3;
        double var8;
        if (this.handleWaterMovement())
        {
            if (this.riddenByEntity != null)
            {
                this.motionX += this.riddenByEntity.motionX * (this.HorseSpeed / 2.0D);
                this.motionZ += this.riddenByEntity.motionZ * (this.HorseSpeed / 2.0D);
                var3 = (EntityPlayer)this.riddenByEntity;
                if (var3.isJumping && !this.getIsHorseJumping())
                {
                    this.motionY += 0.5D;
                    this.setHorseJumping(true);
                }

                if (!this.worldObj.isRemote)
                {
                    this.moveEntity(this.motionX, this.motionY, this.motionZ);
                }

                if (this.onGround)
                {
                    this.setHorseJumping(false);
                }

                this.rotationPitch = this.riddenByEntity.rotationPitch * 0.5F;
                if (this.rand.nextInt(20) == 0)
                {
                    this.rotationYaw = this.riddenByEntity.rotationYaw;
                }

                this.setRotation(this.rotationYaw, this.rotationPitch);
                if (!this.getIsTamed())
                {
                    this.riddenByEntity = null;
                }
            }

            var8 = this.posY;
            if (!this.worldObj.isRemote)
            {
                this.moveFlying(var1, var2, 0.02F);
                this.moveEntity(this.motionX, this.motionY, this.motionZ);
            }

            this.motionX *= 0.800000011920929D;
            this.motionY *= 0.800000011920929D;
            this.motionZ *= 0.800000011920929D;
            this.motionY -= 0.02D;
            if (this.isCollidedHorizontally && this.isOffsetPositionInLiquid(this.motionX, this.motionY + 0.6000000238418579D - this.posY + var8, this.motionZ))
            {
                this.motionY = 0.300000011920929D;
            }
        }
        else if (this.handleLavaMovement())
        {
            if (this.riddenByEntity != null)
            {
                this.motionX += this.riddenByEntity.motionX * (this.HorseSpeed / 2.0D);
                this.motionZ += this.riddenByEntity.motionZ * (this.HorseSpeed / 2.0D);
                var3 = (EntityPlayer)this.riddenByEntity;
                if (var3.isJumping && !this.getIsHorseJumping())
                {
                    this.motionY += 0.5D;
                    this.setHorseJumping(true);
                }

                if (!this.worldObj.isRemote)
                {
                    this.moveEntity(this.motionX, this.motionY, this.motionZ);
                }

                if (this.onGround)
                {
                    this.setHorseJumping(false);
                }

                this.rotationPitch = this.riddenByEntity.rotationPitch * 0.5F;
                if (this.rand.nextInt(20) == 0)
                {
                    this.rotationYaw = this.riddenByEntity.rotationYaw;
                }

                this.setRotation(this.rotationYaw, this.rotationPitch);
                if (!this.getIsTamed())
                {
                    this.riddenByEntity = null;
                }
            }

            var8 = this.posY;
            if (!this.worldObj.isRemote)
            {
                this.moveFlying(var1, var2, 0.02F);
                this.moveEntity(this.motionX, this.motionY, this.motionZ);
            }

            this.motionX *= 0.5D;
            this.motionY *= 0.5D;
            this.motionZ *= 0.5D;
            this.motionY -= 0.02D;
            if (this.isCollidedHorizontally && this.isOffsetPositionInLiquid(this.motionX, this.motionY + 0.6000000238418579D - this.posY + var8, this.motionZ))
            {
                this.motionY = 0.300000011920929D;
            }
        }
        else
        {
            float var9 = 0.91F;
            if (this.onGround)
            {
                var9 = 0.5460001F;
                int var4 = this.worldObj.getBlockId(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.boundingBox.minY) - 1, MathHelper.floor_double(this.posZ));
                if (var4 > 0)
                {
                    var9 = Block.blocksList[var4].slipperiness * 0.91F;
                }
            }

            float var10 = 0.162771F / (var9 * var9 * var9);
            if (!this.worldObj.isRemote)
            {
                this.moveFlying(var1, var2, this.onGround ? 0.1F * var10 : 0.02F);
            }

            var9 = 0.91F;
            if (this.onGround)
            {
                var9 = 0.5460001F;
                int var5 = this.worldObj.getBlockId(MathHelper.floor_double(this.posX), MathHelper.floor_double(this.boundingBox.minY) - 1, MathHelper.floor_double(this.posZ));
                if (var5 > 0)
                {
                    var9 = Block.blocksList[var5].slipperiness * 0.91F;
                }
            }

            if (this.isOnLadder())
            {
                this.fallDistance = 0.0F;
                if (this.motionY < -0.15D)
                {
                    this.motionY = -0.15D;
                }
            }

            if (this.riddenByEntity != null && !this.getIsTamed())
            {
                if (!this.worldObj.isRemote)
                {
                    if (this.rand.nextInt(5) == 0 && !this.getIsHorseJumping())
                    {
                        this.motionY += 0.4D;
                        this.setHorseJumping(true);
                    }

                    if (this.rand.nextInt(10) == 0)
                    {
                        this.motionX += this.rand.nextDouble() / 30.0D;
                        this.motionZ += this.rand.nextDouble() / 10.0D;
                    }

                    this.moveEntity(this.motionX, this.motionY, this.motionZ);
                    if (this.rand.nextInt(50) == 0)
                    {
                        this.worldObj.playSoundAtEntity(this, "horsemad", 1.0F, 1.0F + (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F);
                        this.riddenByEntity.motionY += 0.9D;
                        this.riddenByEntity.motionZ -= 0.3D;
                        this.riddenByEntity = null;
                    }

                    if (this.onGround)
                    {
                        this.setHorseJumping(false);
                    }
                }

                if (this.rand.nextInt(this.getTemper() * 8) == 0)
                {
                    this.setTamed(true);
                    // mod_mocreatures.setName((MoCEntityAnimal)this);
                }
            }

            if (this.riddenByEntity != null && this.getIsTamed())
            {
                this.boundingBox.maxY = this.riddenByEntity.boundingBox.maxY;
                this.motionX += this.riddenByEntity.motionX * this.HorseSpeed;
                this.motionZ += this.riddenByEntity.motionZ * this.HorseSpeed;
                EntityPlayer var11 = (EntityPlayer)this.riddenByEntity;
                if (var11.isJumping && !this.getIsHorseJumping())
                {
                    this.motionY += this.HorseJump;
                    this.setHorseJumping(true);
                }

                if (var11.isJumping && (this.getType() == 5 || this.getType() == 8))
                {
                    this.motionY += 0.1D;
                }

                if (!this.worldObj.isRemote)
                {
                    this.moveEntity(this.motionX, this.motionY, this.motionZ);
                }

                if (this.onGround)
                {
                    this.setHorseJumping(false);
                }

                this.prevRotationYaw = this.rotationYaw = this.riddenByEntity.rotationYaw;
                this.rotationPitch = this.riddenByEntity.rotationPitch * 0.5F;
                this.setRotation(this.rotationYaw, this.rotationPitch);
            }

            if (!this.worldObj.isRemote)
            {
                this.moveEntity(this.motionX, this.motionY, this.motionZ);
            }

            if (this.isCollidedHorizontally && this.isOnLadder())
            {
                this.motionY = 0.2D;
            }

            if ((this.getType() == 5 || this.getType() == 8) && this.riddenByEntity != null && this.getIsTamed())
            {
                this.motionY -= 0.08D;
                this.motionY *= 0.6D;
            }
            else
            {
                this.motionY -= 0.08D;
                this.motionY *= 0.9800000190734863D;
            }

            this.motionX *= (double)var9;
            this.motionZ *= (double)var9;
        }

        this.field_9142_bc = this.field_9141_bd;
        var8 = this.posX - this.prevPosX;
        double var12 = this.posZ - this.prevPosZ;
        float var7 = MathHelper.sqrt_double(var8 * var8 + var12 * var12) * 4.0F;
        if (var7 > 1.0F)
        {
            var7 = 1.0F;
        }

        this.field_9141_bd += (var7 - this.field_9141_bd) * 0.4F;
        this.field_386_ba += this.field_9141_bd;
    }

    public void NightmareEffect()
    {
        int var1 = MathHelper.floor_double(this.posX);
        int var2 = MathHelper.floor_double(this.boundingBox.minY);
        int var3 = MathHelper.floor_double(this.posZ);
        this.worldObj.setBlockWithNotify(var1 - 1, var2, var3 - 1, Block.fire.blockID);
        EntityPlayer var4 = (EntityPlayer)this.riddenByEntity;
        if (var4 != null && var4.isBurning())
        {
            var4.extinguish();
        }

        this.setNightmareInt(this.getNightmareInt() - 1);
    }

    public void onDeath(DamageSource var1)
    {
        super.onDeath(var1);
        if (this.getChestedHorse() && !this.worldObj.isRemote && (this.getType() == 6 || this.getType() == 8))
        {
            int var2 = MathHelper.floor_double(this.posX);
            int var3 = MathHelper.floor_double(this.boundingBox.minY);
            int var4 = MathHelper.floor_double(this.posZ);
            this.HorseRemoval(this.worldObj, var2, var3, var4);
        }
    }

    public void onLivingUpdate()
    {
        if (this.rand.nextInt(300) == 0 && this.health <= this.getMaxHealth() && this.deathTime == 0 && !this.worldObj.isRemote)
        {
            ++this.health;
        }

        if (!this.worldObj.isRemote)
        {
            this.Riding();
        }

        if (this.getType() == 5 || this.getType() == 8)
        {
            this.fwinge = this.fwingb;
            this.fwingd = this.fwingc;
            this.fwingc = (float)((double)this.fwingc + (double)(this.onGround ? -1 : 4) * 0.3D);
            if (this.fwingc < 0.0F)
            {
                this.fwingc = 0.0F;
            }

            if (this.fwingc > 1.0F)
            {
                this.fwingc = 1.0F;
            }

            if (!this.onGround && this.fwingh < 1.0F)
            {
                this.fwingh = 0.3F;
            }

            this.fwingh = (float)((double)this.fwingh * 0.9D);
            if (!this.onGround && this.motionY < 0.0D)
            {
                this.motionY *= 0.6D;
            }

            this.fwingb += this.fwingh * 2.0F;
        }

        super.onLivingUpdate();
        if (!this.worldObj.isRemote)
        {
            if (this.getType() == 7 && this.riddenByEntity != null && this.getNightmareInt() > 0 && this.rand.nextInt(2) == 0)
            {
                this.NightmareEffect();
            }

            if (!this.getIsAdult() && this.rand.nextInt(200) == 0)
            {
                this.setEdad(this.getEdad() + 0.01F);
                if (this.getEdad() >= 1.0F)
                {
                    this.setAdult(true);
                }
            }

            if (!this.ReadyforParenting(this))
            {
                return;
            }

            int var1 = 0;
            List var2 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(8.0D, 3.0D, 8.0D));

            for (int var3 = 0; var3 < var2.size(); ++var3)
            {
                Entity var4 = (Entity)var2.get(var3);
                if (var4 instanceof MoCEntityHorse)
                {
                    ++var1;
                }
            }

            if (var1 > 1)
            {
                return;
            }

            List var9 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(4.0D, 2.0D, 4.0D));

            for (int var10 = 0; var10 < var2.size(); ++var10)
            {
                Entity var5 = (Entity)var9.get(var10);
                if (var5 instanceof MoCEntityHorse && var5 != this)
                {
                    MoCEntityHorse var6 = (MoCEntityHorse)var5;
                    if (this.ReadyforParenting(this) && this.ReadyforParenting(var6))
                    {
                        if (this.rand.nextInt(100) == 0)
                        {
                            ++this.gestationtime;
                        }

                        if (this.gestationtime > 50)
                        {
                            MoCEntityHorse var7 = new MoCEntityHorse(this.worldObj);
                            var7.setPosition(this.posX, this.posY, this.posZ);
                            this.worldObj.spawnEntityInWorld(var7);
                            this.worldObj.playSoundAtEntity(this, "mob.chickenplop", 1.0F, (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F);
                            this.eatenpumpkin = false;
                            if (!((Boolean)mod_mocreatures.easybreeding.get()).booleanValue())
                            {
                                this.setReproduced(true);
                            }

                            var6.eatenpumpkin = false;
                            this.gestationtime = 0;
                            var6.gestationtime = 0;
                            int var8 = this.HorseGenetics(this, var6);
                            var7.setBred(true);
                            var7.setAdult(false);
                            var7.setTypeInt(var8);
                            break;
                        }
                    }
                }
            }
        }
    }

    public boolean ReadyforParenting(MoCEntityHorse var1)
    {
        return var1.riddenByEntity == null && var1.ridingEntity == null && var1.getIsTamed() && var1.eatenpumpkin && !var1.getHasReproduced() && var1.getIsAdult();
    }

    public boolean renderName()
    {
        return this.getDisplayName() && this.riddenByEntity == null;
    }

    public void setBred(boolean var1)
    {
        this.wasBred = var1;
    }

    public void setChestedHorse(boolean var1)
    {
        this.chested = var1;
    }

    public void setEntityDead()
    {
        if (!this.getIsTamed() && !this.getHasBred() || this.health <= 0)
        {
            super.setEntityDead();
        }
    }

    public void setHorseJumping(boolean var1)
    {
        this.isjumping = var1;
    }

    public void setNightmareInt(int var1)
    {
        this.nightmareInt = var1;
    }

    public void setReproduced(boolean var1)
    {
        this.hasReproduced = var1;
    }

    public void setRideable(boolean var1)
    {
        this.isRidable = var1;
    }

    public void setTemper(int var1)
    {
        this.temper = var1;
    }

    public void setTypeInt(int var1)
    {
        this.setType(var1);
        this.setTypeChosen(false);
        this.chooseType();
    }

    protected void updateEntityActionState()
    {
        if (!this.worldObj.isRemote && this.riddenByEntity == null)
        {
            super.updateEntityActionState();
        }

        if (this.getIsTamed() && this.ridingEntity == null && this.roper != null)
        {
            float var1 = this.roper.getDistanceToEntity(this);
            if (var1 > 5.0F)
            {
                this.getPathOrWalkableBlock(this.roper, var1);
            }
        }
    }

    public void readEntityFromNBT(NBTTagCompound var1)
    {
        super.readEntityFromNBT(var1);
        this.setRideable(var1.getBoolean("Saddle"));
        this.setTamed(var1.getBoolean("Tamed"));
        this.eatinghaystack = var1.getBoolean("EatingHaystack");
        this.setBred(var1.getBoolean("Bred"));
        this.setAdult(var1.getBoolean("Adult"));
        this.setChestedHorse(var1.getBoolean("ChestedHorse"));
        this.setReproduced(var1.getBoolean("HasReproduced"));
        this.setType(var1.getInteger("TypeInt"));
        this.setEdad(var1.getFloat("Edad"));
        this.setName(var1.getString("Name"));
        this.setDisplayName(var1.getBoolean("DisplayName"));
        if (this.getType() == 6 || this.getType() == 8)
        {
            NBTTagList var2 = var1.getTagList("Items");
            this.localstack = new ItemStack[27];

            for (int var3 = 0; var3 < var2.tagCount(); ++var3)
            {
                NBTTagCompound var4 = (NBTTagCompound)var2.tagAt(var3);
                int var5 = var4.getByte("Slot") & 255;
                if (var5 >= 0 && var5 < this.localstack.length)
                {
                    this.localstack[var5] = ItemStack.loadItemStackFromNBT(var4);
                }
            }
        }
    }

    public void writeEntityToNBT(NBTTagCompound var1)
    {
        super.writeEntityToNBT(var1);
        var1.setBoolean("Saddle", this.getIsRideable());
        var1.setBoolean("EatingHaystack", this.eatinghaystack);
        var1.setBoolean("Tamed", this.getIsTamed());
        var1.setInteger("TypeInt", this.getType());
        var1.setBoolean("ChestedHorse", this.getChestedHorse());
        var1.setBoolean("HasReproduced", this.getHasReproduced());
        var1.setBoolean("Bred", this.getHasBred());
        var1.setBoolean("Adult", this.getIsAdult());
        var1.setFloat("Edad", this.getEdad());
        var1.setString("Name", this.getName());
        var1.setBoolean("DisplayName", this.getDisplayName());
        if (this.getType() == 6 || this.getType() == 8)
        {
            NBTTagList var2 = new NBTTagList();

            for (int var3 = 0; var3 < this.localstack.length; ++var3)
            {
                if (this.localstack[var3] != null)
                {
                    NBTTagCompound var4 = new NBTTagCompound();
                    var4.setByte("Slot", (byte)var3);
                    this.localstack[var3].writeToNBT(var4);
                    var2.appendTag(var4);
                }
            }

            var1.setTag("Items", var2);
        }
    }
}
