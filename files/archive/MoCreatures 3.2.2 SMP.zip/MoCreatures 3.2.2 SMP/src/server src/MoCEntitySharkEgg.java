package net.minecraft.src;

import net.minecraft.src.EntityLiving;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.ItemStack;
import net.minecraft.src.Material;
import net.minecraft.src.MoCEntityShark;
import net.minecraft.src.World;
import net.minecraft.src.mod_mocreatures;

public class MoCEntitySharkEgg extends EntityLiving
{
    private int tCounter;
    private int lCounter;

    public MoCEntitySharkEgg(World var1)
    {
        super(var1);
        this.setSize(0.25F, 0.25F);
        this.tCounter = 0;
        this.lCounter = 0;
        this.texture = "/mocreatures/sharkeggt.png";
    }

    public MoCEntitySharkEgg(World var1, double var2, double var4, double var6)
    {
        super(var1);
        this.setPosition(var2, var4, var6);
        this.setSize(0.25F, 0.25F);
        this.tCounter = 0;
        this.lCounter = 0;
        this.texture = "/mocreatures/sharkeggt.png";
    }

    public boolean canBreatheUnderwater()
    {
        return true;
    }

    protected String getDeathSound()
    {
        return null;
    }

    protected String getHurtSound()
    {
        return null;
    }

    protected String getLivingSound()
    {
        return null;
    }

    protected float getSoundVolume()
    {
        return 0.4F;
    }

    public boolean handleWaterMovement()
    {
        return this.worldObj.handleMaterialAcceleration(this.boundingBox, Material.water, this);
    }

    public void onCollideWithPlayer(EntityPlayer var1)
    {
        if (!this.worldObj.isRemote)
        {
            if (this.lCounter > 10 && var1.inventory.addItemStackToInventory(new ItemStack(mod_mocreatures.sharkegg, 1)))
            {
                this.worldObj.playSoundAtEntity(this, "random.pop", 0.2F, ((this.rand.nextFloat() - this.rand.nextFloat()) * 0.7F + 1.0F) * 2.0F);
                var1.onItemPickup(this, 1);
                this.setEntityDead();
            }
        }
    }

    public void onLivingUpdate()
    {
        this.moveStrafing = 0.0F;
        this.moveForward = 0.0F;
        this.randomYawVelocity = 0.0F;
        this.moveEntityWithHeading(this.moveStrafing, this.moveForward);
    }

    public void onUpdate()
    {
        super.onUpdate();
        if (!this.worldObj.isRemote)
        {
            if (this.rand.nextInt(20) == 0)
            {
                ++this.lCounter;
            }

            if (this.isInWater() && this.rand.nextInt(20) == 0)
            {
                ++this.tCounter;
                if (this.tCounter >= 50)
                {
                    MoCEntityShark var1 = new MoCEntityShark(this.worldObj);
                    var1.setEdad(0.3F);
                    var1.setTamed(true);
                    var1.setPosition(this.posX, this.posY, this.posZ);
                    this.worldObj.spawnEntityInWorld(var1);
                    this.worldObj.playSoundAtEntity(this, "mob.chickenplop", 1.0F, (this.rand.nextFloat() - this.rand.nextFloat()) * 0.2F + 1.0F);
                    this.setEntityDead();
                }
            }
        }
    }

    public int getMaxHealth()
    {
        return 10;
    }
}
