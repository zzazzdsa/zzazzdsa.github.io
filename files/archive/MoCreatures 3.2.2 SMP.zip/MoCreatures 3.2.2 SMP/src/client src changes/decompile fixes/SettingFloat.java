package net.minecraft.src;

import net.minecraft.src.Setting;

public class SettingFloat extends Setting
{
    public float maximumValue;
    public float minimumValue;
    public float stepValue;

    public SettingFloat(String var1)
    {
        this(var1, 0.0F, 0.0F, 0.1F, 1.0F);
    }

    public SettingFloat(String var1, float var2)
    {
        this(var1, var2, 0.0F, 0.1F, 1.0F);
    }

    public SettingFloat(String var1, float var2, float var3, float var4)
    {
        this(var1, var2, var3, 0.1F, var4);
    }

    public SettingFloat(String var1, float var2, float var3, float var4, float var5)
    {
        this.values.put("", Float.valueOf(var2));
        this.defaultValue = Float.valueOf(var2);
        this.minimumValue = var3;
        this.stepValue = var4;
        this.maximumValue = var5;
        this.backendName = var1;
        if (this.minimumValue > this.maximumValue)
        {
            float var6 = this.minimumValue;
            this.minimumValue = this.maximumValue;
            this.maximumValue = var6;
        }
    }

    public void fromString(String var1, String var2)
    {
        this.values.put(var2, new Float(var1));
        if (this.displayWidget != null)
        {
            this.displayWidget.update();
        }
    }

    public Float get(String var1)
    {
        return this.values.get(var1) != null ? (Float)this.values.get(var1) : (this.values.get("") != null ? (Float)this.values.get("") : (Float)this.defaultValue);
    }

    public void set(Float var1, String var2)
    {
        if (this.stepValue > 0.0F)
        {
            this.values.put(var2, Float.valueOf((float)Math.round(var1.floatValue() / this.stepValue) * this.stepValue));
        }
        else
        {
            this.values.put(var2, var1);
        }

        if (this.parent != null)
        {
            this.parent.save(var2);
        }

        if (this.displayWidget != null)
        {
            this.displayWidget.update();
        }
    }

    public String toString(String var1)
    {
        return "" + this.get(var1);
    }

    public void set(Object var1, String var2)
    {
        this.set((Float)var1, var2);
    }
}
