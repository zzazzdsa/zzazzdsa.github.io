package net.minecraft.src;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Properties;
import net.minecraft.src.ModSettings;
import net.minecraft.src.Setting;

public class SettingDictionary extends Setting
{
    public SettingDictionary(String var1)
    {
        this(var1, new Properties());
    }

    public SettingDictionary(String var1, Properties var2)
    {
        this.backendName = var1;
        this.defaultValue = var2;
        this.values.put("", var2);
    }

    public void fromString(String var1, String var2)
    {
        Properties var3 = new Properties();

        try
        {
            var3.loadFromXML(new ByteArrayInputStream(var1.getBytes("UTF-8")));
        }
        catch (Throwable var5)
        {
            ModSettings.dbgout("Error reading SettingDictionary from context \'" + var2 + "\': " + var5);
        }

        this.values.put(var2, var3);
        if (this.displayWidget != null)
        {
            this.displayWidget.update();
        }
    }

    public Properties get(String var1)
    {
        return this.values.get(var1) != null ? (Properties)this.values.get(var1) : (this.values.get("") != null ? (Properties)this.values.get("") : (Properties)this.defaultValue);
    }

    public void set(Properties var1, String var2)
    {
        this.values.put(var2, var1);
        if (this.parent != null)
        {
            this.parent.save(var2);
        }

        if (this.displayWidget != null)
        {
            this.displayWidget.update();
        }
    }

    public String toString(String var1)
    {
        try
        {
            Properties var2 = this.get(var1);
            ByteArrayOutputStream var3 = new ByteArrayOutputStream();
            var2.storeToXML(var3, "GuiAPI SettingDictionary: DO NOT EDIT.");
            return var3.toString("UTF-8");
        }
        catch (IOException var4)
        {
            ModSettings.dbgout("Error writing SettingDictionary from context \'" + var1 + "\': " + var4);
            return "";
        }
    }

    public void set(Object var1, String var2)
    {
        this.set((Properties)var1, var2);
    }
}
