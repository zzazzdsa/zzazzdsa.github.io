package net.minecraft.src;

import net.minecraft.src.Setting;

public class SettingBoolean extends Setting
{
    public SettingBoolean(String var1)
    {
        this(var1, Boolean.valueOf(false));
    }

    public SettingBoolean(String var1, Boolean var2)
    {
        this.defaultValue = var2;
        this.values.put("", this.defaultValue);
        this.backendName = var1;
    }

    public void fromString(String var1, String var2)
    {
        this.values.put(var2, Boolean.valueOf(var1.equals("true")));
        if (this.displayWidget != null)
        {
            this.displayWidget.update();
        }
    }

    public Boolean get(String var1)
    {
        return this.values.get(var1) != null ? (Boolean)this.values.get(var1) : (this.values.get("") != null ? (Boolean)this.values.get("") : (Boolean)this.defaultValue);
    }

    public void set(Boolean var1, String var2)
    {
        this.values.put(var2, var1);
        if (this.parent != null)
        {
            this.parent.save(var2);
        }

        if (this.displayWidget != null)
        {
            this.displayWidget.update();
        }
    }

    public String toString(String var1)
    {
        return this.get(var1).booleanValue() ? "true" : "false";
    }

    public void set(Object var1, String var2)
    {
        this.set((Boolean)var1, var2);
    }
}
