package net.minecraft.src;

import net.minecraft.src.ModSettings;
import net.minecraft.src.Setting;
import org.lwjgl.input.Keyboard;

public class SettingKey extends Setting
{
    public SettingKey(String var1, int var2)
    {
        this.defaultValue = Integer.valueOf(var2);
        this.values.put("", Integer.valueOf(var2));
        this.backendName = var1;
    }

    public SettingKey(String var1, String var2)
    {
        this(var1, Keyboard.getKeyIndex(var2));
    }

    public void fromString(String var1, String var2)
    {
        if (var1.equals("UNBOUND"))
        {
            this.values.put(var2, Integer.valueOf(0));
        }
        else
        {
            this.values.put(var2, Integer.valueOf(Keyboard.getKeyIndex(var1)));
        }

        if (this.displayWidget != null)
        {
            this.displayWidget.update();
        }
    }

    public Integer get(String var1)
    {
        return this.values.get(var1) != null ? (Integer)this.values.get(var1) : (this.values.get("") != null ? (Integer)this.values.get("") : (Integer)this.defaultValue);
    }

    public boolean isKeyDown()
    {
        return this.isKeyDown(ModSettings.currentContext);
    }

    public boolean isKeyDown(String var1)
    {
        return this.get(var1).intValue() != -1 ? Keyboard.isKeyDown(this.get(var1).intValue()) : false;
    }

    public void set(Integer var1, String var2)
    {
        this.values.put(var2, var1);
        if (this.parent != null)
        {
            this.parent.save(var2);
        }

        if (this.displayWidget != null)
        {
            this.displayWidget.update();
        }
    }

    public void set(String var1)
    {
        this.set(var1, ModSettings.currentContext);
    }

    public void set(String var1, String var2)
    {
        this.set(Integer.valueOf(Keyboard.getKeyIndex(var1)), var2);
    }

    public String toString(String var1)
    {
        return Keyboard.getKeyName(this.get(var1).intValue());
    }

    public void set(Object var1, String var2)
    {
        this.set((Integer)var1, var2);
    }
}
