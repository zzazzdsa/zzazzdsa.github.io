package net.minecraft.src;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import net.minecraft.src.ModSettings;
import net.minecraft.src.Setting;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class SettingList extends Setting
{
    public SettingList(String var1)
    {
        this(var1, new ArrayList());
    }

    public SettingList(String var1, ArrayList var2)
    {
        this.backendName = var1;
        this.defaultValue = var2;
        this.values.put("", var2);
    }

    public void fromString(String var1, String var2)
    {
        ArrayList var3 = new ArrayList();

        try
        {
            DocumentBuilderFactory var4 = DocumentBuilderFactory.newInstance();
            var4.setIgnoringElementContentWhitespace(true);
            var4.setValidating(true);
            var4.setCoalescing(true);
            var4.setIgnoringComments(true);
            DocumentBuilder var5 = var4.newDocumentBuilder();
            Document var6 = var5.parse(var1);
            Element var7 = (Element)var6.getChildNodes().item(1);
            NodeList var8 = var7.getChildNodes();

            for (int var9 = 0; var9 < var8.getLength(); ++var9)
            {
                String var10 = var8.item(var9).getNodeValue();
                var3.add(var10);
            }

            this.values.put(var2, var3);
            if (this.displayWidget != null)
            {
                this.displayWidget.update();
            }
        }
        catch (Throwable var11)
        {
            ;
        }
    }

    public ArrayList get(String var1)
    {
        return this.values.get(var1) != null ? (ArrayList)this.values.get(var1) : (this.values.get("") != null ? (ArrayList)this.values.get("") : (ArrayList)this.defaultValue);
    }

    public void set(ArrayList var1, String var2)
    {
        this.values.put(var2, var1);
        if (this.parent != null)
        {
            this.parent.save(var2);
        }

        if (this.displayWidget != null)
        {
            this.displayWidget.update();
        }
    }

    public String toString(String var1)
    {
        try
        {
            DocumentBuilder var2 = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            Document var3 = var2.newDocument();
            Element var4 = (Element)var3.appendChild(var3.createElement("list"));
            ArrayList var5 = this.get(var1);
            Iterator var7;
            synchronized (var5)
            {
                var7 = var5.iterator();

                while (true)
                {
                    if (!var7.hasNext())
                    {
                        break;
                    }

                    String var8 = (String)var7.next();
                    var4.appendChild(var3.createTextNode(var8));
                }
            }

            TransformerFactory var6 = TransformerFactory.newInstance();
            var7 = null;
            Transformer var13 = var6.newTransformer();
            var13.setOutputProperty("method", "xml");
            var13.setOutputProperty("encoding", "UTF8");
            DOMSource var14 = new DOMSource(var3);
            ByteArrayOutputStream var9 = new ByteArrayOutputStream();
            StreamResult var10 = new StreamResult(var9);
            var13.transform(var14, var10);
            return var9.toString("UTF-8");
        }
        catch (Throwable var12)
        {
            ModSettings.dbgout("Error writing SettingList from context \'" + var1 + "\': " + var12);
            return "";
        }
    }

    public void set(Object var1, String var2)
    {
        this.set((ArrayList)var1, var2);
    }
}
