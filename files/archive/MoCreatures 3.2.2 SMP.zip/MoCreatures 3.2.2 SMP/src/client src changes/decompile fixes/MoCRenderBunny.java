package net.minecraft.src;

import net.minecraft.src.EntityLiving;
import net.minecraft.src.MoCEntityBunny;
import net.minecraft.src.ModelBase;
import net.minecraft.src.RenderLiving;
import net.minecraft.src.mod_mocreatures;
import org.lwjgl.opengl.GL11;

public class MoCRenderBunny extends RenderLiving
{
    private boolean textureset = false;

    public MoCRenderBunny(ModelBase var1, float var2)
    {
        super(var1, var2);
    }

    public void doRenderLiving(EntityLiving var1, double var2, double var4, double var6, float var8, float var9)
    {
        MoCEntityBunny var10 = (MoCEntityBunny)var1;
        super.doRenderLiving(var10, var2, var4, var6, var8, var9);
    }

    protected float handleRotationFloat(EntityLiving var1, float var2)
    {
        MoCEntityBunny var3 = (MoCEntityBunny)var1;
        if (!var3.getIsAdult())
        {
            this.stretch(var3);
        }

        return (float)var1.ticksExisted + var2;
    }

    protected void preRenderCallback(EntityLiving var1, float var2)
    {
        this.rotBunny((MoCEntityBunny)var1);
        if (mod_mocreatures.mc.isMultiplayerWorld() && var1.ridingEntity == mod_mocreatures.mc.thePlayer)
        {
            GL11.glTranslatef(0.0F, 1.3F, 0.0F);
        }
    }

    protected void rotBunny(MoCEntityBunny var1)
    {
        if (!var1.onGround && var1.ridingEntity == null)
        {
            if (var1.motionY > 0.5D)
            {
                GL11.glRotatef(35.0F, -1.0F, 0.0F, 0.0F);
            }
            else if (var1.motionY < -0.5D)
            {
                GL11.glRotatef(-35.0F, -1.0F, 0.0F, 0.0F);
            }
            else
            {
                GL11.glRotatef((float)(var1.motionY * 70.0D), -1.0F, 0.0F, 0.0F);
            }
        }
    }

    protected void stretch(MoCEntityBunny var1)
    {
        float var2 = var1.getEdad();
        GL11.glScalef(var2, var2, var2);
    }
}
