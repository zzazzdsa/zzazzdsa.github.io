package net.minecraft.src;

import de.matthiasmann.twl.Button;
import de.matthiasmann.twl.Widget;
import de.matthiasmann.twl.model.SimpleButtonModel;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.src.Achievement;
import net.minecraft.src.AchievementList;
import net.minecraft.src.BaseMod;
import net.minecraft.src.BiomeGenBase;
import net.minecraft.src.Block;
import net.minecraft.src.CustomSpawner;
import net.minecraft.src.DamageSource;
import net.minecraft.src.EntityCaveSpider;
import net.minecraft.src.EntityChicken;
import net.minecraft.src.EntityCow;
import net.minecraft.src.EntityCreeper;
import net.minecraft.src.EntityEnderman;
import net.minecraft.src.EntityGhast;
import net.minecraft.src.EntityPig;
import net.minecraft.src.EntityPigZombie;
import net.minecraft.src.EntityPlayerSP;
import net.minecraft.src.EntitySheep;
import net.minecraft.src.EntitySkeleton;
import net.minecraft.src.EntitySpider;
import net.minecraft.src.EntitySquid;
import net.minecraft.src.EntityWolf;
import net.minecraft.src.EntityZombie;
import net.minecraft.src.EnumArmorMaterial;
import net.minecraft.src.EnumCreatureType;
import net.minecraft.src.GuiIngameMenu;
import net.minecraft.src.GuiModScreen;
import net.minecraft.src.GuiScreen;
import net.minecraft.src.Item;
import net.minecraft.src.ItemArmor;
import net.minecraft.src.ItemDye;
import net.minecraft.src.ItemStack;
import net.minecraft.src.MoCEntityAnimal;
import net.minecraft.src.MoCEntityBear;
import net.minecraft.src.MoCEntityBigCat;
import net.minecraft.src.MoCEntityBird;
import net.minecraft.src.MoCEntityBoar;
import net.minecraft.src.MoCEntityBunny;
import net.minecraft.src.MoCEntityCaveOgre;
import net.minecraft.src.MoCEntityCrocodile;
import net.minecraft.src.MoCEntityDeer;
import net.minecraft.src.MoCEntityDolphin;
import net.minecraft.src.MoCEntityDuck;
import net.minecraft.src.MoCEntityFireOgre;
import net.minecraft.src.MoCEntityFishy;
import net.minecraft.src.MoCEntityFishyEgg;
import net.minecraft.src.MoCEntityFlameWraith;
import net.minecraft.src.MoCEntityFox;
import net.minecraft.src.MoCEntityGoat;
import net.minecraft.src.MoCEntityHellRat;
import net.minecraft.src.MoCEntityHorse;
import net.minecraft.src.MoCEntityJellyFish;
import net.minecraft.src.MoCEntityKitty;
import net.minecraft.src.MoCEntityKittyBed;
import net.minecraft.src.MoCEntityLitterBox;
import net.minecraft.src.MoCEntityMouse;
import net.minecraft.src.MoCEntityOgre;
import net.minecraft.src.MoCEntityPolarBear;
import net.minecraft.src.MoCEntityRat;
import net.minecraft.src.MoCEntityRay;
import net.minecraft.src.MoCEntityScorpion;
import net.minecraft.src.MoCEntityShark;
import net.minecraft.src.MoCEntitySharkEgg;
import net.minecraft.src.MoCEntityTurtle;
import net.minecraft.src.MoCEntityWWolf;
import net.minecraft.src.MoCEntityWerewolf;
import net.minecraft.src.MoCEntityWraith;
import net.minecraft.src.MoCGUI;
import net.minecraft.src.MoCItemFishyEgg;
import net.minecraft.src.MoCItemHayStack;
import net.minecraft.src.MoCItemHorseSaddle;
import net.minecraft.src.MoCItemKittyBed;
import net.minecraft.src.MoCItemLitterBox;
import net.minecraft.src.MoCItemSharkEgg;
import net.minecraft.src.MoCItemSugarLump;
import net.minecraft.src.MoCItemWhip;
import net.minecraft.src.MoCModelBear1;
import net.minecraft.src.MoCModelBear2;
import net.minecraft.src.MoCModelBigCat1;
import net.minecraft.src.MoCModelBigCat2;
import net.minecraft.src.MoCModelBird;
import net.minecraft.src.MoCModelBunny;
import net.minecraft.src.MoCModelCrocodile;
import net.minecraft.src.MoCModelDeer;
import net.minecraft.src.MoCModelDolphin;
import net.minecraft.src.MoCModelFishy;
import net.minecraft.src.MoCModelFox;
import net.minecraft.src.MoCModelGoat;
import net.minecraft.src.MoCModelHorse1;
import net.minecraft.src.MoCModelHorse2;
import net.minecraft.src.MoCModelJellyFish;
import net.minecraft.src.MoCModelKitty;
import net.minecraft.src.MoCModelKittyBed;
import net.minecraft.src.MoCModelKittyBed2;
import net.minecraft.src.MoCModelLitterBox;
import net.minecraft.src.MoCModelMouse;
import net.minecraft.src.MoCModelOgre1;
import net.minecraft.src.MoCModelOgre2;
import net.minecraft.src.MoCModelRat;
import net.minecraft.src.MoCModelRay;
import net.minecraft.src.MoCModelScorpion;
import net.minecraft.src.MoCModelShark;
import net.minecraft.src.MoCModelSharkEgg;
import net.minecraft.src.MoCModelTurtle;
import net.minecraft.src.MoCModelWereHuman;
import net.minecraft.src.MoCModelWerewolf;
import net.minecraft.src.MoCModelWolf1;
import net.minecraft.src.MoCModelWolf2;
import net.minecraft.src.MoCModelWraith;
import net.minecraft.src.MoCRenderBear;
import net.minecraft.src.MoCRenderBigCat;
import net.minecraft.src.MoCRenderBird;
import net.minecraft.src.MoCRenderBunny;
import net.minecraft.src.MoCRenderCaveOgre;
import net.minecraft.src.MoCRenderCrocodile;
import net.minecraft.src.MoCRenderDeer;
import net.minecraft.src.MoCRenderDolphin;
import net.minecraft.src.MoCRenderFireOgre;
import net.minecraft.src.MoCRenderFishy;
import net.minecraft.src.MoCRenderFishyEgg;
import net.minecraft.src.MoCRenderFox;
import net.minecraft.src.MoCRenderGoat;
import net.minecraft.src.MoCRenderHellRat;
import net.minecraft.src.MoCRenderHorse;
import net.minecraft.src.MoCRenderJellyFish;
import net.minecraft.src.MoCRenderKitty;
import net.minecraft.src.MoCRenderKittyBed;
import net.minecraft.src.MoCRenderLitterBox;
import net.minecraft.src.MoCRenderMouse;
import net.minecraft.src.MoCRenderOgre;
import net.minecraft.src.MoCRenderPolarBear;
import net.minecraft.src.MoCRenderRat;
import net.minecraft.src.MoCRenderRay;
import net.minecraft.src.MoCRenderScorpion;
import net.minecraft.src.MoCRenderShark;
import net.minecraft.src.MoCRenderSharkEgg;
import net.minecraft.src.MoCRenderTurtle;
import net.minecraft.src.MoCRenderWWolf;
import net.minecraft.src.MoCRenderWerewolf;
import net.minecraft.src.MoCRenderWraith;
import net.minecraft.src.MoCTools;
import net.minecraft.src.ModAction;
import net.minecraft.src.ModLoader;
import net.minecraft.src.ModSettingScreen;
import net.minecraft.src.ModSettings;
import net.minecraft.src.ModelChicken;
import net.minecraft.src.ModelPig;
import net.minecraft.src.Potion;
import net.minecraft.src.RenderChicken;
import net.minecraft.src.RenderPig;
import net.minecraft.src.ScaledResolution;
import net.minecraft.src.SettingBoolean;
import net.minecraft.src.SettingFloat;
import net.minecraft.src.SettingInt;
import net.minecraft.src.SettingMulti;
import net.minecraft.src.Tessellator;
import net.minecraft.src.WidgetBoolean;
import net.minecraft.src.WidgetClassicTwocolumn;
import net.minecraft.src.WidgetFloat;
import net.minecraft.src.WidgetInt;
import net.minecraft.src.WidgetMulti;
import net.minecraft.src.WidgetSimplewindow;
import org.lwjgl.opengl.GL11;

public class mod_mocreatures extends BaseModMp
{
    public static Minecraft mc = ModLoader.getMinecraftInstance();
    static mod_mocreatures inst;
    private static CustomSpawner myCustomSpawner;
    private long sTime;
    public static HashMap mocEntities;
    public static int min = 4;
    public static int max = 5;
    public static long lastTickRun = 0L;
    public static boolean inMenu = false;
    public static Item horsesaddle = (new MoCItemHorseSaddle(3772)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/hsaddle.png")).setItemName("HorseSaddle");
    public static Item haystack = (new MoCItemHayStack(3775)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/haystack.png")).setItemName("HayStack");
    public static Item sugarlump = (new MoCItemSugarLump(3776)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/sugarlump.png")).setItemName("SugarLump");
    public static Item sharkteeth = (new Item(3774)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/sharkteeth.png")).setItemName("sharkteeth");
    public static Item sharkegg = (new MoCItemSharkEgg(3773)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/sharkegg.png")).setItemName("sharkegg");
    public static Item fishyegg = (new MoCItemFishyEgg(3777)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/fishyegg.png")).setItemName("fishyegg");
    public static Item bigcatclaw = (new Item(3778)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/bigcatclaw.png")).setItemName("bigcatclaw");
    public static Item whip = (new MoCItemWhip(3779)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/whip.png")).setItemName("whip");
    public static Item medallion = (new Item(3783)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/medallion.png")).setItemName("medallion");
    public static Item kittybed = (new MoCItemKittyBed(3784, 0)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/bedkitty.png")).setItemName("kittybed");
    public static Item litterbox = (new MoCItemLitterBox(3785)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/boxlitter.png")).setItemName("litterbox");
    public static Item woolball = (new Item(3786)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/woolball.png")).setItemName("woolball");
    public static Item rope = (new Item(3787)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/rope.png")).setItemName("rope");
    public static Item petfood = (new Item(3788)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/petfood.png")).setItemName("petfood");
    public static Item crochide = (new Item(3790)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/crochide.png")).setItemName("crochide");
    public static Item plateCroc = (new ItemArmor(3791, EnumArmorMaterial.CLOTH, ModLoader.AddArmor("croc"), 1)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/crocplate.png")).setItemName("plateCroc");
    public static Item helmetCroc = (new ItemArmor(3792, EnumArmorMaterial.CLOTH, ModLoader.AddArmor("croc"), 0)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/crochelmet.png")).setItemName("helmetCroc");
    public static Item legsCroc = (new ItemArmor(3793, EnumArmorMaterial.CLOTH, ModLoader.AddArmor("croc"), 2)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/croclegs.png")).setItemName("legsCroc");
    public static Item bootsCroc = (new ItemArmor(3794, EnumArmorMaterial.CLOTH, ModLoader.AddArmor("croc"), 3)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mocreatures/crocboots.png")).setItemName("bootsCroc");
    public static Achievement Indiana = (new Achievement(77, "indiana", -4, -4, whip, AchievementList.openInventory)).registerAchievement();
    public static Achievement BunnyKilla = (new Achievement(78, "bunnykilla", -5, -5, whip, AchievementList.openInventory)).registerAchievement();
    public static boolean poisoned = false;
    public static boolean freezed = false;
    public static boolean burned = false;
    public static int poisoncounter = 0;
    public static int freezedcounter = 0;
    public static SettingInt maxMobsS;
    public static WidgetInt maxMobsW;
    public static SettingInt maxAnimalsS;
    public static WidgetInt maxAnimalsW;
    public static SettingInt maxWaterMobsS;
    public static WidgetInt maxWaterMobsW;
    public static SettingBoolean spawnpiranha;
    public static SettingInt horsefreq;
    public static SettingInt birdfreq;
    public static SettingInt lionfreq;
    public static SettingInt bearfreq;
    public static SettingInt pbearfreq;
    public static SettingInt wwolffreq;
    public static SettingInt duckfreq;
    public static SettingInt boarfreq;
    public static SettingInt bunnyfreq;
    public static SettingInt wraithfreq;
    public static SettingInt fwraithfreq;
    public static SettingInt ogrefreq;
    public static SettingInt cogrefreq;
    public static SettingInt fogrefreq;
    public static SettingInt werewolffreq;
    public static SettingInt foxfreq;
    public static SettingInt sharkfreq;
    public static SettingInt squidfreq;
    public static SettingInt dolphinfreq;
    public static SettingInt fishfreq;
    public static SettingInt deerfreq;
    public static SettingInt kittyfreq;
    public static SettingInt micefreq;
    public static SettingInt ratfreq;
    public static SettingInt hellratfreq;
    public static SettingInt scorpionfreq;
    public static SettingInt turtlefreq;
    public static SettingInt crocfreq;
    public static SettingInt rayfreq;
    public static SettingInt jellyfishfreq;
    public static SettingInt snakefreq;
    public static SettingInt goatfreq;
    public static WidgetInt horsefreqW;
    public static WidgetInt birdfreqW;
    public static WidgetInt lionfreqW;
    public static WidgetInt bearfreqW;
    public static WidgetInt pbearfreqW;
    public static WidgetInt wwolffreqW;
    public static WidgetInt duckfreqW;
    public static WidgetInt boarfreqW;
    public static WidgetInt bunnyfreqW;
    public static WidgetInt wraithfreqW;
    public static WidgetInt fwraithfreqW;
    public static WidgetInt ogrefreqW;
    public static WidgetInt cogrefreqW;
    public static WidgetInt fogrefreqW;
    public static WidgetInt werewolffreqW;
    public static WidgetInt foxfreqW;
    public static WidgetInt sharkfreqW;
    public static WidgetInt squidfreqW;
    public static WidgetInt dolphinfreqW;
    public static WidgetInt fishfreqW;
    public static WidgetInt deerfreqW;
    public static WidgetInt kittyfreqW;
    public static WidgetInt micefreqW;
    public static WidgetInt ratfreqW;
    public static WidgetInt hellratfreqW;
    public static WidgetInt scorpionfreqW;
    public static WidgetInt turtlefreqW;
    public static WidgetInt crocfreqW;
    public static WidgetInt rayfreqW;
    public static WidgetInt jellyfishfreqW;
    public static WidgetInt snakefreqW;
    public static WidgetInt goatfreqW;
    public static SettingBoolean displayname;
    public static WidgetBoolean displaynameW;
    public static SettingBoolean displayhealth;
    public static WidgetBoolean displayhealthW;
    public static SettingBoolean displayemo;
    public static WidgetBoolean displayemoW;
    public static SettingBoolean staticbed;
    public static WidgetBoolean staticbedW;
    public static SettingBoolean staticlitter;
    public static WidgetBoolean staticlitterW;
    public static SettingBoolean attackdolphins;
    public static WidgetBoolean attackdolphinsW;
    public static SettingBoolean attackhorses;
    public static WidgetBoolean attackhorsesW;
    public static SettingBoolean attackwolves;
    public static WidgetBoolean attackwolvesW;
    public static SettingBoolean destroyitems;
    public static WidgetBoolean destroyitemsW;
    public static WidgetBoolean spawnpiranhaW;
    public static SettingInt pegasusChanceS;
    public static WidgetInt pegasusChanceW;
    public static SettingBoolean easybreeding;
    public static WidgetBoolean easybreedingW;
    public static SettingInt ogrerange;
    public static SettingFloat ogreStrength;
    public static SettingFloat fogreStrength;
    public static SettingFloat cogreStrength;
    public static WidgetFloat ogreStrengthW;
    public static WidgetFloat fogreStrengthW;
    public static WidgetFloat cogreStrengthW;
    public static WidgetInt ogrerangeW;
    public static SettingMulti ogreSpawnDifficulty;
    public static SettingMulti cogreSpawnDifficulty;
    public static SettingMulti fogreSpawnDifficulty;
    public static WidgetMulti ogreSpawnDifficultyW;
    public static WidgetMulti cogreSpawnDifficultyW;
    public static WidgetMulti fogreSpawnDifficultyW;
    public static SettingMulti wereSpawnDifficulty;
    public static SettingMulti wraithSpawnDifficulty;
    public static SettingMulti fwraithSpawnDifficulty;
    public static WidgetMulti wereSpawnDifficultyW;
    public static WidgetMulti wraithSpawnDifficultyW;
    public static WidgetMulti fwraithSpawnDifficultyW;
    public static SettingMulti sharkSpawnDifficulty;
    public static WidgetMulti sharkSpawnDifficultyW;
    public String modName;
    public ModSettings MoCSettings;
    public ModSettingScreen MoCScreen;
    public WidgetSimplewindow spawnwindow;
    public WidgetSimplewindow animalwindow;
    public WidgetSimplewindow hunterwindow;
    public WidgetSimplewindow mobwindow;
    public WidgetSimplewindow watermobwindow;
    public WidgetSimplewindow displaytagwindow;
    public WidgetSimplewindow vanillamobwindow;
    public static SettingBoolean despawnVanilla;
    public static WidgetBoolean despawnVanillaW;
    public static SettingBoolean modifyVanillaSpawns;
    public static WidgetBoolean modifyVanillaSpawnsW;
    public static SettingBoolean isOldWorld;
    public static WidgetBoolean isOldWorldW;
    public static SettingInt cowfreq;
    public static WidgetInt cowfreqW;
    public static SettingInt sheepfreq;
    public static WidgetInt sheepfreqW;
    public static SettingInt pigfreq;
    public static WidgetInt pigfreqW;
    public static SettingInt chickenfreq;
    public static WidgetInt chickenfreqW;
    public static SettingInt zombiefreq;
    public static WidgetInt zombiefreqW;
    public static SettingInt skeletonfreq;
    public static WidgetInt skeletonfreqW;
    public static SettingInt spiderfreq;
    public static WidgetInt spiderfreqW;
    public static SettingInt creeperfreq;
    public static WidgetInt creeperfreqW;
    public static SettingInt enderfreq;
    public static WidgetInt enderfreqW;
    public static SettingInt wolffreq;
    public static WidgetInt wolffreqW;
    public static WidgetInt basefreqW;

    private boolean loaded = false;
    
    public mod_mocreatures()
    {
    	load();
    }

    public String getVersion()
    {
        return "v3.2.2 (MC 1.1)";
    }

    public void load()
    {
    	if (loaded) return;
    	loaded = true;
    
        ModLoader.SetInGameHook(this, true, false);
        ModLoader.SetInGUIHook(this, true, false);
        inst = this;
        mocEntities = new HashMap();
        myCustomSpawner = new CustomSpawner();
        this.modName = "DrZhark\'s Mo\'Creatures";
        this.AddNames();
        this.RegisterEntities();
        this.AddRecipes();
        this.AddAchievements();
        this.GUIApiInit();
        updateSettings();
    }

    public boolean OnTickInGame(float var1, Minecraft var2)
    {
        if (!mc.theWorld.isRemote && mc.theWorld.worldInfo.getWorldTime() % 200L == 0L)
        {
            int var3 = myCustomSpawner.doCustomSpawning(mc.theWorld, mc.gameSettings.difficulty > 0, mc.theWorld.isDaytime());
            System.out.println("Mo\'Creatures Spawned " + var3 + " Mo\'Creatures");
            if (((Boolean)despawnVanilla.get()).booleanValue())
            {
                int var4 = myCustomSpawner.despawnMob(mc.theWorld);
                System.out.println("Mo\'Creatures DeSpawned " + var4 + " Vanilla Creatures");
            }
        }

        if (inMenu)
        {
            if (lastTickRun > 10L)
            {
                updateSettings();
                inMenu = false;
            }

            ++lastTickRun;
        }

        EntityPlayerSP var5 = var2.thePlayer;
        if (poisoned)
        {
            ++poisoncounter;
            if (!var5.isPotionActive(Potion.poison) || var5.isDead)
            {
                poisoncounter = 0;
                poisoned = false;
            }

            renderHaze(0.2F, "/mocreatures/maskgreen.png");
            MoCTools.disorientEntity(var5);
            if (poisoncounter % 20 == 0)
            {
                mc.theWorld.spawnParticle("slime", var5.posX, var5.posY + 0.5D, var5.posZ, 0.0D, 0.5D, 0.0D);
            }
        }

        if (freezed)
        {
            ++freezedcounter;
            if (freezedcounter > 200 || var5.isDead)
            {
                freezedcounter = 0;
                freezed = false;
            }

            renderHaze(0.2F, "/mocreatures/maskblue.png");
            MoCTools.slowEntity(var5);
            if (freezedcounter % 20 == 0)
            {
                mc.theWorld.spawnParticle("bubble", var5.posX, var5.posY + 0.5D, var5.posZ, 0.0D, 0.5D, 0.0D);
                var5.attackEntityFrom(DamageSource.magic, 1);
            }
        }

        if (burned)
        {
            if (var5.isDead || !var5.isBurning())
            {
                burned = false;
            }

            renderHaze(0.2F, "/mocreatures/maskred.png");
        }

        return true;
    }

    public static void updateSettings()
    {
        myCustomSpawner.setMaxMobs(Integer.valueOf(((Integer)maxMobsS.get()).intValue()).intValue());
        myCustomSpawner.setMaxAnimals(Integer.valueOf(((Integer)maxAnimalsS.get()).intValue()).intValue());
        myCustomSpawner.setMaxAquatic(Integer.valueOf(((Integer)maxWaterMobsS.get()).intValue()).intValue());
        myCustomSpawner.clearLists();
        PopulatemyCustomSpawner();
        if (((Boolean)isOldWorld.get()).booleanValue())
        {
            PopulatemyCustomSpawnerOldWorlds();
        }

        if (((Boolean)modifyVanillaSpawns.get()).booleanValue())
        {
            ClearVanillaSpawnLists();
            ClearVanillaMobSpawns();
            PopulateVanillaSpawnLists();
        }

        System.out.println("Mo\'Creatures is updating settings");
    }

    public boolean OnTickInGUI(float var1, Minecraft var2, GuiScreen var3)
    {
        if (mc.thePlayer != null && var3 instanceof GuiIngameMenu)
        {
            inMenu = true;
            lastTickRun = 0L;
        }

        return true;
    }

    public static void PopulatemyCustomSpawnerOldWorlds()
    {
        if (((Integer)horsefreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityHorse.class, ((Integer)horsefreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.ocean});
        }

        if (((Integer)boarfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityBoar.class, ((Integer)boarfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.ocean});
        }

        if (((Integer)bearfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityBear.class, ((Integer)bearfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.ocean});
        }

        if (((Integer)duckfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityDuck.class, ((Integer)duckfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.ocean});
        }

        if (((Integer)lionfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityBigCat.class, ((Integer)lionfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.ocean});
        }

        if (((Integer)pbearfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityPolarBear.class, ((Integer)pbearfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.ocean});
        }

        if (((Integer)bunnyfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityBunny.class, ((Integer)bunnyfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.ocean});
        }

        if (((Integer)birdfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityBird.class, ((Integer)birdfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.ocean});
        }

        if (((Integer)deerfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityDeer.class, ((Integer)deerfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.ocean});
        }

        if (((Integer)foxfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityFox.class, ((Integer)foxfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.ocean});
        }

        if (((Integer)kittyfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityKitty.class, ((Integer)kittyfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.ocean});
        }

        if (((Integer)micefreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityMouse.class, ((Integer)micefreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.ocean});
        }

        if (((Integer)turtlefreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityTurtle.class, ((Integer)turtlefreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.ocean});
        }

        if (((Integer)crocfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityCrocodile.class, ((Integer)crocfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.ocean});
        }

        if (((Integer)goatfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityGoat.class, ((Integer)goatfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.ocean});
        }
    }

    public static void PopulatemyCustomSpawner()
    {
        if (((Integer)horsefreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityHorse.class, ((Integer)horsefreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.plains, BiomeGenBase.taiga});
        }

        if (((Integer)ogrefreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityOgre.class, ((Integer)ogrefreq.get()).intValue(), EnumCreatureType.monster);
        }

        if (((Integer)fogrefreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityFireOgre.class, ((Integer)fogrefreq.get()).intValue(), EnumCreatureType.monster, new BiomeGenBase[] {BiomeGenBase.hell});
            myCustomSpawner.AddCustomSpawn(MoCEntityFireOgre.class, ((Integer)fogrefreq.get()).intValue(), EnumCreatureType.monster);
        }

        if (((Integer)cogrefreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityCaveOgre.class, ((Integer)cogrefreq.get()).intValue(), EnumCreatureType.monster);
        }

        if (((Integer)boarfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityBoar.class, ((Integer)boarfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.plains, BiomeGenBase.taiga});
        }

        if (((Integer)bearfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityBear.class, ((Integer)bearfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.plains, BiomeGenBase.taiga});
        }

        if (((Integer)duckfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityDuck.class, ((Integer)duckfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.extremeHills, BiomeGenBase.plains, BiomeGenBase.swampland, BiomeGenBase.taiga});
        }

        if (((Integer)lionfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityBigCat.class, ((Integer)lionfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.extremeHills, BiomeGenBase.plains, BiomeGenBase.taiga, BiomeGenBase.iceMountains, BiomeGenBase.icePlains});
        }

        if (((Integer)wwolffreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityWWolf.class, ((Integer)wwolffreq.get()).intValue(), EnumCreatureType.monster);
        }

        if (((Integer)pbearfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityPolarBear.class, ((Integer)pbearfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.iceMountains, BiomeGenBase.icePlains});
        }

        if (((Integer)wraithfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityWraith.class, ((Integer)wraithfreq.get()).intValue(), EnumCreatureType.monster);
        }

        if (((Integer)fwraithfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityFlameWraith.class, ((Integer)fwraithfreq.get()).intValue(), EnumCreatureType.monster, new BiomeGenBase[] {BiomeGenBase.hell});
            myCustomSpawner.AddCustomSpawn(MoCEntityFlameWraith.class, ((Integer)fwraithfreq.get()).intValue(), EnumCreatureType.monster);
        }

        if (((Integer)hellratfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityHellRat.class, ((Integer)hellratfreq.get()).intValue(), EnumCreatureType.monster, new BiomeGenBase[] {BiomeGenBase.hell});
        }

        if (((Integer)bunnyfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityBunny.class, ((Integer)bunnyfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.extremeHills, BiomeGenBase.plains, BiomeGenBase.taiga});
        }

        if (((Integer)birdfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityBird.class, ((Integer)birdfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.extremeHills, BiomeGenBase.plains, BiomeGenBase.taiga});
        }

        if (((Integer)deerfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityDeer.class, ((Integer)deerfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.plains, BiomeGenBase.taiga});
        }

        if (((Integer)foxfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityFox.class, ((Integer)foxfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.extremeHills, BiomeGenBase.plains, BiomeGenBase.taiga});
        }

        if (((Integer)kittyfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityKitty.class, ((Integer)kittyfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.extremeHills, BiomeGenBase.plains, BiomeGenBase.taiga});
        }

        if (((Integer)micefreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityMouse.class, ((Integer)micefreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.extremeHills, BiomeGenBase.plains, BiomeGenBase.taiga});
        }

        if (((Integer)turtlefreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityTurtle.class, ((Integer)turtlefreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.swampland, BiomeGenBase.river});
        }

        if (((Integer)crocfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityCrocodile.class, ((Integer)crocfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.swampland});
        }

        if (((Integer)werewolffreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityWerewolf.class, ((Integer)werewolffreq.get()).intValue(), EnumCreatureType.monster);
        }

        if (((Integer)ratfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityRat.class, ((Integer)ratfreq.get()).intValue(), EnumCreatureType.monster);
        }

        if (((Integer)scorpionfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityScorpion.class, ((Integer)scorpionfreq.get()).intValue(), EnumCreatureType.monster);
        }

        if (((Integer)scorpionfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityScorpion.class, ((Integer)scorpionfreq.get()).intValue(), EnumCreatureType.monster, new BiomeGenBase[] {BiomeGenBase.hell});
        }

        if (((Integer)sharkfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityShark.class, ((Integer)sharkfreq.get()).intValue(), EnumCreatureType.waterCreature, new BiomeGenBase[] {BiomeGenBase.ocean, BiomeGenBase.river});
        }

        if (((Integer)dolphinfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityDolphin.class, ((Integer)dolphinfreq.get()).intValue(), EnumCreatureType.waterCreature, new BiomeGenBase[] {BiomeGenBase.ocean, BiomeGenBase.river});
        }

        if (((Integer)fishfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityFishy.class, ((Integer)fishfreq.get()).intValue(), EnumCreatureType.waterCreature, new BiomeGenBase[] {BiomeGenBase.ocean, BiomeGenBase.river, BiomeGenBase.swampland});
        }

        if (((Integer)rayfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityRay.class, ((Integer)rayfreq.get()).intValue(), EnumCreatureType.waterCreature, new BiomeGenBase[] {BiomeGenBase.ocean, BiomeGenBase.river, BiomeGenBase.swampland, BiomeGenBase.forest, BiomeGenBase.taiga});
        }

        if (((Integer)jellyfishfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityJellyFish.class, ((Integer)jellyfishfreq.get()).intValue(), EnumCreatureType.waterCreature, new BiomeGenBase[] {BiomeGenBase.ocean, BiomeGenBase.swampland, BiomeGenBase.forest, BiomeGenBase.taiga});
        }

        if (((Integer)goatfreq.get()).intValue() > 0)
        {
            myCustomSpawner.AddCustomSpawn(MoCEntityGoat.class, ((Integer)goatfreq.get()).intValue(), EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.extremeHills, BiomeGenBase.plains});
        }
    }

    private void RegisterEntities()
    {
        ModLoader.RegisterEntityID(MoCEntityHorse.class, "Horse", 98);
        ModLoader.RegisterEntityID(MoCEntityOgre.class, "Ogre", 99);
        ModLoader.RegisterEntityID(MoCEntityFireOgre.class, "FireOgre", 100);
        ModLoader.RegisterEntityID(MoCEntityCaveOgre.class, "CaveOgre", 101);
        ModLoader.RegisterEntityID(MoCEntityBoar.class, "Boar", 102);
        ModLoader.RegisterEntityID(MoCEntityBear.class, "Bear", 103);
        ModLoader.RegisterEntityID(MoCEntityDuck.class, "Duck", 104);
        ModLoader.RegisterEntityID(MoCEntityBigCat.class, "BigCat", 105);
        ModLoader.RegisterEntityID(MoCEntityDeer.class, "Deer", 106);
        ModLoader.RegisterEntityID(MoCEntityWWolf.class, "WildWolf", 107);
        ModLoader.RegisterEntityID(MoCEntityPolarBear.class, "PolarBear", 108);
        ModLoader.RegisterEntityID(MoCEntityWraith.class, "Wraith", 109);
        ModLoader.RegisterEntityID(MoCEntityFlameWraith.class, "FlameWraith", 110);
        ModLoader.RegisterEntityID(MoCEntityBunny.class, "Bunny", 111);
        ModLoader.RegisterEntityID(MoCEntityBird.class, "Bird", 112);
        ModLoader.RegisterEntityID(MoCEntityFox.class, "Fox", 113);
        ModLoader.RegisterEntityID(MoCEntityWerewolf.class, "Werewolf", 114);
        ModLoader.RegisterEntityID(MoCEntityShark.class, "Shark", 115);
        ModLoader.RegisterEntityID(MoCEntityDolphin.class, "Dolphin", 116);
        ModLoader.RegisterEntityID(MoCEntityFishy.class, "Fishy", 117);
        ModLoader.RegisterEntityID(MoCEntityKitty.class, "Kitty", 118);
        ModLoader.RegisterEntityID(MoCEntityRat.class, "Rat", 119);
        ModLoader.RegisterEntityID(MoCEntityMouse.class, "Mouse", 120);
        ModLoader.RegisterEntityID(MoCEntityHellRat.class, "HellRat", 121);
        ModLoader.RegisterEntityID(MoCEntityScorpion.class, "Scorpion", 122);
        ModLoader.RegisterEntityID(MoCEntityTurtle.class, "Turtle", 123);
        ModLoader.RegisterEntityID(MoCEntityCrocodile.class, "Crocodile", 124);
        ModLoader.RegisterEntityID(MoCEntityRay.class, "Ray", 125);
        ModLoader.RegisterEntityID(MoCEntityJellyFish.class, "JellyFish", 126);
        ModLoader.RegisterEntityID(MoCEntityGoat.class, "Goat", 127);
        
        ModLoaderMp.RegisterNetClientHandlerEntity(MoCEntityKittyBed.class, 200);
        ModLoaderMp.RegisterNetClientHandlerEntity(MoCEntityLitterBox.class, 201);
        ModLoaderMp.RegisterNetClientHandlerEntity(MoCEntitySharkEgg.class, 202);
        ModLoaderMp.RegisterNetClientHandlerEntity(MoCEntityFishyEgg.class, 203);
    }

    private void AddNames()
    {
        ModLoader.AddName(horsesaddle, "Horse Saddle");
        ModLoader.AddName(sharkteeth, "Shark Teeth");
        ModLoader.AddName(sharkegg, "Shark Egg");
        ModLoader.AddName(haystack, "Hay Stack");
        ModLoader.AddName(sugarlump, "Sugar Lump");
        ModLoader.AddName(fishyegg, "Fish Egg");
        ModLoader.AddName(bigcatclaw, "BigCat Claw");
        ModLoader.AddName(whip, "Whip");
        ModLoader.AddName(medallion, "Medallion");
        ModLoader.AddName(kittybed, "Kitty Bed");
        ModLoader.AddName(litterbox, "Litter Box");
        ModLoader.AddName(woolball, "Wool Ball");
        ModLoader.AddName(petfood, "Pet Food");
        ModLoader.AddName(rope, "Rope");
        ModLoader.AddName(crochide, "Croc Hide");
        ModLoader.AddName(plateCroc, "Croc Plate");
        ModLoader.AddName(helmetCroc, "Croc Helmet");
        ModLoader.AddName(bootsCroc, "Croc Boots");
        ModLoader.AddName(legsCroc, "Croc Legs");
    }

    private void AddRecipes()
    {
        ModLoader.AddRecipe(new ItemStack(rope, 1), new Object[] {"# #", " # ", "# #", Character.valueOf('#'), Item.silk});
        ModLoader.AddShapelessRecipe(new ItemStack(petfood, 4), new Object[] {new ItemStack(Item.fishRaw, 1), new ItemStack(Item.porkRaw, 1)});
        ModLoader.AddRecipe(new ItemStack(woolball, 1), new Object[] {" # ", "# #", " # ", Character.valueOf('#'), Item.silk});
        ModLoader.AddRecipe(new ItemStack(litterbox, 1), new Object[] {"###", "#X#", "###", Character.valueOf('#'), Block.planks, Character.valueOf('X'), Block.sand});
        ModLoader.AddRecipe(new ItemStack(medallion, 1), new Object[] {"# #", "XZX", " X ", Character.valueOf('#'), Item.leather, Character.valueOf('Z'), Item.diamond, Character.valueOf('X'), Item.ingotGold});
        ModLoader.AddRecipe(new ItemStack(medallion, 1), new Object[] {"# #", " X ", Character.valueOf('#'), Item.leather, Character.valueOf('X'), Item.ingotGold});
        ModLoader.AddRecipe(new ItemStack(whip, 1), new Object[] {"#X#", "X X", "# Z", Character.valueOf('#'), bigcatclaw, Character.valueOf('X'), Item.leather, Character.valueOf('Z'), Item.ingotIron});
        ModLoader.AddRecipe(new ItemStack(horsesaddle, 1), new Object[] {"XXX", "X#X", "# #", Character.valueOf('#'), Item.ingotIron, Character.valueOf('X'), Item.leather});
        ModLoader.AddRecipe(new ItemStack(haystack, 1), new Object[] {"XXX", "XXX", Character.valueOf('X'), Item.wheat});
        ModLoader.AddRecipe(new ItemStack(Item.wheat, 6), new Object[] {"X", Character.valueOf('X'), haystack});
        ModLoader.AddRecipe(new ItemStack(sugarlump, 1), new Object[] {"XX", "##", Character.valueOf('X'), Item.sugar, Character.valueOf('#'), Item.sugar});
        ModLoader.AddRecipe(new ItemStack(horsesaddle, 1), new Object[] {"X", "#", Character.valueOf('X'), Item.saddle, Character.valueOf('#'), Item.ingotIron});
        ModLoader.AddRecipe(new ItemStack(Item.plateChain, 1), new Object[] {"X X", "XXX", "XXX", Character.valueOf('X'), sharkteeth});
        ModLoader.AddRecipe(new ItemStack(Item.helmetChain, 1), new Object[] {"XXX", "X X", Character.valueOf('X'), sharkteeth});
        ModLoader.AddRecipe(new ItemStack(Item.legsChain, 1), new Object[] {"XXX", "X X", "X X", Character.valueOf('X'), sharkteeth});
        ModLoader.AddRecipe(new ItemStack(Item.bootsChain, 1), new Object[] {"X X", "X X", Character.valueOf('X'), sharkteeth});
        ModLoader.AddRecipe(new ItemStack(plateCroc, 1), new Object[] {"X X", "XXX", "XXX", Character.valueOf('X'), crochide});
        ModLoader.AddRecipe(new ItemStack(helmetCroc, 1), new Object[] {"XXX", "X X", Character.valueOf('X'), crochide});
        ModLoader.AddRecipe(new ItemStack(legsCroc, 1), new Object[] {"XXX", "X X", "X X", Character.valueOf('X'), crochide});
        ModLoader.AddRecipe(new ItemStack(bootsCroc, 1), new Object[] {"X X", "X X", Character.valueOf('X'), crochide});

        for (int var1 = 0; var1 < 16; ++var1)
        {
            ModLoader.AddShapelessRecipe(new ItemStack(kittybed, 1, var1), new Object[] {new ItemStack(Item.dyePowder, 1, var1), new ItemStack(kittybed, 1)});
            ModLoader.AddRecipe(new ItemStack(kittybed, 1, var1), new Object[] {"###", "#X#", "Z  ", Character.valueOf('#'), Block.planks, Character.valueOf('X'), new ItemStack(Item.itemsList[Block.cloth.blockID], 1, MoCTools.colorize(var1)), Character.valueOf('Z'), Item.ingotIron});
            String var2 = ItemDye.dyeColorNames[var1];
            var2 = var2.substring(0, 1).toUpperCase() + var2.substring(1);
            ModLoader.AddName(new ItemStack(kittybed, 1, var1), var2 + " Kitty Bed");
        }
    }

    private void AddAchievements()
    {
        ModLoader.AddAchievementDesc(Indiana, "Indiana, Master of the BigCats", "Using a whip, command at least 7 tamed BigCats at once");
        ModLoader.AddAchievementDesc(BunnyKilla, "Da Bunny Killa", "using the bunny-kill-o-matic, euthanize at least 69 promiscuous bunnies at once");
    }

    public void AddRenderer(Map var1)
    {
        var1.put(MoCEntityHorse.class, new MoCRenderHorse(new MoCModelHorse2(), new MoCModelHorse1()));
        var1.put(MoCEntityFireOgre.class, new MoCRenderFireOgre(new MoCModelOgre2(), new MoCModelOgre1(), 1.5F));
        var1.put(MoCEntityCaveOgre.class, new MoCRenderCaveOgre(new MoCModelOgre2(), new MoCModelOgre1(), 1.5F));
        var1.put(MoCEntityOgre.class, new MoCRenderOgre(new MoCModelOgre2(), new MoCModelOgre1(), 1.5F));
        var1.put(MoCEntityBoar.class, new RenderPig(new ModelPig(), new ModelPig(0.5F), 0.7F));
        var1.put(MoCEntityBear.class, new MoCRenderBear(new MoCModelBear2(), new MoCModelBear1(), 0.7F));
        var1.put(MoCEntityDuck.class, new RenderChicken(new ModelChicken(), 0.3F));
        var1.put(MoCEntityBigCat.class, new MoCRenderBigCat(new MoCModelBigCat2(), new MoCModelBigCat1(), 0.7F));
        var1.put(MoCEntityDeer.class, new MoCRenderDeer(new MoCModelDeer(), 0.5F));
        var1.put(MoCEntityWWolf.class, new MoCRenderWWolf(new MoCModelWolf2(), new MoCModelWolf1(), 0.7F));
        var1.put(MoCEntityPolarBear.class, new MoCRenderPolarBear(new MoCModelBear2(), new MoCModelBear1(), 0.7F));
        var1.put(MoCEntityWraith.class, new MoCRenderWraith(new MoCModelWraith(), 0.5F));
        var1.put(MoCEntityFlameWraith.class, new MoCRenderWraith(new MoCModelWraith(), 0.5F));
        var1.put(MoCEntityBunny.class, new MoCRenderBunny(new MoCModelBunny(), 0.3F));
        var1.put(MoCEntityBird.class, new MoCRenderBird(new MoCModelBird(), 0.3F));
        var1.put(MoCEntityFox.class, new MoCRenderFox(new MoCModelFox()));
        var1.put(MoCEntityWerewolf.class, new MoCRenderWerewolf(new MoCModelWereHuman(), new MoCModelWerewolf(), 0.7F));
        var1.put(MoCEntityShark.class, new MoCRenderShark(new MoCModelShark(), 0.6F));
        var1.put(MoCEntitySharkEgg.class, new MoCRenderSharkEgg(new MoCModelSharkEgg(), 0.1F));
        var1.put(MoCEntityDolphin.class, new MoCRenderDolphin(new MoCModelDolphin(), 0.6F));
        var1.put(MoCEntityFishy.class, new MoCRenderFishy(new MoCModelFishy(), 0.2F));
        var1.put(MoCEntityFishyEgg.class, new MoCRenderFishyEgg(new MoCModelSharkEgg(), 0.1F));
        var1.put(MoCEntityKitty.class, new MoCRenderKitty(new MoCModelKitty(0.0F, 15.0F), 0.4F));
        var1.put(MoCEntityKittyBed.class, new MoCRenderKittyBed(new MoCModelKittyBed(), new MoCModelKittyBed2(), 0.3F));
        var1.put(MoCEntityLitterBox.class, new MoCRenderLitterBox(new MoCModelLitterBox(), 0.3F));
        var1.put(MoCEntityRat.class, new MoCRenderRat(new MoCModelRat(), 0.2F));
        var1.put(MoCEntityMouse.class, new MoCRenderMouse(new MoCModelMouse(), 0.1F));
        var1.put(MoCEntityHellRat.class, new MoCRenderHellRat(new MoCModelRat(), 0.4F));
        var1.put(MoCEntityScorpion.class, new MoCRenderScorpion(new MoCModelScorpion(), 0.6F));
        var1.put(MoCEntityTurtle.class, new MoCRenderTurtle(new MoCModelTurtle(), 0.4F));
        var1.put(MoCEntityCrocodile.class, new MoCRenderCrocodile(new MoCModelCrocodile(), 0.5F));
        var1.put(MoCEntityRay.class, new MoCRenderRay(new MoCModelRay(), 0.4F));
        var1.put(MoCEntityJellyFish.class, new MoCRenderJellyFish(new MoCModelJellyFish(), 0.1F));
        var1.put(MoCEntityGoat.class, new MoCRenderGoat(new MoCModelGoat(), 0.3F));
    }

    private void GUIApiInit()
    {
        this.MoCSettings = new ModSettings("mocreatures");
        this.MoCScreen = new ModSettingScreen("DrZhark\'s Mo\'Creatures");
        SimpleButtonModel var1 = new SimpleButtonModel();
        var1.addActionCallback(new ModAction(this, "spawnlimits", new Class[0]));
        Button var2 = new Button(var1);
        var2.setText("Spawn Limits");
        this.MoCScreen.append(var2);
        this.MoCSettings.append(maxMobsS = new SettingInt("MobsSpawnLimit", 60, 1, 1, 1000));
        maxMobsW = new WidgetInt(maxMobsS, "Hostiles");
        this.MoCSettings.append(maxAnimalsS = new SettingInt("AnimalsSpawnLimit", 50, 1, 1, 1000));
        maxAnimalsW = new WidgetInt(maxAnimalsS, "Animals");
        this.MoCSettings.append(maxWaterMobsS = new SettingInt("WaterMobSpawnLimit", 25, 1, 1, 1000));
        maxWaterMobsW = new WidgetInt(maxWaterMobsS, "Water Mobs");
        SimpleButtonModel var3 = new SimpleButtonModel();
        var3.addActionCallback(new ModAction(this, "animalsettings", new Class[0]));
        Button var4 = new Button(var3);
        var4.setText("Animals");
        this.MoCScreen.append(var4);
        this.MoCSettings.append(horsefreq = new SettingInt("FreqHorse", 6, 0, 1, 10));
        horsefreqW = new WidgetInt(horsefreq, "Horse Freq");
        this.MoCSettings.append(easybreeding = new SettingBoolean("EasyHorseBreeding", Boolean.valueOf(false)));
        easybreedingW = new WidgetBoolean(easybreeding, "Easy Horse Breed", "Yes", "No");
        this.MoCSettings.append(pegasusChanceS = new SettingInt("PegasusSpawningP", 1, 1, 1, 3));
        pegasusChanceW = new WidgetInt(pegasusChanceS, "Pegasus chance");
        this.MoCSettings.append(birdfreq = new SettingInt("FreqBird", 5, 0, 1, 10));
        birdfreqW = new WidgetInt(birdfreq, "Bird Freq");
        this.MoCSettings.append(bunnyfreq = new SettingInt("FreqBunny", 6, 0, 1, 10));
        bunnyfreqW = new WidgetInt(bunnyfreq, "Bunny Freq");
        this.MoCSettings.append(duckfreq = new SettingInt("FreqDuck", 6, 0, 1, 10));
        duckfreqW = new WidgetInt(duckfreq, "Duck Freq");
        this.MoCSettings.append(deerfreq = new SettingInt("FreqDeer", 6, 0, 1, 10));
        deerfreqW = new WidgetInt(deerfreq, "Deer Freq");
        this.MoCSettings.append(kittyfreq = new SettingInt("FreqKitty", 4, 0, 1, 10));
        kittyfreqW = new WidgetInt(kittyfreq, "Kitty Freq");
        this.MoCSettings.append(micefreq = new SettingInt("FreqMice", 7, 0, 1, 10));
        micefreqW = new WidgetInt(micefreq, "Mice Freq");
        this.MoCSettings.append(turtlefreq = new SettingInt("FreqTurtle", 6, 0, 1, 10));
        turtlefreqW = new WidgetInt(turtlefreq, "Turtle Freq");
        this.MoCSettings.append(goatfreq = new SettingInt("FreqGoat", 5, 0, 1, 10));
        goatfreqW = new WidgetInt(goatfreq, "Goat Freq");
        SimpleButtonModel var5 = new SimpleButtonModel();
        var5.addActionCallback(new ModAction(this, "huntersettings", new Class[0]));
        Button var6 = new Button(var5);
        var6.setText("Hunter Creatures");
        this.MoCScreen.append(var6);
        this.MoCSettings.append(attackhorses = new SettingBoolean("HuntersAttackHorses", Boolean.valueOf(false)));
        attackhorsesW = new WidgetBoolean(attackhorses, "Target horses?", "Yes", "No");
        this.MoCSettings.append(attackwolves = new SettingBoolean("HuntersAttackWolves", Boolean.valueOf(false)));
        attackwolvesW = new WidgetBoolean(attackwolves, "Target dogs?", "Yes", "No");
        this.MoCSettings.append(destroyitems = new SettingBoolean("HuntersDestroyDrops", Boolean.valueOf(true)));
        destroyitemsW = new WidgetBoolean(destroyitems, "Destroy drops?", "Yes", "No");
        this.MoCSettings.append(lionfreq = new SettingInt("FreqLion", 3, 0, 1, 10));
        lionfreqW = new WidgetInt(lionfreq, "BigCat Freq");
        this.MoCSettings.append(bearfreq = new SettingInt("FreqBear", 4, 0, 1, 10));
        bearfreqW = new WidgetInt(bearfreq, "Bear Freq");
        this.MoCSettings.append(pbearfreq = new SettingInt("FreqPBear", 3, 0, 1, 10));
        pbearfreqW = new WidgetInt(pbearfreq, "PBear Freq");
        this.MoCSettings.append(boarfreq = new SettingInt("FreqBoar", 4, 0, 1, 10));
        boarfreqW = new WidgetInt(boarfreq, "Boar Freq");
        this.MoCSettings.append(foxfreq = new SettingInt("FreqFox", 4, 0, 1, 10));
        foxfreqW = new WidgetInt(foxfreq, "Fox Freq");
        this.MoCSettings.append(crocfreq = new SettingInt("CrocFreq", 8, 0, 1, 10));
        crocfreqW = new WidgetInt(crocfreq, "Crocodile Freq");
        SimpleButtonModel var7 = new SimpleButtonModel();
        var7.addActionCallback(new ModAction(this, "mobsettings", new Class[0]));
        Button var8 = new Button(var7);
        var8.setText("Hostile Mobs");
        this.MoCScreen.append(var8);
        this.MoCSettings.append(ogrefreq = new SettingInt("FreqOgre", 6, 0, 1, 10));
        ogrefreqW = new WidgetInt(ogrefreq, "Ogre Freq");
        this.MoCSettings.append(ogreSpawnDifficulty = new SettingMulti("ogreSpawnDifficulty", 1, new String[] {"Easy", "Normal", "Hard"}));
        ogreSpawnDifficultyW = new WidgetMulti(ogreSpawnDifficulty, "Spawn Ogres in");
        this.MoCSettings.append(ogreStrength = new SettingFloat("OgreStrength", 2.5F, 0.1F, 0.1F, 5.0F));
        ogreStrengthW = new WidgetFloat(ogreStrength, "Ogre Strength");
        this.MoCSettings.append(fogrefreq = new SettingInt("FreqFOgre", 2, 0, 1, 10));
        fogrefreqW = new WidgetInt(fogrefreq, "F.Ogre Freq");
        this.MoCSettings.append(fogreSpawnDifficulty = new SettingMulti("FireOgreSpawnDifficulty", 2, new String[] {"Easy", "Normal", "Hard"}));
        fogreSpawnDifficultyW = new WidgetMulti(fogreSpawnDifficulty, "Spawn Fire O. in");
        this.MoCSettings.append(fogreStrength = new SettingFloat("FireOgreStrength", 2.0F, 0.1F, 0.1F, 5.0F));
        fogreStrengthW = new WidgetFloat(fogreStrength, "Fire O. Strength");
        this.MoCSettings.append(cogrefreq = new SettingInt("FreqCOgre", 3, 0, 1, 10));
        cogrefreqW = new WidgetInt(cogrefreq, "C.Ogre Freq");
        this.MoCSettings.append(cogreSpawnDifficulty = new SettingMulti("CaveOgreSpawnDifficulty", 1, new String[] {"Easy", "Normal", "Hard"}));
        cogreSpawnDifficultyW = new WidgetMulti(cogreSpawnDifficulty, "Spawn Cave O. in");
        this.MoCSettings.append(cogreStrength = new SettingFloat("CaveOgreStrength", 3.0F, 0.1F, 0.1F, 5.0F));
        cogreStrengthW = new WidgetFloat(cogreStrength, "Cave O. Strength");
        this.MoCSettings.append(ogrerange = new SettingInt("OgreRange", 12, 1, 1, 24));
        ogrerangeW = new WidgetInt(ogrerange, "Ogre Range");
        this.MoCSettings.append(werewolffreq = new SettingInt("FreqWereWolf", 6, 0, 1, 10));
        werewolffreqW = new WidgetInt(werewolffreq, "WereWolf Freq");
        this.MoCSettings.append(wereSpawnDifficulty = new SettingMulti("wereSpawnDifficulty", 1, new String[] {"Easy", "Normal", "Hard"}));
        wereSpawnDifficultyW = new WidgetMulti(wereSpawnDifficulty, "Spawn Werew. in");
        this.MoCSettings.append(wraithfreq = new SettingInt("FreqWraith", 5, 0, 1, 10));
        wraithfreqW = new WidgetInt(wraithfreq, "Wraith Freq");
        this.MoCSettings.append(wraithSpawnDifficulty = new SettingMulti("wraithSpawnDifficulty", 1, new String[] {"Easy", "Normal", "Hard"}));
        wraithSpawnDifficultyW = new WidgetMulti(wraithSpawnDifficulty, "Spawn Wraiths in");
        this.MoCSettings.append(fwraithfreq = new SettingInt("FreqFWraith", 2, 0, 1, 10));
        fwraithfreqW = new WidgetInt(fwraithfreq, "F.Wraith Freq");
        this.MoCSettings.append(fwraithSpawnDifficulty = new SettingMulti("flameWraithSpawnDifficulty", 2, new String[] {"Easy", "Normal", "Hard"}));
        fwraithSpawnDifficultyW = new WidgetMulti(fwraithSpawnDifficulty, "Spawn Flame W. in");
        this.MoCSettings.append(wwolffreq = new SettingInt("FreqWildWolf", 6, 0, 1, 10));
        wwolffreqW = new WidgetInt(wwolffreq, "WildWolf Freq");
        this.MoCSettings.append(ratfreq = new SettingInt("FreqRat", 8, 0, 1, 10));
        ratfreqW = new WidgetInt(ratfreq, "Rat Freq");
        this.MoCSettings.append(hellratfreq = new SettingInt("FreqHellRat", 7, 0, 1, 10));
        hellratfreqW = new WidgetInt(hellratfreq, "HellRat Freq");
        this.MoCSettings.append(scorpionfreq = new SettingInt("ScorpionFreq", 6, 0, 1, 10));
        scorpionfreqW = new WidgetInt(scorpionfreq, "Scorpion Freq");
        SimpleButtonModel var9 = new SimpleButtonModel();
        var9.addActionCallback(new ModAction(this, "watermobsettings", new Class[0]));
        Button var10 = new Button(var9);
        var10.setText("Water Mobs");
        this.MoCScreen.append(var10);
        this.MoCSettings.append(sharkfreq = new SettingInt("FreqShark", 2, 0, 1, 10));
        sharkfreqW = new WidgetInt(sharkfreq, "Shark Freq");
        this.MoCSettings.append(sharkSpawnDifficulty = new SettingMulti("sharkSpawnDifficulty", 0, new String[] {"Easy", "Normal", "Hard"}));
        sharkSpawnDifficultyW = new WidgetMulti(sharkSpawnDifficulty, "Spawn Sharks");
        this.MoCSettings.append(dolphinfreq = new SettingInt("FreqDolphin", 4, 0, 1, 10));
        dolphinfreqW = new WidgetInt(dolphinfreq, "Dolphin Freq");
        this.MoCSettings.append(attackdolphins = new SettingBoolean("DolphinsAttackSharks", Boolean.valueOf(true)));
        attackdolphinsW = new WidgetBoolean(attackdolphins, "Aggresive Dolphins?", "Yes", "No");
        this.MoCSettings.append(fishfreq = new SettingInt("FreqFishy", 15, 0, 1, 20));
        fishfreqW = new WidgetInt(fishfreq, "Fishy Freq");
        this.MoCSettings.append(spawnpiranha = new SettingBoolean("SpawnPiranhas", Boolean.valueOf(true)));
        spawnpiranhaW = new WidgetBoolean(spawnpiranha, "Spawn Piranhas?", "Yes", "No");
        this.MoCSettings.append(rayfreq = new SettingInt("FreqRays", 15, 0, 1, 20));
        rayfreqW = new WidgetInt(rayfreq, "Rays Freq");
        this.MoCSettings.append(jellyfishfreq = new SettingInt("FreqJellyFish", 15, 0, 1, 20));
        jellyfishfreqW = new WidgetInt(jellyfishfreq, "JellyFish Freq");
        SimpleButtonModel var11 = new SimpleButtonModel();
        var11.addActionCallback(new ModAction(this, "displaytagsettings", new Class[0]));
        Button var12 = new Button(var11);
        var12.setText("Other Settings");
        this.MoCScreen.append(var12);
        this.MoCSettings.append(displayname = new SettingBoolean("DisplayPetNames", Boolean.valueOf(true)));
        displaynameW = new WidgetBoolean(displayname, "Show Pet Name?", "Yes", "No");
        this.MoCSettings.append(displayhealth = new SettingBoolean("DisplayPetHealth", Boolean.valueOf(true)));
        displayhealthW = new WidgetBoolean(displayhealth, "Show Pet Health?", "Yes", "No");
        this.MoCSettings.append(displayemo = new SettingBoolean("DisplayPetEmotions", Boolean.valueOf(true)));
        displayemoW = new WidgetBoolean(displayemo, "Show Pet Icons?", "Yes", "No");
        this.MoCSettings.append(staticbed = new SettingBoolean("StaticKBeds", Boolean.valueOf(true)));
        staticbedW = new WidgetBoolean(staticbed, "Static K.Bed?", "Yes", "No");
        this.MoCSettings.append(staticlitter = new SettingBoolean("StaticLitter", Boolean.valueOf(true)));
        staticlitterW = new WidgetBoolean(staticlitter, "Static Litter?", "Yes", "No");
        SimpleButtonModel var13 = new SimpleButtonModel();
        var13.addActionCallback(new ModAction(this, "vanillamobs", new Class[0]));
        Button var14 = new Button(var13);
        var14.setText("Vanilla Mobs");
        this.MoCScreen.append(var14);
        this.MoCSettings.append(despawnVanilla = new SettingBoolean("DespawnVanilla", Boolean.valueOf(true)));
        despawnVanillaW = new WidgetBoolean(despawnVanilla, "Despawn vanilla mobs?", "Yes", "No");
        this.MoCSettings.append(modifyVanillaSpawns = new SettingBoolean("ChangeVanillaSpawns", Boolean.valueOf(false)));
        modifyVanillaSpawnsW = new WidgetBoolean(modifyVanillaSpawns, "Change vanilla spawns?", "Yes", "No");
        this.MoCSettings.append(isOldWorld = new SettingBoolean("isOldWorld", Boolean.valueOf(false)));
        isOldWorldW = new WidgetBoolean(isOldWorld, "Old World?", "Yes", "No");
        this.MoCSettings.append(cowfreq = new SettingInt("CowFreq", 3, 0, 1, 10));
        cowfreqW = new WidgetInt(cowfreq, "Cow Freq");
        this.MoCSettings.append(sheepfreq = new SettingInt("SheepFreq", 5, 0, 1, 10));
        sheepfreqW = new WidgetInt(sheepfreq, "Sheep Freq");
        this.MoCSettings.append(pigfreq = new SettingInt("PigFreq", 4, 0, 1, 10));
        pigfreqW = new WidgetInt(pigfreq, "Pig Freq");
        this.MoCSettings.append(chickenfreq = new SettingInt("ChickenFreq", 4, 0, 1, 10));
        chickenfreqW = new WidgetInt(chickenfreq, "Chicken Freq");
        this.MoCSettings.append(wolffreq = new SettingInt("WolfFreq", 5, 0, 1, 3));
        wolffreqW = new WidgetInt(wolffreq, "Wolf Freq");
        this.MoCSettings.append(squidfreq = new SettingInt("FreqSquid", 3, 0, 1, 3));
        squidfreqW = new WidgetInt(squidfreq, "Squid Freq");
        this.MoCSettings.append(zombiefreq = new SettingInt("ZombieFreq", 4, 0, 1, 10));
        zombiefreqW = new WidgetInt(zombiefreq, "Zombie Freq");
        this.MoCSettings.append(skeletonfreq = new SettingInt("SkeletonFreq", 4, 0, 1, 10));
        skeletonfreqW = new WidgetInt(skeletonfreq, "Skeleton Freq");
        this.MoCSettings.append(spiderfreq = new SettingInt("SpiderFreq", 4, 0, 1, 10));
        spiderfreqW = new WidgetInt(spiderfreq, "Spider Freq");
        this.MoCSettings.append(creeperfreq = new SettingInt("CreeperFreq", 4, 0, 1, 10));
        creeperfreqW = new WidgetInt(creeperfreq, "Creeper Freq");
        this.MoCSettings.append(enderfreq = new SettingInt("EnderFreq", 2, 0, 1, 10));
        enderfreqW = new WidgetInt(enderfreq, "Ender Freq");
        SimpleButtonModel var15 = new SimpleButtonModel();
        var15.addActionCallback(new ModAction(this.MoCSettings, "resetAll", new Class[0]));
        Button var16 = new Button(var15);
        var16.setText("Reset to defaults");
        this.MoCScreen.append(var16);
        this.MoCSettings.load();
    }

    public void spawnlimits()
    {
        if (this.spawnwindow == null)
        {
            WidgetClassicTwocolumn var1 = new WidgetClassicTwocolumn(new Widget[0]);
            var1.add(maxMobsW);
            var1.add(maxAnimalsW);
            var1.add(maxWaterMobsW);
            var1.add(isOldWorldW);
            this.spawnwindow = new WidgetSimplewindow(var1, "Spawn Settings");
        }

        GuiModScreen.show((Widget)this.spawnwindow);
    }

    public void animalsettings()
    {
        if (this.animalwindow == null)
        {
            WidgetClassicTwocolumn var1 = new WidgetClassicTwocolumn(new Widget[0]);
            var1.add(birdfreqW);
            var1.add(bunnyfreqW);
            var1.add(duckfreqW);
            var1.add(horsefreqW);
            var1.add(easybreedingW);
            var1.add(pegasusChanceW);
            var1.add(deerfreqW);
            var1.add(kittyfreqW);
            var1.add(micefreqW);
            var1.add(turtlefreqW);
            var1.add(goatfreqW);
            this.animalwindow = new WidgetSimplewindow(var1, "Pacific Creatures Settings");
        }

        GuiModScreen.show((Widget)this.animalwindow);
    }

    public void displaytagsettings()
    {
        if (this.displaytagwindow == null)
        {
            WidgetClassicTwocolumn var1 = new WidgetClassicTwocolumn(new Widget[0]);
            var1.add(displaynameW);
            var1.add(displayhealthW);
            var1.add(displayemoW);
            var1.add(staticbedW);
            var1.add(staticlitterW);
            this.displaytagwindow = new WidgetSimplewindow(var1, "Other Settings");
        }

        GuiModScreen.show((Widget)this.displaytagwindow);
    }

    public void huntersettings()
    {
        if (this.hunterwindow == null)
        {
            WidgetClassicTwocolumn var1 = new WidgetClassicTwocolumn(new Widget[0]);
            var1.add(attackhorsesW);
            var1.add(attackwolvesW);
            var1.add(destroyitemsW);
            var1.add(lionfreqW);
            var1.add(bearfreqW);
            var1.add(pbearfreqW);
            var1.add(boarfreqW);
            var1.add(foxfreqW);
            var1.add(crocfreqW);
            this.hunterwindow = new WidgetSimplewindow(var1, "Hunter Creatures Settings");
        }

        GuiModScreen.show((Widget)this.hunterwindow);
    }

    public void mobsettings()
    {
        if (this.mobwindow == null)
        {
            WidgetClassicTwocolumn var1 = new WidgetClassicTwocolumn(new Widget[0]);
            var1.add(ogrefreqW);
            var1.add(ogreSpawnDifficultyW);
            var1.add(ogreStrengthW);
            var1.add(fogrefreqW);
            var1.add(fogreSpawnDifficultyW);
            var1.add(fogreStrengthW);
            var1.add(cogrefreqW);
            var1.add(cogreSpawnDifficultyW);
            var1.add(cogreStrengthW);
            var1.add(ogrerangeW);
            var1.add(wwolffreqW);
            var1.add(wraithfreqW);
            var1.add(wraithSpawnDifficultyW);
            var1.add(fwraithfreqW);
            var1.add(fwraithSpawnDifficultyW);
            var1.add(werewolffreqW);
            var1.add(wereSpawnDifficultyW);
            var1.add(ratfreqW);
            var1.add(hellratfreqW);
            var1.add(scorpionfreqW);
            this.mobwindow = new WidgetSimplewindow(var1, "Hostile Mob Settings");
        }

        GuiModScreen.show((Widget)this.mobwindow);
    }

    public void vanillamobs()
    {
        if (this.vanillamobwindow == null)
        {
            WidgetClassicTwocolumn var1 = new WidgetClassicTwocolumn(new Widget[0]);
            var1.add(despawnVanillaW);
            var1.add(modifyVanillaSpawnsW);
            var1.add(cowfreqW);
            var1.add(pigfreqW);
            var1.add(sheepfreqW);
            var1.add(chickenfreqW);
            var1.add(wolffreqW);
            var1.add(squidfreqW);
            var1.add(zombiefreqW);
            var1.add(skeletonfreqW);
            var1.add(spiderfreqW);
            var1.add(creeperfreqW);
            var1.add(enderfreqW);
            this.vanillamobwindow = new WidgetSimplewindow(var1, "Vanilla Mobs Settings");
        }

        GuiModScreen.show((Widget)this.vanillamobwindow);
    }

    public void watermobsettings()
    {
        if (this.watermobwindow == null)
        {
            WidgetClassicTwocolumn var1 = new WidgetClassicTwocolumn(new Widget[0]);
            var1.add(sharkfreqW);
            var1.add(sharkSpawnDifficultyW);
            var1.add(dolphinfreqW);
            var1.add(attackdolphinsW);
            var1.add(fishfreqW);
            var1.add(spawnpiranhaW);
            var1.add(rayfreqW);
            var1.add(jellyfishfreqW);
            this.watermobwindow = new WidgetSimplewindow(var1, "Water Mobs Settings");
        }

        GuiModScreen.show((Widget)this.watermobwindow);
    }

    public static void renderHaze(float var0, String var1)
    {
        ScaledResolution var2 = new ScaledResolution(mc.gameSettings, mc.displayWidth, mc.displayHeight);
        int var3 = var2.getScaledWidth();
        int var4 = var2.getScaledHeight();
        GL11.glEnable(3042 /*GL_BLEND*/);
        GL11.glDisable(2929 /*GL_DEPTH_TEST*/);
        GL11.glDepthMask(false);
        GL11.glBlendFunc(770, 771);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, var0);
        GL11.glDisable(3008 /*GL_ALPHA_TEST*/);
        GL11.glBindTexture(3553 /*GL_TEXTURE_2D*/, mc.renderEngine.getTexture(var1));
        Tessellator var5 = Tessellator.instance;
        var5.startDrawingQuads();
        var5.addVertexWithUV(0.0D, (double)var4, -90.0D, 0.0D, 1.0D);
        var5.addVertexWithUV((double)var3, (double)var4, -90.0D, 1.0D, 1.0D);
        var5.addVertexWithUV((double)var3, 0.0D, -90.0D, 1.0D, 0.0D);
        var5.addVertexWithUV(0.0D, 0.0D, -90.0D, 0.0D, 0.0D);
        var5.draw();
        GL11.glDepthMask(true);
        GL11.glEnable(2929 /*GL_DEPTH_TEST*/);
        GL11.glEnable(3008 /*GL_ALPHA_TEST*/);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, var0);
    }

    public static void setName(MoCEntityAnimal var0)
    {
        var0.setDisplayName(true);
        mc.displayGuiScreen(new MoCGUI(var0, var0.getName()));
    }

    public static void setName(MoCEntityDolphin var0)
    {
        var0.setDisplayName(true);
        mc.displayGuiScreen(new MoCGUI(var0, var0.getName()));
    }

    public static void setName(MoCEntityShark var0)
    {
        var0.setDisplayName(true);
        mc.displayGuiScreen(new MoCGUI(var0, var0.getName()));
    }

    public static void sendNameInfo(int var0, String var1) {}

    public static void ClearVanillaSpawnLists()
    {
        ModLoader.RemoveSpawn(EntityCow.class, EnumCreatureType.creature);
        ModLoader.RemoveSpawn(EntityPig.class, EnumCreatureType.creature);
        ModLoader.RemoveSpawn(EntitySheep.class, EnumCreatureType.creature);
        ModLoader.RemoveSpawn(EntityChicken.class, EnumCreatureType.creature);
        ModLoader.RemoveSpawn(EntityWolf.class, EnumCreatureType.creature);
        ModLoader.RemoveSpawn(EntitySquid.class, EnumCreatureType.waterCreature);
    }

    public static void ClearVanillaMobSpawns()
    {
        ModLoader.RemoveSpawn(EntityCreeper.class, EnumCreatureType.monster);
        ModLoader.RemoveSpawn(EntitySkeleton.class, EnumCreatureType.monster);
        ModLoader.RemoveSpawn(EntityZombie.class, EnumCreatureType.monster);
        ModLoader.RemoveSpawn(EntitySpider.class, EnumCreatureType.monster);
        ModLoader.RemoveSpawn(EntityEnderman.class, EnumCreatureType.monster);
        ModLoader.RemoveSpawn(EntityCaveSpider.class, EnumCreatureType.monster);
        ModLoader.RemoveSpawn(EntityGhast.class, EnumCreatureType.monster);
        ModLoader.RemoveSpawn(EntityPigZombie.class, EnumCreatureType.monster);
    }

    public static void PopulateVanillaSpawnLists()
    {
        if (((Integer)cowfreq.get()).intValue() > 0)
        {
            ModLoader.AddSpawn(EntityCow.class, ((Integer)cowfreq.get()).intValue(), min, max, EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.extremeHills, BiomeGenBase.plains, BiomeGenBase.taiga, BiomeGenBase.swampland, BiomeGenBase.icePlains, BiomeGenBase.iceMountains, BiomeGenBase.ocean});
        }

        if (((Integer)pigfreq.get()).intValue() > 0)
        {
            ModLoader.AddSpawn(EntityPig.class, ((Integer)pigfreq.get()).intValue(), min, max, EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.extremeHills, BiomeGenBase.plains, BiomeGenBase.taiga, BiomeGenBase.swampland, BiomeGenBase.icePlains, BiomeGenBase.iceMountains, BiomeGenBase.ocean});
        }

        if (((Integer)sheepfreq.get()).intValue() > 0)
        {
            ModLoader.AddSpawn(EntitySheep.class, ((Integer)sheepfreq.get()).intValue(), min, max, EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.extremeHills, BiomeGenBase.plains, BiomeGenBase.taiga, BiomeGenBase.swampland, BiomeGenBase.icePlains, BiomeGenBase.iceMountains, BiomeGenBase.ocean});
        }

        if (((Integer)chickenfreq.get()).intValue() > 0)
        {
            ModLoader.AddSpawn(EntityChicken.class, ((Integer)chickenfreq.get()).intValue(), min, max, EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.extremeHills, BiomeGenBase.plains, BiomeGenBase.taiga, BiomeGenBase.swampland, BiomeGenBase.icePlains, BiomeGenBase.iceMountains, BiomeGenBase.ocean});
        }

        if (((Integer)wolffreq.get()).intValue() > 0)
        {
            ModLoader.AddSpawn(EntityWolf.class, ((Integer)wolffreq.get()).intValue(), min, max, EnumCreatureType.creature, new BiomeGenBase[] {BiomeGenBase.forest, BiomeGenBase.taiga, BiomeGenBase.icePlains, BiomeGenBase.iceMountains, BiomeGenBase.ocean});
        }

        if (((Integer)zombiefreq.get()).intValue() > 0)
        {
            ModLoader.AddSpawn(EntityZombie.class, ((Integer)zombiefreq.get()).intValue(), min, max, EnumCreatureType.monster);
        }

        if (((Integer)skeletonfreq.get()).intValue() > 0)
        {
            ModLoader.AddSpawn(EntitySkeleton.class, ((Integer)skeletonfreq.get()).intValue(), min, max, EnumCreatureType.monster);
        }

        if (((Integer)spiderfreq.get()).intValue() > 0)
        {
            ModLoader.AddSpawn(EntitySpider.class, ((Integer)spiderfreq.get()).intValue(), min, max, EnumCreatureType.monster);
        }

        if (((Integer)creeperfreq.get()).intValue() > 0)
        {
            ModLoader.AddSpawn(EntityCreeper.class, ((Integer)creeperfreq.get()).intValue(), min, max, EnumCreatureType.monster);
        }

        if (((Integer)enderfreq.get()).intValue() > 0)
        {
            ModLoader.AddSpawn(EntityEnderman.class, ((Integer)enderfreq.get()).intValue(), min, max, EnumCreatureType.monster);
        }

        if (((Integer)squidfreq.get()).intValue() > 0)
        {
            ModLoader.AddSpawn(EntitySquid.class, ((Integer)squidfreq.get()).intValue(), min, max, EnumCreatureType.waterCreature, new BiomeGenBase[] {BiomeGenBase.ocean, BiomeGenBase.river});
        }
    }
}
