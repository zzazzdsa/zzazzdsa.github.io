package net.minecraft.src;

import java.util.List;

public class MoCEntityAnimal extends EntityAnimal
{
    //private boolean isAdult;
    //private boolean chosenType;
    protected int maxHealth;
    //private float edad;
    //private boolean isTamed;
    private String myName = "";
    private boolean displayName;
    //private int type;
    public boolean textureSet = false;

    public MoCEntityAnimal(World var1)
    {
        super(var1);
        this.setTamed(false);
        this.setAdult(true);
    }
    
    protected void entityInit()
    {
        super.entityInit();
        this.dataWatcher.addObject(16, new Integer(0)); // bool isAdult
        this.dataWatcher.addObject(17, new Integer(0)); // bool isTamed
        this.dataWatcher.addObject(18, new Integer(0)); // bool chosenType
        this.dataWatcher.addObject(19, new Integer(0)); // int type
        this.dataWatcher.addObject(20, new Float(0).toString()); // edad
    }

    public boolean getDisplayName()
    {
        return this.displayName;
    }

    public boolean getIsAdult()
    {
        return (this.dataWatcher.getWatchableObjectInt(16) != 0);
    }

    public boolean getIsTamed()
    {
        return (this.dataWatcher.getWatchableObjectInt(17) != 0);
    }

    public String getName()
    {
        return this.myName;
    }

    public String getTexture()
    {
        return this.texture;
    }

    public float getEdad()
    {
        return Float.parseFloat(this.dataWatcher.getWatchableObjectString(20));
    }

    public int getType()
    {
        return this.dataWatcher.getWatchableObjectInt(19);
    }

    public boolean getTypeChosen()
    {
        return (this.dataWatcher.getWatchableObjectInt(18) != 0);
    }

    public void setEdad(float var1)
    {
    	if (!this.worldObj.isRemote)
    		this.dataWatcher.updateObject(20, Float.valueOf(var1).toString());
    }

    public void setAdult(boolean var1)
    {
    	if (!this.worldObj.isRemote)
    		this.dataWatcher.updateObject(16, new Integer(var1 ? 1 : 0));
    }

    public void setDisplayName(boolean var1)
    {
        this.displayName = var1;
    }

    public void setName(String var1)
    {
        this.myName = var1;
    }

    public void setTamed(boolean var1)
    {
    	if (!this.worldObj.isRemote)
    		this.dataWatcher.updateObject(17, new Integer(var1 ? 1 : 0));
    }

    public void setTexture(String var1)
    {
        this.texture = var1;
    }

    public void setTypeChosen(boolean var1)
    {
    	if (!this.worldObj.isRemote)
    		this.dataWatcher.updateObject(18, new Integer(var1 ? 1 : 0));
    }

    public void setType(int var1)
    {
    	if (!this.worldObj.isRemote)
    		this.dataWatcher.updateObject(19, new Integer(var1));
    }

    protected boolean canDespawn()
    {
        return !this.getIsTamed();
    }

    protected void despawnEntity2()
    {
        EntityPlayer var1 = this.worldObj.getClosestPlayerToEntity(this, -1.0D);
        if (this.canDespawn() && var1 != null)
        {
            double var2 = var1.posX - this.posX;
            double var4 = var1.posY - this.posY;
            double var6 = var1.posZ - this.posZ;
            double var8 = var2 * var2 + var4 * var4 + var6 * var6;
            if (var8 > 16384.0D)
            {
                this.setEntityDead();
            }

            if (this.entityAge > 600 && this.rand.nextInt(800) == 0)
            {
                if (var8 < 1024.0D)
                {
                    this.entityAge = 0;
                }
                else
                {
                    this.setEntityDead();
                }
            }
        }
    }

    protected EntityLiving getClosestEntityLiving(Entity var1, double var2)
    {
        double var4 = -1.0D;
        EntityLiving var6 = null;
        List var7 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(var2, var2, var2));

        for (int var8 = 0; var8 < var7.size(); ++var8)
        {
            Entity var9 = (Entity)var7.get(var8);
            if (!this.entitiesToIgnore(var9))
            {
                double var10 = var9.getDistanceSq(var1.posX, var1.posY, var1.posZ);
                if ((var2 < 0.0D || var10 < var2 * var2) && (var4 == -1.0D || var10 < var4) && ((EntityLiving)var9).canEntityBeSeen(var1))
                {
                    var4 = var10;
                    var6 = (EntityLiving)var9;
                }
            }
        }

        return var6;
    }

    public boolean entitiesToIgnore(Entity var1)
    {
        return !(var1 instanceof EntityLiving) || var1 instanceof EntityMob || var1 instanceof EntityPlayer && this.getIsTamed() || var1 instanceof MoCEntityKittyBed || var1 instanceof MoCEntityLitterBox || this.getIsTamed() && var1 instanceof MoCEntityAnimal && ((MoCEntityAnimal)var1).getIsTamed() || var1 instanceof EntityWolf && !((Boolean)mod_mocreatures.attackwolves.get()).booleanValue() || var1 instanceof MoCEntityHorse && !((Boolean)mod_mocreatures.attackhorses.get()).booleanValue();
    }

    public void runLikeHell(Entity var1)
    {
        double var2 = this.posX - var1.posX;
        double var4 = this.posZ - var1.posZ;
        double var6 = Math.atan2(var2, var4);
        var6 += (double)(this.rand.nextFloat() - this.rand.nextFloat()) * 0.75D;
        double var8 = this.posX + Math.sin(var6) * 8.0D;
        double var10 = this.posZ + Math.cos(var6) * 8.0D;
        int var12 = MathHelper.floor_double(var8);
        int var13 = MathHelper.floor_double(this.boundingBox.minY);
        int var14 = MathHelper.floor_double(var10);

        for (int var15 = 0; var15 < 16; ++var15)
        {
            int var16 = var12 + this.rand.nextInt(4) - this.rand.nextInt(4);
            int var17 = var13 + this.rand.nextInt(3) - this.rand.nextInt(3);
            int var18 = var14 + this.rand.nextInt(4) - this.rand.nextInt(4);
            if (var17 > 4 && (this.worldObj.getBlockId(var16, var17, var18) == 0 || this.worldObj.getBlockId(var16, var17, var18) == Block.snow.blockID) && this.worldObj.getBlockId(var16, var17 - 1, var18) != 0)
            {
                PathEntity var19 = this.worldObj.getEntityPathToXYZ(this, var16, var17, var18, 16.0F);
                this.setPathToEntity(var19);
                break;
            }
        }
    }

    protected EntityLiving getBoogey(double var1)
    {
        double var3 = -1.0D;
        EntityLiving var5 = null;
        List var6 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(var1, 4.0D, var1));

        for (int var7 = 0; var7 < var6.size(); ++var7)
        {
            Entity var8 = (Entity)var6.get(var7);
            if (this.entitiesToInclude(var8))
            {
                var5 = (EntityLiving)var8;
            }
        }

        return var5;
    }

    public boolean entitiesToInclude(Entity var1)
    {
        return var1 instanceof EntityLiving && ((double)var1.width >= 0.5D || (double)var1.height >= 0.5D);
    }

    public boolean attackEntityFrom(DamageSource var1, int var2)
    {
        if (this.isNotScared())
        {
            Entity var3 = this.entityToAttack;
            boolean var4 = super.attackEntityFrom(var1, var2);
            this.fleeingTick = 0;
            this.entityToAttack = var3;
            return var4;
        }
        else
        {
            return super.attackEntityFrom(var1, var2);
        }
    }

    public void onLivingUpdate()
    {
        if (this.isNotScared() && this.fleeingTick > 0)
        {
            this.fleeingTick = 0;
        }

        if (this.isSwimming() && this.swimmerEntity())
        {
            this.floating();
        }

        super.onLivingUpdate();
    }

    public boolean isNotScared()
    {
        return false;
    }

    public boolean swimmerEntity()
    {
        return false;
    }

    public boolean isSwimming()
    {
        return this.isInsideOfMaterial(Material.water);
    }

    public void setMaxHealth(int var1)
    {
        this.maxHealth = var1;
    }

    public void floating()
    {
        if (this.motionY < 0.0D)
        {
            this.motionY = 0.0D;
        }

        this.motionY += 0.001D;
        int var1 = (int)MoCTools.distanceToSurface(this);
        if (var1 > 1)
        {
            this.motionY += (double)var1 * 0.07D;
        }

        if (this.hasPath() && this.isCollidedHorizontally)
        {
            this.jump();
        }
    }

    public void bigsmack(Entity var1, Entity var2, float var3)
    {
        double var4 = var1.posX - var2.posX;

        double var6;
        for (var6 = var1.posZ - var2.posZ; var4 * var4 + var6 * var6 < 1.0E-4D; var6 = (Math.random() - Math.random()) * 0.01D)
        {
            var4 = (Math.random() - Math.random()) * 0.01D;
        }

        float var8 = MathHelper.sqrt_double(var4 * var4 + var6 * var6);
        var2.motionX /= 2.0D;
        var2.motionY /= 2.0D;
        var2.motionZ /= 2.0D;
        var2.motionX -= var4 / (double)var8 * (double)var3;
        var2.motionY += (double)var3;
        var2.motionZ -= var6 / (double)var8 * (double)var3;
        if (var2.motionY > (double)var3)
        {
            var2.motionY = (double)var3;
        }
    }

    public boolean isItemEdible(Item var1)
    {
        return var1 instanceof ItemFood || var1 instanceof ItemSeeds || var1.shiftedIndex == Item.wheat.shiftedIndex || var1.shiftedIndex == Item.sugar.shiftedIndex || var1.shiftedIndex == Item.cake.shiftedIndex || var1.shiftedIndex == Item.egg.shiftedIndex;
    }

    public boolean isInWater()
    {
        return this.swimmerEntity() ? false : super.isInWater();
    }

    public boolean canBreatheUnderwater()
    {
        return this.swimmerEntity();
    }

    public EntityItem getClosestItem(Entity var1, double var2, int var4, int var5)
    {
        double var6 = -1.0D;
        EntityItem var8 = null;
        List var9 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(var2, var2, var2));

        for (int var10 = 0; var10 < var9.size(); ++var10)
        {
            Entity var11 = (Entity)var9.get(var10);
            if (var11 instanceof EntityItem)
            {
                EntityItem var12 = (EntityItem)var11;
                if (var12.item.itemID == var4 || var12.item.itemID == var5)
                {
                    double var13 = var12.getDistanceSq(var1.posX, var1.posY, var1.posZ);
                    if ((var2 < 0.0D || var13 < var2 * var2) && (var6 == -1.0D || var13 < var6))
                    {
                        var6 = var13;
                        var8 = var12;
                    }
                }
            }
        }

        return var8;
    }

    public EntityItem getClosestEntityItem(Entity var1, double var2)
    {
        double var4 = -1.0D;
        EntityItem var6 = null;
        List var7 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(var2, var2, var2));

        for (int var8 = 0; var8 < var7.size(); ++var8)
        {
            Entity var9 = (Entity)var7.get(var8);
            if (var9 instanceof EntityItem)
            {
                EntityItem var10 = (EntityItem)var9;
                double var11 = var10.getDistanceSq(var1.posX, var1.posY, var1.posZ);
                if ((var2 < 0.0D || var11 < var2 * var2) && (var4 == -1.0D || var11 < var4))
                {
                    var4 = var11;
                    var6 = var10;
                }
            }
        }

        return var6;
    }

    public EntityItem getClosestFood(Entity var1, double var2)
    {
        double var4 = -1.0D;
        EntityItem var6 = null;
        List var7 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(var2, var2, var2));

        for (int var8 = 0; var8 < var7.size(); ++var8)
        {
            Entity var9 = (Entity)var7.get(var8);
            if (var9 instanceof EntityItem)
            {
                EntityItem var10 = (EntityItem)var9;
                if (this.isItemEdible(var10.item.getItem()))
                {
                    double var11 = var10.getDistanceSq(var1.posX, var1.posY, var1.posZ);
                    if ((var2 < 0.0D || var11 < var2 * var2) && (var4 == -1.0D || var11 < var4))
                    {
                        var4 = var11;
                        var6 = var10;
                    }
                }
            }
        }

        return var6;
    }

    public void faceLocation(int var1, int var2, int var3, float var4)
    {
        double var5 = (double)var1 - this.posX;
        double var7 = (double)var3 - this.posZ;
        double var9 = (double)var2 - this.posY;
        double var11 = (double)MathHelper.sqrt_double(var5 * var5 + var7 * var7);
        float var13 = (float)(Math.atan2(var7, var5) * 180.0D / 3.141592741012573D) - 90.0F;
        float var14 = (float)(Math.atan2(var9, var11) * 180.0D / 3.141592741012573D);
        this.rotationPitch = -this.adjustAngle(this.rotationPitch, var14, var4);
        this.rotationYaw = this.adjustAngle(this.rotationYaw, var13, var4);
    }

    public float adjustAngle(float var1, float var2, float var3)
    {
        float var4;
        for (var4 = var2 - var1; var4 < -180.0F; var4 += 360.0F)
        {
            ;
        }

        while (var4 >= 180.0F)
        {
            var4 -= 360.0F;
        }

        if (var4 > var3)
        {
            var4 = var3;
        }

        if (var4 < -var3)
        {
            var4 = -var3;
        }

        return var1 + var4;
    }

    public void getMyOwnPath(Entity var1, float var2)
    {
        PathEntity var3 = this.worldObj.getPathToEntity(this, var1, 16.0F);
        if (var3 != null)
        {
            this.setPathToEntity(var3);
        }
    }

    public void Riding()
    {
        if (this.riddenByEntity != null && this.riddenByEntity instanceof EntityPlayer)
        {
            EntityPlayer var1 = (EntityPlayer)this.riddenByEntity;
            List var2 = this.worldObj.getEntitiesWithinAABBExcludingEntity(this, this.boundingBox.expand(1.0D, 0.0D, 1.0D));
            if (var2 != null)
            {
                for (int var3 = 0; var3 < var2.size(); ++var3)
                {
                    Entity var4 = (Entity)var2.get(var3);
                    if (!var4.isDead)
                    {
                        var4.onCollideWithPlayer(var1);
                        if (var4 instanceof EntityMob)
                        {
                            float var5 = this.getDistanceToEntity(var4);
                            if (var5 < 2.0F && this.rand.nextInt(10) == 0)
                            {
                                this.attackEntityFrom(DamageSource.causeMobDamage((EntityLiving)var4), ((EntityMob)var4).attackStrength);
                            }
                        }
                    }
                }
            }

            if (var1.isSneaking() && !this.worldObj.isRemote)
            {
                var1.mountEntity((Entity)null);
            }
        }
    }

    public void heal(int var1)
    {
        if (this.health > 0)
        {
            this.health += var1;
            if (this.health > this.maxHealth)
            {
                this.health = this.maxHealth;
            }

            this.heartsLife = this.heartsHalvesLife / 2;
        }
    }

    protected void getPathOrWalkableBlock(Entity var1, float var2)
    {
        PathEntity var3 = this.worldObj.getPathToEntity(this, var1, 16.0F);
        if (var3 == null && var2 > 12.0F)
        {
            int var4 = MathHelper.floor_double(var1.posX) - 2;
            int var5 = MathHelper.floor_double(var1.posZ) - 2;
            int var6 = MathHelper.floor_double(var1.boundingBox.minY);

            for (int var7 = 0; var7 <= 4; ++var7)
            {
                for (int var8 = 0; var8 <= 4; ++var8)
                {
                    if ((var7 < 1 || var8 < 1 || var7 > 3 || var8 > 3) && this.worldObj.isBlockNormalCube(var4 + var7, var6 - 1, var5 + var8) && !this.worldObj.isBlockNormalCube(var4 + var7, var6, var5 + var8) && !this.worldObj.isBlockNormalCube(var4 + var7, var6 + 1, var5 + var8))
                    {
                        this.setLocationAndAngles((double)((float)(var4 + var7) + 0.5F), (double)var6, (double)((float)(var5 + var8) + 0.5F), this.rotationYaw, this.rotationPitch);
                        return;
                    }
                }
            }
        }
        else
        {
            this.setPathToEntity(var3);
        }
    }

    public int getMaxHealth()
    {
        return this.maxHealth;
    }

    protected EntityAnimal spawnBabyAnimal(EntityAnimal var1)
    {
        return null;
    }

    public boolean getCanSpawnHereAnimal()
    {
        int var1 = MathHelper.floor_double(this.posX);
        int var2 = MathHelper.floor_double(this.boundingBox.minY);
        int var3 = MathHelper.floor_double(this.posZ);
        return this.worldObj.getBlockId(var1, var2 - 1, var3) == Block.grass.blockID && this.worldObj.getFullBlockLightValue(var1, var2, var3) > 8;
    }

    public boolean getCanSpawnHereCreature()
    {
        int var1 = MathHelper.floor_double(this.posX);
        int var2 = MathHelper.floor_double(this.boundingBox.minY);
        int var3 = MathHelper.floor_double(this.posZ);
        return this.getBlockPathWeight(var1, var2, var3) >= 0.0F;
    }

    public boolean getCanSpawnHereLiving()
    {
        return this.worldObj.checkIfAABBIsClear(this.boundingBox) && this.worldObj.getCollidingBoundingBoxes(this, this.boundingBox).size() == 0 && !this.worldObj.isAnyLiquid(this.boundingBox);
    }

    public boolean getCanSpawnHereAquatic()
    {
        return this.worldObj.checkIfAABBIsClear(this.boundingBox);
    }

    public void writeEntityToNBT(NBTTagCompound var1)
    {
        super.writeEntityToNBT(var1);
        var1.setBoolean("Tamed", this.getIsTamed());
        var1.setBoolean("Adult", this.getIsAdult());
        var1.setFloat("Edad", this.getEdad());
    }

    public void readEntityFromNBT(NBTTagCompound var1)
    {
        super.readEntityFromNBT(var1);
        this.setTamed(var1.getBoolean("Tamed"));
        this.setAdult(var1.getBoolean("Adult"));
        this.setEdad(var1.getFloat("Edad"));
    }
}
