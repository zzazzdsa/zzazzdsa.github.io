package net.minecraft.src;


public class BlockRope extends Block
{

    protected BlockRope(int i, int j)
    {
        super(i, Material.plants);
        blockIndexInTexture = mod_Rope.rtex;
        float f = 0.1F;
        setBlockBounds(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, 1.0F, 0.5F + f);
    }

    public int getBlockTexture(IBlockAccess iblockaccess, int i, int j, int k, int l)
    {
        return mod_Rope.rtex;
    }

    public int getBlockTextureFromSide(int i)
    {
        return mod_Rope.rtex;
    }

    public void onBlockAdded(World world, int i, int j, int k)
    {
        byte xoffset = 0;
        byte zoffset = 0;
        byte ropeending = 0;
        if(world.getBlockId(i - 1, j, k + 0) == mod_Rope.rope.blockID)
        {
            xoffset = -1;
            zoffset = 0;
        }
        else if(world.getBlockId(i + 1, j, k + 0) == mod_Rope.rope.blockID)
        {
            xoffset = 1;
            zoffset = 0;
        }
        else if(world.getBlockId(i, j, k - 1) == mod_Rope.rope.blockID)
        {
            xoffset = 0;
            zoffset = -1;
        }
        else if(world.getBlockId(i, j, k + 1) == mod_Rope.rope.blockID)
        {
            xoffset = 0;
            zoffset = 1;
        }
        if(xoffset != 0 || zoffset != 0)
        {
            for(int length = 1; length <= 32; length++)
            {
                if((ropeending == 0) & world.isBlockOpaqueCube(i + xoffset, j - length, k + zoffset))
                {
                    ropeending = 2;
                }
                if((ropeending == 0) & (world.getBlockId(i + xoffset, j - length, k + zoffset) == 0))
                {
                    ropeending = 1;
                    world.setBlockWithNotify(i, j, k, 0);
                    world.setBlockWithNotify(i + xoffset, j - length, k + zoffset, mod_Rope.rope.blockID);
                }
            }

        }
        if((ropeending == 0 || ropeending == 2) & (world.getBlockId(i, j + 1, k) != mod_Rope.rope.blockID) && !world.isBlockOpaqueCube(i, j + 1, k))
        {
            dropBlockAsItem(world, i, j, k, world.getBlockMetadata(i, j, k), 0);
            world.setBlockWithNotify(i, j, k, 0);
        }
    }

    public void onNeighborBlockChange(World world, int i, int j, int k, int l)
    {
        super.onNeighborBlockChange(world, i, j, k, l);
        boolean blockstays = false;
        if(world.getBlockId(i - 1, j, k + 0) == mod_Rope.rope.blockID)
        {
            blockstays = true;
        }
        if(world.getBlockId(i + 1, j, k + 0) == mod_Rope.rope.blockID)
        {
            blockstays = true;
        }
        if(world.getBlockId(i, j, k - 1) == mod_Rope.rope.blockID)
        {
            blockstays = true;
        }
        if(world.getBlockId(i, j, k + 1) == mod_Rope.rope.blockID)
        {
            blockstays = true;
        }
        if(world.isBlockOpaqueCube(i, j + 1, k))
        {
            blockstays = true;
        }
        if(world.getBlockId(i, j + 1, k) == mod_Rope.rope.blockID)
        {
            blockstays = true;
        }
        if((world.getBlockId(i, j + 1, k) == 0) & (world.getBlockId(i, j + 2, k) != 0))
        {
            blockstays = true;
            world.setBlockWithNotify(i, j + 1, k, mod_Rope.rope.blockID);
            world.setBlockWithNotify(i, j, k, 0);
        }
        if(!blockstays)
        {
            dropBlockAsItem(world, i, j, k, world.getBlockMetadata(i, j, k), 0);
            world.setBlockWithNotify(i, j, k, 0);
        }
    }

    public boolean canPlaceBlockAt(World world, int i, int j, int k)
    {
        if(world.getBlockId(i - 1, j, k + 0) == mod_Rope.rope.blockID)
        {
            return true;
        }
        if(world.getBlockId(i + 1, j, k + 0) == mod_Rope.rope.blockID)
        {
            return true;
        }
        if(world.getBlockId(i, j, k - 1) == mod_Rope.rope.blockID)
        {
            return true;
        }
        if(world.getBlockId(i, j, k + 1) == mod_Rope.rope.blockID)
        {
            return true;
        }
        if(world.isBlockOpaqueCube(i, j + 1, k))
        {
            return true;
        }
        return world.getBlockId(i, j + 1, k) == mod_Rope.rope.blockID;
    }
	
    public void onBlockDestroyedByPlayer(World world, int a, int b, int c, int l)
    {
        byte xoffset = 0;
        byte zoffset = 0;
        if(world.getBlockId(a, b, c) == mod_Rope.rope.blockID)
        {
            xoffset = 0;
            zoffset = 0;
        }
        else if(world.getBlockId(a - 1, b, c + 0) == mod_Rope.rope.blockID)
        {
            xoffset = -1;
            zoffset = 0;
        }
        else if(world.getBlockId(a + 1, b, c + 0) == mod_Rope.rope.blockID)
        {
            xoffset = 1;
            zoffset = 0;
        }
        else if(world.getBlockId(a, b, c - 1) == mod_Rope.rope.blockID)
        {
            xoffset = 0;
            zoffset = -1;
        }
        else if(world.getBlockId(a, b, c + 1) == mod_Rope.rope.blockID)
        {
            xoffset = 0;
            zoffset = 1;
        }
        
        System.out.println("Player destroyed Rope block at "+a+","+b+","+c);
        System.out.println("Player destroyed Rope offsets: x="+xoffset+", z="+zoffset);
        
        a += xoffset;
        c += zoffset;    	
    	
		int[] coords = mod_Rope.areCoordsArrowRope(a, b, c);
		if (coords == null)
		{
			System.out.println("Player destroyed Rope is not Arrow Rope, going on");
			return;
		}
		
		int rope_max_y;
		int rope_min_y;
		
		for(int x = 0;; x++)
		{
			if (world.getBlockId(a, b+x, c) != mod_Rope.rope.blockID)
			{
				rope_max_y = b+x-1;
				System.out.println("Player destroyed Rope goes ["+(x-1)+"] blocks higher, up to "+a+","+rope_max_y+","+c);
				break;
			}
		}
		
		for(int x = 0;; x--)
		{
			if (world.getBlockId(a, b+x, c) != mod_Rope.rope.blockID)
			{
				rope_min_y = b+x+1;
				System.out.println("Player destroyed Rope goes ["+(x+1)+"] blocks lower, down to "+a+","+rope_min_y+","+c);
				break;
			}
		}
		
		int ropelenght = rope_max_y-rope_min_y;
		
		for(int x = 0; x <= ropelenght; x++)
		{
			coords = mod_Rope.areCoordsArrowRope(a, rope_min_y+x, c);
			
			world.setBlockWithNotify(a, rope_min_y+x, c, 0);
			
			if (coords != null)
			{
				mod_Rope.removeCoordsFromRopeArray(coords);
			}
		}
		
		System.out.println("Player destroyed Rope lenght: "+(rope_max_y-rope_min_y));
		
		if(!world.multiplayerWorld)
        {
			EntityItem entityitem = new EntityItem(world, a, b, c, new ItemStack(Item.stick));
			entityitem.delayBeforeCanPickup = 5;
			world.entityJoinedWorld(entityitem);
			
			entityitem = new EntityItem(world, a, b, c, new ItemStack(Item.feather));
			entityitem.delayBeforeCanPickup = 5;
			world.entityJoinedWorld(entityitem);
		}
		
		System.out.println("Rope destruction func finished");
		ModLoader.getMinecraftInstance().ingameGUI.addChatMessage("The Rope Arrow broke apart...");
	}

    public boolean isOpaqueCube()
    {
        return false;
    }

    public boolean renderAsNormalBlock()
    {
        return false;
    }

    public int getRenderType()
    {
        return 1;
    }
}
