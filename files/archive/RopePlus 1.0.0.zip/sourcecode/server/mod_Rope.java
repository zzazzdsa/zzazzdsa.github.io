package net.minecraft.src;
import java.util.*;
import net.minecraft.server.MinecraftServer;

public class mod_Rope extends BaseModMp
{
	public mod_Rope()
	{
		load();
	}

    public void load()
    {
        rtex = ModLoader.addOverride("/terrain.png", "/imgz/rope2.png");
        ModLoader.RegisterBlock(rope);
        
        ModLoader.AddRecipe(new ItemStack(rope, 12), new Object[] {
            " # ", " # ", " # ", Character.valueOf('#'), Item.silk
        });
		
		time = System.currentTimeMillis();
		ModLoader.SetInGameHook(this, true, false);
    }
	
	public void OnTickInGame(MinecraftServer minecraft)
	{
		if (minecraft.worldMngr == null || minecraft.worldMngr[0] == null) return;
		
		for(int x = 0; x < ropeEntArray.size(); x++)
		{
			Object temp = ropeEntArray.get(x);
			if (temp instanceof BlockRopePseudoEnt)
			{
				if (((BlockRopePseudoEnt) temp).OnUpdate())
				{
					ropeEntArray.remove(x);
				}
			}
			else if (temp instanceof ASTileEntityRope)
			{
				if (((ASTileEntityRope) temp).OnUpdate())
				{
					ropeEntArray.remove(x);
				}
			}
		}
	}
	
	public static void onRopeArrowHit(World world, int x, int y, int z)
	{
		int[] coords = new int[3];
		coords[0] = x;
		coords[1] = y;
		coords[2] = z;
		addCoordsToRopeArray(coords);
		
		BlockRopePseudoEnt newent = new BlockRopePseudoEnt(world, x, y, z, 31);
		addRopeToArray(newent);
	}
	
	public static void addRopeToArray(BlockRopePseudoEnt ent)
	{
		ropeEntArray.add(ent);
	}
	
	public static void addRopeToArray(ASTileEntityRope newent)
	{
		ropeEntArray.add(newent);
	}
	
	public static void addCoordsToRopeArray(int[] coords)
	{
		ropePosArray.add(coords);
	}
	
	public static void removeCoordsFromRopeArray(int[] coords)
	{
		ropePosArray.remove(coords);
	}
	
	public static int[] areCoordsArrowRope(int i, int j, int k)
	{
		for(int w = 0; w < ropePosArray.size(); w++)
		{
			int[] coords = (int[])ropePosArray.get(w);
			
			if (i == coords[0] && j == coords[1] && k == coords[2])
			{
				return coords;
			}
		}
		return null;
	}
	
	static java.util.List ropeEntArray = new ArrayList();
	static java.util.List ropePosArray = new ArrayList();
	
    public String Version()
    {
        return "1.0.0 AS";
    }
	
    public static int idBlock;
    public static Block rope;
    public static int rtex;
	private static long time;
	
    static
    {
    	AS_Settings_RopePlus.InitSettings();
    	
        idBlock = AS_Settings_RopePlus.blockIdRopeDJRoslin;
        rope = (new BlockRope(idBlock, rtex)).setHardness(0.3F).setStepSound(Block.soundMetalFootstep).setBlockName("rope");
    }
}
