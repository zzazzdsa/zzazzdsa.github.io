package atomicstryker.ropesplus.common;

public class CommonProxy
{
    public void load()
    {
        // NOOP
    }
}
