package net.minecraft.src;

import java.util.*;

/**
 * Control Class for AstarPath, creates workers and manages returns
 * 
 * @author AtomicStryker
 */

public class AS_AStarPath
{
	private volatile AS_AStarWorker worker;
	private World worldObj;
	private boolean isWorking = false;
	private ArrayList pathResult;
	private AS_IAStarPathedEntity pathedEntity;
	private long timeStarted = 0L;
	
	public AS_AStarPath(World worldObj)
	{
		this.worldObj = worldObj;
	}
	
	public AS_AStarPath(World worldObj, AS_IAStarPathedEntity ent)
	{
		this.worldObj = worldObj;
		pathedEntity = ent;
	}
	
	public boolean isBusy()
	{
		if (timeStarted != 0L && System.currentTimeMillis() - timeStarted > 5000L)
		{
			timeStarted = 0L;
			OnNoPathAvailable();
		}
		
		return isWorking;
	}
	
	public void getPath(int startx, int starty, int startz, int destx, int desty, int destz, boolean allowDropping)
	{
		AS_AStarNode starter = new AS_AStarNode(startx, starty, startz, 0);
		AS_AStarNode finish = new AS_AStarNode(destx, desty, destz, -1);;
		
		getPath(starter, finish, allowDropping);
	}
	
	public void getPath(AS_AStarNode start, AS_AStarNode end, boolean allowDropping)
	{
		if (isWorking)
		{
			stopPathSearch();
		}
		
		timeStarted = System.currentTimeMillis();
		worker = new AS_AStarWorker(this);
		worker.setup(worldObj, start, end, allowDropping);
		worker.start();
		isWorking = true;
	}
	
	public void OnFoundPath(ArrayList result)
	{
		flushWorker();
		pathResult = result;
		isWorking = false;
		
		if (pathedEntity != null)
		{
			pathedEntity.OnFoundPath(result);
		}
	}
	
	public void OnNoPathAvailable()
	{
		flushWorker();
		isWorking = false;
		
		if (pathedEntity != null)
		{
			pathedEntity.OnNoPathAvailable();
		}
	}
	
	public void stopPathSearch()
	{
		flushWorker();
		isWorking = false;
		
		if (pathedEntity != null)
		{
			pathedEntity.OnNoPathAvailable();
		}
	}
	
	private void flushWorker()
	{
		timeStarted = 0L;
		if (worker != null)
		{
			worker.interrupt();
			worker = null;
		}
	}
}