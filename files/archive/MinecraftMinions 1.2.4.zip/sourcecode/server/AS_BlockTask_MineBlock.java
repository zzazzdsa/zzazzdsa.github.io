package net.minecraft.src;

import java.util.*;

/**
 * Blocktask for destroying and stashing a single Block
 * 
 * 
 * @author AtomicStryker
 */

public class AS_BlockTask_MineBlock extends AS_BlockTask
{
    public Block targetBlock;
    private int blocksDropped = 0;
    public int blockID;
    public int blockmetadata;
    public boolean disableDangerCheck = false;
	
    public AS_BlockTask_MineBlock(AS_Minion_Job_Manager boss, AS_EntityMinion input, int ix, int iy, int iz)
    {
    	super(boss, input, ix, iy, iz);
    }

    public void onStartedTask()
    {
    	super.onStartedTask();
    }
    
    public void onReachedTaskBlock()
    {
    	super.onReachedTaskBlock();
    	
    	this.blockID = worker.worldObj.getBlockId(posX, posY, posZ);
    	//if (blockID > 13) System.out.println("Reached Block["+blockID+"], name "+Block.blocksList[blockID].getBlockName());
    	
    	if (blockID == 0)
    	{
    		this.onFinishedTask();
    	}
    	else
    	{
        	this.blockmetadata = worker.worldObj.getBlockMetadata(posX, posY, posZ);
        	this.targetBlock = Block.blocksList[blockID];
    	}
    }
    
    public void onUpdate()
    {
    	super.onUpdate();
    }
    
    public void onFinishedTask()
    {
    	super.onFinishedTask();
    	
    	checkDangers();
    	
    	this.blockID = worker.worldObj.getBlockId(posX, posY, posZ); // check against interference mining
    	//if (blockID > 13) System.out.println("Finished mining of Block["+blockID+"], name "+Block.blocksList[blockID].getBlockName());
    	if (blockID != 0 && Block.blocksList[blockID].getHardness() >= 0F && this.worker.worldObj.setBlockWithNotify(posX, posY, posZ, 0))
    	{
    		putBlockHarvestInWorkerInventory(posX, posY, posZ);
    	}
    }
    
    public void putBlockHarvestInWorkerInventory(int x, int y, int z)
    {
    	ItemStack stack = getItemStackFromWorldBlock(worker.worldObj, x, y, z);
    	
		if (stack != null && !this.worker.inventory.addItemStackToInventory(stack))
		{
			worker.inventoryFull = true;
			worker.worldObj.spawnEntityInWorld(new EntityItem(worker.worldObj, this.posX, this.posY, this.posZ, stack));
		}
    }
    
    public void checkDangers()
    {
    	if (!disableDangerCheck)
    	{
	    	// check adjacent blocks for fluids or holes, put safe blocks down
	    	checkBlockForDanger(posX, posY-1, posZ, true);
	    	//checkBlockForDanger(posX, posY+1, posZ);
	    	checkBlockForDanger(posX+1, posY, posZ);
	    	checkBlockForDanger(posX-1, posY, posZ);
	    	checkBlockForDanger(posX, posY, posZ+1);
	    	checkBlockForDanger(posX, posY, posZ-1);
    	}
    	
    	checkBlockForCaveIn(posX, posY+1, posZ);
    }
    
    private void checkBlockForCaveIn(int x, int y, int z)
    {
    	int checkBlockID = worker.worldObj.getBlockId(x, y, z);
    	
    	if (checkBlockID > 0)
    	{
    		if (checkBlockID == Block.sand.blockID || checkBlockID == Block.gravel.blockID)
    		{
    			putBlockHarvestInWorkerInventory(x, y, z);
    			
            	this.worker.inventory.consumeInventoryItem(Block.dirt.blockID);
            	this.worker.worldObj.setBlockWithNotify(x, y, z, Block.dirt.blockID);
    		}
    	}
	}
    
    private void checkBlockForDanger(int x, int y, int z)
    {
    	this.checkBlockForDanger(x, y, z, false);
    }
    
    private void checkBlockForDanger(int x, int y, int z, boolean putFloor)
    {
    	int checkBlockID = worker.worldObj.getBlockId(x, y, z);
    	int meta = 0;
    	boolean replaceBlock = false;
    	
    	if (checkBlockID == 0)
    	{
    		if (putFloor)
    		{
    			replaceBlock = true;
    		}
    	}
    	else if (!Block.blocksList[checkBlockID].blockMaterial.isSolid() && checkBlockID != Block.torchWood.blockID)
    	{
    		meta = worker.worldObj.getBlockMetadata(x, y, z);
    		replaceBlock = true;
    	}
    	
    	if (replaceBlock)
    	{    		
        	if (checkBlockID != 0 && this.worker.worldObj.setBlockWithNotify(x, y, z, 0))
        	{
        		putBlockHarvestInWorkerInventory(x, y, z);
        	}
        	
        	this.worker.inventory.consumeInventoryItem(Block.dirt.blockID);
        	this.worker.worldObj.setBlockWithNotify(x, y, z, Block.dirt.blockID);
    	}
    }
}
