package net.minecraft.src;

/**
 * Minion Job Manager superclass. Provides minion control methods and keeps a Workerlist.
 * Also interfaces with the main mod class.
 * 
 * @author AtomicStryker
 */

import java.util.ArrayList;
import java.util.Iterator;


public class AS_Minion_Job_Manager
{
	protected ArrayList workerList = new ArrayList();
	public ChunkCoordinates pointOfOrigin;
	protected ArrayList jobQueue = new ArrayList();
	public String masterName = null;
	
	public AS_Minion_Job_Manager()
	{
	}
	
    public AS_Minion_Job_Manager(AS_EntityMinion[] minions, int ix, int iy, int iz)
    {
    	int i = 0;
    	while (i < minions.length)
    	{
    		this.workerList.add(minions[i]);
    		
   			minions[i].currentState = AS_EnumMinionState.AWAITING_JOB;
    		minions[i].lastOrderedState = AS_EnumMinionState.WALKING_TO_COORDS;
    		
    		if (minions[i].riddenByEntity != null)
    		{
    			minions[i].riddenByEntity.mountEntity(null);
    		}
    		
    		if (masterName == null)
    		{
    			masterName = minions[i].masterUsername;
    		}
    		
    		i++;
    	}
    	
    	this.pointOfOrigin = new ChunkCoordinates(ix, iy, iz);
    }
    
    public AS_EntityMinion getNearestAvailableWorker(int x, int y, int z)
    {
    	Iterator<AS_EntityMinion> iter = workerList.iterator();
    	AS_EntityMinion temp;
    	AS_EntityMinion result = null;
    	
    	double distance = 9999D;
    	double distTemp;
    	
    	while (iter.hasNext())
    	{
    		temp = iter.next();
    		if ((temp.currentState == AS_EnumMinionState.AWAITING_JOB && !temp.hasTask())
    		|| (temp.currentState == AS_EnumMinionState.IDLE && temp.lastOrderedState == AS_EnumMinionState.RETURNING_GOODS))
    		{
    			distTemp = temp.getDistanceSq(x, y, z);
        		if (distTemp < distance)
        		{
        			result = temp;
        			distance = distTemp;
        		}
    		}
    	}
    	
    	return result;
    }
    
    public AS_EntityMinion getAnyAvailableWorker()
    {
    	if (workerList.isEmpty())
    	{
    		return null;
    	}
    	
    	Iterator<AS_EntityMinion> iter = workerList.iterator();
    	AS_EntityMinion temp;
    	
    	while (iter.hasNext())
    	{
    		temp = iter.next();
    		if (temp.currentState == AS_EnumMinionState.AWAITING_JOB && !temp.hasTask())
    		{
    			return temp;
    		}
    	}
    	
    	return null;
    }
    
    public void setWorkerFree(AS_EntityMinion input)
    {
    	input.giveTask(null);
    	workerList.remove(input);
    	
    	if (workerList.isEmpty())
    	{
    		this.onJobFinished();
    	}
    }
    
    public void onJobStarted()
    {
    	
    }
    
    public void onJobUpdateTick()
    {
    	
    }
    
    public void onJobFinished()
    {
    	while(!this.workerList.isEmpty())
    	{
    		this.setWorkerFree((AS_EntityMinion) this.workerList.get(0));
    	}
    	
    	mod_Minions.onJobHasFinished(this);
    }
}
