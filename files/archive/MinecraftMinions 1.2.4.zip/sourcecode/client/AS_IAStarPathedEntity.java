package net.minecraft.src;

import java.util.ArrayList;

/**
 * Smallest ever interface. One can create his own AStarPathed Entities with this.
 * 
 * 
 * @author AtomicStryker
 */

public interface AS_IAStarPathedEntity
{
	public void OnFoundPath(ArrayList result);
	
	public void OnNoPathAvailable();
}