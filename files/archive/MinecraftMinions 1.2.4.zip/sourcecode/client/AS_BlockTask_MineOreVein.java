package net.minecraft.src;

import java.util.*;

/**
 * Blocktask for destroying any number of interconnected Blocks
 * 
 * 
 * @author AtomicStryker
 */

public class AS_BlockTask_MineOreVein extends AS_BlockTask_MineBlock
{
    private ArrayList oreVeinBlocks;
	
    public AS_BlockTask_MineOreVein(AS_Minion_Job_Manager boss, AS_EntityMinion input, int ix, int iy, int iz)
    {
    	super(boss, input, ix, iy, iz);
    }
    
    public AS_BlockTask_MineOreVein(AS_Minion_Job_Manager boss, AS_EntityMinion input, ArrayList moreBlocks, int ix, int iy, int iz)
    {
    	super(boss, input, ix, iy, iz);
    	oreVeinBlocks = moreBlocks;
    }

    public void onStartedTask()
    {
    	super.onStartedTask();
    }
    
    public void onReachedTaskBlock()
    {
    	super.onReachedTaskBlock();

    	if (oreVeinBlocks == null)
    	{
    		oreVeinBlocks = new ArrayList();
    	}
    	checkAdjacentBlocks();
    }
    
    public void onUpdate()
    {
    	super.onUpdate();	
    }
    
    public void onTaskNotPathable()
    {
    	super.onTaskNotPathable();
    	
    	this.worker.dataWatcher.updateObject(12, Integer.valueOf(0));
    	
    	ChunkCoordinates check = new ChunkCoordinates(posX, posY, posZ);
		if (oreVeinBlocks != null && oreVeinBlocks.contains(check))
		{
			oreVeinBlocks.remove(check);
		}
		if (oreVeinBlocks != null && !oreVeinBlocks.isEmpty())
		{
			check = (ChunkCoordinates) oreVeinBlocks.get(0);
			AS_BlockTask_MineOreVein next = new AS_BlockTask_MineOreVein(boss, worker, oreVeinBlocks, check.posX, check.posY, check.posZ);
			worker.giveTask(next);
		}
		else
		{
	    	this.worker.currentState = AS_EnumMinionState.AWAITING_JOB;
	    	this.worker.giveTask(null, true);
		}
    }
    
    public void onFinishedTask()
    {
    	this.worker.dataWatcher.updateObject(12, Integer.valueOf(0));
    	checkDangers();
    	
    	this.blockID = worker.worldObj.getBlockId(posX, posY, posZ); // check against interference mining
    	checkBlockForCaveIn(posX, posY+1, posZ);
    	if (blockID != 0 && Block.blocksList[blockID].getHardness() >= 0F && blockID != Block.chest.blockID)
    	{
    		putBlockHarvestInWorkerInventory(posX, posY, posZ);
    		worker.worldObj.setBlockWithNotify(posX, posY, posZ, 0);
    	}
    	
    	checkForVeinContinueTask();
    }
    
    private void checkBlockForCaveIn(int x, int y, int z)
    {
    	int checkBlockID = worker.worldObj.getBlockId(x, y, z);
    	
    	if (checkBlockID > 0)
    	{
    		if (checkBlockID == Block.sand.blockID || checkBlockID == Block.gravel.blockID)
    		{            	
            	this.worker.inventory.consumeInventoryItem(Block.dirt.blockID);
            	this.worker.worldObj.setBlockWithNotify(x, y, z, Block.dirt.blockID);
    		}
    	}
	}
    
    private void checkForVeinContinueTask()
    {
    	if (oreVeinBlocks == null)
    	{
    		oreVeinBlocks = new ArrayList();
    	}
    	
    	ChunkCoordinates check = new ChunkCoordinates(posX, posY, posZ);
		if (oreVeinBlocks.contains(check))
		{
			oreVeinBlocks.remove(check);
		}
		
		if (!oreVeinBlocks.isEmpty())
		{
			check = (ChunkCoordinates) oreVeinBlocks.get(0);
			AS_BlockTask_MineOreVein next = new AS_BlockTask_MineOreVein(boss, worker, oreVeinBlocks, check.posX, check.posY, check.posZ);
			worker.giveTask(next);
		}
		else
		{
	    	this.worker.currentState = AS_EnumMinionState.AWAITING_JOB;
	    	this.worker.giveTask(null, true);
		}
	}

	public void checkAdjacentBlocks()
    {
    	// check adjacent blocks for being the same id
    	checkBlockForVein(posX, posY-1, posZ);
    	checkBlockForVein(posX, posY+1, posZ);
    	checkBlockForVein(posX+1, posY, posZ);
    	checkBlockForVein(posX-1, posY, posZ);
    	checkBlockForVein(posX, posY, posZ+1);
    	checkBlockForVein(posX, posY, posZ-1);
    }
    
    private void checkBlockForVein(int x, int y, int z)
    {
    	int checkBlockID = worker.worldObj.getBlockId(x, y, z);
    	if (!mod_Minions.isBlockValuable(checkBlockID))
    	{
    		return;
    	}

    	if (checkBlockID == this.blockID)
    	{
    		ChunkCoordinates check = new ChunkCoordinates(x, y, z);
    		if (!oreVeinBlocks.contains(check))
    		{
    			oreVeinBlocks.add(check);
    		}
    	}
    }
}
