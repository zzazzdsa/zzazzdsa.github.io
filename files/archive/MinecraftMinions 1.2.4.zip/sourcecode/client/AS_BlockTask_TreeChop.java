package net.minecraft.src;

import java.util.*;

/**
 * BlockTask dummy to compute tree chopping time, give out the Items, and destroy the tree. The actual work is done in the threaded AS_TreeScanner
 * 
 * 
 * @author AtomicStryker
 */

public class AS_BlockTask_TreeChop extends AS_BlockTask
{
    private ItemStack choppedTreeStack;  
    private final ArrayList<ChunkCoordinates> treeBlockList;
    private final ArrayList<ChunkCoordinates> leaveBlockList;
	
    public AS_BlockTask_TreeChop(AS_Minion_Job_Manager boss, AS_EntityMinion input, int ix, int iy, int iz, ArrayList treeBlocks, ArrayList leaveBlocks)
    {
    	super(boss, input, ix, iy, iz);
    	
    	treeBlockList = treeBlocks;
    	leaveBlockList = leaveBlocks;
    	this.setTaskDuration(1000L * treeBlockList.size());
    }

    public void onUpdate()
    {
    	super.onUpdate();
    }
    
    public void onFinishedTask()
    {
    	super.onFinishedTask();
    	
    	// count tree wood blocks, place wood in minion inventory, destroy tree
    	choppedTreeStack = this.getItemStackFromWorldBlock(worker.worldObj, posX, posY, posZ);
    	chopTree();
    	
    	if (choppedTreeStack != null && choppedTreeStack.stackSize > 0)
    	{
    		placeWoodInMinionInventory(this.worker);
    	}
    }
    
    private void placeWoodInMinionInventory(AS_EntityMinion output)
    {
    	choppedTreeStack.stackSize = treeBlockList.size();
    	
    	if (!output.inventory.addItemStackToInventory(choppedTreeStack))
    	{
    		EntityItem item = new EntityItem(output.worldObj, output.posX, output.posY - 0.30000001192092896D + (double)output.getEyeHeight(), output.posZ, choppedTreeStack);
    		item.delayBeforeCanPickup = 40;
    		output.worldObj.spawnEntityInWorld(item);
    	}
    }
    
    private void chopTree()
    {
    	ChunkCoordinates tempCoords;
    	for (int i = treeBlockList.size()-1; i >= 0; i--)
    	{
    		tempCoords = treeBlockList.get(i);
    		worker.worldObj.setBlockWithNotify(tempCoords.posX, tempCoords.posY, tempCoords.posZ, 0);
    	}
    	
    	if (leaveBlockList.size() > 0)
    	{
    		tempCoords = leaveBlockList.get(0);
    		int id = worker.worldObj.getBlockId(tempCoords.posX, tempCoords.posY, tempCoords.posZ);
    		if (id > 0)
    		{
    			Block leave = Block.blocksList[id];
    	    	for (int i = leaveBlockList.size()-1; i >= 0; i--)
    	    	{
    	    		tempCoords = leaveBlockList.get(i);
    	    		leave.dropBlockAsItem(worker.worldObj, tempCoords.posX, tempCoords.posY, tempCoords.posZ, worker.worldObj.getBlockMetadata(tempCoords.posX, tempCoords.posY, tempCoords.posZ), 0);
    	    		worker.worldObj.setBlockWithNotify(tempCoords.posX, tempCoords.posY, tempCoords.posZ, 0);
    	    	}
    		}
    	}
    }
}
