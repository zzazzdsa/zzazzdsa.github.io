package net.minecraft.src;

import java.util.*;

/**
 * Blocktask super schematic. By default a Blocktask doesnt change the Block.
 * 
 * 
 * @author AtomicStryker
 */

public class AS_BlockTask
{
	public AS_Minion_Job_Manager boss;
	public final int posX;
	public final int posY;
	public final int posZ;
	public boolean startedTask = false;
	public boolean finishedTask = false;
	public AS_EntityMinion worker;
	protected double accessRange = 4.0D;
	protected long taskDurationMillis = 1000L;
	public boolean isWorkerInRange = false;
	protected long timeBlockReached;
	protected AS_AStarNode[] possibleAccessNodes;
	protected int currentAccessNode;
	private long taskTimeStarted;
	private double startMinionX;
	private double startMinionZ;
	
    public AS_BlockTask(AS_Minion_Job_Manager boss, AS_EntityMinion input, int ix, int iy, int iz)
    {
    	//System.out.println("BlockTask created!");
    	this.boss = boss;
    	this.worker = input;
    	this.posX = ix;
    	this.posY = iy;
    	this.posZ = iz;
    }
    
    public void setWorker(AS_EntityMinion input)
    {
    	this.worker = input;
    }
    
    public void setAccessRange(double input)
    {
    	this.accessRange = input;
    }
    
    public void setTaskDuration(long input)
    {
    	this.taskDurationMillis = input;
    }
    
    public void onUpdate()
    {
    	if (!startedTask)
    	{
        	if (!worker.inventoryFull)
        	{
        		onStartedTask();
        	}
        	else
        	{
        		worker.currentState = AS_EnumMinionState.RETURNING_GOODS;
        		System.out.println("Blocktask worker is full, sending to return goods");
        	}
    	}
    	else if (!isWorkerInRange && System.currentTimeMillis() - taskTimeStarted > 3000L)
    	{
    		if (Math.abs(startMinionX - worker.posX) < 1D && Math.abs(startMinionZ - worker.posZ) < 1D)
    		{
    			onTaskNotPathable();
    		}
    		else
    		{
        		taskTimeStarted = System.currentTimeMillis();
        		startMinionX = worker.posX;
        		startMinionZ = worker.posZ;
    		}
    	}
    	
    	if (this.isWorking())
    	{
    		this.worker.faceBlock(posX, posY, posZ);
    		
    		this.worker.dataWatcher.updateObject(12, Integer.valueOf(1));
    		this.worker.dataWatcher.updateObject(13, Integer.valueOf(posX));
    		this.worker.dataWatcher.updateObject(14, Integer.valueOf(posY));
    		this.worker.dataWatcher.updateObject(15, Integer.valueOf(posZ));
    	}
    	
    	if (!isWorkerInRange)
    	{
    		if (Math.sqrt(this.worker.getDistanceSq(posX+0.5D, posY+0.5D, posZ+0.5D)) < accessRange)
    		{
        		this.onReachedTaskBlock();
        		isWorkerInRange = true;
    		}
    	}
    	else if ((System.currentTimeMillis() - timeBlockReached) > (taskDurationMillis/worker.workSpeed))
    	{
    		this.onFinishedTask();
    	}
    }
    
    public void onWorkerPathFailed()
    {
    	if (possibleAccessNodes != null && this.currentAccessNode < possibleAccessNodes.length-1)
    	{
    		this.currentAccessNode++;
    		this.worker.orderMinionToMoveTo(possibleAccessNodes[currentAccessNode].x, possibleAccessNodes[currentAccessNode].y, possibleAccessNodes[currentAccessNode].z, false);
    		// System.out.println("BlockTask onWorkerPathFailed assigning next path");
    	}
    	else
    	{
    		// System.out.println("BlockTask onWorkerPathFailed all paths failed, teleporting dat minion");
    		this.worker.setPositionAndUpdate(possibleAccessNodes[currentAccessNode].x, possibleAccessNodes[currentAccessNode].y, possibleAccessNodes[currentAccessNode].z);
    	}
    }
    
    public void onReachedTaskBlock()
    {
    	// System.out.println("BlockTask onReachedTaskBlock");
    	timeBlockReached = System.currentTimeMillis();
    	this.worker.currentState = AS_EnumMinionState.MINING;
    	this.worker.setPathToEntity(null);
    }
    
    public void onStartedTask()
    {
    	// System.out.println("onStartedTask ["+this.posX+"|"+this.posY+"|"+this.posZ+"]");
    	if (startedTask) return;
    	startedTask = true;
    	
    	taskTimeStarted = System.currentTimeMillis();
    	startMinionX = worker.posX;
    	startMinionZ = worker.posZ;
    	
    	this.worker.currentState = AS_EnumMinionState.THINKING;
    	this.currentAccessNode = 0;
    	this.possibleAccessNodes = getAccessNodesSorted((int)Math.floor(worker.posX), (int)Math.floor(worker.posY)-1, (int)Math.floor(worker.posZ));
    	
    	if (this.possibleAccessNodes.length != 0)
    	{
    		// System.out.println("Ordering Minion to move to possible path no.: "+currentAccessNode);
    		this.worker.orderMinionToMoveTo(possibleAccessNodes[currentAccessNode].x, possibleAccessNodes[currentAccessNode].y, possibleAccessNodes[currentAccessNode].z, false);
    		this.worker.currentState = AS_EnumMinionState.WALKING_TO_COORDS;
    	}
    	else
    	{
    		this.onTaskNotPathable();
    	}
    }
    
    public void onTaskNotPathable()
    {
    	// System.out.println("onTaskNotPathable ["+this.posX+"|"+this.posY+"|"+this.posZ+"], skipping task");
    	this.worker.dataWatcher.updateObject(12, Integer.valueOf(0));
    	this.worker.currentState = AS_EnumMinionState.AWAITING_JOB;
    	this.worker.giveTask(null, true);
    }
    
    public void onFinishedTask()
    {
    	if (finishedTask) return;
    	finishedTask = true;
    	
    	// System.out.println("onFinishedTask ["+this.posX+"|"+this.posY+"|"+this.posZ+"], resetting minion");
    	this.worker.dataWatcher.updateObject(12, Integer.valueOf(0));
    	this.worker.currentState = AS_EnumMinionState.AWAITING_JOB;
    	this.worker.giveTask(null, true);
    }
    
    public boolean isWorking()
    {
    	return isWorkerInRange;
    }
    
    public boolean isEntityInAccessRange(EntityLiving ent)
    {
    	return (ent.getDistanceSq(this.posX, this.posY, this.posZ) < accessRange);
    }
    
    // returns an Array of pathable AStarNodes, starting with the closest one to parameter coordinates and ascending
    public AS_AStarNode[] getAccessNodesSorted(int workerX, int workerY, int workerZ)
    {
    	return AS_AStarStatic.getAccessNodesSorted(worker.worldObj, workerX, workerY, workerZ, posX, posY, posZ);
    }
    
    public ItemStack getItemStackFromWorldBlock(World world, int i, int j, int k)
    {
    	Block block = Block.blocksList[world.getBlockId(i, j, k)];
    	if (block == null
    	|| block.blockMaterial == Material.water
    	|| block.blockMaterial == Material.lava
    	|| block.blockMaterial == Material.leaves
    	|| block.blockMaterial == Material.plants)
    	{
    		return null;
    	}
    	
    	int blockMeta = world.getBlockMetadata(i, j, k);
    	int idDropped = block.idDropped(blockMeta, world.rand, 0);
    	int amountDropped = block.quantityDropped(world.rand);
    	int damageDropped = block.damageDropped(blockMeta);
    	
    	if (idDropped <= 0 || amountDropped == 0)
    	{
    		return null;
    	}
    	else
    	{    	
    		return new ItemStack(idDropped, amountDropped, damageDropped);
    	}
    }
    
    @Override
    public boolean equals(Object o)
    {
    	if (o instanceof AS_BlockTask)
    	{
    		AS_BlockTask checktask = (AS_BlockTask) o;
    		return (this.posX == checktask.posX && this.posY == checktask.posY && this.posZ == checktask.posZ);
    	}
    	return false;	
    }
}
