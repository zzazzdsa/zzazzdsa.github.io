package net.minecraft.src;

import java.util.*;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;
import static org.lwjgl.opengl.GL11.*;

/**
 * Minion Menu, provides access to evil deeds and later minion commands
 * 
 * 
 * @author AtomicStryker
 */

public class AS_GuiMinionMenu extends GuiScreen
{
    protected String screenTitle = "The Darkness listens...";
    private EntityPlayer playerBoss;
    private int updateCounter;
    
    private int actionCalled;

    public AS_GuiMinionMenu(EntityPlayer caller)
    {
        this.playerBoss = caller;
    }

    @Override
    public void initGui()
    {
        this.controlList.clear();
        
        this.controlList.add(new GuiButton(0, this.width / 2 - 100, this.height / 4 + 120, "Nevermind"));
        
        if (mod_Minions.hasPlayerMinions(playerBoss))
        {
        	this.controlList.add(new GuiButton(2, this.width / 2 - 100, this.height / 4 + 40, "Dig Mineshaft"));
        	this.controlList.add(new GuiButton(3, this.width / 2 - 100, this.height / 4 + 80, "Strip Mine"));
        }
        else if (mod_Minions.evilDeedXPCost > -1 && playerBoss.experienceLevel >= mod_Minions.evilDeedXPCost)
        {
        	this.controlList.add(new GuiButton(1, this.width / 2 - 100, this.height / 4 + 0, "Commit to Evil"));
        }
        
        mod_Minions.requestXPSettingFromServer();
    }

    @Override
    public void onGuiClosed()
    {

    }

    @Override
    public void updateScreen()
    {
        ++this.updateCounter;
    }

    @Override
    protected void actionPerformed(GuiButton var1)
    {
        if (var1.enabled)
        {
        	int ID = var1.id;
        	this.actionCalled = ID;
        	
        	if (ID == 0)
        	{
        		this.mc.displayGuiScreen((GuiScreen)null);
        	}
        	else if (ID == 1)
        	{
        		this.mc.displayGuiScreen(new AS_GuiDeedMenu(playerBoss));
        	}
        	else if (ID == 2)
        	{
            	mod_Minions.isSelectingMineArea = !mod_Minions.isSelectingMineArea;
                this.mc.displayGuiScreen((GuiScreen)null);
                mod_Minions.mineAreaShape = 0;
        	}
        	else if (ID == 3)
        	{
            	mod_Minions.isSelectingMineArea = !mod_Minions.isSelectingMineArea;
            	mod_Minions.mineAreaShape = 1;
                this.mc.displayGuiScreen((GuiScreen)null);
        	}
        }
    }
    
    private int cheatCount = 0;

    @Override
    protected void keyTyped(char var1, int var2)
    {
    	if (var1 == 'i' && cheatCount == 0) cheatCount++;
    	if (var1 == 'l' && cheatCount == 1) cheatCount++;
    	if (var1 == 'u' && cheatCount == 2) cheatCount++;
    	if (var1 == 'v' && cheatCount == 3) cheatCount++;
    	if (var1 == 'e' && cheatCount == 4) cheatCount++;
    	if (var1 == 'v' && cheatCount == 5) cheatCount++;
    	if (var1 == 'i' && cheatCount == 6) cheatCount++;
    	if (var1 == 'l' && cheatCount == 7)
    	{
    		if (playerBoss.worldObj.isRemote)
    		{
				Packet230ModLoader packet = new Packet230ModLoader();
				packet.packetType = 666; // cheater!!!!
				ModLoaderMp.sendPacket(mod_Minions.instance, packet);
				
    			this.mc.displayGuiScreen((GuiScreen)null);
    		}
    		else
    		{
        		playerBoss.addExperience(200);
        		this.mc.displayGuiScreen((GuiScreen)null);
    		}
    	}
    }

    @Override
    public void drawScreen(int var1, int var2, float var3)
    {
    	this.drawDefaultBackground();
    	this.drawCenteredString(this.fontRenderer, this.screenTitle, this.width / 2, 40, 16777215);
    	GL11.glPushMatrix();
    	GL11.glTranslatef((float)(this.width / 2), 0.0F, 50.0F);
    	float var4 = 93.75F;
    	GL11.glScalef(-var4, -var4, -var4);
    	GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);

    	GL11.glPopMatrix();
    	super.drawScreen(var1, var2, var3);
    }
}
