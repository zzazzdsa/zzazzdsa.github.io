package net.minecraft.src;

import net.minecraft.src.*;

public class ItemMagicYarn extends Item
{
	private AStarNode origin = null;
	private AStarNode target = null;

	public ItemMagicYarn(int var1)
	{
		super(var1);
		this.setMaxDamage(64);
		this.setMaxStackSize(1);
	}

	@Override
	public boolean isFull3D()
	{
		return true;
	}

	@Override
	public boolean shouldRotateAroundWhenRendering()
	{
		return true;
	}

	@Override
	public void onPlayerStoppedUsing(ItemStack var1, World var2, EntityPlayer var3, int var4)
	{
		int var5 = this.getMaxItemUseDuration(var1) - var4;
		float var6 = (float)var5 / 20.0F;
		var6 = (var6 * var6 + var6 * 2.0F) / 3.0F;

		if(var6 > 2.5F)
		{
			var6 = 2.5F;
		}

		if(var6 < 2.5F)
		{
			if(origin == null)
			{		
				origin = new AStarNode((int)Math.floor(var3.posX), (int)Math.floor(var3.posY)-1, (int)Math.floor(var3.posZ), 0);
				System.out.println("Magic Yarn Origin set to ["+origin.x+"|"+origin.y+"|"+origin.z+"]");
				var2.playSoundAtEntity(var3, "random.orb", 1.0F, 1.0F);
				mod_MagicYarn.showPath = false;
			}
			else
			{
				if (target == null && mod_MagicYarn.path == null)
				{					
					target = new AStarNode((int)Math.floor(var3.posX), (int)var3.posY-1, (int)Math.floor(var3.posZ), 0);
					System.out.println("Magic Yarn Target set to ["+target.x+"|"+target.y+"|"+target.z+"]");

					AStarPath.getPath(origin, target, false, (var6 < 0.5F));
					mod_MagicYarn.showPath = true;
				}
				else
				{
					boolean soundplayed = false;
					if (mod_MagicYarn.path != null)
					{
						target = new AStarNode((int)Math.floor(var3.posX), (int)Math.floor(var3.posY)-1, (int)Math.floor(var3.posZ), 0);
						for (int i = mod_MagicYarn.path.size()-1; i != 0; i--)
						{
							if (((AStarNode) mod_MagicYarn.path.get(i)).equals(target))
							{
								System.out.println("Magic Yarn being cut shorter!");
								var2.playSoundAtEntity(var3, "random.break", 1.0F, 1.0F);
								soundplayed = true;
								while (i >= 0)
								{
									mod_MagicYarn.path.remove(i);
									i--;
								}
								break;
							}
						}
					}
					
					target = null;
					mod_MagicYarn.inputPath(null, true);
					AStarPath.stopPathSearch();
					System.out.println("Magic Yarn Target nulled");
					if (!soundplayed)
					{
						var2.playSoundAtEntity(var3, "random.pop", 1.0F, 1.0F);
					}
					mod_MagicYarn.showPath = false;
				}
			}
		}
		else
		{
			if(origin != null)
			{
				origin = null;
				target = null;
				mod_MagicYarn.inputPath(null, true);
				mod_MagicYarn.lastPath = null;
				AStarPath.stopPathSearch();
				System.out.println("Magic Yarn Origin nulled");
				var2.playSoundAtEntity(var3, "random.fizz", 1.0F, 1.0F);
				mod_MagicYarn.showPath = false;
			}
		}
	}

	@Override
	public ItemStack onItemRightClick(ItemStack var1, World var2, EntityPlayer var3)
	{
		var3.setItemInUse(var1, this.getMaxItemUseDuration(var1));
		return var1;
	}

	@Override
	public int getMaxItemUseDuration(ItemStack var1)
	{
		return 72000;
	}

	@Override
	public EnumAction getItemUseAction(ItemStack var1) {
		return EnumAction.bow;
	}
}
