package net.minecraft.src;

import org.lwjgl.input.Keyboard;

import net.minecraft.client.Minecraft;
import net.minecraft.src.*;

public class MPMagicYarn
{
	private AStarNode origin = null;
	private AStarNode target = null;
	
	private Minecraft mcinstance;
	
	private long timeStartedHoldingButton = 0L;
	private boolean isHoldingButton = false;
	
	private String sTriggerKey = "J";
	private int triggerKey = Keyboard.getKeyIndex(sTriggerKey);
	
	private AS_Settings_MagicYarn settings;

	public MPMagicYarn(Minecraft mc)
	{
		mcinstance = mc;
		
		settings = new AS_Settings_MagicYarn();
		sTriggerKey = settings.sTriggerKey;
		triggerKey = settings.triggerKey;
	}
	
	public void onUpdate(World worldObj)
	{
		if (worldObj.isRemote)
		{
			if (isHoldingButton != Keyboard.isKeyDown(triggerKey))
			{
				if (timeStartedHoldingButton == 0L)
				{
					timeStartedHoldingButton = System.currentTimeMillis();
				}
				else
				{
					onPlayerStoppedUsing(worldObj, mcinstance.thePlayer, (float)((System.currentTimeMillis()-timeStartedHoldingButton)/1000));
					timeStartedHoldingButton = 0L;
				}
				
				isHoldingButton = Keyboard.isKeyDown(triggerKey);
			}
		}
	}

	private void onPlayerStoppedUsing(World var2, EntityPlayer var3, float timeButtonHeld)
	{
		if(timeButtonHeld > 2.5F)
		{
			timeButtonHeld = 2.5F;
		}

		if(timeButtonHeld < 2.5F)
		{
			if(origin == null)
			{		
				origin = new AStarNode((int)Math.floor(var3.posX), (int)Math.floor(var3.posY)-1, (int)Math.floor(var3.posZ), 0);
				System.out.println("Magic Yarn Origin set to ["+origin.x+"|"+origin.y+"|"+origin.z+"]");
				var2.playSoundAtEntity(var3, "random.orb", 1.0F, 1.0F);
				mod_MagicYarn.showPath = false;
			}
			else
			{
				if (target == null && mod_MagicYarn.path == null)
				{					
					target = new AStarNode((int)Math.floor(var3.posX), (int)var3.posY-1, (int)Math.floor(var3.posZ), 0);
					System.out.println("Magic Yarn Target set to ["+target.x+"|"+target.y+"|"+target.z+"]");

					AStarPath.getPath(origin, target, false, (timeButtonHeld < 0.5F));
					mod_MagicYarn.showPath = true;
				}
				else
				{
					boolean soundplayed = false;
					if (mod_MagicYarn.path != null)
					{
						target = new AStarNode((int)Math.floor(var3.posX), (int)Math.floor(var3.posY)-1, (int)Math.floor(var3.posZ), 0);
						for (int i = mod_MagicYarn.path.size()-1; i != 0; i--)
						{
							if (((AStarNode) mod_MagicYarn.path.get(i)).equals(target))
							{
								System.out.println("Magic Yarn being cut shorter!");
								var2.playSoundAtEntity(var3, "random.break", 1.0F, 1.0F);
								soundplayed = true;
								while (i >= 0)
								{
									mod_MagicYarn.path.remove(i);
									i--;
								}
								break;
							}
						}
					}
					
					target = null;
					mod_MagicYarn.inputPath(null, true);
					AStarPath.stopPathSearch();
					System.out.println("Magic Yarn Target nulled");
					if (!soundplayed)
					{
						var2.playSoundAtEntity(var3, "random.pop", 1.0F, 1.0F);
					}
					mod_MagicYarn.showPath = false;
				}
			}
		}
		else
		{
			if(origin != null)
			{
				origin = null;
				target = null;
				mod_MagicYarn.inputPath(null, true);
				mod_MagicYarn.lastPath = null;
				AStarPath.stopPathSearch();
				System.out.println("Magic Yarn Origin nulled");
				var2.playSoundAtEntity(var3, "random.fizz", 1.0F, 1.0F);
				mod_MagicYarn.showPath = false;
			}
		}
	}
}
