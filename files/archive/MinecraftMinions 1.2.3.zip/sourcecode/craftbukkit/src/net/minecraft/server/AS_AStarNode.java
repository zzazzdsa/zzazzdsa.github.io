package net.minecraft.server;

public class AS_AStarNode
{
    public final int x;
    public final int y;
    public final int z;
    public AS_AStarNode parent = null;
    public int parentxoffset;
    public int parentyoffset;
    public int parentzoffset;
    public int g_BlockDistToStart;
    public double f_distanceToGoal;
    public double h_reachCost;

    public AS_AStarNode(int var1, int var2, int var3, int var4)
    {
        this.x = var1;
        this.y = var2;
        this.z = var3;
        this.g_BlockDistToStart = var4;
    }

    public AS_AStarNode(int var1, int var2, int var3, int var4, AS_AStarNode var5)
    {
        this.x = var1;
        this.y = var2;
        this.z = var3;
        this.g_BlockDistToStart = var4;
        this.parent = var5;
        this.updateParentOffset();
    }

    public void updateReachCost(double var1)
    {
        this.f_distanceToGoal = var1;
        this.h_reachCost = (double)this.g_BlockDistToStart + this.f_distanceToGoal;
    }

    public boolean updateDistance(int var1, AS_AStarNode var2)
    {
        if (var1 < this.g_BlockDistToStart)
        {
            this.g_BlockDistToStart = var1;
            this.h_reachCost = (double)this.g_BlockDistToStart + this.f_distanceToGoal;
            this.parent = var2;
            this.updateParentOffset();
            return true;
        }
        else
        {
            return false;
        }
    }

    public void updateParentOffset()
    {
        this.parentxoffset = this.parent.x - this.x;
        this.parentyoffset = this.parent.y - this.y;
        this.parentzoffset = this.parent.z - this.z;
    }

    public boolean equals(Object var1)
    {
        if (var1 instanceof AS_AStarNode)
        {
            AS_AStarNode var2 = (AS_AStarNode)var1;

            if (var2.hashCode() == this.hashCode() && var2.x == this.x && var2.y == this.y && var2.z == this.z)
            {
                return true;
            }
        }

        return false;
    }

    public int compare(Object var1, Object var2)
    {
        if (var1 instanceof AS_AStarNode && var2 instanceof AS_AStarNode)
        {
            AS_AStarNode var3 = (AS_AStarNode)var1;
            AS_AStarNode var4 = (AS_AStarNode)var2;
            return var3.h_reachCost == var4.h_reachCost ? 0 : (var3.h_reachCost < var4.h_reachCost ? -1 : 1);
        }
        else
        {
            return 0;
        }
    }

    public int hashCode()
    {
        return this.x << 16 ^ this.z ^ this.y << 24;
    }
}
