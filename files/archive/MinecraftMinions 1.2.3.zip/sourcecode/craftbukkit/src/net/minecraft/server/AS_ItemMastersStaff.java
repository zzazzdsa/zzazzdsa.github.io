package net.minecraft.server;

public class AS_ItemMastersStaff extends Item
{
    public AS_ItemMastersStaff(int var1)
    {
        super(var1);
        this.maxStackSize = 1;
    }

    public void a(ItemStack var1, World var2, EntityHuman var3, int var4) {}

    public ItemStack b(ItemStack var1, World var2, EntityHuman var3)
    {
        return var1;
    }

    /**
     * How long it takes to use or consume an item
     */
    public int c(ItemStack var1)
    {
        return 72000;
    }

    /**
     * returns the action that specifies what animation to play when the items is being used
     */
    public EnumAnimation d(ItemStack var1)
    {
        return EnumAnimation.d;
    }

    /**
     * Called whenever this item is equipped and the right mouse button is pressed. Args: itemStack, world, entityPlayer
     */
    public ItemStack a(ItemStack var1, World var2, EntityHuman var3)
    {
        var3.a(var1, this.c(var1));
        return var1;
    }
}
