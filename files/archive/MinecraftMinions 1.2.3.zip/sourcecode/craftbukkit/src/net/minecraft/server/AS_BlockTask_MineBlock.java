package net.minecraft.server;

public class AS_BlockTask_MineBlock extends AS_BlockTask
{
    public Block targetBlock;
    private int blocksDropped = 0;
    public int blockID;
    public int blockmetadata;
    public boolean disableDangerCheck = false;

    public AS_BlockTask_MineBlock(AS_Minion_Job_Manager var1, AS_EntityMinion var2, int var3, int var4, int var5)
    {
        super(var1, var2, var3, var4, var5);
    }

    public void onStartedTask()
    {
        super.onStartedTask();
    }

    public void onReachedTaskBlock()
    {
        super.onReachedTaskBlock();
        this.blockID = this.worker.world.getTypeId(this.posX, this.posY, this.posZ);

        if (this.blockID == 0)
        {
            this.onFinishedTask();
        }
        else
        {
            this.blockmetadata = this.worker.world.getData(this.posX, this.posY, this.posZ);
            this.targetBlock = Block.byId[this.blockID];
        }
    }

    public void onUpdate()
    {
        super.onUpdate();
    }

    public void onFinishedTask()
    {
        super.onFinishedTask();
        this.checkDangers();
        this.blockID = this.worker.world.getTypeId(this.posX, this.posY, this.posZ);

        if (this.blockID != 0 && Block.byId[this.blockID].l() >= 0.0F && this.worker.world.setTypeId(this.posX, this.posY, this.posZ, 0))
        {
            this.putBlockHarvestInWorkerInventory();
        }
    }

    public void putBlockHarvestInWorkerInventory()
    {
        this.putBlockHarvestInWorkerInventory(this.targetBlock, this.blockID, this.blockmetadata);
    }

    public void putBlockHarvestInWorkerInventory(Block var1, int var2, int var3)
    {
        if (!var1.material.isLiquid())
        {
            int var4 = var1.a(this.worker.random);

            if (var4 > 0)
            {
                int var5 = var1.getDropType(var2, this.worker.random, 0);

                if (var5 > 0)
                {
                    ItemStack var6 = new ItemStack(var1.getDropType(var2, this.worker.random, 0), 1, var1.getDropData(var3));

                    if (var6 != null)
                    {
                        var6.count = var4;

                        if (!this.worker.inventory.addItemStackToInventory(var6))
                        {
                            this.worker.inventoryFull = true;
                            this.worker.world.addEntity(new EntityItem(this.worker.world, (double)this.posX, (double)this.posY, (double)this.posZ, var6));
                        }
                    }
                }
            }
        }
    }

    public void checkDangers()
    {
        if (!this.disableDangerCheck)
        {
            this.checkBlockForDanger(this.posX, this.posY - 1, this.posZ, true);
            this.checkBlockForDanger(this.posX + 1, this.posY, this.posZ);
            this.checkBlockForDanger(this.posX - 1, this.posY, this.posZ);
            this.checkBlockForDanger(this.posX, this.posY, this.posZ + 1);
            this.checkBlockForDanger(this.posX, this.posY, this.posZ - 1);
        }

        this.checkBlockForCaveIn(this.posX, this.posY + 1, this.posZ);
    }

    private void checkBlockForCaveIn(int var1, int var2, int var3)
    {
        int var4 = this.worker.world.getTypeId(var1, var2, var3);

        if (var4 > 0 && (var4 == Block.SAND.id || var4 == Block.GRAVEL.id))
        {
            this.putBlockHarvestInWorkerInventory(Block.byId[var4], var4, 0);
            this.worker.inventory.consumeInventoryItem(Block.DIRT.id);
            this.worker.world.setTypeId(var1, var2, var3, Block.DIRT.id);
        }
    }

    private void checkBlockForDanger(int var1, int var2, int var3)
    {
        this.checkBlockForDanger(var1, var2, var3, false);
    }

    private void checkBlockForDanger(int var1, int var2, int var3, boolean var4)
    {
        int var5 = this.worker.world.getTypeId(var1, var2, var3);
        int var6 = 0;
        boolean var7 = false;

        if (var5 == 0)
        {
            if (var4)
            {
                var7 = true;
            }
        }
        else if (!Block.byId[var5].material.isBuildable() && var5 != Block.TORCH.id)
        {
            var6 = this.worker.world.getData(var1, var2, var3);
            var7 = true;
        }

        if (var7)
        {
            if (var5 != 0 && this.worker.world.setTypeId(var1, var2, var3, 0))
            {
                this.putBlockHarvestInWorkerInventory(Block.byId[var5], var5, var6);
            }

            this.worker.inventory.consumeInventoryItem(Block.DIRT.id);
            this.worker.world.setTypeId(var1, var2, var3, Block.DIRT.id);
        }
    }
}
