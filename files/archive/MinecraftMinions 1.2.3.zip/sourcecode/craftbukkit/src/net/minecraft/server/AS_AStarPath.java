package net.minecraft.server;

import java.util.ArrayList;

public class AS_AStarPath
{
    private volatile AS_AStarWorker worker;
    private World worldObj;
    private boolean isWorking = false;
    private ArrayList pathResult;
    private AS_IAStarPathedEntity pathedEntity;
    private long timeStarted = 0L;

    public AS_AStarPath(World var1)
    {
        this.worldObj = var1;
    }

    public AS_AStarPath(World var1, AS_IAStarPathedEntity var2)
    {
        this.worldObj = var1;
        this.pathedEntity = var2;
    }

    public boolean isBusy()
    {
        if (this.timeStarted != 0L && System.currentTimeMillis() - this.timeStarted > 5000L)
        {
            this.timeStarted = 0L;
            this.OnNoPathAvailable();
        }

        return this.isWorking;
    }

    public void getPath(int var1, int var2, int var3, int var4, int var5, int var6, boolean var7)
    {
        AS_AStarNode var8 = new AS_AStarNode(var1, var2, var3, 0);
        AS_AStarNode var9 = new AS_AStarNode(var4, var5, var6, -1);
        this.getPath(var8, var9, var7);
    }

    public void getPath(AS_AStarNode var1, AS_AStarNode var2, boolean var3)
    {
        if (this.isWorking)
        {
            this.stopPathSearch();
        }

        this.timeStarted = System.currentTimeMillis();
        this.worker = new AS_AStarWorker(this);
        this.worker.setup(this.worldObj, var1, var2, var3);
        this.worker.start();
        this.isWorking = true;
    }

    public void OnFoundPath(ArrayList var1)
    {
        this.flushWorker();
        this.pathResult = var1;
        this.isWorking = false;

        if (this.pathedEntity != null)
        {
            this.pathedEntity.OnFoundPath(var1);
        }
    }

    public void OnNoPathAvailable()
    {
        this.flushWorker();
        this.isWorking = false;

        if (this.pathedEntity != null)
        {
            this.pathedEntity.OnNoPathAvailable();
        }
    }

    public void stopPathSearch()
    {
        this.flushWorker();
        this.isWorking = false;

        if (this.pathedEntity != null)
        {
            this.pathedEntity.OnNoPathAvailable();
        }
    }

    private void flushWorker()
    {
        this.timeStarted = 0L;

        if (this.worker != null)
        {
            this.worker.interrupt();
            this.worker = null;
        }
    }
}
