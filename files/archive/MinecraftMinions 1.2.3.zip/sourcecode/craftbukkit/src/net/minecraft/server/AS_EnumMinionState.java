package net.minecraft.server;

public enum AS_EnumMinionState
{
    IDLE("IDLE", 0),
    FOLLOWING_PLAYER("FOLLOWING_PLAYER", 1),
    WALKING_TO_COORDS("WALKING_TO_COORDS", 2),
    AWAITING_JOB("AWAITING_JOB", 3),
    RETURNING_GOODS("RETURNING_GOODS", 4),
    THINKING("THINKING", 5),
    MINING("MINING", 6);
    private String name;
    private int number;

    private AS_EnumMinionState(String var3, int var4)
    {
        this.name = var3;
        this.number = var4;
    }

    public String getName()
    {
        return this.name;
    }

    public int getNumber()
    {
        return this.number;
    }

    public static AS_EnumMinionState getStateByString(String var0)
    {
        AS_EnumMinionState[] var1 = values();
        int var2 = var1.length;

        for (int var3 = 0; var3 < var2; ++var3)
        {
            AS_EnumMinionState var4 = var1[var3];

            if (var4.getName().equals(var0))
            {
                return var4;
            }
        }

        return null;
    }
}
