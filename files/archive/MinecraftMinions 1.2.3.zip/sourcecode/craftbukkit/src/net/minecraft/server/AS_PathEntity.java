package net.minecraft.server;

public class AS_PathEntity extends PathEntity
{
    private long timeLastPathIncrement = 0L;
    private final PathPoint[] pointsCopy;
    private int pathIndexCopy;

    public AS_PathEntity(PathPoint[] var1)
    {
        super(var1);
        this.timeLastPathIncrement = System.currentTimeMillis();
        this.pointsCopy = var1;
        this.pathIndexCopy = 0;
    }

    /**
     * Directs this path to the next point in its array
     */
    public void a()
    {
        super.a();
        this.timeLastPathIncrement = System.currentTimeMillis();
        ++this.pathIndexCopy;
    }

    public long getTimeSinceLastPathIncrement()
    {
        return System.currentTimeMillis() - this.timeLastPathIncrement;
    }

    public PathPoint getCurrentTargetPathPoint()
    {
        return this.b() ? null : this.pointsCopy[this.pathIndexCopy];
    }

    public Vec3D a(Entity var1)
    {
        return super.b() ? null : super.a(var1);
    }
}
