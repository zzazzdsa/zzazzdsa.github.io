package net.minecraft.server;

public class AS_Minion_Job_DigMineStairwell extends AS_Minion_Job_Manager
{
    private World worldObj;
    private int currentDepth = -1;
    private int currentSegment = 0;
    private boolean isFinished = false;
    private final int startX;
    private final int startY;
    private final int startZ;

    public AS_Minion_Job_DigMineStairwell(AS_EntityMinion[] var1, int var2, int var3, int var4)
    {
        super(var1, var2, var3, var4);
        this.worldObj = var1[0].world;
        this.startX = this.pointOfOrigin.x;
        this.startY = this.pointOfOrigin.y;
        this.startZ = this.pointOfOrigin.z;
    }

    public void onJobStarted()
    {
        super.onJobStarted();
    }

    public void onJobUpdateTick()
    {
        AS_BlockTask var1 = null;
        boolean var3 = !this.jobQueue.isEmpty();

        if (!var3 && !this.isFinished)
        {
            var3 = this.canAddNextLayer();
        }

        AS_EntityMinion var2;

        if (var3)
        {
            var1 = (AS_BlockTask)this.jobQueue.get(0);
            var2 = this.getNearestAvailableWorker(var1.posX, var1.posY, var1.posZ);
        }
        else
        {
            var2 = this.getAnyAvailableWorker();
        }

        if (var2 != null)
        {
            if (var3)
            {
                AS_BlockTask var4 = (AS_BlockTask)this.jobQueue.get(0);
                var2.giveTask(var4);
                var4.setWorker(var2);
                this.jobQueue.remove(0);
            }
            else
            {
                this.setWorkerFree(var2);
            }
        }
    }

    public void onJobFinished()
    {
        super.onJobFinished();
    }

    private boolean canAddNextLayer()
    {
        ++this.currentDepth;

        if (this.currentDepth % 3 == 0)
        {
            if (this.startY - this.currentDepth <= 8)
            {
                this.isFinished = true;
                return false;
            }

            ++this.currentSegment;

            if (this.currentSegment == 5)
            {
                this.currentSegment = 1;
            }
        }

        for (int var1 = this.startX; var1 <= this.startX + 4; ++var1)
        {
            for (int var2 = this.startZ; var2 <= this.startZ + 4; ++var2)
            {
                if (!this.isBlockCorner(var1, var2) && !this.isBlockStairs(var1, var2))
                {
                    this.jobQueue.add(new AS_BlockTask_MineBlock(this, (AS_EntityMinion)null, var1, this.startY - this.currentDepth, var2));
                }
            }
        }

        return true;
    }

    private boolean isBlockCorner(int var1, int var2)
    {
        if (this.currentDepth % 3 == 0)
        {
            int var3 = var1 - this.startX;
            int var4 = var2 - this.startZ;

            if (this.currentSegment == 1 && var3 == 0 && var4 == 0)
            {
                this.jobQueue.add(new AS_BlockTask_ReplaceBlock(this, (AS_EntityMinion)null, var1, this.startY - this.currentDepth, var2, Block.COBBLESTONE.id, 0));
                return true;
            }

            if (this.currentSegment == 2 && var3 == 4 && var4 == 0)
            {
                this.jobQueue.add(new AS_BlockTask_ReplaceBlock(this, (AS_EntityMinion)null, var1, this.startY - this.currentDepth, var2, Block.COBBLESTONE.id, 0));
                return true;
            }

            if (this.currentSegment == 3 && var3 == 4 && var4 == 4)
            {
                this.jobQueue.add(new AS_BlockTask_ReplaceBlock(this, (AS_EntityMinion)null, var1, this.startY - this.currentDepth, var2, Block.COBBLESTONE.id, 0));
                return true;
            }

            if (this.currentSegment == 4 && var3 == 0 && var4 == 4)
            {
                this.jobQueue.add(new AS_BlockTask_ReplaceBlock(this, (AS_EntityMinion)null, var1, this.startY - this.currentDepth, var2, Block.COBBLESTONE.id, 0));
                return true;
            }
        }

        return false;
    }

    private boolean isBlockStairs(int var1, int var2)
    {
        int var3 = var1 - this.startX;
        int var4 = var2 - this.startZ;

        if (this.currentSegment == 1 && var3 - 1 == this.currentDepth % 4 && var4 == 0)
        {
            this.jobQueue.add(new AS_BlockTask_ReplaceBlock(this, (AS_EntityMinion)null, var1, this.startY - this.currentDepth, var2, Block.COBBLESTONE_STAIRS.id, this.getCurrentStairMeta()));
            return true;
        }
        else if (this.currentSegment == 2 && var3 == 4 && (var4 == 1 && this.currentDepth % 4 == 3 || var4 == 2 && this.currentDepth % 4 == 0 || var4 == 3 && this.currentDepth % 4 == 1))
        {
            this.jobQueue.add(new AS_BlockTask_ReplaceBlock(this, (AS_EntityMinion)null, var1, this.startY - this.currentDepth, var2, Block.COBBLESTONE_STAIRS.id, this.getCurrentStairMeta()));
            return true;
        }
        else if (this.currentSegment == 3 && var4 == 4 && (var3 == 3 && this.currentDepth % 4 == 2 || var3 == 2 && this.currentDepth % 4 == 3 || var3 == 1 && this.currentDepth % 4 == 0))
        {
            this.jobQueue.add(new AS_BlockTask_ReplaceBlock(this, (AS_EntityMinion)null, var1, this.startY - this.currentDepth, var2, Block.COBBLESTONE_STAIRS.id, this.getCurrentStairMeta()));
            return true;
        }
        else if (this.currentSegment == 4 && var3 == 0 && this.areModsCounterPosed(var4, this.currentDepth))
        {
            this.jobQueue.add(new AS_BlockTask_ReplaceBlock(this, (AS_EntityMinion)null, var1, this.startY - this.currentDepth, var2, Block.COBBLESTONE_STAIRS.id, this.getCurrentStairMeta()));
            return true;
        }
        else
        {
            return false;
        }
    }

    private boolean areModsCounterPosed(int var1, int var2)
    {
        switch (var1 % 4)
        {
            case 1:
                return var2 % 4 == 3;

            case 2:
                return var2 % 4 == 2;

            case 3:
                return var2 % 4 == 1;

            default:
                return false;
        }
    }

    private int getCurrentStairMeta()
    {
        switch (this.currentSegment)
        {
            case 1:
                return 1;

            case 2:
                return 3;

            case 3:
                return 0;

            default:
                return 2;
        }
    }
}
