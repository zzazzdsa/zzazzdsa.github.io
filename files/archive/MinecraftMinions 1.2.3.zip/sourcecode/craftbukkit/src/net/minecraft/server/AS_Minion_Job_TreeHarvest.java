package net.minecraft.server;

public class AS_Minion_Job_TreeHarvest extends AS_Minion_Job_Manager
{
    private volatile AS_TreeScanner treeScanWorker;
    private volatile Thread thread;
    private World worldObj;
    private boolean isWorking = false;
    private boolean doneLookingForTrees = false;

    public AS_Minion_Job_TreeHarvest(AS_EntityMinion[] var1, int var2, int var3, int var4)
    {
        super(var1, var2, var3, var4);
        this.worldObj = var1[0].world;
    }

    public void onJobStarted()
    {
        super.onJobStarted();
        this.treeScanWorker = new AS_TreeScanner(this);
        this.treeScanWorker.setup(this.pointOfOrigin, this.worldObj);
        this.thread = new Thread(this.treeScanWorker);
        this.thread.run();
    }

    public void onJobUpdateTick()
    {
        if (!this.isWorking)
        {
            this.isWorking = true;
            this.onJobStarted();
        }
        else
        {
            ChunkCoordinates var1 = null;
            boolean var3 = !this.jobQueue.isEmpty();
            AS_EntityMinion var2;

            if (var3)
            {
                var1 = (ChunkCoordinates)this.jobQueue.get(0);
                var2 = this.getNearestAvailableWorker(var1.x, var1.y, var1.z);
            }
            else
            {
                var2 = this.getAnyAvailableWorker();
            }

            if (var2 != null)
            {
                if (var3)
                {
                    var2.giveTask(new AS_BlockTask_TreeChop(this, var2, var1.x, var1.y, var1.z));
                    this.jobQueue.remove(0);
                }
                else
                {
                    this.setWorkerFree(var2);
                }
            }
        }
    }

    public void onJobFinished()
    {
        if (this.thread != null && !this.thread.isInterrupted())
        {
            this.thread.interrupt();
        }

        super.onJobFinished();
    }

    public void onFoundTreeBase(int var1, int var2, int var3)
    {
        ChunkCoordinates var4 = new ChunkCoordinates(var1, var2, var3);

        if (!this.jobQueue.contains(var4))
        {
            this.jobQueue.add(var4);
        }
    }

    public void onDoneFindingTrees()
    {
        this.doneLookingForTrees = true;
    }
}
