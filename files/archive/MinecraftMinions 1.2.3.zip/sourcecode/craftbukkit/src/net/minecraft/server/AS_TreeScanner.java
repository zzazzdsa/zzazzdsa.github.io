package net.minecraft.server;

public class AS_TreeScanner implements Runnable
{
    private AS_Minion_Job_TreeHarvest boss;
    private ChunkCoordinates startCoords;
    private World worldObj;
    private int foundTreeCount = 0;
    private int currentX;
    private int currentZ;
    private int currentMaxX = 0;
    private int currentMaxZ = 0;

    public AS_TreeScanner(AS_Minion_Job_TreeHarvest var1)
    {
        this.boss = var1;
    }

    public void setup(ChunkCoordinates var1, World var2)
    {
        this.startCoords = var1;
        this.currentX = var1.x;
        this.currentZ = var1.z;
        this.worldObj = var2;
    }

    public void run()
    {
        System.out.println("AS_TreeScanner starting to run at [" + this.currentX + "|" + this.currentZ + "]");

        for (boolean var1 = false; this.foundTreeCount < 16 && this.currentMaxX < 64; ++this.currentMaxZ)
        {
            int var2 = this.currentX + (var1 ? this.currentMaxX * -1 : this.currentMaxX);

            while (this.currentX != var2)
            {
                this.checkForTreeAtCoords();

                if (var1)
                {
                    --this.currentX;
                }
                else
                {
                    ++this.currentX;
                }
            }

            int var3 = this.currentZ + (var1 ? this.currentMaxZ * -1 : this.currentMaxZ);

            while (this.currentZ != var3)
            {
                this.checkForTreeAtCoords();

                if (var1)
                {
                    --this.currentZ;
                }
                else
                {
                    ++this.currentZ;
                }
            }

            var1 = !var1;
            ++this.currentMaxX;
        }

        System.out.println("AS_TreeScanner finished work, found: " + this.foundTreeCount + "; checked length: " + this.currentMaxX);
        this.boss.onDoneFindingTrees();
    }

    private void checkForTreeAtCoords()
    {
        int var1 = this.worldObj.g(this.currentX, this.currentZ);

        if (var1 != -1)
        {
            int var2 = this.worldObj.getTypeId(this.currentX, var1 - 1, this.currentZ);

            if (mod_Minions.foundTreeBlocks.contains(Integer.valueOf(var2)))
            {
                while (true)
                {
                    --var1;
                    int var3;

                    if ((var3 = this.worldObj.getTypeId(this.currentX, var1, this.currentZ)) != var2)
                    {
                        if (var3 == 0 || Block.byId[var3].material == Material.LEAVES)
                        {
                            return;
                        }

                        this.onFoundTreeBase(this.currentX, var1 + 1, this.currentZ);
                        break;
                    }
                }
            }
        }

        Thread.yield();
    }

    private void onFoundTreeBase(int var1, int var2, int var3)
    {
        ++this.foundTreeCount;
        this.boss.onFoundTreeBase(var1, var2, var3);
    }
}
