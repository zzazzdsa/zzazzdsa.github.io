package net.minecraft.server;

public class AS_BlockTask_ReplaceBlock extends AS_BlockTask_MineBlock
{
    public final int blockToPlace;
    public final int metaToPlace;

    public AS_BlockTask_ReplaceBlock(AS_Minion_Job_Manager var1, AS_EntityMinion var2, int var3, int var4, int var5, int var6, int var7)
    {
        super(var1, var2, var3, var4, var5);
        this.blockToPlace = var6;
        this.metaToPlace = var7;
    }

    public void onFinishedTask()
    {
        super.onFinishedTask();
        this.worker.world.setTypeIdAndData(this.posX, this.posY, this.posZ, this.blockToPlace, this.metaToPlace);
    }
}
