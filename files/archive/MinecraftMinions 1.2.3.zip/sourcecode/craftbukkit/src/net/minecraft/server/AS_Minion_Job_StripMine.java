package net.minecraft.server;

public class AS_Minion_Job_StripMine extends AS_Minion_Job_Manager
{
    private World worldObj;
    private int currentSegment = -1;
    private final int xDirection;
    private final int zDirection;
    private boolean isFinished = false;
    private final int startX;
    private final int startY;
    private final int startZ;
    private long timeLastSegmentAdded;

    public AS_Minion_Job_StripMine(AS_EntityMinion[] var1, int var2, int var3, int var4)
    {
        for (int var5 = 0; var5 < var1.length; ++var5)
        {
            if (!var1[var5].isStripMining)
            {
                this.workerList.add(var1[var5]);
                var1[var5].isStripMining = true;
                var1[var5].currentState = AS_EnumMinionState.AWAITING_JOB;
                var1[var5].lastOrderedState = AS_EnumMinionState.WALKING_TO_COORDS;

                if (var1[var5].passenger != null)
                {
                    var1[var5].passenger.mount((Entity)null);
                }

                if (this.masterName == null)
                {
                    this.masterName = var1[var5].masterUsername;
                }

                break;
            }
        }

        if (this.workerList.isEmpty())
        {
            System.out.println("Attempted to create Strip Mine Job, but all Minions are already stripmining!");
            this.onJobFinished();
        }

        this.pointOfOrigin = new ChunkCoordinates(var2, var3, var4);
        this.worldObj = var1[0].world;
        this.startX = this.pointOfOrigin.x;
        this.startY = this.pointOfOrigin.y;
        this.startZ = this.pointOfOrigin.z;
        EntityHuman var6 = var1[0].master;

        if (Math.abs((double)this.startX - var6.locX) > Math.abs((double)this.startZ - var6.locZ))
        {
            this.xDirection = (double)this.startX - var6.locX > 0.0D ? 1 : -1;
            this.zDirection = 0;
        }
        else
        {
            this.xDirection = 0;
            this.zDirection = (double)this.startZ - var6.locZ > 0.0D ? 1 : -1;
        }
    }

    public void onJobStarted()
    {
        super.onJobStarted();
    }

    public void onJobUpdateTick()
    {
        AS_BlockTask var1 = null;
        boolean var3 = !this.jobQueue.isEmpty();

        if (!var3 && !this.isFinished)
        {
            var3 = this.canAddNextLayer();
        }

        AS_EntityMinion var2;

        if (var3)
        {
            if (!this.workerList.isEmpty() && System.currentTimeMillis() > this.timeLastSegmentAdded + 10000L)
            {
                var2 = (AS_EntityMinion)this.workerList.get(0);

                if (var2.getCurrentTask() instanceof AS_BlockTask_MineOreVein)
                {
                    var2.giveTask((AS_BlockTask)null, true);
                    var2.currentState = AS_EnumMinionState.AWAITING_JOB;
                }
                else
                {
                    --this.currentSegment;
                    var2.giveTask((AS_BlockTask)null, true);
                    var2.currentState = AS_EnumMinionState.AWAITING_JOB;
                }
            }

            var1 = (AS_BlockTask)this.jobQueue.get(0);
            var2 = this.getNearestAvailableWorker(var1.posX, var1.posY, var1.posZ);
        }
        else
        {
            var2 = this.getAnyAvailableWorker();
        }

        if (var2 != null)
        {
            if (var3)
            {
                AS_BlockTask var4 = (AS_BlockTask)this.jobQueue.get(0);
                var2.giveTask(var4);
                var4.setWorker(var2);
                var2.currentState = AS_EnumMinionState.THINKING;
                this.jobQueue.remove(0);
            }
            else
            {
                this.setWorkerFree(var2);
            }
        }
    }

    public void onJobFinished()
    {
        super.onJobFinished();
    }

    public void setWorkerFree(AS_EntityMinion var1)
    {
        var1.isStripMining = false;
        super.setWorkerFree(var1);
    }

    private boolean canAddNextLayer()
    {
        this.timeLastSegmentAdded = System.currentTimeMillis();
        ++this.currentSegment;

        if (this.currentSegment >= 40)
        {
            return false;
        }
        else
        {
            int var1 = this.startX + this.currentSegment * this.xDirection;
            int var2 = this.startZ + this.currentSegment * this.zDirection;

            if (this.currentSegment > 0 && this.currentSegment % 7 == 0 && this.worldObj.p(var1, this.startY, var2) < 10.0F)
            {
                this.worldObj.setTypeId(var1 - 2 * this.xDirection, this.startY, var2 - 2 * this.zDirection, Block.TORCH.id);
            }

            AS_BlockTask_MineBlock var3 = new AS_BlockTask_MineBlock(this, (AS_EntityMinion)null, var1, this.startY, var2);
            this.jobQueue.add(var3);
            var3 = new AS_BlockTask_MineBlock(this, (AS_EntityMinion)null, var1, this.startY + 1, var2);
            var3.disableDangerCheck = true;
            this.jobQueue.add(var3);
            this.checkBlockValuables(var1, this.startY + 2, var2);

            if (this.xDirection == 0)
            {
                this.checkBlockValuables(var1 + 1, this.startY, var2);
                this.checkBlockValuables(var1 - 1, this.startY, var2);
                this.checkBlockValuables(var1 + 1, this.startY + 1, var2);
                this.checkBlockValuables(var1 - 1, this.startY + 1, var2);
            }
            else
            {
                this.checkBlockValuables(var1, this.startY, var2 + 1);
                this.checkBlockValuables(var1, this.startY, var2 - 1);
                this.checkBlockValuables(var1, this.startY + 1, var2 + 1);
                this.checkBlockValuables(var1, this.startY + 1, var2 - 1);
            }

            this.checkBlockValuables(var1, this.startY - 1, var2);
            return true;
        }
    }

    private void checkBlockValuables(int var1, int var2, int var3)
    {
        int var4 = this.worldObj.getTypeId(var1, var2, var3);

        if (mod_Minions.isBlockValuable(var4))
        {
            AS_BlockTask_MineOreVein var5 = new AS_BlockTask_MineOreVein(this, (AS_EntityMinion)null, var1, var2, var3);

            if (var5.posY > this.startY)
            {
                var5.disableDangerCheck = true;
            }

            this.jobQueue.add(var5);

            if (var2 == this.startY + 1)
            {
                this.checkBlockValuables(var1, this.startY + 2, var2);
            }
        }
    }
}
