package net.minecraft.server;

import java.util.ArrayList;

public class AS_BlockTask_MineOreVein extends AS_BlockTask_MineBlock
{
    private ArrayList oreVeinBlocks;

    public AS_BlockTask_MineOreVein(AS_Minion_Job_Manager var1, AS_EntityMinion var2, int var3, int var4, int var5)
    {
        super(var1, var2, var3, var4, var5);
    }

    public AS_BlockTask_MineOreVein(AS_Minion_Job_Manager var1, AS_EntityMinion var2, ArrayList var3, int var4, int var5, int var6)
    {
        super(var1, var2, var4, var5, var6);
        this.oreVeinBlocks = var3;
    }

    public void onStartedTask()
    {
        super.onStartedTask();
    }

    public void onReachedTaskBlock()
    {
        super.onReachedTaskBlock();

        if (this.oreVeinBlocks == null)
        {
            this.oreVeinBlocks = new ArrayList();
        }

        this.checkAdjacentBlocks();
    }

    public void onUpdate()
    {
        super.onUpdate();
    }

    public void onTaskNotPathable()
    {
        super.onTaskNotPathable();
        this.worker.datawatcher.watch(12, Integer.valueOf(0));
        ChunkCoordinates var1 = new ChunkCoordinates(this.posX, this.posY, this.posZ);

        if (this.oreVeinBlocks != null && this.oreVeinBlocks.contains(var1))
        {
            this.oreVeinBlocks.remove(var1);
        }

        if (this.oreVeinBlocks != null && !this.oreVeinBlocks.isEmpty())
        {
            var1 = (ChunkCoordinates)this.oreVeinBlocks.get(0);
            AS_BlockTask_MineOreVein var2 = new AS_BlockTask_MineOreVein(this.boss, this.worker, this.oreVeinBlocks, var1.x, var1.y, var1.z);
            this.worker.giveTask(var2);
        }
        else
        {
            this.worker.currentState = AS_EnumMinionState.AWAITING_JOB;
            this.worker.giveTask((AS_BlockTask)null, true);
        }
    }

    public void onFinishedTask()
    {
        this.worker.datawatcher.watch(12, Integer.valueOf(0));
        this.checkDangers();
        this.blockID = this.worker.world.getTypeId(this.posX, this.posY, this.posZ);
        this.checkBlockForCaveIn(this.posX, this.posY + 1, this.posZ);

        if (this.blockID != 0 && Block.byId[this.blockID].l() >= 0.0F && this.blockID != Block.CHEST.id && this.worker.world.setTypeId(this.posX, this.posY, this.posZ, 0))
        {
            this.putBlockHarvestInWorkerInventory();
        }

        this.checkForVeinContinueTask();
    }

    private void checkBlockForCaveIn(int var1, int var2, int var3)
    {
        int var4 = this.worker.world.getTypeId(var1, var2, var3);

        if (var4 > 0 && (var4 == Block.SAND.id || var4 == Block.GRAVEL.id))
        {
            this.worker.inventory.consumeInventoryItem(Block.DIRT.id);
            this.worker.world.setTypeId(var1, var2, var3, Block.DIRT.id);
        }
    }

    private void checkForVeinContinueTask()
    {
        if (this.oreVeinBlocks == null)
        {
            this.oreVeinBlocks = new ArrayList();
        }

        ChunkCoordinates var1 = new ChunkCoordinates(this.posX, this.posY, this.posZ);

        if (this.oreVeinBlocks.contains(var1))
        {
            this.oreVeinBlocks.remove(var1);
        }

        if (!this.oreVeinBlocks.isEmpty())
        {
            var1 = (ChunkCoordinates)this.oreVeinBlocks.get(0);
            AS_BlockTask_MineOreVein var2 = new AS_BlockTask_MineOreVein(this.boss, this.worker, this.oreVeinBlocks, var1.x, var1.y, var1.z);
            this.worker.giveTask(var2);
        }
        else
        {
            this.worker.currentState = AS_EnumMinionState.AWAITING_JOB;
            this.worker.giveTask((AS_BlockTask)null, true);
        }
    }

    public void checkAdjacentBlocks()
    {
        this.checkBlockForVein(this.posX, this.posY - 1, this.posZ);
        this.checkBlockForVein(this.posX, this.posY + 1, this.posZ);
        this.checkBlockForVein(this.posX + 1, this.posY, this.posZ);
        this.checkBlockForVein(this.posX - 1, this.posY, this.posZ);
        this.checkBlockForVein(this.posX, this.posY, this.posZ + 1);
        this.checkBlockForVein(this.posX, this.posY, this.posZ - 1);
    }

    private void checkBlockForVein(int var1, int var2, int var3)
    {
        int var4 = this.worker.world.getTypeId(var1, var2, var3);

        if (mod_Minions.isBlockValuable(var4))
        {
            if (var4 == this.blockID)
            {
                ChunkCoordinates var5 = new ChunkCoordinates(var1, var2, var3);

                if (!this.oreVeinBlocks.contains(var5))
                {
                    this.oreVeinBlocks.add(var5);
                }
            }
        }
    }
}
