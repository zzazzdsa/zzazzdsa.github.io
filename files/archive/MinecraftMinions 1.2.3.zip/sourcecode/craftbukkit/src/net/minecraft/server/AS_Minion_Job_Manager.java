package net.minecraft.server;

import java.util.ArrayList;
import java.util.Iterator;

public class AS_Minion_Job_Manager
{
    protected ArrayList workerList = new ArrayList();
    public ChunkCoordinates pointOfOrigin;
    protected ArrayList jobQueue = new ArrayList();
    public String masterName = null;

    public AS_Minion_Job_Manager() {}

    public AS_Minion_Job_Manager(AS_EntityMinion[] var1, int var2, int var3, int var4)
    {
        for (int var5 = 0; var5 < var1.length; ++var5)
        {
            this.workerList.add(var1[var5]);
            var1[var5].currentState = AS_EnumMinionState.AWAITING_JOB;
            var1[var5].lastOrderedState = AS_EnumMinionState.WALKING_TO_COORDS;

            if (var1[var5].passenger != null)
            {
                var1[var5].passenger.mount((Entity)null);
            }

            if (this.masterName == null)
            {
                this.masterName = var1[var5].masterUsername;
            }
        }

        this.pointOfOrigin = new ChunkCoordinates(var2, var3, var4);
    }

    public AS_EntityMinion getNearestAvailableWorker(int var1, int var2, int var3)
    {
        Iterator var4 = this.workerList.iterator();
        AS_EntityMinion var6 = null;
        double var7 = 9999.0D;

        while (var4.hasNext())
        {
            AS_EntityMinion var5 = (AS_EntityMinion)var4.next();

            if (var5.currentState == AS_EnumMinionState.AWAITING_JOB && !var5.hasTask() || var5.currentState == AS_EnumMinionState.IDLE && var5.lastOrderedState == AS_EnumMinionState.RETURNING_GOODS)
            {
                double var9 = var5.e((double)var1, (double)var2, (double)var3);

                if (var9 < var7)
                {
                    var6 = var5;
                    var7 = var9;
                }
            }
        }

        return var6;
    }

    public AS_EntityMinion getAnyAvailableWorker()
    {
        if (this.workerList.isEmpty())
        {
            return null;
        }
        else
        {
            Iterator var1 = this.workerList.iterator();
            AS_EntityMinion var2;

            do
            {
                if (!var1.hasNext())
                {
                    return null;
                }

                var2 = (AS_EntityMinion)var1.next();
            }
            while (var2.currentState != AS_EnumMinionState.AWAITING_JOB || var2.hasTask());

            return var2;
        }
    }

    public void setWorkerFree(AS_EntityMinion var1)
    {
        var1.giveTask((AS_BlockTask)null);
        this.workerList.remove(var1);

        if (this.workerList.isEmpty())
        {
            this.onJobFinished();
        }
    }

    public void onJobStarted() {}

    public void onJobUpdateTick() {}

    public void onJobFinished()
    {
        while (!this.workerList.isEmpty())
        {
            this.setWorkerFree((AS_EntityMinion)this.workerList.get(0));
        }

        mod_Minions.onJobHasFinished(this);
    }
}
