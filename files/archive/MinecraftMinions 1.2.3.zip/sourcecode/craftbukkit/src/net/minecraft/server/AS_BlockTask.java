package net.minecraft.server;

public class AS_BlockTask
{
    public AS_Minion_Job_Manager boss;
    public final int posX;
    public final int posY;
    public final int posZ;
    public boolean startedTask = false;
    public AS_EntityMinion worker;
    protected double accessRange = 4.0D;
    protected long taskDurationMillis = 1000L;
    public boolean isWorkerInRange = false;
    protected long timeBlockReached;
    protected AS_AStarNode[] possibleAccessNodes;
    protected int currentAccessNode;
    private long taskTimeStarted;
    private double startMinionX;
    private double startMinionZ;

    public AS_BlockTask(AS_Minion_Job_Manager var1, AS_EntityMinion var2, int var3, int var4, int var5)
    {
        this.boss = var1;
        this.worker = var2;
        this.posX = var3;
        this.posY = var4;
        this.posZ = var5;
    }

    public void setWorker(AS_EntityMinion var1)
    {
        this.worker = var1;
    }

    public void setAccessRange(double var1)
    {
        this.accessRange = var1;
    }

    public void setTaskDuration(long var1)
    {
        this.taskDurationMillis = var1;
    }

    public void onUpdate()
    {
        if (!this.startedTask)
        {
            if (!this.worker.inventoryFull)
            {
                this.onStartedTask();
            }
            else
            {
                this.worker.currentState = AS_EnumMinionState.RETURNING_GOODS;
                System.out.println("Blocktask worker is full, sending to return goods");
            }
        }
        else if (!this.isWorkerInRange && System.currentTimeMillis() - this.taskTimeStarted > 3000L)
        {
            if (Math.abs(this.startMinionX - this.worker.locX) < 1.0D && Math.abs(this.startMinionZ - this.worker.locZ) < 1.0D)
            {
                this.onTaskNotPathable();
            }
            else
            {
                this.taskTimeStarted = System.currentTimeMillis();
                this.startMinionX = this.worker.locX;
                this.startMinionZ = this.worker.locZ;
            }
        }

        if (this.isWorking())
        {
            this.worker.faceBlock(this.posX, this.posY, this.posZ);
            this.worker.datawatcher.watch(12, Integer.valueOf(1));
            this.worker.datawatcher.watch(13, Integer.valueOf(this.posX));
            this.worker.datawatcher.watch(14, Integer.valueOf(this.posY));
            this.worker.datawatcher.watch(15, Integer.valueOf(this.posZ));
        }

        if (!this.isWorkerInRange)
        {
            if (Math.sqrt(this.worker.e((double)this.posX + 0.5D, (double)this.posY + 0.5D, (double)this.posZ + 0.5D)) < this.accessRange)
            {
                this.onReachedTaskBlock();
                this.isWorkerInRange = true;
            }
        }
        else if ((float)(System.currentTimeMillis() - this.timeBlockReached) > (float)this.taskDurationMillis / this.worker.workSpeed)
        {
            this.onFinishedTask();
        }
    }

    public void onWorkerPathFailed()
    {
        if (this.possibleAccessNodes != null && this.currentAccessNode < this.possibleAccessNodes.length - 1)
        {
            ++this.currentAccessNode;
            this.worker.orderMinionToMoveTo(this.possibleAccessNodes[this.currentAccessNode].x, this.possibleAccessNodes[this.currentAccessNode].y, this.possibleAccessNodes[this.currentAccessNode].z, false);
        }
        else
        {
            this.worker.enderTeleportTo((double)this.possibleAccessNodes[this.currentAccessNode].x, (double)this.possibleAccessNodes[this.currentAccessNode].y, (double)this.possibleAccessNodes[this.currentAccessNode].z);
        }
    }

    public void onReachedTaskBlock()
    {
        this.timeBlockReached = System.currentTimeMillis();
        this.worker.currentState = AS_EnumMinionState.MINING;
        this.worker.setPathEntity((PathEntity)null);
    }

    public void onStartedTask()
    {
        if (!this.startedTask)
        {
            this.startedTask = true;
            this.taskTimeStarted = System.currentTimeMillis();
            this.startMinionX = this.worker.locX;
            this.startMinionZ = this.worker.locZ;
            this.worker.currentState = AS_EnumMinionState.THINKING;
            this.currentAccessNode = 0;
            this.possibleAccessNodes = this.getAccessNodesSorted((int)Math.floor(this.worker.locX), (int)Math.floor(this.worker.locY) - 1, (int)Math.floor(this.worker.locZ));

            if (this.possibleAccessNodes.length != 0)
            {
                this.worker.orderMinionToMoveTo(this.possibleAccessNodes[this.currentAccessNode].x, this.possibleAccessNodes[this.currentAccessNode].y, this.possibleAccessNodes[this.currentAccessNode].z, false);
                this.worker.currentState = AS_EnumMinionState.WALKING_TO_COORDS;
            }
            else
            {
                this.onTaskNotPathable();
            }
        }
    }

    public void onTaskNotPathable()
    {
        this.worker.currentState = AS_EnumMinionState.AWAITING_JOB;
        this.worker.datawatcher.watch(12, Integer.valueOf(0));
        this.worker.currentState = AS_EnumMinionState.AWAITING_JOB;
        this.worker.giveTask((AS_BlockTask)null, true);
    }

    public void onFinishedTask()
    {
        this.worker.datawatcher.watch(12, Integer.valueOf(0));
        this.worker.currentState = AS_EnumMinionState.AWAITING_JOB;
        this.worker.giveTask((AS_BlockTask)null, true);
    }

    public boolean isWorking()
    {
        return this.isWorkerInRange;
    }

    public boolean isEntityInAccessRange(EntityLiving var1)
    {
        return var1.e((double)this.posX, (double)this.posY, (double)this.posZ) < this.accessRange;
    }

    public AS_AStarNode[] getAccessNodesSorted(int var1, int var2, int var3)
    {
        return AS_AStarStatic.getAccessNodesSorted(this.worker.world, var1, var2, var3, this.posX, this.posY, this.posZ);
    }
}
