package net.minecraft.server;

import java.util.ArrayList;

public final class AS_AStarStatic
{
    static final int[][] candidates = new int[][] {{0, 0, -1, 1}, {0, 0, 1, 1}, {0, 1, 0, 1}, {1, 0, 0, 1}, { -1, 0, 0, 1}, {1, 1, 0, 2}, { -1, 1, 0, 2}, {0, 1, 1, 2}, {0, 1, -1, 2}, {1, -1, 0, 1}, { -1, -1, 0, 1}, {0, -1, 1, 1}, {0, -1, -1, 1}};
    static final int[][] candidates_allowdrops = new int[][] {{0, 0, -1, 1}, {0, 0, 1, 1}, {1, 0, 0, 1}, { -1, 0, 0, 1}, {1, 1, 0, 2}, { -1, 1, 0, 2}, {0, 1, 1, 2}, {0, 1, -1, 2}, {1, -1, 0, 1}, { -1, -1, 0, 1}, {0, -1, 1, 1}, {0, -1, -1, 1}, {1, -2, 0, 1}, { -1, -2, 0, 1}, {0, -2, 1, 1}, {0, -2, -1, 1}};

    static boolean isViable(World var0, AS_AStarNode var1, int var2)
    {
        int var3 = var1.x;
        int var4 = var1.y;
        int var5 = var1.z;
        int var6 = var0.getTypeId(var3, var4, var5);

        if (var6 == Block.LADDER.id)
        {
            return true;
        }
        else if (isPassableBlock(var0, var3, var4, var5) && isPassableBlock(var0, var3, var4 + 1, var5) && (!isPassableBlock(var0, var3, var4 - 1, var5) || var6 == Block.STATIONARY_WATER.id && var6 == Block.WATER.id))
        {
            if (var2 < 0)
            {
                var2 *= -1;
            }

            for (int var7 = 1; var7 <= var2; ++var7)
            {
                if (!isPassableBlock(var0, var3, var4 + var2, var5))
                {
                    return false;
                }
            }

            return true;
        }
        else
        {
            return false;
        }
    }

    static boolean isPassableBlock(World var0, int var1, int var2, int var3)
    {
        int var4 = var0.getTypeId(var1, var2, var3);
        return var4 != 0 ? !Block.byId[var4].material.isBuildable() : true;
    }

    static int getIntCoordFromDoubleCoord(double var0)
    {
        return MathHelper.floor(var0);
    }

    static double getEntityLandSpeed(EntityLiving var0)
    {
        return Math.sqrt(var0.motX * var0.motX + var0.motZ * var0.motZ);
    }

    static double getDistanceBetweenNodes(AS_AStarNode var0, AS_AStarNode var1)
    {
        return (double)(Math.abs(var0.x - var1.x) + Math.abs(var0.y - var1.y) + Math.abs(var0.z - var1.z));
    }

    static double getDistanceBetweenCoords(int var0, int var1, int var2, int var3, int var4, int var5)
    {
        return Math.sqrt(Math.pow((double)(var0 - var3), 2.0D) + Math.pow((double)(var1 - var4), 2.0D) + Math.pow((double)(var2 - var5), 2.0D));
    }

    static boolean isLadder(int var0)
    {
        return var0 == Block.LADDER.id || var0 == 242 || var0 == 243;
    }

    static AS_AStarNode[] getAccessNodesSorted(World var0, int var1, int var2, int var3, int var4, int var5, int var6)
    {
        ArrayList var7 = new ArrayList();
        AS_AStarNode var8;
        int var9;

        for (var9 = -2; var9 <= 2; ++var9)
        {
            for (int var10 = -2; var10 <= 2; ++var10)
            {
                for (int var11 = -2; var11 <= 2; ++var11)
                {
                    var8 = new AS_AStarNode(var4 + var9, var5 + var11, var6 + var10, 0);

                    if (isViable(var0, var8, 1))
                    {
                        var8.f_distanceToGoal = getDistanceBetweenCoords(var1, var2, var3, var8.x, var8.y, var8.z);
                        int var12 = 0;

                        if (var7.size() != 0)
                        {
                            while (var12 < var7.size() && var7.get(var12) != null && ((AS_AStarNode)var7.get(var12)).f_distanceToGoal <= var8.f_distanceToGoal)
                            {
                                ++var12;
                            }
                        }

                        var7.add(var12, var8);
                    }
                }
            }
        }

        var9 = 0;
        AS_AStarNode[] var13;

        for (var13 = new AS_AStarNode[var7.size()]; !var7.isEmpty() && (var8 = (AS_AStarNode)var7.get(0)) != null; ++var9)
        {
            var13[var9] = var8;
            var7.remove(0);
        }

        return var13;
    }

    static AS_PathEntity translateAStarPathtoPathEntity(ArrayList var0)
    {
        PathPoint[] var1 = new PathPoint[var0.size()];
        int var3 = 0;

        for (int var4 = var0.size(); var4 > 0; ++var3)
        {
            AS_AStarNode var2 = (AS_AStarNode)var0.get(var4 - 1);
            var1[var3] = new PathPoint(var2.x, var2.y, var2.z);
            var1[var3].i = var3 == 0;
            var1[var3].d = var3;
            var1[var3].e = (float)var3;
            var1[var3].f = 1.0F;
            var1[var3].g = (float)var4;

            if (var3 > 0)
            {
                var1[var3].h = var1[var3 - 1];
            }

            var0.remove(var4 - 1);
            --var4;
        }

        return new AS_PathEntity(var1);
    }
}
