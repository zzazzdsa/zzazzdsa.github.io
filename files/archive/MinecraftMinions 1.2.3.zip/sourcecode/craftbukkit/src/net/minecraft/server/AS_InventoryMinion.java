package net.minecraft.server;

import java.util.List;

import org.bukkit.craftbukkit.entity.CraftHumanEntity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.inventory.InventoryHolder;

public class AS_InventoryMinion implements IInventory
{
    public ItemStack[] mainInventory = new ItemStack[24];
    public AS_EntityMinion minion;
    public boolean inventoryChanged = false;

    public AS_InventoryMinion(AS_EntityMinion var1)
    {
        this.minion = var1;
    }

    public boolean containsItems()
    {
        return this.getFirstEmptyStack() != 0;
    }

    private int getInventorySlotContainItem(int var1)
    {
        for (int var2 = 0; var2 < this.mainInventory.length; ++var2)
        {
            if (this.mainInventory[var2] != null && this.mainInventory[var2].id == var1)
            {
                return var2;
            }
        }

        return -1;
    }

    private int getInventorySlotContainItemAndDamage(int var1, int var2)
    {
        for (int var3 = 0; var3 < this.mainInventory.length; ++var3)
        {
            if (this.mainInventory[var3] != null && this.mainInventory[var3].id == var1 && this.mainInventory[var3].getData() == var2)
            {
                return var3;
            }
        }

        return -1;
    }

    private int storeItemStack(ItemStack var1)
    {
        for (int var2 = 0; var2 < this.mainInventory.length; ++var2)
        {
            if (this.mainInventory[var2] != null && this.mainInventory[var2].id == var1.id && this.mainInventory[var2].isStackable() && this.mainInventory[var2].count < this.mainInventory[var2].getMaxStackSize() && this.mainInventory[var2].count < this.getMaxStackSize() && (!this.mainInventory[var2].usesData() || this.mainInventory[var2].getData() == var1.getData()) && ItemStack.equals(this.mainInventory[var2], var1))
            {
                return var2;
            }
        }

        return -1;
    }

    private int getFirstEmptyStack()
    {
        for (int var1 = 0; var1 < this.mainInventory.length; ++var1)
        {
            if (this.mainInventory[var1] == null)
            {
                return var1;
            }
        }

        return -1;
    }

    private int storePartialItemStack(ItemStack var1)
    {
        int var2 = var1.id;
        int var3 = var1.count;
        int var4;

        if (var1.getMaxStackSize() == 1)
        {
            var4 = this.getFirstEmptyStack();

            if (var4 < 0)
            {
                return var3;
            }
            else
            {
                if (this.mainInventory[var4] == null)
                {
                    this.mainInventory[var4] = ItemStack.b(var1);
                }

                return 0;
            }
        }
        else
        {
            var4 = this.storeItemStack(var1);

            if (var4 < 0)
            {
                var4 = this.getFirstEmptyStack();
            }

            if (var4 < 0)
            {
                return var3;
            }
            else
            {
                if (this.mainInventory[var4] == null)
                {
                    this.mainInventory[var4] = new ItemStack(var2, 0, var1.getData());

                    if (var1.hasTag())
                    {
                        this.mainInventory[var4].setTag((NBTTagCompound)var1.getTag().clone());
                    }
                }

                int var5 = var3;

                if (var3 > this.mainInventory[var4].getMaxStackSize() - this.mainInventory[var4].count)
                {
                    var5 = this.mainInventory[var4].getMaxStackSize() - this.mainInventory[var4].count;
                }

                if (var5 > this.getMaxStackSize() - this.mainInventory[var4].count)
                {
                    var5 = this.getMaxStackSize() - this.mainInventory[var4].count;
                }

                if (var5 == 0)
                {
                    return var3;
                }
                else
                {
                    var3 -= var5;
                    this.mainInventory[var4].count += var5;
                    this.mainInventory[var4].b = 5;
                    return var3;
                }
            }
        }
    }

    public boolean consumeInventoryItem(int var1)
    {
        int var2 = this.getInventorySlotContainItem(var1);

        if (var2 < 0)
        {
            return false;
        }
        else
        {
            if (--this.mainInventory[var2].count <= 0)
            {
                this.mainInventory[var2] = null;
            }

            return true;
        }
    }

    public boolean hasItem(int var1)
    {
        int var2 = this.getInventorySlotContainItem(var1);
        return var2 >= 0;
    }

    public boolean addItemStackToInventory(ItemStack var1)
    {
        int var2;

        if (var1.id > 0 && var1.d() && var1.f())
        {
            var2 = this.getFirstEmptyStack();

            if (var2 >= 0)
            {
                this.mainInventory[var2] = ItemStack.b(var1);
                this.mainInventory[var2].b = 5;
                var1.count = 0;
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            do
            {
                var2 = var1.count;
                var1.count = this.storePartialItemStack(var1);
            }
            while (var1.count > 0 && var1.count < var2);

            return var1.count < var2;
        }
    }

    /**
     * Decrease the size of the stack in slot (first int arg) by the amount of the second int arg. Returns the new
     * stack.
     */
    public ItemStack splitStack(int var1, int var2)
    {
        ItemStack[] var3 = this.mainInventory;

        if (var1 >= this.mainInventory.length)
        {
            var1 -= this.mainInventory.length;
        }

        if (var3[var1] != null)
        {
            ItemStack var4;

            if (var3[var1].count <= var2)
            {
                var4 = var3[var1];
                var3[var1] = null;
                return var4;
            }
            else
            {
                var4 = var3[var1].a(var2);

                if (var3[var1].count == 0)
                {
                    var3[var1] = null;
                }

                return var4;
            }
        }
        else
        {
            return null;
        }
    }

    /**
     * Sets the given item stack to the specified slot in the inventory (can be crafting or armor sections).
     */
    public void setItem(int var1, ItemStack var2)
    {
        ItemStack[] var3 = this.mainInventory;

        if (var1 >= var3.length)
        {
            var1 -= var3.length;
        }

        var3[var1] = var2;
    }

    public NBTTagList writeToNBT(NBTTagList var1)
    {
        for (int var2 = 0; var2 < this.mainInventory.length; ++var2)
        {
            if (this.mainInventory[var2] != null)
            {
                NBTTagCompound var3 = new NBTTagCompound();
                var3.setByte("Slot", (byte)var2);
                this.mainInventory[var2].save(var3);
                var1.add(var3);
            }
        }

        return var1;
    }

    public void readFromNBT(NBTTagList var1)
    {
        this.mainInventory = new ItemStack[36];

        for (int var2 = 0; var2 < var1.size(); ++var2)
        {
            NBTTagCompound var3 = (NBTTagCompound)var1.get(var2);
            int var4 = var3.getByte("Slot") & 255;
            ItemStack var5 = ItemStack.a(var3);

            if (var5 != null && var4 >= 0 && var4 < this.mainInventory.length)
            {
                this.mainInventory[var4] = var5;
            }
        }
    }

    public int getSize()
    {
        return this.mainInventory.length + 4;
    }

    /**
     * Returns the stack in slot i
     */
    public ItemStack getItem(int var1)
    {
        ItemStack[] var2 = this.mainInventory;

        if (var1 >= var2.length)
        {
            var1 -= var2.length;
        }

        return var2[var1];
    }

    /**
     * Returns the name of the inventory.
     */
    public String getName()
    {
        return "MinionInventory";
    }

    /**
     * Returns the maximum stack size for a inventory slot. Seems to always be 64, possibly will be extended. *Isn't
     * this more of a set than a get?*
     */
    public int getMaxStackSize()
    {
        return 64;
    }

    public void dropAllItems()
    {
        for (int var1 = 0; var1 < this.mainInventory.length; ++var1)
        {
            if (this.mainInventory[var1] != null)
            {
                this.minion.dropMinionItemWithRandomChoice(this.mainInventory[var1]);
                this.mainInventory[var1] = null;
            }
        }
    }

    public void putAllItemsToChest(TileEntityChest var1)
    {
        for (int var2 = 0; var2 < this.mainInventory.length; ++var2)
        {
            if (this.mainInventory[var2] != null)
            {
                if (!this.addItemStackToChest(var1, this.mainInventory[var2]) && (var1.d == null || !this.addItemStackToChest(var1.d, this.mainInventory[var2])) && (var1.c == null || !this.addItemStackToChest(var1.c, this.mainInventory[var2])) && (var1.b == null || !this.addItemStackToChest(var1.b, this.mainInventory[var2])) && (var1.e == null || !this.addItemStackToChest(var1.e, this.mainInventory[var2])))
                {
                    this.dropAllItems();
                    return;
                }

                this.mainInventory[var2] = null;
            }
        }
    }

    private boolean addItemStackToChest(TileEntityChest var1, ItemStack var2)
    {
        int var3;

        if (var2.id > 0 && var2.d() && var2.f())
        {
            var3 = this.getChestFirstEmptyStack(var1);

            if (var3 >= 0)
            {
                var1.setItem(var3, ItemStack.b(var2));
                var1.getItem(var3).b = 5;
                var2.count = 0;
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            do
            {
                var3 = var2.count;
                var2.count = this.storePartialItemStackInChest(var1, var2);
            }
            while (var2.count > 0 && var2.count < var3);

            return var2.count < var3;
        }
    }

    private int storeItemStackInChest(TileEntityChest var1, ItemStack var2)
    {
        for (int var3 = 0; var3 < var1.getSize(); ++var3)
        {
            if (var1.getItem(var3) != null && var1.getItem(var3).id == var2.id && var1.getItem(var3).isStackable() && var1.getItem(var3).count < var1.getItem(var3).getMaxStackSize() && var1.getItem(var3).count < var1.getMaxStackSize() && (!var1.getItem(var3).usesData() || var1.getItem(var3).getData() == var2.getData()) && ItemStack.equals(var1.getItem(var3), var2))
            {
                return var3;
            }
        }

        return -1;
    }

    private int getChestFirstEmptyStack(TileEntityChest var1)
    {
        for (int var2 = 0; var2 < var1.getSize(); ++var2)
        {
            if (var1.getItem(var2) == null)
            {
                return var2;
            }
        }

        return -1;
    }

    private int storePartialItemStackInChest(TileEntityChest var1, ItemStack var2)
    {
        int var3 = var2.id;
        int var4 = var2.count;
        int var5;

        if (var2.getMaxStackSize() == 1)
        {
            var5 = this.getChestFirstEmptyStack(var1);

            if (var5 < 0)
            {
                return var4;
            }
            else
            {
                if (var1.getItem(var5) == null)
                {
                    var1.setItem(var5, ItemStack.b(var2));
                }

                return 0;
            }
        }
        else
        {
            var5 = this.storeItemStackInChest(var1, var2);

            if (var5 < 0)
            {
                var5 = this.getChestFirstEmptyStack(var1);
            }

            if (var5 < 0)
            {
                return var4;
            }
            else
            {
                if (var1.getItem(var5) == null)
                {
                    var1.setItem(var5, new ItemStack(var3, 0, var2.getData()));

                    if (var2.hasTag())
                    {
                        var1.getItem(var5).setTag((NBTTagCompound)var2.getTag().clone());
                    }
                }

                int var6 = var4;

                if (var4 > var1.getItem(var5).getMaxStackSize() - var1.getItem(var5).count)
                {
                    var6 = var1.getItem(var5).getMaxStackSize() - var1.getItem(var5).count;
                }

                if (var6 > var1.getMaxStackSize() - var1.getItem(var5).count)
                {
                    var6 = var1.getMaxStackSize() - var1.getItem(var5).count;
                }

                if (var6 == 0)
                {
                    return var4;
                }
                else
                {
                    var4 -= var6;
                    ItemStack var10000 = var1.getItem(var5);
                    var10000.count += var6;
                    var1.getItem(var5).b = 5;
                    return var4;
                }
            }
        }
    }

    /**
     * Called when an the contents of an Inventory change, usually
     */
    public void update()
    {
        this.inventoryChanged = true;
    }

    /**
     * Do not make give this method the name canInteractWith because it clashes with Container
     */
    public boolean a(EntityHuman var1)
    {
        return var1.name.equals(this.minion.masterUsername) && var1.j(this.minion) <= 64.0D;
    }

    public boolean hasItemStack(ItemStack var1)
    {
        for (int var2 = 0; var2 < this.mainInventory.length; ++var2)
        {
            if (this.mainInventory[var2] != null && this.mainInventory[var2].c(var1))
            {
                return true;
            }
        }

        return false;
    }

    public void f() {}

    public void g() {}

    public void copyInventory(AS_InventoryMinion var1)
    {
        for (int var2 = 0; var2 < this.mainInventory.length; ++var2)
        {
            this.mainInventory[var2] = ItemStack.b(var1.mainInventory[var2]);
        }
    }

	@Override
	public ItemStack[] getContents()
	{
		return this.mainInventory;
	}

	@Override
	public InventoryHolder getOwner()
	{
		return null;
	}

	@Override
	public List<HumanEntity> getViewers()
	{
		return null;
	}

	@Override
	public void onClose(CraftHumanEntity arg0){		
	}

	@Override
	public void onOpen(CraftHumanEntity arg0) {
	}

	@Override
	public void setMaxStackSize(int arg0) {
	}

	@Override
	public ItemStack splitWithoutUpdate(int arg0) {
		return null;
	}
}
