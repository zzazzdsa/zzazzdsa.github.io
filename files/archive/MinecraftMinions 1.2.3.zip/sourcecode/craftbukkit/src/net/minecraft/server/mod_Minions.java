package net.minecraft.server;

import forge.DimensionManager;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.minecraft.server.MinecraftServer;

public class mod_Minions extends BaseModMp
{
    private static long loadTime;
    public static MinecraftServer mcinstance;
    public static BaseModMp instance;
    private static File configfile = new File("mods/mod_minions_evils.cfg");
    public static final Item itemMastersStaff = (new AS_ItemMastersStaff(2527)).d(ModLoader.addOverride("/gui/items.png", "/mod_minions/masterstaff.png")).a("Master\'s Staff");
    private static MovingObjectPosition targetObjectMouseOver;
    public static ArrayList foundTreeBlocks = new ArrayList();
    public static ArrayList runningJobList = new ArrayList();
    public static ArrayList finishedJobList = new ArrayList();
    public static Map masterNames = new HashMap();
    public static Map masterCommits = new HashMap();
    private static int evilDeedXPCost = 2;
    private static int minionsPerPlayer = 4;
    private boolean minionsInSavegame = false;
    public static ArrayList evilDoings = new ArrayList();
    private boolean loaded = false;

    public void load()
    {
        if (!this.loaded)
        {
            this.loaded = true;
            loadTime = System.currentTimeMillis();
            ModLoader.setInGameHook(this, true, false);
            ModLoaderMp.registerEntityTrackerEntry(AS_EntityMinion.class, 85);
            ModLoaderMp.registerEntityTracker(AS_EntityMinion.class, 160, 5);
            instance = this;
            this.initializeSettingsFile();

            if (this.minionsInSavegame)
            {
                ModLoader.registerEntityID(AS_EntityMinion.class, "Minion", 17);
            }
        }
    }

    public void modsLoaded()
    {
        this.load();
        this.getViableTreeBlocks();
    }

    public String getVersion()
    {
        return "1.2.3";
    }

    public void onTickInGame(MinecraftServer var1)
    {
        mcinstance = var1;
        Iterator var2 = runningJobList.iterator();

        while (var2.hasNext())
        {
            if (finishedJobList.contains(var2))
            {
                finishedJobList.remove(var2);
                runningJobList.remove(var2);
            }
            else
            {
                ((AS_Minion_Job_Manager)var2.next()).onJobUpdateTick();
            }
        }
    }

    public static void onJobHasFinished(AS_Minion_Job_Manager var0)
    {
        if (!finishedJobList.contains(var0))
        {
            finishedJobList.add(var0);
        }
    }

    private static void cancelRunningJobsForMaster(String var0)
    {
        Iterator var2 = runningJobList.iterator();

        while (var2.hasNext())
        {
            AS_Minion_Job_Manager var1 = (AS_Minion_Job_Manager)var2.next();

            if (var1 != null && var1.masterName != null && var1.masterName.equals(var0))
            {
                var1.onJobFinished();
            }
        }
    }

    public static void MinionLoadRegister(AS_EntityMinion var0)
    {
        if (var0.masterUsername == null)
        {
            System.out.println("Loaded Minion without masterName, killing");
            var0.die();
        }
        else
        {
            String var1 = var0.masterUsername;

            if (!masterNames.containsKey(var1))
            {
                masterNames.put(var1, (Object)null);
            }

            AS_EntityMinion[] var2 = (AS_EntityMinion[])((AS_EntityMinion[])masterNames.get(var1));

            if (var2 == null)
            {
                var2 = new AS_EntityMinion[] {var0};
                masterNames.put(var1, var2);
            }
            else
            {
                if (var2.length >= minionsPerPlayer)
                {
                    System.out.println("Adding a minion too many for " + var1 + ", killing it NOW");
                    var0.die();
                    return;
                }

                AS_EntityMinion[] var3 = new AS_EntityMinion[var2.length + 1];

                for (int var4 = 0; var4 < var2.length; ++var4)
                {
                    var3[var4] = var2[var4];
                }

                var3[var2.length] = var0;
                masterNames.put(var1, var3);
            }
        }
    }

    public static void onMasterAddedEvil(EntityHuman var0)
    {
        if (masterCommits.get(var0.name) != null)
        {
            int var1 = ((Integer)masterCommits.get(var0.name)).intValue();
            ++var1;

            if (var1 == 4)
            {
                sendSoundToClients(var0, "mod_minions.thegodshaverewardedyouroffering");
                var0.inventory.pickup(new ItemStack(itemMastersStaff.id, 1, 0));
            }
            else
            {
                masterCommits.put(var0.name, Integer.valueOf(var1));
                sendSoundToClients(var0, "mod_minions.thegodsarepleaseedwithyoursacrifice");
            }
        }
        else
        {
            masterCommits.put(var0.name, Integer.valueOf(1));
            sendSoundToClients(var0, "mod_minions.thegodsarepleaseedwithyoursacrifice");
        }
    }

    public static boolean hasPlayerMinions(EntityHuman var0)
    {
        return masterNames.get(var0.name) != null;
    }

    public static boolean hasAllMinions(EntityHuman var0)
    {
        AS_EntityMinion[] var1 = (AS_EntityMinion[])((AS_EntityMinion[])masterNames.get(var0.name));
        return var1 == null ? false : var1.length >= minionsPerPlayer;
    }

    public void handleLogin(EntityPlayer var1) {}

    private ArrayList findEntitiesWithID(int ID)
    {
    	ArrayList result = new ArrayList();
    	int i = 0;

    	for (i = 0; i < mcinstance.worlds.size() && mcinstance.worlds.get(i) != null; i++)
    	{
    		List var13 = mcinstance.worlds.get(i).entityList;
    		Iterator var15 = var13.iterator();

    		while (var15.hasNext())
    		{
    			Entity var14 = (Entity)var15.next();

    			if (var14.id == ID)
    			{
    				result.add(var14);
    			}
    		}
    	}

        return result;
    }

    private EntityHuman findPlayerByName(String var1)
    {
        List var2 = mcinstance.serverConfigurationManager.players;
        Iterator var4 = var2.iterator();
        EntityHuman var3;

        do
        {
            if (!var4.hasNext())
            {
                return null;
            }

            var3 = (EntityHuman)var4.next();
        }
        while (!var3.name.equals(var1));

        return var3;
    }

    public void handlePacket(Packet230ModLoader var1, EntityPlayer var2)
    {
        if (var1.packetType != 0)
        {
            String var3;

            if (var1.packetType == 1)
            {
                var3 = var1.dataString[0];

                if (var2 != null && var2.expLevel >= evilDeedXPCost)
                {
                    var2.levelDown(evilDeedXPCost);
                    onMasterAddedEvil(var2);
                }
            }
            else
            {
                int var4;
                int var5;
                ArrayList var6;
                Iterator var7;
                Entity var8;

                if (var1.packetType == 2)
                {
                    var3 = var1.dataString[0];
                    var4 = var1.dataInt[0];
                    var5 = var1.dataInt[1];
                    var6 = this.findEntitiesWithID(var5);
                    var7 = var6.iterator();

                    while (var7.hasNext())
                    {
                        var8 = (Entity)var7.next();

                        if (var8 instanceof EntityAnimal || var8 instanceof EntityHuman)
                        {
                            EntityLiving var9 = (EntityLiving)var8;
                            orderMinionToPickupEntity(var2, var9);
                            break;
                        }
                    }
                }
                else if (var1.packetType == 3)
                {
                    var3 = var1.dataString[0];
                    var4 = var1.dataInt[0];
                    var5 = var1.dataInt[1];
                    var6 = this.findEntitiesWithID(var5);
                    var7 = var6.iterator();

                    while (var7.hasNext())
                    {
                        var8 = (Entity)var7.next();

                        if (var8 instanceof AS_EntityMinion)
                        {
                            AS_EntityMinion var14 = (AS_EntityMinion)var8;
                            orderMinionToDrop(var2, var14);
                            break;
                        }
                    }
                }
                else
                {
                    int var10;
                    int var12;

                    if (var1.packetType == 4)
                    {
                        var3 = var1.dataString[0];
                        var4 = var1.dataInt[0];
                        var5 = var1.dataInt[1];
                        var10 = var1.dataInt[2];
                        var12 = var1.dataInt[3];
                        spawnMinionsForPlayer(var2, var5, var10, var12);
                        Packet230ModLoader var13 = new Packet230ModLoader();
                        var13.packetType = 0;
                        var13.dataInt = new int[2];
                        var13.dataInt[0] = hasPlayerMinions(var2) ? 1 : 0;
                        var13.dataInt[1] = hasAllMinions(var2) ? 1 : 0;
                        ModLoaderMp.sendPacketTo(instance, var2, var13);
                    }
                    else if (var1.packetType == 5)
                    {
                        var3 = var1.dataString[0];
                        var4 = var1.dataInt[0];
                        var5 = var1.dataInt[1];
                        var10 = var1.dataInt[2];
                        var12 = var1.dataInt[3];
                        orderMinionsToChopTrees(var2, var5, var10, var12);
                    }
                    else if (var1.packetType == 6)
                    {
                        var3 = var1.dataString[0];
                        var4 = var1.dataInt[0];
                        var5 = var1.dataInt[1];
                        var10 = var1.dataInt[2];
                        var12 = var1.dataInt[3];
                        orderMinionsToDigStairWell(var2, var5, var10, var12);
                    }
                    else if (var1.packetType == 7)
                    {
                        var3 = var1.dataString[0];
                        var4 = var1.dataInt[0];
                        var5 = var1.dataInt[1];
                        var10 = var1.dataInt[2];
                        var12 = var1.dataInt[3];
                        orderMinionsToDigStripMineShaft(var2, var5, var10, var12);
                    }
                    else if (var1.packetType == 8)
                    {
                        var3 = var1.dataString[0];
                        var4 = var1.dataInt[0];
                        var5 = var1.dataInt[1];
                        var10 = var1.dataInt[2];
                        var12 = var1.dataInt[3];
                        orderMinionsToChestBlock(var2, var5, var10, var12);
                    }
                    else if (var1.packetType == 9)
                    {
                        var3 = var1.dataString[0];
                        var4 = var1.dataInt[0];
                        var5 = var1.dataInt[1];
                        var10 = var1.dataInt[2];
                        var12 = var1.dataInt[3];
                        orderMinionsToMoveTo(var2, var5, var10, var12);
                    }
                    else if (var1.packetType == 10)
                    {
                        var3 = var1.dataString[0];
                        var4 = var1.dataInt[0];
                        var5 = var1.dataInt[1];
                        var10 = var1.dataInt[2];
                        var12 = var1.dataInt[3];
                        orderMinionsToMineOre(var2, var5, var10, var12);
                    }
                    else if (var1.packetType == 11)
                    {
                        var3 = var1.dataString[0];
                        var4 = var1.dataInt[0];
                        orderMinionsToFollow(var2);
                    }
                    else if (var1.packetType == 13)
                    {
                        Packet230ModLoader var11 = new Packet230ModLoader();
                        var11.packetType = 13;
                        var11.dataInt = new int[1];
                        var11.dataInt[0] = evilDeedXPCost;
                        ModLoaderMp.sendPacketTo(instance, var2, var11);
                    }
                    else if (var1.packetType == 666)
                    {
                        var2.giveExp(200);
                    }
                }
            }
        }
    }

    static void sendSoundToClients(Entity var0, String var1)
    {
        Packet230ModLoader var2 = new Packet230ModLoader();
        var2.packetType = 12;
        var2.dataInt = new int[1];
        var2.dataInt[0] = var0.id;
        var2.dataString = new String[1];
        var2.dataString[0] = var1;
        ModLoaderMp.sendPacketToAll(instance, var2);
    }

    private static void orderMinionToPickupEntity(EntityHuman var0, EntityLiving var1)
    {
        AS_EntityMinion[] var2 = (AS_EntityMinion[])((AS_EntityMinion[])masterNames.get(var0.name));

        if (var2 != null)
        {
            for (int var3 = 0; var3 < var2.length; ++var3)
            {
                var2[var3].master = var0;

                if (var2[var3].passenger == null)
                {
                    var2[var3].targetEntityToGrab = var1;
                    sendSoundToClients(var2[var3], "mod_minions.grabanimalorder");
                    break;
                }
            }
        }
    }

    private static void orderMinionToDrop(EntityHuman var0, AS_EntityMinion var1)
    {
        if (var1.passenger != null)
        {
            sendSoundToClients(var1, "mod_minions.foryou");
            var1.passenger.mount((Entity)null);
        }
        else if (var1.inventory.containsItems())
        {
            sendSoundToClients(var1, "mod_minions.foryou");
            var1.a(var0, 180.0F, 180.0F);
            var1.inventory.dropAllItems();
        }
    }

    private static void spawnMinionsForPlayer(EntityHuman var0, int var1, int var2, int var3)
    {
        AS_EntityMinion[] var4 = (AS_EntityMinion[])((AS_EntityMinion[])masterNames.get(var0.name));

        if (var4 == null || var4.length < minionsPerPlayer)
        {
            int var5 = var4 == null ? 0 : var4.length;
            AS_EntityMinion[] var6 = new AS_EntityMinion[var5 + 1];

            for (int var7 = 0; var7 < var5; ++var7)
            {
                var6[var7] = var4[var7];
            }

            var6[var5] = new AS_EntityMinion(var0.world);
            var6[var5].setPosition((double)var1, (double)(var2 + 1), (double)var3);
            var0.world.addEntity(var6[var5]);
            var6[var5].setMaster(var0);
            masterNames.put(var0.name, var6);
        }

        orderMinionsToMoveTo(var0, var1, var2, var3);
    }

    private static void orderMinionsToChopTrees(EntityHuman var0, int var1, int var2, int var3)
    {
        AS_EntityMinion[] var4 = (AS_EntityMinion[])((AS_EntityMinion[])masterNames.get(var0.name));

        if (var4 != null)
        {
            for (int var5 = 0; var5 < var4.length; ++var5)
            {
                var4[var5].master = var0;
                var4[var5].giveTask((AS_BlockTask)null, true);
            }

            cancelRunningJobsForMaster(var0.name);
            runningJobList.add(new AS_Minion_Job_TreeHarvest(var4, var1, var2, var3));
            var0.world.makeSound(var0, "mod_minions.ordertreecutting", 1.0F, 1.0F);
        }
    }

    private static void orderMinionsToDigStairWell(EntityHuman var0, int var1, int var2, int var3)
    {
        AS_EntityMinion[] var4 = (AS_EntityMinion[])((AS_EntityMinion[])masterNames.get(var0.name));

        if (var4 != null)
        {
            for (int var5 = 0; var5 < var4.length; ++var5)
            {
                var4[var5].master = var0;
                var4[var5].giveTask((AS_BlockTask)null, true);
            }

            cancelRunningJobsForMaster(var0.name);
            runningJobList.add(new AS_Minion_Job_DigMineStairwell(var4, var1, var2 - 1, var3));
            var0.world.makeSound(var0, "mod_minions.ordermineshaft", 1.0F, 1.0F);
        }
    }

    private static void orderMinionsToDigStripMineShaft(EntityHuman var0, int var1, int var2, int var3)
    {
        AS_EntityMinion[] var4 = (AS_EntityMinion[])((AS_EntityMinion[])masterNames.get(var0.name));

        if (var4 != null)
        {
            for (int var5 = 0; var5 < var4.length; ++var5)
            {
                var4[var5].master = var0;
                var4[var5].giveTask((AS_BlockTask)null, true);
            }

            var4[0].master = var0;
            runningJobList.add(new AS_Minion_Job_StripMine(var4, var1, var2 - 1, var3));
            var0.world.makeSound(var0, "mod_minions.randomorder", 1.0F, 1.0F);
        }
    }

    private static void orderMinionsToChestBlock(EntityHuman var0, int var1, int var2, int var3)
    {
        AS_EntityMinion[] var4 = (AS_EntityMinion[])((AS_EntityMinion[])masterNames.get(var0.name));

        if (var4 != null)
        {
            TileEntity var5;

            if ((var5 = var0.world.getTileEntity(var1, var2 - 1, var3)) != null && var5 instanceof TileEntityChest)
            {
                cancelRunningJobsForMaster(var0.name);
                var0.world.makeSound(var0, "mod_minions.randomorder", 2.0F, 1.0F);

                for (int var6 = 0; var6 < var4.length; ++var6)
                {
                    var4[var6].master = var0;
                    var4[var6].giveTask((AS_BlockTask)null, true);
                    var4[var6].returnChest = (TileEntityChest)var5;
                    var4[var6].currentState = AS_EnumMinionState.RETURNING_GOODS;
                }
            }
        }
    }

    private static void orderMinionsToMoveTo(EntityHuman var0, int var1, int var2, int var3)
    {
        AS_EntityMinion[] var4 = (AS_EntityMinion[])((AS_EntityMinion[])masterNames.get(var0.name));

        if (var4 != null)
        {
            cancelRunningJobsForMaster(var0.name);
            var0.world.makeSound(var0, "mod_minions.randomorder", 1.0F, 0.8F);

            for (int var5 = 0; var5 < var4.length; ++var5)
            {
                var4[var5].master = var0;
                var4[var5].giveTask((AS_BlockTask)null, true);
                var4[var5].currentState = AS_EnumMinionState.IDLE;
                var4[var5].orderMinionToMoveTo(var1, var2, var3, false);
            }
        }
    }

    private static void orderMinionsToMineOre(EntityHuman var0, int var1, int var2, int var3)
    {
        AS_EntityMinion[] var4 = (AS_EntityMinion[])((AS_EntityMinion[])masterNames.get(var0.name));

        if (var4 != null)
        {
            if (isBlockValuable(var0.world.getTypeId(var1, var2 - 1, var3)))
            {
                cancelRunningJobsForMaster(var0.name);
                var0.world.makeSound(var0, "mod_minions.randomorder", 1.0F, 0.8F);

                for (int var5 = 0; var5 < var4.length; ++var5)
                {
                    var4[var5].master = var0;

                    if (!var4[var5].hasTask())
                    {
                        var4[var5].giveTask(new AS_BlockTask_MineOreVein((AS_Minion_Job_Manager)null, var4[var5], var1, var2 - 1, var3));
                        break;
                    }
                }
            }
        }
    }

    private static void orderMinionsToFollow(EntityHuman var0)
    {
        cancelRunningJobsForMaster(var0.name);
        AS_EntityMinion[] var1 = (AS_EntityMinion[])((AS_EntityMinion[])masterNames.get(var0.name));

        if (var1 != null)
        {
            var0.world.makeSound(var0, "mod_minions.orderfollowplayer", 1.0F, 0.8F);

            for (int var2 = 0; var2 < var1.length; ++var2)
            {
                var1[var2].master = var0;
                var1[var2].giveTask((AS_BlockTask)null, true);
                var1[var2].currentState = AS_EnumMinionState.FOLLOWING_PLAYER;
            }
        }
    }

    private void getViableTreeBlocks()
    {
        Block[] var1 = Block.byId;
        int var2 = var1.length;

        for (int var3 = 0; var3 < var2; ++var3)
        {
            Block var4 = var1[var3];

            if (var4 != null && var4.p() != null && (var4 instanceof BlockLog || var4.p().contains("log")))
            {
                foundTreeBlocks.add(Integer.valueOf(var4.id));
            }
        }
    }

    public static boolean isBlockIDViableTreeBlock(int var0)
    {
        return foundTreeBlocks.contains(Integer.valueOf(var0));
    }

    void initializeSettingsFile()
    {
        File var1 = configfile;

        try
        {
            if (var1.exists())
            {
                System.out.println("/mods/mod_minions_evils.cfg found and opened");
                BufferedReader var2 = new BufferedReader(new FileReader(var1));
                String var3;

                while ((var3 = var2.readLine()) != null)
                {
                    if (!var3.startsWith("//"))
                    {
                        String[] var4;

                        if (var3.startsWith("minionsPerPlayer"))
                        {
                            var4 = var3.split(":");
                            minionsPerPlayer = Integer.parseInt(var4[1]);
                            System.out.println("Config: Set minionsPerPlayer to " + minionsPerPlayer);
                        }
                        else if (var3.startsWith("evilDeedXPCost"))
                        {
                            var4 = var3.split(":");
                            evilDeedXPCost = Integer.parseInt(var4[1]);
                            System.out.println("Config: Set Evil Deed XP Cost to " + evilDeedXPCost);
                        }
                        else if (!var3.startsWith("minionMenuKey"))
                        {
                            if (var3.startsWith("minionsInSavegame"))
                            {
                                var4 = var3.split(":");
                                this.minionsInSavegame = Integer.parseInt(var4[1]) != 0;
                                System.out.println("Config: Set persisting Minions " + this.minionsInSavegame);
                            }
                            else
                            {
                                var4 = var3.split(":");
                                AS_EvilDeed var5 = new AS_EvilDeed(var4[0], var4[1], Integer.parseInt(var4[2]));
                                evilDoings.add(var5);
                            }
                        }
                    }
                }

                var2.close();
            }
            else
            {
                System.out.println("Could not open /mods/mod_minions_evils.cfg, you suck");
            }
        }
        catch (Exception var6)
        {
            System.out.println("EXCEPTION BufferedReader: " + var6);
        }
    }

    public static boolean isBlockValuable(int var0)
    {
        return var0 != 0 && var0 != Block.DIRT.id && var0 != Block.GRASS.id && var0 != Block.STONE.id && var0 != Block.COBBLESTONE.id && var0 != Block.GRAVEL.id && var0 != Block.SAND.id && var0 != Block.LEAVES.id && var0 != Block.OBSIDIAN.id && var0 != Block.BEDROCK.id && var0 != Block.COBBLESTONE_STAIRS.id && var0 != Block.NETHERRACK.id && var0 != Block.SOUL_SAND.id;
    }
}
