package net.minecraft.server;

import java.util.ArrayList;

public interface AS_IAStarPathedEntity
{
    void OnFoundPath(ArrayList var1);

    void OnNoPathAvailable();
}
