package net.minecraft.server;

import java.util.ArrayList;

public class AS_EntityMinion extends EntityCreature implements AS_IAStarPathedEntity
{
    public EntityHuman master;
    public String masterUsername;
    private ItemStack heldItem;
    public AS_InventoryMinion inventory;
    public boolean inventoryFull;
    public TileEntityChest returnChest;
    public AS_AStarPath pathPlanner;
    public AS_EnumMinionState currentState;
    public AS_EnumMinionState lastOrderedState;
    public AS_EnumMinionState nextState;
    private AS_PathEntity pathToWalkInputCache;
    private AS_PathEntity pathToWalkActive;
    public ChunkCoordinates currentTarget;
    private final int pathingCooldownTicks;
    private int currentPathNotFoundCooldownTick;
    private int pathFindingFails;
    private int currentPathingStopCooldownTick;
    private AS_BlockTask currentTask;
    public EntityLiving targetEntityToGrab;
    public float workSpeed;
    private long workBoostTime;
    public boolean isStripMining;
    private long timeLastSound;

    public AS_EntityMinion(World var1)
    {
        super(var1);
        this.heldItem = new ItemStack(Item.IRON_PICKAXE, 1);
        this.inventory = new AS_InventoryMinion(this);
        this.inventoryFull = false;
        this.currentState = AS_EnumMinionState.FOLLOWING_PLAYER;
        this.lastOrderedState = AS_EnumMinionState.FOLLOWING_PLAYER;
        this.nextState = null;
        this.pathingCooldownTicks = 30;
        this.currentPathNotFoundCooldownTick = 0;
        this.pathFindingFails = 0;
        this.currentPathingStopCooldownTick = 0;
        this.workSpeed = 1.0F;
        this.workBoostTime = 0L;
        this.isStripMining = false;
        this.fireProof = true;
        this.bb = 3.0F;
        this.width = (float)((double)this.width * 0.4D);
        this.texture = "/mod_minions/AS_EntityMinion.png";
        this.pathPlanner = new AS_AStarPath(this.world, this);
    }

    public AS_EntityMinion(World var1, double var2, double var4, double var6)
    {
        super(var1);
        this.heldItem = new ItemStack(Item.IRON_PICKAXE, 1);
        this.inventory = new AS_InventoryMinion(this);
        this.inventoryFull = false;
        this.currentState = AS_EnumMinionState.FOLLOWING_PLAYER;
        this.lastOrderedState = AS_EnumMinionState.FOLLOWING_PLAYER;
        this.nextState = null;
        this.pathingCooldownTicks = 30;
        this.currentPathNotFoundCooldownTick = 0;
        this.pathFindingFails = 0;
        this.currentPathingStopCooldownTick = 0;
        this.workSpeed = 1.0F;
        this.workBoostTime = 0L;
        this.isStripMining = false;
        this.enderTeleportTo(var2, var4, var6);
        this.texture = "/mod_minions/AS_EntityMinion.png";
        this.world.makeSound(this, "mod_minions.minionspawn", 1.0F, 1.0F);
        this.world.a("hugeexplosion", var2, var4, var6, 0.0D, 0.0D, 0.0D);
    }

    public void setMaster(EntityHuman var1)
    {
        this.master = var1;
        this.masterUsername = this.master.name;
    }

    protected void b()
    {
        super.b();
        this.datawatcher.a(12, new Integer(0));
        this.datawatcher.a(13, new Integer(0));
        this.datawatcher.a(14, new Integer(0));
        this.datawatcher.a(15, new Integer(0));
    }

    public void giveTask(AS_BlockTask var1, boolean var2)
    {
        if (var2)
        {
            this.currentTask = var1;
        }
        else
        {
            this.giveTask(var1);
        }
    }

    public void giveTask(AS_BlockTask var1)
    {
        this.currentTask = var1;

        if (this.currentTask == null)
        {
            this.ao = 0.0F;
            this.currentState = AS_EnumMinionState.RETURNING_GOODS;
            this.lastOrderedState = AS_EnumMinionState.RETURNING_GOODS;
        }
    }

    public AS_BlockTask getCurrentTask()
    {
        return this.currentTask;
    }

    public boolean hasTask()
    {
        return this.currentTask != null;
    }

    public int getMaxHealth()
    {
        return 20;
    }

    public boolean o_()
    {
        return true;
    }

    public boolean e_()
    {
        return false;
    }

    /**
     * Called by a player entity when they collide with an entity
     */
    public void a_(EntityHuman var1) {}

    /**
     * Applies a velocity to each of the entities pushing them away from each other. Args: entity
     */
    public void collide(Entity var1) {}

    /**
     * Determines if an entity can be despawned, used on idle far away entities
     */
    protected boolean n()
    {
        return false;
    }

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void b(NBTTagCompound var1)
    {
        super.b(var1);
        var1.set("MinionInventory", this.inventory.writeToNBT(new NBTTagList()));
        var1.setString("masterUsername", this.masterUsername);
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void a(NBTTagCompound var1)
    {
        super.a(var1);
        NBTTagList var2 = var1.getList("MinionInventory");
        this.inventory.readFromNBT(var2);
        this.masterUsername = var1.getString("masterUsername");
        this.master = this.world.a(this.masterUsername);
        mod_Minions.MinionLoadRegister(this);
    }

    private void performTeleportToTarget()
    {
        this.enderTeleportTo((double)this.currentTarget.x, (double)this.currentTarget.y, (double)this.currentTarget.z);
        this.world.makeSound(this, "random.pop", 0.5F, 1.0F);
    }

    public void performRecallTeleportToMaster()
    {
        if (this.master != null)
        {
            this.enderTeleportTo(this.master.locX + 1.0D, this.master.locY, this.master.locZ + 1.0D);
            this.world.makeSound(this, "random.pop", 0.5F, 1.0F);
        }
    }

    public void orderMinionToMoveTo(int var1, int var2, int var3, boolean var4)
    {
        if (this.pathPlanner.isBusy())
        {
            this.pathPlanner.stopPathSearch();
        }

        this.datawatcher.watch(12, Integer.valueOf(0));
        this.currentTarget = new ChunkCoordinates(var1, var2, var3);
        this.pathPlanner.getPath(this.doubleToInt(this.locX), this.doubleToInt(this.locY) - 1, this.doubleToInt(this.locZ), var1, var2, var3, var4);
    }

    /**
     * Called to update the entity's position/logic.
     */
    public void G_()
    {
        super.G_();

        if (this.passenger != null && this.passenger.equals(this.master) && !this.G())
        {
            this.yaw = this.pitch = 0.0F;
        }

        if (this.datawatcher.getInt(12) != 0)
        {
            this.ao = (float)((double)this.ao + 0.08500000089406967D * (double)this.workSpeed);

            if (this.ao > 1.0F)
            {
                this.ao = 0.0F;
            }

            int var1 = this.datawatcher.getInt(13);
            int var2 = this.datawatcher.getInt(14);
            int var3 = this.datawatcher.getInt(15);
            int var4 = this.world.getTypeId(var1, var2, var3);

            if (var4 > 0)
            {
                long var5 = System.currentTimeMillis();

                if ((float)(var5 - this.timeLastSound) > 500.0F / this.workSpeed)
                {
                    Block var7 = Block.byId[var4];
                    this.world.makeSound(this, var7.stepSound.getName(), (var7.stepSound.getVolume1() + 1.0F) / 2.0F, var7.stepSound.getVolume2() * 0.8F);
                    this.timeLastSound = var5;
                }

                this.world.a("tilecrack_" + var4, this.locX + ((double)this.random.nextFloat() - 0.5D), this.locY + 1.5D, this.locZ + ((double)this.random.nextFloat() - 0.5D), 1.0D, 1.0D, 1.0D);
            }
        }
        else
        {
            this.ao = 0.0F;
        }
    }

    /**
     * Gets called every tick from main Entity class
     */
    public void az()
    {
        super.az();

        if (this.workBoostTime != 0L && System.currentTimeMillis() - this.workBoostTime > 30000L)
        {
            this.workBoostTime = 0L;
            this.workSpeed = 1.0F;
        }

        if (this.targetEntityToGrab != null)
        {
            if (this.i(this.targetEntityToGrab) > 3.0F)
            {
                if (!this.G() || this.pathPlanner.isBusy())
                {
                    if (this.currentPathNotFoundCooldownTick > 0)
                    {
                        --this.currentPathNotFoundCooldownTick;
                    }
                    else
                    {
                        int var1 = this.doubleToInt(this.targetEntityToGrab.locX);
                        int var2 = this.doubleToInt(this.targetEntityToGrab.locY);
                        int var3;

                        for (var3 = this.doubleToInt(this.targetEntityToGrab.locZ); !AS_AStarStatic.isViable(this.world, new AS_AStarNode(var1, var2, var3, 0), 1); --var2)
                        {
                            ;
                        }

                        this.orderMinionToMoveTo(var1, var2, var3, false);
                        this.currentTarget = new ChunkCoordinates(this.doubleToInt(this.targetEntityToGrab.locX), this.doubleToInt(this.targetEntityToGrab.locY), this.doubleToInt(this.targetEntityToGrab.locZ));
                    }
                }
            }
            else if (this.passenger != this.targetEntityToGrab)
            {
                this.targetEntityToGrab.mount(this);
                this.targetEntityToGrab = null;
            }
        }
        else if (this.currentState != AS_EnumMinionState.WALKING_TO_COORDS && this.currentState != AS_EnumMinionState.THINKING)
        {
            AS_AStarNode[] var5;

            if ((this.currentState == AS_EnumMinionState.FOLLOWING_PLAYER || this.currentState == AS_EnumMinionState.RETURNING_GOODS && this.returnChest == null) && this.master != null && !this.G())
            {
                if (this.i(this.master) > 5.0F && !this.pathPlanner.isBusy())
                {
                    if (this.currentPathNotFoundCooldownTick > 0)
                    {
                        --this.currentPathNotFoundCooldownTick;
                    }
                    else
                    {
                        if (this.i(this.master) > 40.0F)
                        {
                            this.performRecallTeleportToMaster();
                        }

                        var5 = AS_AStarStatic.getAccessNodesSorted(this.world, this.doubleToInt(this.locX), this.doubleToInt(this.locY), this.doubleToInt(this.locZ), this.doubleToInt(this.master.locX), this.doubleToInt(this.master.locY) - 1, this.doubleToInt(this.master.locZ));

                        if (var5.length != 0)
                        {
                            this.orderMinionToMoveTo(var5[0].x, var5[0].y, var5[0].z, false);
                            this.currentTarget = new ChunkCoordinates(this.doubleToInt(this.master.locX), this.doubleToInt(this.master.locY) - 1, this.doubleToInt(this.master.locZ));
                        }
                    }
                }
                else if (this.i(this.master) < 5.0F && this.currentState == AS_EnumMinionState.RETURNING_GOODS && this.returnChest == null && this.inventory.containsItems())
                {
                    this.world.makeSound(this, "mod_minions.foryou", 1.0F, 1.0F);
                    this.a(this.master, 180.0F, 180.0F);
                    this.inventory.dropAllItems();
                }
            }
            else if (this.currentState == AS_EnumMinionState.RETURNING_GOODS && this.returnChest != null)
            {
                if (this.getDistanceToEntity(this.returnChest) > 4.0D)
                {
                    if (!this.G() || this.pathPlanner.isBusy())
                    {
                        if (this.currentPathNotFoundCooldownTick > 0)
                        {
                            --this.currentPathNotFoundCooldownTick;
                        }
                        else
                        {
                            var5 = AS_AStarStatic.getAccessNodesSorted(this.world, this.doubleToInt(this.locX), this.doubleToInt(this.locY), this.doubleToInt(this.locZ), this.returnChest.x, this.returnChest.y, this.returnChest.z);

                            if (var5.length != 0)
                            {
                                this.orderMinionToMoveTo(var5[0].x, var5[0].y, var5[0].z, false);
                                this.currentTarget = new ChunkCoordinates(var5[0].x, var5[0].y, var5[0].z);
                            }
                        }
                    }
                }
                else
                {
                    if (this.inventory.containsItems())
                    {
                        this.openChest(this.returnChest);
                        this.inventory.putAllItemsToChest(this.returnChest);
                    }

                    this.currentState = AS_EnumMinionState.IDLE;
                    this.orderMinionToMoveTo(this.doubleToInt(this.locX), this.doubleToInt(this.locY) - 1, this.doubleToInt(this.locZ), false);
                }
            }
        }
        else if (this.hasReachedTarget())
        {
            this.pathToWalkActive = null;

            if (this.nextState != null)
            {
                if (this.nextState == AS_EnumMinionState.WALKING_TO_COORDS)
                {
                    this.nextState = this.lastOrderedState;
                }

                this.currentState = this.nextState;
            }
            else
            {
                this.currentState = this.lastOrderedState;
            }
        }
        else if (this.pathToWalkActive != null && this.pathToWalkActive.getTimeSinceLastPathIncrement() > 750L)
        {
            ++this.currentPathingStopCooldownTick;

            if (this.currentPathingStopCooldownTick > 30)
            {
                this.currentPathingStopCooldownTick = 0;
                PathPoint var4 = this.pathToWalkActive.getCurrentTargetPathPoint();

                if (var4 != null)
                {
                    this.pathToWalkActive.a();
                    this.enderTeleportTo((double)var4.a + 0.5D, (double)var4.b + 0.5D, (double)var4.c + 0.5D);
                    this.motX = 0.0D;
                    this.motZ = 0.0D;
                    this.pathPlanner.getPath(this.doubleToInt(this.locX), this.doubleToInt(this.locY) - 1, this.doubleToInt(this.locZ), this.currentTarget.x, this.currentTarget.y, this.currentTarget.z, false);
                }
                else
                {
                    this.performTeleportToTarget();
                }
            }
        }
    }

    private void openChest(TileEntityChest var1)
    {
        if (var1.c != null)
        {
            var1.c.f = 1.0F;
        }
        else if (var1.d != null)
        {
            var1.d.f = 1.0F;
        }
        else if (var1.e != null)
        {
            var1.e.f = 1.0F;
        }
        else if (var1.b != null)
        {
            var1.b.f = 1.0F;
        }

        var1.f = 1.0F;
    }

    private double getDistanceToEntity(TileEntity var1)
    {
        return AS_AStarStatic.getDistanceBetweenCoords(this.doubleToInt(this.locX), this.doubleToInt(this.locY), this.doubleToInt(this.locZ), var1.x, var1.y, var1.z);
    }

    public boolean hasReachedTarget()
    {
        return !this.G() && this.currentTarget != null && AS_AStarStatic.getDistanceBetweenCoords(this.doubleToInt(this.locX), this.doubleToInt(this.locY), this.doubleToInt(this.locZ), this.currentTarget.x, this.currentTarget.y, this.currentTarget.z) < 1.5D;
    }

    public void d_()
    {
        super.d_();

        if (this.onGround)
        {
            double var1 = AS_AStarStatic.getEntityLandSpeed(this);

            if (var1 > 0.1D && var1 < 0.3D)
            {
                this.motX *= 1.25D;
                this.motZ *= 1.25D;
            }
        }

        if (this.pathToWalkInputCache != null)
        {
            this.setPathEntity(this.pathToWalkInputCache);
            this.currentState = AS_EnumMinionState.WALKING_TO_COORDS;
            this.pathToWalkActive = this.pathToWalkInputCache;
            this.pathToWalkInputCache = null;
        }

        if (this.hasTask())
        {
            this.currentTask.onUpdate();
        }
    }

    protected void F()
    {
        if (this.currentState == AS_EnumMinionState.IDLE && this.currentTarget != null && this.passenger == null)
        {
            MethodProfiler.a("stroll");
            boolean var1 = false;
            int var2 = -1;
            int var3 = -1;
            int var4 = -1;
            float var5 = -99999.0F;

            for (int var6 = 0; var6 < 10; ++var6)
            {
                int var7 = MathHelper.floor((double)this.currentTarget.x + (double)this.random.nextInt(6) - 6.0D);
                int var8 = MathHelper.floor((double)this.currentTarget.y + (double)this.random.nextInt(3) - 3.0D);
                int var9 = MathHelper.floor((double)this.currentTarget.z + (double)this.random.nextInt(6) - 6.0D);
                float var10 = this.a(var7, var8, var9);

                if (var10 > var5)
                {
                    var5 = var10;
                    var2 = var7;
                    var3 = var8;
                    var4 = var9;
                    var1 = true;
                }
            }

            if (var1)
            {
                this.setPathEntity(this.world.a(this, var2, var3, var4, 10.0F, false, false, false, false));
            }

            MethodProfiler.a();
        }
    }

    /**
     * Called when the entity is attacked.
     */
    public boolean damageEntity(DamageSource var1, int var2)
    {
        if (var1.getEntity() != null)
        {
            if (var1.getEntity().equals(this.master))
            {
                this.workBoostTime = System.currentTimeMillis();
                this.workSpeed = 2.0F;
                this.master.c(this);
                this.world.makeSound(this, "mod_minions.minionsqueak", 1.0F, 1.0F);

                if (this.passenger != null)
                {
                    this.passenger.mount((Entity)null);
                    return true;
                }

                return true;
            }

            if (var1.getEntity() instanceof EntityHuman && this.passenger != null)
            {
                this.passenger.mount((Entity)null);
                return true;
            }
        }

        return false;
    }

    public void faceBlock(int var1, int var2, int var3)
    {
        double var4 = (double)var1 - this.locX;
        double var6 = (double)var3 - this.locZ;
        double var8 = (double)var2 - this.locY;
        double var10 = (double)MathHelper.sqrt(var4 * var4 + var6 * var6);
        float var12 = (float)(Math.atan2(var6, var4) * 180.0D / Math.PI) - 90.0F;
        float var13 = (float)(-(Math.atan2(var8, var10) * 180.0D / Math.PI));
        this.pitch = -var13;
        this.yaw = var12;
    }

    private AS_PathEntity getCurrentEntityPath()
    {
        AS_EntityMinion var1 = this;
        this.getClass().getDeclaredFields()[0].setAccessible(true);

        try
        {
            Object var2 = var1.getClass().getDeclaredFields()[0].get(this);

            if (var2 instanceof AS_PathEntity)
            {
                return (AS_PathEntity)var2;
            }
        }
        catch (IllegalArgumentException var3)
        {
            var3.printStackTrace();
        }
        catch (SecurityException var4)
        {
            var4.printStackTrace();
        }
        catch (IllegalAccessException var5)
        {
            var5.printStackTrace();
        }

        return null;
    }

    public void OnFoundPath(ArrayList var1)
    {
        this.currentPathNotFoundCooldownTick = 30;
        this.pathFindingFails = 0;
        this.pathToWalkInputCache = AS_AStarStatic.translateAStarPathtoPathEntity(var1);
        this.nextState = this.currentState;
    }

    public void OnNoPathAvailable()
    {
        if (this.hasTask())
        {
            this.currentTask.onWorkerPathFailed();
        }

        this.currentPathNotFoundCooldownTick = 30;
        ++this.pathFindingFails;

        if (this.pathFindingFails == 3)
        {
            this.performTeleportToTarget();
            this.pathFindingFails = 0;
        }
    }

    public String getDisplayName()
    {
        return null;
    }

    public void dropMinionItemWithRandomChoice(ItemStack var1)
    {
        if (var1 != null)
        {
            EntityItem var2 = new EntityItem(this.world, this.locX, this.locY - 0.30000001192092896D + (double)this.getHeadHeight(), this.locZ, var1);
            var2.pickupDelay = 40;
            float var3 = 0.1F;
            var2.motX = (double)(-MathHelper.sin(this.yaw / 180.0F * (float)Math.PI) * MathHelper.cos(this.pitch / 180.0F * (float)Math.PI) * var3);
            var2.motZ = (double)(MathHelper.cos(this.yaw / 180.0F * (float)Math.PI) * MathHelper.cos(this.pitch / 180.0F * (float)Math.PI) * var3);
            var2.motY = (double)(-MathHelper.sin(this.pitch / 180.0F * (float)Math.PI) * var3 + 0.1F);
            var3 = 0.02F;
            float var4 = this.random.nextFloat() * (float)Math.PI * 2.0F;
            var3 *= this.random.nextFloat();
            var2.motX += Math.cos((double)var4) * (double)var3;
            var2.motY += (double)((this.random.nextFloat() - this.random.nextFloat()) * 0.1F);
            var2.motZ += Math.sin((double)var4) * (double)var3;
            this.world.addEntity(var2);
        }
    }

    public int doubleToInt(double var1)
    {
        return AS_AStarStatic.getIntCoordFromDoubleCoord(var1);
    }
}
