package net.minecraft.server;

public class AS_BlockTask_TreeChop extends AS_BlockTask
{
    private int treeBlocks = 0;
    private int treeBlockID;
    private int treeBlockmetadata;

    public AS_BlockTask_TreeChop(AS_Minion_Job_Manager var1, AS_EntityMinion var2, int var3, int var4, int var5)
    {
        super(var1, var2, var3, var4, var5);
        this.setTaskDuration(5000L);
    }

    public void onUpdate()
    {
        super.onUpdate();
    }

    public void onFinishedTask()
    {
        super.onFinishedTask();
        this.chopTree();

        if (this.treeBlockID != 0)
        {
            this.placeWoodInMinionInventory(this.worker);
        }
    }

    private void placeWoodInMinionInventory(AS_EntityMinion var1)
    {
        ItemStack var2 = Block.byId[this.treeBlockID].a_(this.treeBlockmetadata);
        var2.count = this.treeBlocks;

        if (!var1.inventory.addItemStackToInventory(var2))
        {
            EntityItem var3 = new EntityItem(var1.world, var1.locX, var1.locY - 0.30000001192092896D + (double)var1.getHeadHeight(), var1.locZ, var2);
            var3.pickupDelay = 40;
            var1.world.addEntity(var3);
        }
    }

    private void chopTree()
    {
        this.treeBlockID = this.worker.world.getTypeId(this.posX, this.posY, this.posZ);
        this.treeBlockmetadata = this.worker.world.getData(this.posX, this.posY, this.posZ);
        this.chopTreeBlockRecursive(this.posX, this.posY, this.posZ);
    }

    private void chopTreeBlockRecursive(int var1, int var2, int var3)
    {
        byte var4 = 1;

        for (int var5 = -var4; var5 <= var4; ++var5)
        {
            for (int var6 = -var4; var6 <= var4; ++var6)
            {
                for (int var7 = 0; var7 <= var4; ++var7)
                {
                    if (this.worker.world.getTypeId(var1 + var5, var2 + var7, var3 + var6) == this.treeBlockID && this.worker.world.setTypeId(var1 + var5, var2 + var7, var3 + var6, 0))
                    {
                        ++this.treeBlocks;
                        this.chopTreeBlockRecursive(var1 + var5, var2 + var7, var3 + var6);
                    }
                }
            }
        }
    }
}
