package net.minecraft.server;

import java.util.ArrayList;

public class AS_AStarWorker extends Thread
{
    private AS_AStarPath boss;
    private boolean isRunning = false;
    public ArrayList closedNodes = new ArrayList();
    private AS_AStarNode startNode;
    private AS_AStarNode targetNode;
    private boolean searchMode;
    private World worldObj;
    private long startingTime;
    private int checkedCubes = 0;
    public int maxCheckedCubes = 1000;
    public int maxSize = 20;
    public int maxSizeSq;
    public int maxSizeSqMinusOne;
    private AS_AStarNode[] openList;
    private int addedItems;

    public AS_AStarWorker(AS_AStarPath var1)
    {
        this.maxSizeSq = this.maxSize * this.maxSize;
        this.maxSizeSqMinusOne = this.maxSizeSq - 1;
        this.openList = new AS_AStarNode[this.maxSizeSq];
        this.addedItems = 1;
        this.boss = var1;
    }

    public void run()
    {
        if (!this.isRunning)
        {
            this.isRunning = true;
            ArrayList var1 = null;
            var1 = this.getPath(this.startNode, this.targetNode, this.searchMode);

            if (var1 == null)
            {
                this.boss.OnNoPathAvailable();
            }
            else
            {
                this.boss.OnFoundPath(var1);
            }
        }
    }

    public void setup(World var1, AS_AStarNode var2, AS_AStarNode var3, boolean var4)
    {
        this.worldObj = var1;
        this.startNode = var2;
        this.targetNode = var3;
        this.searchMode = var4;
    }

    public void resetSearch()
    {
        this.closedNodes = new ArrayList();
        this.checkedCubes = 0;
        this.openList = new AS_AStarNode[this.maxSizeSq + 1];
        this.addedItems = 1;
    }

    public ArrayList getPath(int var1, int var2, int var3, int var4, int var5, int var6, boolean var7)
    {
        AS_AStarNode var8 = new AS_AStarNode(var1, var2, var3, 0);
        AS_AStarNode var9 = new AS_AStarNode(var4, var5, var6, -1);
        return this.getPath(var8, var9, var7);
    }

    public ArrayList getPath(AS_AStarNode var1, AS_AStarNode var2, boolean var3)
    {
        this.openList[1] = var1;
        this.startingTime = System.currentTimeMillis();
        this.targetNode = var2;
        var1.f_distanceToGoal = AS_AStarStatic.getDistanceBetweenNodes(var1, this.targetNode);
        AS_AStarNode var4;

        for (var4 = var1; !var4.equals(var2); var4 = this.openList[1])
        {
            this.deleteLowestValueInHeap();
            this.closedNodes.add(var4);
            this.checkPossibleLadder(var4);
            this.getNextCandidates(var4, var3);

            if (this.addedItems == 0 || this.addedItems == this.maxSizeSqMinusOne || Thread.interrupted() || this.checkedCubes >= this.maxCheckedCubes)
            {
                return null;
            }
        }

        ArrayList var5 = new ArrayList();
        var5.add(var4);

        while (var4 != var1)
        {
            var5.add(var4.parent);
            var4 = var4.parent;
        }

        return var5;
    }

    private void addToBinaryHeap(AS_AStarNode var1)
    {
        ++this.addedItems;

        if (this.addedItems == this.maxSizeSqMinusOne)
        {
            Thread.yield();
        }
        else
        {
            this.openList[this.addedItems] = var1;
            this.sortBinaryHeap();
            ++this.checkedCubes;
        }
    }

    private void sortBinaryHeap()
    {
        this.sortBinaryHeapFromValue(this.addedItems);
    }

    private void sortBinaryHeapFromValue(int var1)
    {
        while (var1 > 1 && this.openList[var1].f_distanceToGoal <= this.openList[var1 / 2].f_distanceToGoal)
        {
            AS_AStarNode var2 = this.openList[var1 / 2];
            this.openList[var1 / 2] = this.openList[var1];
            this.openList[var1] = var2;
            var1 /= 2;
        }
    }

    private void deleteLowestValueInHeap()
    {
        this.openList[1] = this.openList[this.addedItems];
        --this.addedItems;
        int var2 = 1;

        while (true)
        {
            int var3 = var2;

            if (2 * var2 + 1 <= this.addedItems)
            {
                if (this.openList[var2].f_distanceToGoal >= this.openList[2 * var2].f_distanceToGoal)
                {
                    var2 = 2 * var2;
                }

                if (this.openList[var2].f_distanceToGoal >= this.openList[2 * var3 + 1].f_distanceToGoal)
                {
                    var2 = 2 * var3 + 1;
                }
            }
            else if (2 * var2 <= this.addedItems && this.openList[var2].f_distanceToGoal >= this.openList[2 * var2].f_distanceToGoal)
            {
                var2 = 2 * var2;
            }

            if (var2 == var2)
            {
                return;
            }

            AS_AStarNode var1 = this.openList[var3];
            this.openList[var3] = this.openList[var2];
            this.openList[var2] = var1;
        }
    }

    private void checkPossibleLadder(AS_AStarNode var1)
    {
        int var2 = var1.x;
        int var3 = var1.y;
        int var4 = var1.z;

        if (AS_AStarStatic.isLadder(this.worldObj.getTypeId(var2, var3, var4)))
        {
            AS_AStarNode var5 = null;

            if (AS_AStarStatic.isLadder(this.worldObj.getTypeId(var2, var3 + 1, var4)))
            {
                var5 = new AS_AStarNode(var2, var3 + 1, var4, var1.g_BlockDistToStart + 1, var1);
                var5.f_distanceToGoal = AS_AStarStatic.getDistanceBetweenNodes(var5, this.targetNode);

                if (!this.tryToFindExistingHeapNode(var1, var5))
                {
                    this.addToBinaryHeap(var5);
                }
            }

            if (AS_AStarStatic.isLadder(this.worldObj.getTypeId(var2, var3 - 1, var4)))
            {
                var5 = new AS_AStarNode(var2, var3 - 1, var4, var1.g_BlockDistToStart + 1, var1);
                var5.f_distanceToGoal = AS_AStarStatic.getDistanceBetweenNodes(var5, this.targetNode);

                if (!this.tryToFindExistingHeapNode(var1, var5))
                {
                    this.addToBinaryHeap(var5);
                }
            }
        }
    }

    public void getNextCandidates(AS_AStarNode var1, boolean var2)
    {
        int var3 = var1.x;
        int var4 = var1.y;
        int var5 = var1.z;
        int var6 = var1.g_BlockDistToStart;
        int[][] var7 = var2 ? AS_AStarStatic.candidates_allowdrops : AS_AStarStatic.candidates;

        for (int var9 = 0; var9 < var7.length; ++var9)
        {
            AS_AStarNode var8 = new AS_AStarNode(var3 + var7[var9][0], var4 + var7[var9][1], var5 + var7[var9][2], var6 + var7[var9][3], var1);
            var8.f_distanceToGoal = AS_AStarStatic.getDistanceBetweenNodes(var8, this.targetNode);

            if (this.closedNodes.contains(var8))
            {
                ((AS_AStarNode)this.closedNodes.get(this.closedNodes.indexOf(var8))).updateDistance(var8.g_BlockDistToStart, var1);
            }
            else if (!this.tryToFindExistingHeapNode(var1, var8) && AS_AStarStatic.isViable(this.worldObj, var8, var7[var9][1]))
            {
                this.addToBinaryHeap(var8);
            }
        }
    }

    private boolean tryToFindExistingHeapNode(AS_AStarNode var1, AS_AStarNode var2)
    {
        for (int var3 = 1; var3 <= this.addedItems; ++var3)
        {
            if (this.openList[var3] != null && this.openList[var3].equals(var2))
            {
                if (this.openList[var3].updateDistance(var2.g_BlockDistToStart, var1))
                {
                    this.sortBinaryHeapFromValue(var3);
                    return true;
                }

                return false;
            }
        }

        return false;
    }
}
