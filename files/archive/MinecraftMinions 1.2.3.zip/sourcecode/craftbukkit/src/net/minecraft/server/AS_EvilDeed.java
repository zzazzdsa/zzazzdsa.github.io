package net.minecraft.server;

public class AS_EvilDeed
{
    private final String buttonText;
    private final String soundFile;
    private final int soundLength;

    public AS_EvilDeed(String var1, String var2, int var3)
    {
        this.buttonText = var1;
        this.soundFile = var2;
        this.soundLength = var3;
    }

    public String getButtonText()
    {
        return this.buttonText;
    }

    public String getSoundFile()
    {
        return this.soundFile;
    }

    public int getSoundLength()
    {
        return this.soundLength;
    }
}
