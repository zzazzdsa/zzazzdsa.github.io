package net.minecraft.src;

/**
 * Minion Job class for scanning for Trees and then keeping track of the minions harvesting them.
 * 
 * 
 * @author AtomicStryker
 */

public class AS_Minion_Job_TreeHarvest extends AS_Minion_Job_Manager
{
	private volatile AS_TreeScanner treeScanWorker;
	private volatile Thread thread;
	private World worldObj;
	private boolean isWorking = false;
	private boolean doneLookingForTrees = false;
	
    public AS_Minion_Job_TreeHarvest(AS_EntityMinion[] minions, int ix, int iy, int iz)
    {
    	super(minions, ix, iy, iz);
    	this.worldObj = minions[0].worldObj;
    }
    
    public void onJobStarted()
    {
    	super.onJobStarted();
    	
    	treeScanWorker = new AS_TreeScanner(this);
    	treeScanWorker.setup(pointOfOrigin, worldObj);
    	
    	thread = new Thread(treeScanWorker);
    	thread.run();
    }
    
    public void onJobUpdateTick()
    {
    	if (!isWorking)
    	{
    		//System.out.println("onJobUpdateTick, starting Tree Job now!");
    		isWorking = true;
    		onJobStarted();
    		return;
    	}
    	
    	ChunkCoordinates nextTree = null;
    	AS_EntityMinion worker;
    	boolean hasJobs = !this.jobQueue.isEmpty();
    	
    	if (hasJobs)
    	{
	    	nextTree = (ChunkCoordinates) this.jobQueue.get(0);
	    	worker = this.getNearestAvailableWorker(nextTree.posX, nextTree.posY, nextTree.posZ);
    	}
    	else
    	{
    		worker = this.getAnyAvailableWorker();
    	}
    	if (worker != null)
    	{
    		if (hasJobs)
    		{
    			// order him to walk there and chop the tree
    			worker.giveTask(new AS_BlockTask_TreeChop(this, worker, nextTree.posX, nextTree.posY, nextTree.posZ));
    			this.jobQueue.remove(0);
    		}
    		else
    		{
    			this.setWorkerFree(worker);
    		}
    	}
    }
    
    public void onJobFinished()
    {
    	if (thread != null && !thread.isInterrupted())
    	{
    		thread.interrupt();
    	}
    	
    	super.onJobFinished();
    }
    
	public void onFoundTreeBase(int ix, int iy, int iz)
	{
		ChunkCoordinates newJob = new ChunkCoordinates(ix, iy, iz);
		if (!this.jobQueue.contains(newJob))
		{
			this.jobQueue.add(newJob);
		}
		//System.out.println("Found Tree Base at: ["+ix+"|"+iy+"|"+iz+"], job Queue size now: "+this.jobQueue.size());
	}
	
	public void onDoneFindingTrees()
	{
		doneLookingForTrees = true;
	}
}