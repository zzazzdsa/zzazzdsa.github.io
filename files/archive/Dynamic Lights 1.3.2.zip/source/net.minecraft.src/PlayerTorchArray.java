package net.minecraft.src;

import java.io.*;
import java.util.*;

import cpw.mods.fml.client.FMLClientHandler;

import net.minecraft.src.Entity;
import net.minecraft.src.EnumSkyBlock;
import net.minecraft.src.World;

public class PlayerTorchArray
{
    static java.util.List torchArray = new ArrayList();
	static java.util.List torchEntityArray = new ArrayList();
	static int [][] lightdata = new int[32][5];
	
	static boolean disableAllLights = false;
	static File settingsFile = null;
	
	static int GetItemBrightnessValue(int ID)
	{	
		int i = 0;
		while (lightdata[i][0] != 0)
		{
			if(lightdata[i][0] == ID)
			{
				return lightdata[i][1];
			}
			i++;
		}
		
		return 0;
	}
	
	static int GetItemLightRangeValue(int ID)
	{
		int i = 0;
		while (lightdata[i][0] != 0)
		{
			if(lightdata[i][0] == ID)
			{
				return lightdata[i][2];
			}
			i++;
		}
		
		return 0;
	}
	
	static int GetItemDeathAgeTicksValue(int ID)
	{
		int i = 0;
		while (lightdata[i][0] != 0)
		{
			if(lightdata[i][0] == ID)
			{
				return lightdata[i][3];
			}
			i++;
		}
		
		return -1;
	}
	
	static boolean GetItemWorksUnderWaterValue(int ID)
	{
		int i = 0;
		while (lightdata[i][0] != 0)
		{
			if(lightdata[i][0] == ID)
			{
				return (lightdata[i][4] != 0);
			}
			i++;
		}
		
		return false;
	}

	public static int getBlockTorchBrightness(int retVal, World worldObj, EnumSkyBlock var1, int var2, int var3, int var4)
	{
	    if (var1 == EnumSkyBlock.Sky || !AreTorchesActive())
	    {
	    	return retVal;
	    }
	    else
	    {
			int cached = LightCache.cache.getLightValue(var2, var3, var4);
			if (cached > retVal) return cached;

	  		int torchLight = (int)java.lang.Math.round(PlayerTorchArray.getLightBrightness(worldObj, var2, var3, var4));
	 		if(retVal < torchLight)
	 		{
	 			return torchLight;
	 		}
	 	}

	 	LightCache.cache.setLightValue(var2, var3, var4, retVal);
	 	return retVal;
	}
	
	public static float getLightBrightness(World world, int i, int j, int k)
	{	
		float torchLight = 0.0F;
		if (disableAllLights) return torchLight;
		
		float lightBuffer;
		PlayerTorch torchLoopClass;
		for(int x = torchArray.size(); --x >= 0;)
        {
			torchLoopClass = (PlayerTorch)torchArray.get(x);
			lightBuffer = torchLoopClass.getTorchLight(world, i, j, k);
			if(lightBuffer > torchLight)
			{
				torchLight = lightBuffer;
			}
		}
		
		return torchLight;
	}
	
	static void ToggleDynamicLights()
	{
		disableAllLights = !disableAllLights;
	}
	
	public static boolean AreTorchesActive()
	{
		if (!disableAllLights)
		{
			PlayerTorch torchLoopClass;
			for(int x = torchArray.size(); --x >= 0;)
			{
				torchLoopClass = (PlayerTorch)torchArray.get(x);
				if (torchLoopClass.isTorchActive())
					return true;
			}
		}
		return false;
	}
	
	static void AddTorchToArray(PlayerTorch playertorch)
    {		
        torchArray.add(playertorch);
		torchEntityArray.add(playertorch.GetTorchEntity());
    }
	
	static void RemoveTorchFromArray(World world, PlayerTorch playertorch)
	{
		playertorch.setTorchState(world, false);
		torchArray.remove(playertorch);
		torchEntityArray.remove(playertorch.GetTorchEntity());
	}
	
	static PlayerTorch GetTorchForEntity(Entity ent)
	{
		if(torchEntityArray.contains(ent))
		{
			PlayerTorch torchLoopClass;
			for(int x = torchArray.size(); --x >= 0;)
			{
				torchLoopClass = (PlayerTorch)torchArray.get(x);
				if (torchLoopClass.GetTorchEntity() == ent)
				{
					return torchLoopClass;
				}
			}
		}
		
		return null;
	}
	
	static void initializeSettingsFile()
	{
		settingsFile = new File(FMLClientHandler.instance().getClient().getAppDir("minecraft"), "dynamiclights.settings");
		
		try
		{
			if(settingsFile.exists())
			{
				BufferedReader in = new BufferedReader(new FileReader(settingsFile));
				String sCurrentLine;
				int i = 0;
				
				while ((sCurrentLine = in.readLine()) != null)
				{
					if(sCurrentLine.startsWith("//")) continue;
					
					if(sCurrentLine.startsWith("ToggleButton"))
					{
						String[] splits = sCurrentLine.split(":");
						Dynamiclights.assignToggleButton(splits[1]);
						continue;
					}
					
					String[] curLine = sCurrentLine.split(":");

					lightdata[i][0] = Integer.parseInt(curLine[0]); // Item ID
					lightdata[i][1] = Integer.parseInt(curLine[1]); // Max Brightness
					lightdata[i][2] = Integer.parseInt(curLine[2]); // Range
					
					if (curLine.length > 3)
						lightdata[i][3] = Integer.parseInt(curLine[3]); // Death Age
					else
						lightdata[i][3] = -1;
						
					if (curLine.length > 4)
						lightdata[i][4] = Integer.parseInt(curLine[4]); // Works Underwater
					else
						lightdata[i][4] = 1;
					
					i++;
					
					System.out.println("read Torch item no " +i+ " of ID " + curLine[0] + ", brightness " + curLine[1] + ", range " + curLine[2]);
				}
				lightdata[i][0] = 0; // Just to make sure we have an ending marked
				
				in.close();
			}
		}
		catch (Exception fuckdammit)
		{
			fuckdammit.printStackTrace();
		}
	}
	
	public static java.util.List getListOfDynamicLights()
	{
		return torchArray;
	}
	
	public static PlayerTorch getDynamicLightForEntity(Entity entity)
	{
		return GetTorchForEntity(entity);
	}
	
	public static Entity getEntityForDynamicLight(PlayerTorch light)
	{
		return light.GetTorchEntity();
	}
	
	public static float[] getDynamicLightPosition(PlayerTorch light)
	{
		float[] pos = new float[3];
		pos[0] = light.posX;
		pos[1] = light.posY;
		pos[2] = light.posZ;
		return pos;
	}
	
	public static int getItemBrightnessValue(int itemID)
	{
		return GetItemBrightnessValue(itemID);
	}
	
	public static int getItemLightRangeValue(int itemID)
	{
		return GetItemLightRangeValue(itemID);
	}
	
	public static int getItemDeathAgeTicksValue(int itemID)
	{
		return GetItemDeathAgeTicksValue(itemID);
	}

	public static boolean getItemWorksUnderWaterValue(int itemID)
	{
		return GetItemWorksUnderWaterValue(itemID);
	}

	public static void toggleDynamicLightsOnOff()
	{
		ToggleDynamicLights();
	}
	
	public static boolean getAreAnyLightsActive()
	{
		return AreTorchesActive();
	}
	
	public static void registerDynamicLight(PlayerTorch light)
	{
		light.FlagTorchAsCustom();
		AddTorchToArray(light);
	}
	
	public static void removeDynamicLight(PlayerTorch light)
	{
		light.UnFlagTorchAsCustom();
		RemoveTorchFromArray(light.GetTorchEntity().worldObj, light);
	}
}
