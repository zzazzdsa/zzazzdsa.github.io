// This file ONLY tells you what and where this mod specifically adds to the minecraft sourcecode.

public class RenderGlobal
    implements IWorldAccess
{

	// this function is fairly easy to find. look for a giant method with strings "rebuild" "cleanup"
    public boolean updateRenderers(EntityLiving entityliving, boolean flag)
    {
		// put it under "nearChunksSearch"
		int numToUpdate = 0;
		long avgTime = 0L;
		boolean torchesActive = PlayerTorchArray.AreTorchesActive();
		if (torchesActive)
		{
			avgTime = AABBPool.getAvgFrameTime();
		}
		
		// the first FOR inside the function
			for(...)
			{
				//loop, whatever

				if (torchesActive)
				{
					numToUpdate++;
					if ((numToUpdate >= 2) || (avgTime > 16666666L))
					{
						break;
					}
				}
			}
		
					// further down, find the 2 calls to *.updateRenderer(); and change them like this
		
					boolean update = *.needsUpdate;
					*.updateRenderer();
					if (update)
					{
						LightCache.cache.clear();
						BlockCoord.resetPool();
					}
    }
}