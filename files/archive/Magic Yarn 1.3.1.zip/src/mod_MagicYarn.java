package net.minecraft.src;

import java.util.*;
import net.minecraft.client.Minecraft;
import net.minecraft.src.atomicstryker.magicyarn.AStarNode;
import net.minecraft.src.atomicstryker.magicyarn.AStarPath;
import net.minecraft.src.atomicstryker.magicyarn.ItemMagicYarn;
import net.minecraft.src.atomicstryker.magicyarn.MPMagicYarn;

public class mod_MagicYarn extends BaseMod
{
	public static final Item magicYarn = (new ItemMagicYarn(2526)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/imgz/itemMagicYarn.png")).setItemName("Magic Yarn");
	private static long time;
	public static AStarPath instance;
	
	public static Minecraft mcinstance;
	public static ArrayList path = null;
	public static ArrayList lastPath = null;
	public static boolean showPath = false;
	
	private static MPMagicYarn mpYarn;
	
	@Override
    public void load()
    {
        ModLoader.addName(magicYarn, "Magic Yarn");
        ModLoader.addRecipe(new ItemStack(magicYarn, 1), new Object[]{
            "###", "#X#", "###", Character.valueOf('X'), Item.compass, Character.valueOf('#'), Block.cloth
        });
		
		time = System.currentTimeMillis();
		ModLoader.setInGameHook(this, true, false);
    }
    
    public static void inputPath(ArrayList given)
    {
    	inputPath(given, false, false);
    }
    
    public static void inputPath(ArrayList given, boolean noSound)
    {
    	inputPath(given, noSound, false);
    }
    
    public static void inputPath(ArrayList given, boolean noSound, boolean forceOverwrite)
    {
    	if (path != null || forceOverwrite)
    	{
    		lastPath = path;
    	}
    	path = given;
    	if (path != null)
    	{
    		mcinstance.theWorld.playSoundAtEntity(mcinstance.thePlayer, "random.levelup", 1.0F, 1.0F);
    	}
    	else if (!noSound)
    	{
    		mcinstance.theWorld.playSoundAtEntity(mcinstance.thePlayer, "random.drr", 1.0F, 1.0F);
    	}
    }
	
    @Override
	public boolean onTickInGame(float derp, net.minecraft.client.Minecraft mc)
	{
		mcinstance = mc;
		if (mc.thePlayer == null || mc.theWorld == null) return false;
		
		if (instance == null)
		{
			instance = new AStarPath(mc);
			mpYarn = new MPMagicYarn(mcinstance);
		}
		
		mpYarn.onUpdate(mc.theWorld);
		
		if (mc.thePlayer.getCurrentEquippedItem() != null && mc.thePlayer.getCurrentEquippedItem().getItem() == magicYarn
		|| mc.theWorld.isRemote)
		{
			if (showPath && path != null)
			{
				AStarNode temp;
				for(int i = path.size()-1; i >= 0; i--)
				{
					temp = ((AStarNode)path.get(i));
					mc.theWorld.spawnParticle("magicCrit", temp.x+0.5D, temp.y+0.5D, temp.z+0.5D, temp.parentxoffset*0.75, (temp.parentyoffset*0.5)+0.2, temp.parentzoffset*0.75);
				}
			}
		}
		
		return true;
	}
	
    public String getVersion()
    {
        return "1.3.1";
    }
}
