
package net.minecraft.src;

import net.minecraft.client.Minecraft;



public class SimplyHaxVisionRenderer extends RenderGlobal
{

    public SimplyHaxVisionRenderer(Minecraft minecraft, RenderEngine renderengine)
    {
        super(minecraft, renderengine);
    }

    public void callSuper(float f)
    {
        super.renderClouds(f);
    }

    public void renderClouds(float f)
    {
    }

    public int sortAndRender(EntityLiving entityliving, int i, double d)
    {
        mod_SimplyHaxVision.preRender();
        return super.sortAndRender(entityliving, i, d);
    }

    public void renderEntities(Vec3D vec3d, ICamera icamera, float f)
    {
        super.renderEntities(vec3d, icamera, f);
    }

    public void renderAllRenderLists(int i, double d)
    {
        super.renderAllRenderLists(i, d);
    }

    public void updateClouds()
    {
        super.updateClouds();
    }

    public void loadRenderers()
    {
        super.loadRenderers();
    }
}
