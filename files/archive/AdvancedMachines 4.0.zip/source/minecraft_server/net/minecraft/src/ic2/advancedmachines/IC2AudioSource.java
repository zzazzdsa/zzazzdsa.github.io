package net.minecraft.src.ic2.advancedmachines;

import net.minecraft.src.*;
import java.lang.reflect.*;


public class IC2AudioSource
{
	private static boolean initFailed = false;
	
	private static Class audioManagerClass;
	private static Method audioManagercreateSource;
	private static Method audioManagerremoveSource;
	private static Method audioManagerplayOnce;
	
	private static Class audioSourceClass;
	private static Method audioSourcePlay;
	private static Method audioSourceStop;
	private static Method audioSourceRemove;
	
	private Object audioSourceinstance;
	
	public IC2AudioSource(TileEntity tEnt, String soundfile)
	{		

	}
	
	public static void removeSource(Object audioSource)
	{

	}
	
	public static void playOnce(TileEntity tEnt, String soundFile)
	{

	}
	
	public void play()
	{

	}
	
	public void stop()
	{

	}
	
	public void remove()
	{

	}
}
