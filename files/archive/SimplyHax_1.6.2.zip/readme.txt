
To install:

Simply Hax is now a FML coremod. That means drag and drop installation, and the fall bug is fixed!
Simply put the .jar found in /setup/coremods/ into your .minecraft/coremods/ folder!

Minecraft 1.6.2 and later: Coremods now go into the /mods/ folder along with everything else! NOT the coremods folder.