package atomicstryker.infernalmobs.common;

import java.util.ArrayList;

import net.minecraft.src.DamageSource;
import net.minecraft.src.EntityItem;
import net.minecraft.src.EntityLiving;

public abstract class MobModifier
{
    protected EntityLiving mob;
    protected MobModifier nextMod = null;
    protected String modName;
    private boolean healthHacked = false;
    private long lastExistCheckTime = System.currentTimeMillis();
    private final long existCheckDelay = 5000L;
    private int lastHealth = 0;

    public String getModName()
    {
        return (modName + " " + ((nextMod != null) ? nextMod.getModName() : ""));
    }

    public boolean containsModifierClass(Class checkfor)
    {
        if (checkfor.equals(this.getClass()))
        {
            return true;
        }

        if (nextMod != null)
        {
            return nextMod.containsModifierClass(checkfor);
        }

        return false;
    }

    /**
     * Called when local Spawn Processing is completed or when a client remote-attached Modifiers to a local Entity
     */
    public void onSpawningComplete()
    {
        mob.getEntityData().setString(InfernalMobsCore.getNBTTag(), getModName());
    }

    public boolean onDeath()
    {
        if (nextMod != null)
        {
            return nextMod.onDeath();
        }

        return false;
    }

    public void onDropItems(DamageSource killSource, ArrayList<EntityItem> drops, int lootingLevel, boolean recentlyHit, int specialDropValue)
    {
        if (recentlyHit
        && !mob.worldObj.isRemote)
        {
            InfernalMobsCore.dropLootForEnt(mob);
        }

        InfernalMobsCore.removeEntFromElites(mob);
    }

    public void onSetAttackTarget(EntityLiving target)
    {
        if (nextMod != null)
        {
            nextMod.onSetAttackTarget(target);
        }
    }

    /**
     * Modified Mob attacks something
     * @param entity Entity being attacked
     * @param source DamageSource instance doing the attacking
     * @param damage unmitigated damage value
     * @return
     */
    public int onAttack(EntityLiving entity, DamageSource source, int damage)
    {
        if (nextMod != null)
        {
            return nextMod.onAttack(entity, source, damage);
        }

        return damage;
    }

    /**
     * Modified Mob is being hurt
     * @param source Damagesource doing the hurting
     * @param damage unmitigated damage value
     * @return
     */
    public int onHurt(DamageSource source, int damage)
    {
        if (nextMod != null)
        {
            return nextMod.onHurt(source, damage);
        }

        return damage;
    }

    public boolean onFall(float distance)
    {
        if (nextMod != null)
        {
            return nextMod.onFall(distance);
        }

        return false;
    }

    public void onJump(EntityLiving entityLiving)
    {
        if (nextMod != null)
        {
            nextMod.onJump(entityLiving);
        }
    }

    public boolean onUpdate()
    {
        if (nextMod != null)
        {
            return nextMod.onUpdate();
        }
        else
        {
            if (!mob.worldObj.isRemote)
            {
                if (mob.getHealth() != lastHealth)
                {
                    if (!healthHacked)
                    {
                        healthHacked = true;
                        lastHealth = mob.getMaxHealth()*InfernalMobsCore.RARE_MOB_HEALTH_MODIFIER;
                        InfernalMobsCore.setEntityHealthPastMax(mob, lastHealth);
                    }
                    
                    lastHealth = mob.getHealth();
                    InfernalMobsCore.instance().sendHealthPacket(mob, lastHealth);
                }
            }
        }

        return false;
    }

    /**
     * @return Array of classes an EntityLiving must equal, implement or extend in order for this MobModifier to be applied to it
     */
    public Class[] getWhiteListMobClasses()
    {
        return null;
    }

    /**
     * @return Array of classes an EntityLiving cannot equal, implement or extend in order for this MobModifier to be applied to it
     */
    public Class[] getBlackListMobClasses()
    {
        return null;
    }

    /**
     * @return Array of MobModifiers a considered MobModifier should not be mixed with. Both sides need to exclude each other for this to work.
     */
    public Class[] getModsNotToMixWith()
    {
        return null;
    }

    @Override
    public boolean equals(Object o)
    {
        return (o instanceof MobModifier
                && ((MobModifier)o).modName.equals(modName));
    }
}
