package atomicstryker.infernalmobs.common;

public interface ISidedProxy
{
    public void load();
}
