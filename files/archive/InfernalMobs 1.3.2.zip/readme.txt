
To install: Throw this mod zip into mods folder.


Requirements: Forge.


Configuration:
	in /config/InfernalMobs.cfg
		- eliteRarity specifies how many EntityLivings have to spawn in order for one of them to become an Infernal Mob
			-> lower value means more rares