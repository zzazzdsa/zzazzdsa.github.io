package net.minecraft.src.atomicstryker.minions;

import vazkii.um.UpdateManagerMod;

public class MinionsUpdateHandler extends UpdateManagerMod
{
    public MinionsUpdateHandler(cpw.mods.fml.common.modloader.BaseMod m)
    {
        super(m);
    }

    @Override
    public String getUpdateURL()
    {
        return "http://www.atomicstryker.net/updatemanager/version_minions.txt";
    }

    @Override
    public String getModName()
    {
        return "Minions!";
    }
}
