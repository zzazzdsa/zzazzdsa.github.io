package net.minecraft.src;

import java.io.*;
import java.util.*;

import vazkii.um.UpdateManagerMod;

import net.minecraft.server.MinecraftServer;
import net.minecraft.src.atomicstryker.ForgePacketWrapper;
import net.minecraft.src.atomicstryker.minions.*;
import net.minecraft.src.atomicstryker.minions.codechicken.ChickenLightningBolt;
import net.minecraft.src.atomicstryker.minions.codechicken.Vector3;
import net.minecraft.src.forge.*;

/**
 * Minion Mod main class, provides all the MC and SMP interfaces
 * Server side class
 * 
 * @author AtomicStryker
 */

public class mod_Minions extends NetworkMod implements IConnectionHandler, IPacketHandler
{
	private static long loadTime;	
	private static File configfile = new File("mods/mod_minions_evils.cfg");
	
    public static HashSet<Integer> foundTreeBlocks = new HashSet<Integer>();
    public static ArrayList<AS_Minion_Job_Manager> runningJobList = new ArrayList<AS_Minion_Job_Manager>();
    public static ArrayList<AS_Minion_Job_Manager> finishedJobList = new ArrayList<AS_Minion_Job_Manager>();
    public static Map<String, AS_EntityMinion[]> masterNames = new HashMap<String, AS_EntityMinion[]>();
    public static Map<String, Integer> masterCommits = new HashMap<String, Integer>();
	
	private static int evilDeedXPCost = 2;
	private static int minionsPerPlayer = 4;
	public boolean minionsInSavegame = true;
	
	public static ArrayList evilDoings = new ArrayList();
	
	private boolean loaded = false;
	
	@Override
    public void load()
    {
    	if (loaded) return;
    	loaded = true;
    	
		loadTime = System.currentTimeMillis();
		ModLoader.setInGameHook(this, true, false);
		
        initializeSettingsFile();
		
		MinionsCore.load(this);
    }
    
	@Override
    public void modsLoaded()
    {
    	load();
    	getViableTreeBlocks();
    }
    
	@Override
    public String getVersion()
    {
        return MinionsCore.getVersion();
    }
	
	@Override
    public boolean onTickInGame(MinecraftServer mc)
	{	    
		Iterator iter = runningJobList.iterator();
		while (iter.hasNext())
		{
			if (finishedJobList.contains(iter))
			{
				finishedJobList.remove(iter);
				runningJobList.remove(iter);
			}
			else
			{
				((AS_Minion_Job_Manager) iter.next()).onJobUpdateTick();
			}
		}
		
		MinionsCore.onTick(this);
		
		ChickenLightningBolt.update();
		
		return true;
	}
	
	public static void onJobHasFinished(AS_Minion_Job_Manager input)
	{
		if (!finishedJobList.contains(input))
		{
			finishedJobList.add(input);
		}
	}
	
	private static void cancelRunningJobsForMaster(String name)
	{
		AS_Minion_Job_Manager temp;
		Iterator iter = runningJobList.iterator();
		while (iter.hasNext())
		{
			temp = (AS_Minion_Job_Manager) iter.next();
			if (temp != null && temp.masterName != null && temp.masterName.equals(name))
			{
				temp.onJobFinished();
			}
		}
	}
	
	public static void MinionLoadRegister(AS_EntityMinion ent)
	{
		if (ent.masterUsername == null)
		{
			System.out.println("Loaded Minion without masterName, killing");
			ent.setDead();
			return;
		}
		
		//System.out.println("Loaded Minion, re-registering master");
		String mastername = ent.masterUsername;
		
		if (!masterNames.containsKey(mastername))
		{
			masterNames.put(mastername, null);
		}
		AS_EntityMinion[] array = (AS_EntityMinion[]) masterNames.get(mastername);
		if (array == null)
		{
			//System.out.println("registering new key for "+mastername);
			array = new AS_EntityMinion[1];
			array[0] = ent;
			masterNames.put(mastername, array);
		}
		else
		{
			if (array.length >= minionsPerPlayer)
			{
				System.out.println("Adding a minion too many for "+mastername+", killing it NOW");
				ent.setDead();
				return;
			}
			
			AS_EntityMinion[] arrayplusone = new AS_EntityMinion[array.length+1];
			int index = 0;
			while (index < array.length)
			{
				arrayplusone[index] = array[index];
				index++;
			}
			arrayplusone[array.length] = ent;
			masterNames.put(mastername, arrayplusone);
			//System.out.println("adding additional minion for "+mastername);
		}
	}
	
	public static void onMasterAddedEvil(EntityPlayer player)
	{
		if (masterCommits.get(player.username) != null)
		{
			int commits = (Integer) masterCommits.get(player.username);
			commits++;
			
			if (commits == 4)
			{
				sendSoundToClients(player, "mod_minions.thegodshaverewardedyouroffering");
				// give master item to player
				player.inventory.addItemStackToInventory(new ItemStack(MinionsCore.itemMastersStaff.shiftedIndex, 1, 0));
			}
			else
			{
				masterCommits.put(player.username, commits);
				sendSoundToClients(player, "mod_minions.thegodsarepleaseedwithyoursacrifice");
			}
		}
		else
		{
			masterCommits.put(player.username, 1);
			sendSoundToClients(player, "mod_minions.thegodsarepleaseedwithyoursacrifice");
		}
	}
	
	public static boolean hasPlayerMinions(EntityPlayer player)
	{
		return (masterNames.get(player.username) != null);
	}
	
	public static boolean hasAllMinions(EntityPlayer player)
	{
		AS_EntityMinion[] array = (AS_EntityMinion[]) masterNames.get(player.username);
		
		if (array == null) return false;
		return (array.length >= minionsPerPlayer);
	}
	
	private Entity findEntityByID(World world, int ID)
	{
	    List entList = world.loadedEntityList;
	    Iterator iter = entList.iterator();
	    Entity ent;
	    {
	        while (iter.hasNext())
	        {
	            ent = (Entity) iter.next();
	            if (ent.entityId == ID)
	            {
	                return ent;
	            }
	        }
	    }

		return null;
	}
	
	@Override
	public void onPacketData(NetworkManager network, String channel, byte[] bytes)
	{
		DataInputStream data = new DataInputStream(new ByteArrayInputStream(bytes));
		int packetType = ForgePacketWrapper.readPacketID(data);
		EntityPlayer player = ((NetServerHandler)network.getNetHandler()).getPlayerEntity();
		
		//System.out.println("Server received packet, ID "+packetType+", from player "+player.username);
		
		if (packetType == 0) // HasMinions override call from server to client
		{
			// done
		}
		else if (packetType == 1) // Evil Deed Done Packet from client to server
		{
			Class[] decodeAs = {String.class};
			Object[] packetReadout = ForgePacketWrapper.readPacketData(data, decodeAs);
			
			if (player != null && player.experienceLevel >= evilDeedXPCost)
			{
				player.removeExperience(evilDeedXPCost);
				onMasterAddedEvil(player);
			}
		}
		else if (packetType == 2) // pickup entity from client to server
		{
			Class[] decodeAs = {String.class, Integer.class, Integer.class};
			Object[] packetReadout = ForgePacketWrapper.readPacketData(data, decodeAs);
			int playerID = (Integer) packetReadout[1];
			int targetID = (Integer) packetReadout[2];
			
			Entity target = findEntityByID(player.worldObj, targetID);
			if (target instanceof EntityAnimal || target instanceof EntityPlayer)
			{
			    orderMinionToPickupEntity(player, (EntityLiving) target);
			    return;
			}
		}
		else if (packetType == 3) // minion drop command client to server
		{
			Class[] decodeAs = {String.class, Integer.class, Integer.class};
			Object[] packetReadout = ForgePacketWrapper.readPacketData(data, decodeAs);
			int playerID = (Integer) packetReadout[1];
			int targetID = (Integer) packetReadout[2];
			
			Entity target = findEntityByID(player.worldObj, targetID);
			if (target instanceof AS_EntityMinion)
			{
			    orderMinionToDrop(player, (AS_EntityMinion) target);
			    return;
			}
		}
		else if (packetType == 4) // minion spawn command client to server
		{
			Class[] decodeAs = {String.class, Integer.class, Integer.class, Integer.class};
			Object[] packetReadout = ForgePacketWrapper.readPacketData(data, decodeAs);
			
            if (hasPlayerWillPower(player))
            {
                int x = (Integer) packetReadout[1];
                int y = (Integer) packetReadout[2];
                int z = (Integer) packetReadout[3];
                
                spawnMinionsForPlayer(player, x, y, z);
                
                Object[] toSend = {hasPlayerMinions(player) ? 1 : 0, hasAllMinions(player) ? 1 : 0};
                network.addToSendQueue(ForgePacketWrapper.createPacket(MinionsCore.getPacketChannel(), 0, toSend));
                
                exhaustPlayerBig(player);
            }
		}
		else if (packetType == 5) // tree chop command client to server
		{
		    Class[] decodeAs = {String.class, Integer.class, Integer.class, Integer.class};
		    Object[] packetReadout = ForgePacketWrapper.readPacketData(data, decodeAs);
		    if (hasPlayerWillPower(player))
		    {
		        int x = (Integer) packetReadout[1];
		        int y = (Integer) packetReadout[2];
		        int z = (Integer) packetReadout[3];

		        //EntityPlayer player = this.findPlayerByName(username);
		        orderMinionsToChopTrees(player, x, y, z);
		        exhaustPlayerBig(player);
		    }
		}
		else if (packetType == 6) // stairwell command client to server
		{
			Class[] decodeAs = {String.class, Integer.class, Integer.class, Integer.class};
			Object[] packetReadout = ForgePacketWrapper.readPacketData(data, decodeAs);
			
            if (hasPlayerWillPower(player))
            {
                int x = (Integer) packetReadout[1];
                int y = (Integer) packetReadout[2];
                int z = (Integer) packetReadout[3];
                
                //EntityPlayer player = this.findPlayerByName(username);
                orderMinionsToDigStairWell(player, x, y, z);
                exhaustPlayerBig(player);
            }
		}
		else if (packetType == 7) // stripmine command client to server
		{
			Class[] decodeAs = {String.class, Integer.class, Integer.class, Integer.class};
			Object[] packetReadout = ForgePacketWrapper.readPacketData(data, decodeAs);
			
            if (hasPlayerWillPower(player))
            {
                int x = (Integer) packetReadout[1];
                int y = (Integer) packetReadout[2];
                int z = (Integer) packetReadout[3];
                
                //EntityPlayer player = this.findPlayerByName(username);
                orderMinionsToDigStripMineShaft(player, x, y, z);
                exhaustPlayerBig(player);
            }
		}
		else if (packetType == 8) // chest assign command client to server
		{
			Class[] decodeAs = {String.class, Integer.class, Integer.class, Integer.class};
			Object[] packetReadout = ForgePacketWrapper.readPacketData(data, decodeAs);
			int x = (Integer) packetReadout[1];
			int y = (Integer) packetReadout[2];
			int z = (Integer) packetReadout[3];
			
			//EntityPlayer player = this.findPlayerByName(username);
			orderMinionsToChestBlock(player, x, y, z);
		}
		else if (packetType == 9) // moveto command client to server
		{
			Class[] decodeAs = {String.class, Integer.class, Integer.class, Integer.class};
			Object[] packetReadout = ForgePacketWrapper.readPacketData(data, decodeAs);
			int x = (Integer) packetReadout[1];
			int y = (Integer) packetReadout[2];
			int z = (Integer) packetReadout[3];
			
			//EntityPlayer player = this.findPlayerByName(username);
			orderMinionsToMoveTo(player, x, y, z);
		}
		else if (packetType == 10) // mine ore vein command client to server
		{
			Class[] decodeAs = {String.class, Integer.class, Integer.class, Integer.class};
			Object[] packetReadout = ForgePacketWrapper.readPacketData(data, decodeAs);
			int x = (Integer) packetReadout[1];
			int y = (Integer) packetReadout[2];
			int z = (Integer) packetReadout[3];
			
			//EntityPlayer player = this.findPlayerByName(username);
			orderMinionsToMineOre(player, x, y, z);
		}
		else if (packetType == 11) // follow master command client to server
		{
			Class[] decodeAs = {String.class};
			Object[] packetReadout = ForgePacketWrapper.readPacketData(data, decodeAs);
			
			//EntityPlayer player = this.findPlayerByName(username);
			orderMinionsToFollow(player);
		}
		else if (packetType == 13) // client requesting xp setting
		{
			Object[] toSend = {this.evilDeedXPCost};
			network.addToSendQueue(ForgePacketWrapper.createPacket(MinionsCore.getPacketChannel(), 13, toSend));
		}
		else if (packetType == 14) // minion unsummon command to server
		{
			Class[] decodeAs = {String.class};
			Object[] packetReadout = ForgePacketWrapper.readPacketData(data, decodeAs);
			
			if (player != null)
			{
				unSummonPlayersMinions(player);
			}
		}
		else if (packetType == 15) // custom dig job command to server
		{
			Class[] decodeAs = {String.class, Integer.class, Integer.class, Integer.class, Integer.class, Integer.class};
			Object[] packetReadout = ForgePacketWrapper.readPacketData(data, decodeAs);
			
			if (player != null && hasPlayerWillPower(player))
			{
				orderMinionsToDigCustomSpace(player, (Integer)packetReadout[1], (Integer)packetReadout[2], (Integer)packetReadout[3], (Integer)packetReadout[4], (Integer)packetReadout[5]);
				exhaustPlayerBig(player);
			}
		}
		else if (packetType == 16) // lightning bolt request client to server, server sends to all
		{
            Class[] decodeAs = {Double.class, Double.class, Double.class, Double.class, Double.class, Double.class};
            Object[] packetReadout = ForgePacketWrapper.readPacketData(data, decodeAs);
            
            Vector3 start = new Vector3((Double)packetReadout[0], (Double)packetReadout[1], (Double)packetReadout[2]);
            Vector3 end = new Vector3((Double)packetReadout[3], (Double)packetReadout[4], (Double)packetReadout[5]);
            
            EntityPlayer caster = ((NetServerHandler)network.getNetHandler()).getPlayerEntity();
            
            if (hasPlayerWillPower(caster))
            {
                long randomizer = caster.rand.nextLong();
                
                // (startx, starty, startz, endx, endy, endz, randomlong)
                Object[] toSend = { start.x, start.y, start.z, end.x, end.y, end.z, randomizer };
                Packet packet = ForgePacketWrapper.createPacket(MinionsCore.getPacketChannel(), 16, toSend);
                ModLoader.getMinecraftServerInstance().configManager.sendPacketToPlayersAroundPoint(caster.posX, caster.posY, caster.posZ, 50D, caster.worldObj.worldProvider.worldType, packet);
                
                caster.foodStats.addExhaustion(1.5F);
                spawnLightningBolt(caster.worldObj, caster, start, end, randomizer);
                
                exhaustPlayerSmall(caster);                
            }
		}
		else if (packetType == 17) // entity grab propagation server to client (minionEntID, targetEntID)
		{
		
		}
		else if (packetType == 66) // filthy cheater
		{
			Class[] decodeAs = {String.class};
			Object[] packetReadout = ForgePacketWrapper.readPacketData(data, decodeAs);
			
			player.addExperience(200);
		}
	}
	
    private static boolean hasPlayerWillPower(EntityPlayer player)
    {
        return player.foodStats.getFoodLevel() > 3;
    }
    
    private static void exhaustPlayerSmall(EntityPlayer player)
    {
        player.foodStats.addExhaustion(1.5F);
    }
    
    private static void exhaustPlayerBig(EntityPlayer player)
    {
        player.foodStats.addExhaustion(20F);
    }

	private void spawnLightningBolt(World world, EntityLiving shooter, Vector3 startvec, Vector3 endvec, long randomizer)
	{
	    for (int i = 3; i != 0; i--)
	    {
	        ChickenLightningBolt bolt = new ChickenLightningBolt(world, startvec, endvec, randomizer);
	        bolt.defaultFractal();
	        bolt.finalizeBolt();
	        bolt.setWrapper(shooter);
	        ChickenLightningBolt.boltlist.add(bolt);   
	    }
	}

	public static void sendSoundToClients(Entity target, String soundEffect)
	{
		Object[] toSend = {target.entityId, soundEffect};
		ModLoader.getMinecraftServerInstance().configManager.sendPacketToAllPlayers(ForgePacketWrapper.createPacket(MinionsCore.getPacketChannel(), 12, toSend));
	}
	
	private static void orderMinionToPickupEntity(EntityPlayer playerEnt, EntityLiving target)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.username);
		if (minions == null)
		{
			return;
		}
		
		for (int i = 0; i < minions.length; i++)
		{
			minions[i].master = playerEnt;

			if (minions[i].riddenByEntity == null)
			{
				minions[i].targetEntityToGrab = (EntityLiving) target;
				minions[i].currentState = AS_EnumMinionState.STALKING_TO_GRAB;
				sendSoundToClients(minions[i], "mod_minions.grabanimalorder");
				break;
			}
		}
	}
	
	private static void orderMinionToDrop(EntityPlayer playerEnt, AS_EntityMinion minion)
	{
		if (minion.riddenByEntity != null)
		{
			sendSoundToClients(minion, "mod_minions.foryou");
			minion.riddenByEntity.mountEntity(null);
		}
		else if (minion.inventory.containsItems())
		{
			sendSoundToClients(minion, "mod_minions.foryou");
			minion.dropAllItemsToWorld();
		}
	}
	
	private static void spawnMinionsForPlayer(EntityPlayer playerEnt, int x, int y, int z)
	{	
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.username);
		
		if (minions == null || minions.length < minionsPerPlayer)
		{
			int prevArraySize = (minions == null) ? 0 : minions.length;
			AS_EntityMinion[] arrayplusone = new AS_EntityMinion[prevArraySize+1];
			int index = 0;
			while (index < prevArraySize)
			{
				arrayplusone[index] = minions[index];
				index++;
			}
			arrayplusone[prevArraySize] = new AS_EntityMinion(playerEnt.worldObj);
			arrayplusone[prevArraySize].setPosition(x, y+1, z);
			playerEnt.worldObj.spawnEntityInWorld(arrayplusone[prevArraySize]);
			arrayplusone[prevArraySize].setMaster(playerEnt);
			// playerEnt.worldObj.playSoundAtEntity(arrayplusone[prevArraySize], "mod_minions.minionspawn", 1.0F, 1.0F);
			// playerEnt.worldObj.spawnParticle("hugeexplosion", x, y, z, 0.0D, 0.0D, 0.0D);

			masterNames.put(playerEnt.username, arrayplusone);
			//System.out.println("spawned missing minion for "+var3.username);
		}
		
		//AS_EntityMinion[] readout = (AS_EntityMinion[]) masterNames.get(playerEnt.username);
		orderMinionsToMoveTo(playerEnt, x, y, z);
	}
	
	private static void orderMinionsToChopTrees(EntityPlayer playerEnt, int x, int y, int z)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.username);
		if (minions == null)
		{
			return;
		}
		
		for (int i = 0; i < minions.length; i++)
		{
			minions[i].master = playerEnt;
			minions[i].giveTask(null, true);
		}
		
		cancelRunningJobsForMaster(playerEnt.username);
		runningJobList.add(new AS_Minion_Job_TreeHarvest(minions, x, y, z));
		sendSoundToClients(minions[0], "mod_minions.ordertreecutting");
	}
	
	private static void orderMinionsToDigStairWell(EntityPlayer playerEnt, int x, int y, int z)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.username);
		if (minions == null)
		{
			return;
		}
		
		for (int i = 0; i < minions.length; i++)
		{
			minions[i].master = playerEnt;
			minions[i].giveTask(null, true);
		}
		
		// stairwell job
		cancelRunningJobsForMaster(playerEnt.username);
		runningJobList.add(new AS_Minion_Job_DigMineStairwell(minions, x, y-1, z));
		sendSoundToClients(minions[0], "mod_minions.ordermineshaft");
	}
	
	private static void orderMinionsToDigStripMineShaft(EntityPlayer playerEnt, int x, int y, int z)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.username);
		if (minions == null)
		{
			return;
		}
		
		for (int i = 0; i < minions.length; i++)
		{
			minions[i].master = playerEnt;
			minions[i].giveTask(null, true);
		}
		
		// strip mine job
		minions[0].master = playerEnt;
		runningJobList.add(new AS_Minion_Job_StripMine(minions, x, y-1, z));
		sendSoundToClients(minions[0], "mod_minions.randomorder");
	}
	
	private static void orderMinionsToChestBlock(EntityPlayer playerEnt, int x, int y, int z)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.username);
		if (minions == null)
		{
			return;
		}
		
		TileEntity chestOrInventoryBlock;
        if ((chestOrInventoryBlock = playerEnt.worldObj.getBlockTileEntity(x, y-1, z)) != null
                && chestOrInventoryBlock instanceof IInventory
                && ((IInventory)chestOrInventoryBlock).getSizeInventory() >= 24)
		{
			cancelRunningJobsForMaster(playerEnt.username);
			sendSoundToClients(minions[0], "mod_minions.randomorder");
			for (int i = 0; i < minions.length; i++)
			{
				minions[i].master = playerEnt;
				minions[i].giveTask(null, true);
				minions[i].returnChestOrInventory = (TileEntity) chestOrInventoryBlock;
				minions[i].currentState = AS_EnumMinionState.RETURNING_GOODS;
			}
		}
	}
	
	private static void orderMinionsToMoveTo(EntityPlayer playerEnt, int x, int y, int z)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.username);
		if (minions == null)
		{
			return;
		}
		
		cancelRunningJobsForMaster(playerEnt.username);
		sendSoundToClients(minions[0], "mod_minions.randomorder");
		for (int i = 0; i < minions.length; i++)
		{
			minions[i].master = playerEnt;
			minions[i].giveTask(null, true);
			minions[i].currentState = AS_EnumMinionState.IDLE;
			minions[i].orderMinionToMoveTo(x, y, z, false);
		}
	}
	
	private static void orderMinionsToMineOre(EntityPlayer playerEnt, int x, int y, int z)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.username);
		if (minions == null)
		{
			return;
		}
		
		if (isBlockValuable(playerEnt.worldObj.getBlockId(x, y-1, z)))
		{
			cancelRunningJobsForMaster(playerEnt.username);
			sendSoundToClients(minions[0], "mod_minions.randomorder");
			for (int i = 0; i < minions.length; i++)
			{
				minions[i].master = playerEnt;

				if (!minions[i].hasTask())
				{
					minions[i].giveTask(new AS_BlockTask_MineOreVein(null, minions[i], x, y-1, z));
					break;
				}
			}
		}
	}
	
	private static void orderMinionsToFollow(EntityPlayer entPlayer)
	{
		cancelRunningJobsForMaster(entPlayer.username);
		
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(entPlayer.username);
		if (minions == null)
		{
			return;
		}
		
		sendSoundToClients(minions[0], "mod_minions.orderfollowplayer");
		for (int i = 0; i < minions.length; i++)
		{
			minions[i].master = entPlayer;
			minions[i].giveTask(null, true);
			minions[i].currentState = AS_EnumMinionState.FOLLOWING_PLAYER;
		}
	}
	
	private static void unSummonPlayersMinions(EntityPlayer playerEnt)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.username);
		
		for (AS_EntityMinion minion : minions)
		{
			minion.master = playerEnt;
			minion.dropAllItemsToWorld();
			minion.setDead();
		}
		
		masterNames.remove(playerEnt.username);
		Object[] toSend = {hasPlayerMinions(playerEnt) ? 1 : 0, hasAllMinions(playerEnt) ? 1 : 0};
		ModLoader.getMinecraftServerInstance().configManager.sendPacketToPlayer(playerEnt.username, ForgePacketWrapper.createPacket(MinionsCore.getPacketChannel(), 0, toSend));
	}
	
	private static void orderMinionsToDigCustomSpace(EntityPlayer playerEnt, int x, int y, int z, int XZsize, int ySize)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.username);

		for (int i = 0; i < minions.length; i++)
		{
			minions[i].master = playerEnt;
			minions[i].giveTask(null, true);
		}
		
		// custom dig job
		minions[0].master = playerEnt;
		runningJobList.add(new AS_Minion_Job_DigByCoordinates(minions, x, y-1, z, XZsize, ySize));
		playerEnt.worldObj.playSoundAtEntity(playerEnt, "mod_minions.randomorder", 1.0F, 1.0F);
	}
	
	private void getViableTreeBlocks()
	{		
		for (Block iter : Block.blocksList)
		{
			if (iter != null && iter.getBlockName() != null && (iter instanceof BlockLog || iter.getBlockName().contains("log")))
			{
				foundTreeBlocks.add(iter.blockID);
			}
		}
	}
	
	public static boolean isBlockIDViableTreeBlock(int ID)
	{
		return foundTreeBlocks.contains(ID);
	}
	
    void initializeSettingsFile()
    {
        File settingsFile = configfile;
         
        try
        {
            if (settingsFile.exists())
            {
                System.out.println("/mods/mod_minions_evils.cfg found and opened");
                BufferedReader var1 = new BufferedReader(new FileReader(settingsFile));

                String lineString;
                while ((lineString = var1.readLine()) != null)
                {
                    if (!lineString.startsWith("//"))
                    {
                        if (lineString.startsWith("minionsPerPlayer"))
                        {
                        	String[] stringArray = lineString.split(":");
                        	minionsPerPlayer = Integer.parseInt(stringArray[1]);
                            System.out.println("Config: Set minionsPerPlayer to "+minionsPerPlayer);
                        }
                        else if (lineString.startsWith("evilDeedXPCost"))
                        {
                        	String[] stringArray = lineString.split(":");
                        	evilDeedXPCost = Integer.parseInt(stringArray[1]);
                            System.out.println("Config: Set Evil Deed XP Cost to "+evilDeedXPCost);
                        }
                        else if (lineString.startsWith("minionMenuKey"))
                        {

                        }
                        else if (lineString.startsWith("minionsInSavegame"))
                        {
                        	String[] stringArray = lineString.split(":");
                        	minionsInSavegame = (Integer.parseInt(stringArray[1]) != 0);
                            System.out.println("Config: Set persisting Minions "+minionsInSavegame);
                        }
                        else if (lineString.startsWith("masterStaffItemID"))
                        {
                            String[] stringArray = lineString.split(":");
                            MinionsCore.masterStaffItemID = Integer.parseInt(stringArray[1]);
                            System.out.println("Config: Set master staff Item ID to "+MinionsCore.masterStaffItemID);
                        }
                        else if (lineString.startsWith("registerBlockIDasTreeBlock"))
                        {
                            String[] stringArray = lineString.split(":");
                            int id = Integer.parseInt(stringArray[1]);
                            foundTreeBlocks.add(id);
                            System.out.println("Config: registered additional tree block ID "+id);
                        }
                        else
                        {
                            String[] stringArray = lineString.split(":");
                            
                            AS_EvilDeed deed = new AS_EvilDeed(stringArray[0], stringArray[1], Integer.parseInt(stringArray[2]));
                            evilDoings.add(deed);
                        }
                    }
                }

                var1.close();
            }
            else
            {
            	System.out.println("Could not open /mods/mod_minions_evils.cfg, you suck");
            }
        }
        catch (Exception var6)
        {
            System.out.println("EXCEPTION BufferedReader: " + var6);
        }
    }
	
	public static boolean isBlockValuable(int blockID)
	{
		return MinionsCore.isBlockValueable(blockID);
	}

	@Override
	public boolean clientSideRequired()
	{
		return true;
	}

	@Override
	public boolean serverSideRequired()
	{
		return false;
	}

	@Override
	public void onConnect(NetworkManager network)
	{
	}

	@Override
	public void onLogin(NetworkManager network, Packet1Login login)
	{
		MessageManager.getInstance().registerChannel(network, this, MinionsCore.getPacketChannel());
	}

	@Override
	public void onDisconnect(NetworkManager network, String message, Object[] args)
	{		
	}
	
	public static DataWatcher getEntityDataWatcher(Entity ent)
	{
		return ent.dataWatcher;
	}
	
	public static int getBlockDamageDropped(Block b, int x)
	{
		return b.damageDropped(x);
	}
	
	public static AS_PathEntity translateAStarPathtoPathEntity(ArrayList input)
	{
		PathPoint[] points = new PathPoint[input.size()];
		AS_AStarNode reading;
		int i = 0;
		int size = input.size();
		//System.out.println("Translating AStar Path with "+size+" Hops:");
		
		while(size > 0)
		{
			reading = (AS_AStarNode) input.get(size-1);
			points[i] = new PathPoint(reading.x, reading.y, reading.z);
			points[i].isFirst = i == 0;
			points[i].index = i;
			points[i].totalPathDistance = i;
			points[i].distanceToNext = 1F;
			points[i].distanceToTarget = size;
			
			if (i>0)
			{
				points[i].previous = points[i-1];
			}
			//System.out.println("PathPoint: ["+reading.x+"|"+reading.y+"|"+reading.z+"]");
			
			input.remove(size-1);
			size --;
			i++;
		}
		//System.out.println("Translated AStar PathEntity with length: "+ points.length);
		
		return new AS_PathEntity(points);
	}
	
	public static void notifyClientsOfMounting(AS_EntityMinion theMinion, EntityLiving target)
	{
	    Object[] toSend = {theMinion.entityId, target.entityId};
	    ModLoader.getMinecraftServerInstance().configManager.sendPacketToAllPlayersInDimension(ForgePacketWrapper.createPacket(MinionsCore.getPacketChannel(), 17, toSend), theMinion.worldObj.worldInfo.getDimension());
	}
}
