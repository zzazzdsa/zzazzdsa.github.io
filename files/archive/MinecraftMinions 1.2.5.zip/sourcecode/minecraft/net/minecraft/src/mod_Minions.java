package net.minecraft.src;

import java.io.*;
import java.util.*;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import vazkii.um.ModType;
import vazkii.um.UpdateManagerMod;

import net.minecraft.client.Minecraft;
import net.minecraft.src.atomicstryker.ForgePacketWrapper;
import net.minecraft.src.atomicstryker.minions.*;
import net.minecraft.src.atomicstryker.minions.codechicken.*;
import net.minecraft.src.forge.*;

/**
 * Minion Mod main class, provides all the MC and SMP interfaces
 * Client side class
 * 
 * @author AtomicStryker
 */

public class mod_Minions extends NetworkMod implements IConnectionHandler, IPacketHandler
{
	private static long loadTime;
	public static Minecraft mcinstance;
	private static World worldObj;

	private String s_MenuKey = "M";
	private int i_MenuKey = Keyboard.getKeyIndex(s_MenuKey);

	private static File configfile = new File(Minecraft.getMinecraftDir(), "mods/mod_minions_evils.cfg");
	private static MovingObjectPosition targetObjectMouseOver;

	public static HashSet<Integer> foundTreeBlocks = new HashSet<Integer>();
	public static ArrayList<AS_Minion_Job_Manager> runningJobList = new ArrayList<AS_Minion_Job_Manager>();
	public static ArrayList<AS_Minion_Job_Manager> finishedJobList = new ArrayList<AS_Minion_Job_Manager>();
	public static Map<String, AS_EntityMinion[]> masterNames = new HashMap<String, AS_EntityMinion[]>();
	public static Map<String, Integer> masterCommits = new HashMap<String, Integer>();

	public static boolean isSelectingMineArea = false;
	public static int mineAreaShape = 0;
	
	public static int customSizeXZ = 3;
	public static int customSizeY = 3;

	private static boolean hasMinionsSMPOverride = false;
	private static boolean hasAllMinionsSMPOverride = false;

	public static int evilDeedXPCost = 2;
	private static int minionsPerPlayer = 4;
	public boolean minionsInSavegame = true;

	public static ArrayList evilDoings = new ArrayList();
	
	private long lastStaffLightningBoltTime = System.currentTimeMillis();
	
    private long timeLastSound = 0L;
    private final long timeSoundDelay = 400L;

    @Override
    public void load()
    {		
        loadTime = System.currentTimeMillis();
        ModLoader.setInGameHook(this, true, false);
        
        initializeSettingsFile();
        MinionsCore.load(this);
        
        ModLoader.addName(MinionsCore.itemMastersStaff, "Master's Staff");
        MinecraftForgeClient.preloadTexture("/mod_minions/codechicken/lightning_outer.png");
        MinecraftForgeClient.preloadTexture("/mod_minions/codechicken/lightning_inner.png");
        MinecraftForgeClient.registerRenderLastHandler(new RenderChickenLightningBolt());
    }

	@Override
	public void modsLoaded()
	{
		getViableTreeBlocks();
	}

	@Override
	public String getVersion()
	{
		return MinionsCore.getVersion();
	}

	@Override
	public void addRenderer(Map map)
	{
		map.put(AS_EntityMinion.class, new AS_RenderMinion(new AS_ModelMinion(), 0.25F));
		map.put(AS_RenderEntLahwran_Minions.class, new AS_MinionsRenderHook(ModLoader.getMinecraftInstance()));
	}
	
	@Override
	public boolean onTickInGame(float renderTick, net.minecraft.client.Minecraft mc)
	{
		mcinstance = mc;
		if (mc.theWorld != worldObj)
		{
			updateWorld(mc.theWorld);
		}

		Iterator iter = runningJobList.iterator();
		while (iter.hasNext())
		{
			if (finishedJobList.contains(iter))
			{
				finishedJobList.remove(iter);
				runningJobList.remove(iter);
			}
			else
			{
				((AS_Minion_Job_Manager) iter.next()).onJobUpdateTick();
			}
		}

		MinionsCore.onTick(this);

		// Menu
		if (Keyboard.isKeyDown(i_MenuKey) && mc.currentScreen == null)
		{
			mcinstance.displayGuiScreen(new AS_GuiMinionMenu(mc.thePlayer));
		}

		if (mc.currentScreen == null && isSelectingMineArea)
		{
			if (mc.thePlayer.inventory.getCurrentItem() == null || mc.thePlayer.inventory.getCurrentItem().itemID != MinionsCore.itemMastersStaff.shiftedIndex)
			{
				isSelectingMineArea = false;
				AS_MinionsRenderHook.deleteSelection();
			}
			else if (mcinstance.objectMouseOver != null && mcinstance.objectMouseOver.typeOfHit == EnumMovingObjectType.TILE)
			{
				int x = mcinstance.objectMouseOver.blockX;
				int y = mcinstance.objectMouseOver.blockY;
				int z = mcinstance.objectMouseOver.blockZ;
				
		    	int bossX = MathHelper.floor_double(mc.thePlayer.posX);
		    	int bossZ = MathHelper.floor_double(mc.thePlayer.posZ);
				int xDirection;
				int zDirection;
				
		    	if (Math.abs(x - bossX) > Math.abs(z - bossZ))
		    	{
		    		xDirection = (x - bossX > 0) ? 1 : -1;
		    		zDirection = 0;
		    	}
		    	else
		    	{
		    		xDirection = 0;
		    		zDirection = (z - bossZ > 0) ? 1 : -1;
		    	}

				if (mineAreaShape == 0) // mineshaft
				{
					AS_MinionsRenderHook.setSelectionPoint(0, x, y, z);
					AS_MinionsRenderHook.setSelectionPoint(1, x+4, y, z+4);

					AS_MinionsRenderHook.deleteAdditionalCubes();
					AS_MinionsRenderHook.addAdditionalCube(x+1, y-1, z);
					AS_MinionsRenderHook.addAdditionalCube(x+2, y-2, z);
					AS_MinionsRenderHook.addAdditionalCube(x+3, y-3, z);
				}
				else if (mineAreaShape == 1) // stripmine
				{
					AS_MinionsRenderHook.setSelectionPoint(0, x, y, z);
					AS_MinionsRenderHook.setSelectionPoint(1, x+xDirection*2, y+1, z+zDirection*2);
				}
				else if (mineAreaShape == 2) // custom size
				{
					int half = ((customSizeXZ-1) / 2);
					
					if (xDirection != 0) // advancing in Xdir, start at x and z-half to x+size and z+half
					{
						AS_MinionsRenderHook.setSelectionPoint(0, x, y, z - half);
						AS_MinionsRenderHook.setSelectionPoint(1, x + (customSizeXZ*xDirection), y + customSizeY-1, z + half);
					}
					else if (zDirection != 0) // advancing in Zdir, start at z and x-half to z+size and x+half
					{
						AS_MinionsRenderHook.setSelectionPoint(0, x - half, y, z);
						AS_MinionsRenderHook.setSelectionPoint(1, x + half, y + customSizeY-1, z + (customSizeXZ*zDirection));
					}
				}
			}
		}
		else
		{
			AS_MinionsRenderHook.deleteSelection();
		}
		
		ChickenLightningBolt.update();
		
		if (mc.currentScreen == null)
		{
		    if (Mouse.isButtonDown(0)
		    && mc.thePlayer.inventory.getCurrentItem() != null
		    && mc.thePlayer.inventory.getCurrentItem().itemID == MinionsCore.itemMastersStaff.shiftedIndex
		    && mc.objectMouseOver == null
		    && hasPlayerWillPower(mc.thePlayer)
		    && lastStaffLightningBoltTime + 100L < System.currentTimeMillis())
		    {
		        lastStaffLightningBoltTime = System.currentTimeMillis();
		        EntityLiving p = mc.renderViewEntity;
		        MovingObjectPosition pos = p.rayTrace(10, renderTick);
		        if (pos != null)
		        {
		            Vector3 startvec = Vector3.fromEntityCenter(p).add(0, 0.68D, 0);
		            startvec.x -= (double)(MathHelper.cos(p.rotationYaw / 180.0F * (float)Math.PI) * 0.16F);
		            //startvec.y -= 0.10000000149011612D;
		            startvec.z -= (double)(MathHelper.sin(p.rotationYaw / 180.0F * (float)Math.PI) * 0.16F);
		            
		            Vector3 endvec = Vector3.fromVec3D(pos.hitVec);
		            
		            if (!mc.theWorld.isRemote)
		            {
		                spawnLightningBolt(mc.theWorld, mc.thePlayer, startvec, endvec, mc.theWorld.rand.nextLong());
		                exhaustPlayerSmall(mc.thePlayer);
		            }
		            else
		            {
		                Object[] toSend = { startvec.x, startvec.y, startvec.z, endvec.x, endvec.y, endvec.z };
		                ModLoader.sendPacket(ForgePacketWrapper.createPacket(MinionsCore.getPacketChannel(), 16, toSend)); // request lightning bolt packet
		            }
		        }
		    }
		}

		return true;
	}
	
	private static boolean hasPlayerWillPower(EntityPlayer player)
	{
	    return player.foodStats.getFoodLevel() > 3;
	}
	
	private static void exhaustPlayerSmall(EntityPlayer player)
	{
	    player.foodStats.addExhaustion(1.5F);
	}
	
    private static void exhaustPlayerBig(EntityPlayer player)
    {
        player.foodStats.addExhaustion(20F);
    }

	public static void onJobHasFinished(AS_Minion_Job_Manager input)
	{
		if (!finishedJobList.contains(input))
		{
			finishedJobList.add(input);
		}
	}

	private static void cancelRunningJobsForMaster(String name)
	{
		AS_Minion_Job_Manager temp;
		Iterator iter = runningJobList.iterator();
		while (iter.hasNext())
		{
			temp = (AS_Minion_Job_Manager) iter.next();
			if (temp != null && temp.masterName != null && temp.masterName.equals(name))
			{
				temp.onJobFinished();
			}
		}
	}
	
	private static void updateWorld(World w)
	{
		if (mcinstance == null)
		{
		    mcinstance = ModLoader.getMinecraftInstance();
		}
		
		worldObj = w;
		masterNames = new HashMap();
		AS_MinionsRenderHook.renderHookEnt = new AS_RenderEntLahwran_Minions(mcinstance, w);
		w.addWeatherEffect(AS_MinionsRenderHook.renderHookEnt);
	}

	public static void MinionLoadRegister(AS_EntityMinion ent)
	{
		if (ent.worldObj != worldObj)
		{
			updateWorld(ent.worldObj);
		}
		
		if (ent.masterUsername == null)
		{
			System.out.println("Loaded Minion without masterName, killing");
			ent.setDead();
			return;
		}

		System.out.println("Loaded Minion, re-registering master: "+ent.masterUsername);
		String mastername = ent.masterUsername;

		if (!masterNames.containsKey(mastername))
		{
			masterNames.put(mastername, null);
		}
		AS_EntityMinion[] array = (AS_EntityMinion[]) masterNames.get(mastername);
		if (array == null)
		{
			System.out.println("registering new key for "+mastername);
			array = new AS_EntityMinion[1];
			array[0] = ent;
			masterNames.put(mastername, array);
		}
		else
		{
			if (array.length >= minionsPerPlayer)
			{
				System.out.println("Adding a minion too many for "+mastername+", killing it NOW");
				ent.setDead();
				return;
			}

			AS_EntityMinion[] arrayplusone = new AS_EntityMinion[array.length+1];
			int index = 0;
			while (index < array.length)
			{
				arrayplusone[index] = array[index];
				index++;
			}
			arrayplusone[array.length] = ent;
			masterNames.put(mastername, arrayplusone);
			System.out.println("adding additional minion for "+mastername+", array now: "+arrayplusone);
		}
	}

	public static void onMasterAddedEvil(EntityPlayer player)
	{
		if (masterCommits.get(player.username) != null)
		{
			int commits = (Integer) masterCommits.get(player.username);
			commits++;

			if (commits == 4)
			{
				player.worldObj.playSoundAtEntity(player, "mod_minions.thegodshaverewardedyouroffering", 1.0F, 1.0F);
				// give master item to player
				player.inventory.addItemStackToInventory(new ItemStack(MinionsCore.itemMastersStaff.shiftedIndex, 1, 0));
			}
			else
			{
				masterCommits.put(player.username, commits);
				player.worldObj.playSoundAtEntity(player, "mod_minions.thegodsarepleaseedwithyoursacrifice", 1.0F, 1.0F);
			}
		}
		else
		{
			masterCommits.put(player.username, 1);
			player.worldObj.playSoundAtEntity(player, "mod_minions.thegodsarepleaseedwithyoursacrifice", 1.0F, 1.0F);
		}
	}

	public static boolean hasPlayerMinions(EntityPlayer player)
	{
		if (player.worldObj.isRemote)
		{
			return hasMinionsSMPOverride;
		}
		return (masterNames.get(player.username) != null);
	}

	@Override
	public void onPacketData(NetworkManager network, String channel, byte[] bytes)
	{
		DataInputStream data = new DataInputStream(new ByteArrayInputStream(bytes));
		int packetType = ForgePacketWrapper.readPacketID(data);

		//System.out.println("Client received packet, ID "+packetType);

		if (packetType == 0) // HasMinions override call from server to client
		{
			Class[] decodeAs = {Integer.class, Integer.class};
			Object[] packetReadout = ForgePacketWrapper.readPacketData(data, decodeAs);
			hasMinionsSMPOverride = ((Integer)packetReadout[0] == 1);
			hasAllMinionsSMPOverride = ((Integer)packetReadout[1] == 1);
			//System.out.println("Client hasMinionsSMPOverride = "+hasMinionsSMPOverride+", hasAllMinionsSMPOverride: "+hasAllMinionsSMPOverride);
		}
		else if (packetType == 1) // Evil Deed Done Packet from client to server
		{

		}
		else if (packetType == 2) // pickup entity from client to server
		{

		}
		else if (packetType == 3) // minion drop command client to server
		{

		}
		else if (packetType == 4) // minion spawn command client to server
		{

		}
		else if (packetType == 5) // tree chop command client to server
		{

		}
		else if (packetType == 6) // stairwell command client to server
		{

		}
		else if (packetType == 7) // stripmine command client to server
		{

		}
		else if (packetType == 8) // chest assign command client to server
		{

		}
		else if (packetType == 9) // moveto command client to server
		{

		}
		else if (packetType == 10) // mine ore vein command client to server
		{

		}
		else if (packetType == 11) // follow master command client to server
		{

		}
		else if (packetType == 12) // play sounds, server to client
		{
			Class[] decodeAs = {Integer.class, String.class};
			Object[] packetReadout = ForgePacketWrapper.readPacketData(data, decodeAs);

			int entID = (Integer) packetReadout[0];
			String sound = (String) packetReadout[1];

			//System.out.println("Minions server demands sound "+sound+" at entity id "+entID);

			Entity temp = null;
			boolean found = false;

			Iterator iter = mcinstance.theWorld.loadedEntityList.iterator();
			while (iter.hasNext())
			{
				temp = (Entity) iter.next();
				if (temp.entityId == entID)
				{
					found = true;
					break;
				}
			}
			if (found)
			{
				//System.out.println("Found ent, playing sound now!");
				mcinstance.theWorld.playSoundAtEntity(temp, sound, 1.0F, 1.0F);
			}
		}
		else if (packetType == 13) // demand serverside XP cost setting, bidirectional
		{
		    Class[] decodeAs = {Integer.class};
		    Object[] packetReadout = ForgePacketWrapper.readPacketData(data, decodeAs);

		    if (evilDeedXPCost != (Integer)packetReadout[0])
		    {
		        evilDeedXPCost = (Integer)packetReadout[0];

		        if (this.mcinstance.currentScreen instanceof AS_GuiMinionMenu)
		        {
		            this.mcinstance.currentScreen = null;

		            if (evilDeedXPCost != -1)
		            {
		                this.mcinstance.ingameGUI.addChatMessage("Server says you don't have enough XP for Evil Deeds");
		            }
		            else
		            {
		                this.mcinstance.ingameGUI.addChatMessage("Server says Minions are unobtainable through Evil Deeds here");
		            }
		        }
		    }
		}
		else if (packetType == 14) // minion unsummon command client to server
		{

		}
		else if (packetType == 15) // custom dig command client to server
		{

		}
		else if (packetType == 16) // lightning bolt (startx, starty, startz, endx, endy, endz, randomlong)
		{
		    Class[] decodeAs = {Double.class, Double.class, Double.class, Double.class, Double.class, Double.class, Long.class};
		    Object[] packetReadout = ForgePacketWrapper.readPacketData(data, decodeAs);

		    Vector3 start = new Vector3((Double)packetReadout[0], (Double)packetReadout[1], (Double)packetReadout[2]);
		    Vector3 end = new Vector3((Double)packetReadout[3], (Double)packetReadout[4], (Double)packetReadout[5]);

		    spawnLightningBolt(mcinstance.theWorld, null, start, end, (Long)packetReadout[6]);
		}
		else if (packetType == 17) // entity grab propagation server to client (minionEntID, targetEntID)
		{
		    Class[] decodeAs = {Integer.class, Integer.class};
		    Object[] packetReadout = ForgePacketWrapper.readPacketData(data, decodeAs);
		    Entity minion = findEntityByID(mcinstance.theWorld, (Integer) packetReadout[0]);
		    Entity target = findEntityByID(mcinstance.theWorld, (Integer) packetReadout[1]);
		    if (minion != null && target != null)
		    {
		        target.mountEntity(minion);
		    }
		}
	}
	
	public static void sendSoundToClients(Entity target, String soundEffect)
	{
	    // no implementation on client
	}

	private void spawnLightningBolt(World world, EntityLiving shooter, Vector3 startvec, Vector3 endvec, long randomizer)
	{
	    for (int i = 3; i != 0; i--)
	    {
	        ChickenLightningBolt bolt = new ChickenLightningBolt(world, startvec, endvec, randomizer);
	        bolt.defaultFractal();
	        bolt.finalizeBolt();
	        bolt.setWrapper(shooter);
	        ChickenLightningBolt.boltlist.add(bolt);   
	    }
	    
	    if (timeLastSound + timeSoundDelay < System.currentTimeMillis())
	    {
	        world.playSoundEffect(startvec.x, startvec.y, startvec.z, "mod_minions.bolt", 0.7F, 1F);
	        timeLastSound = System.currentTimeMillis();
	    }
	}
	
	private Entity findEntityByID(World world, int ID)
	{
	    List entList = world.loadedEntityList;
	    Iterator iter = entList.iterator();
	    Entity ent;
	    {
	        while (iter.hasNext())
	        {
	            ent = (Entity) iter.next();
	            if (ent.entityId == ID)
	            {
	                return ent;
	            }
	        }
	    }

	    return null;
	}

	private static void orderMinionToPickupEntity(EntityPlayer playerEnt, EntityLiving target)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.username);

		for (int i = 0; i < minions.length; i++)
		{
			minions[i].master = playerEnt;

			if (minions[i].riddenByEntity == null)
			{
				minions[i].targetEntityToGrab = (EntityLiving) target;
				minions[i].currentState = AS_EnumMinionState.STALKING_TO_GRAB;
				minions[i].worldObj.playSoundAtEntity(minions[i], "mod_minions.grabanimalorder", 1.0F, 1.0F);
				break;
			}
		}
	}

	private static void orderMinionToDrop(EntityPlayer playerEnt, AS_EntityMinion minion)
	{
		if (minion.riddenByEntity != null)
		{
			minion.worldObj.playSoundAtEntity(minion, "mod_minions.foryou", 1.0F, 1.0F);
			minion.riddenByEntity.mountEntity(null);
		}
		else if (minion.inventory.containsItems())
		{
			minion.dropAllItemsToWorld();
		}
	}

	private static void spawnMinionsForPlayer(EntityPlayer playerEnt, int x, int y, int z)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.username);

		if (minions == null || minions.length < minionsPerPlayer)
		{
			int prevArraySize = (minions == null) ? 0 : minions.length;
			AS_EntityMinion[] arrayplusone = new AS_EntityMinion[prevArraySize+1];
			int index = 0;
			while (index < prevArraySize)
			{
				arrayplusone[index] = minions[index];
				index++;
			}
			arrayplusone[prevArraySize] = new AS_EntityMinion(playerEnt.worldObj);
			arrayplusone[prevArraySize].setPosition(x, y+1, z);
			playerEnt.worldObj.spawnEntityInWorld(arrayplusone[prevArraySize]);
			arrayplusone[prevArraySize].setMaster(playerEnt);
			playerEnt.worldObj.playSoundAtEntity(arrayplusone[prevArraySize], "mod_minions.minionspawn", 1.0F, 1.0F);
			playerEnt.worldObj.spawnParticle("hugeexplosion", x, y, z, 0.0D, 0.0D, 0.0D);

			masterNames.put(playerEnt.username, arrayplusone);
			//System.out.println("spawned missing minion for "+var3.username);
		}

		orderMinionsToMoveTo(playerEnt, x, y, z);
	}

	private static void orderMinionsToChopTrees(EntityPlayer playerEnt, int x, int y, int z)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.username);

		for (int i = 0; i < minions.length; i++)
		{
			minions[i].master = playerEnt;
			minions[i].giveTask(null, true);
		}

		cancelRunningJobsForMaster(playerEnt.username);
		runningJobList.add(new AS_Minion_Job_TreeHarvest(minions, x, y, z));
		playerEnt.worldObj.playSoundAtEntity(playerEnt, "mod_minions.ordertreecutting", 1.0F, 1.0F);
	}

	private static void orderMinionsToDigStairWell(EntityPlayer playerEnt, int x, int y, int z)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.username);

		for (int i = 0; i < minions.length; i++)
		{
			minions[i].master = playerEnt;
			minions[i].giveTask(null, true);
		}

		// stairwell job
		cancelRunningJobsForMaster(playerEnt.username);
		runningJobList.add(new AS_Minion_Job_DigMineStairwell(minions, x, y-1, z));
		playerEnt.worldObj.playSoundAtEntity(playerEnt, "mod_minions.ordermineshaft", 1.0F, 1.0F);
	}

	private static void orderMinionsToDigStripMineShaft(EntityPlayer playerEnt, int x, int y, int z)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.username);

		for (int i = 0; i < minions.length; i++)
		{
			minions[i].master = playerEnt;
			minions[i].giveTask(null, true);
		}

		// strip mine job
		minions[0].master = playerEnt;
		runningJobList.add(new AS_Minion_Job_StripMine(minions, x, y-1, z));
		playerEnt.worldObj.playSoundAtEntity(playerEnt, "mod_minions.randomorder", 1.0F, 1.0F);
	}

	private static void orderMinionsToChestBlock(EntityPlayer playerEnt, int x, int y, int z)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.username);

		TileEntity chestOrInventoryBlock;
		if ((chestOrInventoryBlock = playerEnt.worldObj.getBlockTileEntity(x, y-1, z)) != null
		        && chestOrInventoryBlock instanceof IInventory
                && ((IInventory)chestOrInventoryBlock).getSizeInventory() >= 24)
		{
			cancelRunningJobsForMaster(playerEnt.username);
			playerEnt.worldObj.playSoundAtEntity(playerEnt, "mod_minions.randomorder", 2.0F, 1.0F);
			for (int i = 0; i < minions.length; i++)
			{
				minions[i].master = playerEnt;
				minions[i].giveTask(null, true);
				minions[i].returnChestOrInventory = (TileEntity) chestOrInventoryBlock;
				minions[i].currentState = AS_EnumMinionState.RETURNING_GOODS;
			}
		}
	}

	private static void orderMinionsToMoveTo(EntityPlayer playerEnt, int x, int y, int z)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.username);

		cancelRunningJobsForMaster(playerEnt.username);
		playerEnt.worldObj.playSoundAtEntity(playerEnt, "mod_minions.randomorder", 1.0F, 0.8F);
		for (int i = 0; i < minions.length; i++)
		{
			minions[i].master = playerEnt;
			minions[i].giveTask(null, true);
			minions[i].currentState = AS_EnumMinionState.IDLE;
			minions[i].orderMinionToMoveTo(x, y, z, false);
		}
	}

	private static void orderMinionsToMineOre(EntityPlayer playerEnt, int x, int y, int z)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.username);

		if (isBlockValuable(playerEnt.worldObj.getBlockId(x, y-1, z)))
		{
			cancelRunningJobsForMaster(playerEnt.username);
			playerEnt.worldObj.playSoundAtEntity(playerEnt, "mod_minions.randomorder", 1.0F, 0.8F);
			for (int i = 0; i < minions.length; i++)
			{
				minions[i].master = playerEnt;

				if (!minions[i].hasTask())
				{
					minions[i].giveTask(new AS_BlockTask_MineOreVein(null, minions[i], x, y-1, z));
					break;
				}
			}
		}
	}

	private static void orderMinionsToFollow(EntityPlayer entPlayer)
	{
		cancelRunningJobsForMaster(entPlayer.username);

		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(entPlayer.username);
		if (minions == null)
		{
			return;
		}

		entPlayer.worldObj.playSoundAtEntity(entPlayer, "mod_minions.orderfollowplayer", 1.0F, 0.8F);
		for (int i = 0; i < minions.length; i++)
		{
			minions[i].master = entPlayer;
			minions[i].giveTask(null, true);
			minions[i].currentState = AS_EnumMinionState.FOLLOWING_PLAYER;
		}
	}
	
	private static void orderMinionsToDigCustomSpace(EntityPlayer playerEnt, int x, int y, int z, int XZsize, int ySize)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.username);

		for (int i = 0; i < minions.length; i++)
		{
			minions[i].master = playerEnt;
			minions[i].giveTask(null, true);
		}
		
		// custom dig job
		minions[0].master = playerEnt;
		runningJobList.add(new AS_Minion_Job_DigByCoordinates(minions, x, y-1, z, XZsize, ySize));
		playerEnt.worldObj.playSoundAtEntity(playerEnt, "mod_minions.randomorder", 1.0F, 1.0F);
	}

	public static void OnMastersGloveRightClick(ItemStack var1, World worldObj, EntityPlayer playerEnt)
	{		
		targetObjectMouseOver = mcinstance.objectMouseOver; //mcinstance.renderViewEntity.rayTrace(30.0D, 1.0F);
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.username);
		// System.out.println("OnMastersGloveRightClick Master: "+playerEnt.username+", minionarray is: "+minions);
		Entity target;

		if (targetObjectMouseOver == null)
		{
			targetObjectMouseOver = mcinstance.renderViewEntity.rayTrace(30.0D, 1.0F);
		}

		if (targetObjectMouseOver == null)
		{

		}
		else if ((target = targetObjectMouseOver.entityHit) != null)
		{
			if (target instanceof EntityAnimal || target instanceof EntityPlayer)
			{
				if (worldObj.isRemote)
				{
					Object[] toSend = {playerEnt.username, playerEnt.entityId, target.entityId};
					ModLoader.sendPacket(ForgePacketWrapper.createPacket(MinionsCore.getPacketChannel(), 2, toSend)); // pickup entity command packet
				}
				else
				{
					orderMinionToPickupEntity(playerEnt, (EntityLiving) target);
				}
			}
			else if (target instanceof AS_EntityMinion)
			{
				AS_EntityMinion minion = (AS_EntityMinion) target;

				if (worldObj.isRemote)
				{
					Object[] toSend = {playerEnt.username, playerEnt.entityId, target.entityId};
					ModLoader.sendPacket(ForgePacketWrapper.createPacket(MinionsCore.getPacketChannel(), 3, toSend)); // minion drop items command packet
				}
				else
				{
					orderMinionToDrop(playerEnt, minion);
				}
			}
		}
		else if (targetObjectMouseOver.typeOfHit == EnumMovingObjectType.TILE)
		{
			int x = targetObjectMouseOver.blockX;
			int y = targetObjectMouseOver.blockY +1;
			int z = targetObjectMouseOver.blockZ;

			if (AS_AStarStatic.isPassableBlock(playerEnt.worldObj, x, y-1, z))
			{
				y--;
			}

			if (worldObj.isRemote)
			{
				if (!hasAllMinionsSMPOverride)
				{
					Object[] toSend = {playerEnt.username, x, y, z};
					ModLoader.sendPacket(ForgePacketWrapper.createPacket(MinionsCore.getPacketChannel(), 4, toSend)); // minion spawn command packet
					return;
				}
			}
			else
			{
				if (minions == null || minions.length < minionsPerPlayer)
				{
					spawnMinionsForPlayer(playerEnt, x, y, z);
					return;
				}
			}

			int ID = worldObj.getBlockId(x, y, z);
			TileEntity chestOrInventoryBlock;

			if (foundTreeBlocks.contains(ID))
			{
			    if (hasPlayerWillPower(playerEnt))
			    {
	                if (worldObj.isRemote)
	                {
	                    Object[] toSend = {playerEnt.username, x, y, z};
	                    ModLoader.sendPacket(ForgePacketWrapper.createPacket(MinionsCore.getPacketChannel(), 5, toSend)); // treechop job command packet
	                }
	                else
	                {
	                    orderMinionsToChopTrees(playerEnt, x, y, z);
	                    exhaustPlayerBig(playerEnt);
	                }
			    }
			}
			else if (isSelectingMineArea)
			{
				if (mineAreaShape == 0)
				{
				    if (hasPlayerWillPower(playerEnt))
				    {
    					if (worldObj.isRemote)
    					{
    						Object[] toSend = {playerEnt.username, x, y, z};
    						ModLoader.sendPacket(ForgePacketWrapper.createPacket(MinionsCore.getPacketChannel(), 6, toSend)); // stairwell job command packet
    					}
    					else
    					{
    						orderMinionsToDigStairWell(playerEnt, x, y, z);
    						exhaustPlayerBig(playerEnt);
    					}
				    }
					isSelectingMineArea = false;
				}
				else if (mineAreaShape == 1)
				{
                    if (hasPlayerWillPower(playerEnt))
                    {
                        if (worldObj.isRemote)
                        {
                            Object[] toSend = {playerEnt.username, x, y, z};
                            ModLoader.sendPacket(ForgePacketWrapper.createPacket(MinionsCore.getPacketChannel(), 7, toSend)); // stripmine job command packet
                        }
                        else
                        {
                            orderMinionsToDigStripMineShaft(playerEnt, x, y, z);
                            exhaustPlayerBig(playerEnt);
                        }
                    }
					isSelectingMineArea = false;
				}
				else if (mineAreaShape == 2)
				{
                    if (hasPlayerWillPower(playerEnt))
                    {
                        if (worldObj.isRemote)
                        {
                            Object[] toSend = {playerEnt.username, x, y, z, customSizeXZ, customSizeY};
                            ModLoader.sendPacket(ForgePacketWrapper.createPacket(MinionsCore.getPacketChannel(), 15, toSend)); // custom dig job command packet
                        }
                        else
                        {
                            orderMinionsToDigCustomSpace(playerEnt, x, y, z, customSizeXZ, customSizeY);
                        }
                        exhaustPlayerBig(playerEnt);
                    }
					isSelectingMineArea = false;
				}
			}
			else if ((chestOrInventoryBlock = worldObj.getBlockTileEntity(x, y-1, z)) != null
			        && chestOrInventoryBlock instanceof IInventory
			        && ((IInventory)chestOrInventoryBlock).getSizeInventory() >= 24)
			{
				if (worldObj.isRemote)
				{
					Object[] toSend = {playerEnt.username, x, y, z};
					ModLoader.sendPacket(ForgePacketWrapper.createPacket(MinionsCore.getPacketChannel(), 8, toSend)); // chest assign command packet
				}
				else
				{
					orderMinionsToChestBlock(playerEnt, x, y, z);
				}
			}
			else if (AS_AStarStatic.isPassableBlock(playerEnt.worldObj, x, y, z) && (minions != null || hasAllMinionsSMPOverride))
			{
				// check if player targets his own feet. if so, order minion carry
				if (MathHelper.floor_double(playerEnt.posX) == x
						&& MathHelper.floor_double(playerEnt.posZ) == z
						&& Math.abs(MathHelper.floor_double(playerEnt.posY) - y) < 3)
				{
					if (worldObj.isRemote)
					{
						Object[] toSend = {playerEnt.username, playerEnt.entityId, playerEnt.entityId};
						ModLoader.sendPacket(ForgePacketWrapper.createPacket(MinionsCore.getPacketChannel(), 2, toSend)); // pickup entity command packet
					}
					else
					{
						orderMinionToPickupEntity(playerEnt, playerEnt);
					}
				}
				else
				{
					if (worldObj.isRemote)
					{
						Object[] toSend = {playerEnt.username, x, y, z};
						ModLoader.sendPacket(ForgePacketWrapper.createPacket(MinionsCore.getPacketChannel(), 9, toSend)); // moveto command packet
					}
					else
					{
						orderMinionsToMoveTo(playerEnt, x, y, z);
					}
				}
			}
			else if (isBlockValuable(worldObj.getBlockId(x, y-1, z)))
			{
				if (worldObj.isRemote)
				{
					Object[] toSend = {playerEnt.username, x, y, z};
					ModLoader.sendPacket(ForgePacketWrapper.createPacket(MinionsCore.getPacketChannel(), 10, toSend)); // mine ore vein command
				}
				else
				{
					orderMinionsToMineOre(playerEnt, x, y, z);
				}
			}
		}
	}

	public static void unSummonMinions(EntityPlayer playerEnt)
	{
		if (playerEnt.worldObj.isRemote)
		{
			Object[] toSend = {playerEnt.username};
			ModLoader.sendPacket(ForgePacketWrapper.createPacket(MinionsCore.getPacketChannel(), 14, toSend));  // minion unsummon command
		}
		else
		{
			unSummonPlayersMinions(playerEnt);
		}
	}

	private static void unSummonPlayersMinions(EntityPlayer playerEnt)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.username);

		for (AS_EntityMinion minion : minions)
		{
			minion.master = playerEnt;
			minion.dropAllItemsToWorld();
			minion.setDead();
		}

		masterNames.remove(playerEnt.username);
	}

	public static void OnMastersGloveRightClickHeld(ItemStack var1, World var2, EntityPlayer var3)
	{
		if (var2.isRemote)
		{
			Object[] toSend = {var3.username};
			ModLoader.sendPacket(ForgePacketWrapper.createPacket(MinionsCore.getPacketChannel(), 11, toSend));
		}
		else
		{
			orderMinionsToFollow(var3);
		}
	}

	private void getViableTreeBlocks()
	{		
		for (Block iter : Block.blocksList)
		{
			if (iter != null && iter.getBlockName() != null && (iter instanceof BlockLog || iter.getBlockName().contains("log")))
			{
				foundTreeBlocks.add(iter.blockID);
			}
		}
	}

	public static boolean isBlockIDViableTreeBlock(int ID)
	{
		return foundTreeBlocks.contains(ID);
	}

	void initializeSettingsFile()
	{
		File settingsFile = configfile;

		try
		{
			if (settingsFile.exists())
			{
				System.out.println("/mods/mod_minions_evils.cfg found and opened");
				BufferedReader var1 = new BufferedReader(new FileReader(settingsFile));

				String lineString;
				while ((lineString = var1.readLine()) != null)
				{
					if (!lineString.startsWith("//"))
					{
						if (lineString.startsWith("minionsPerPlayer"))
						{
							String[] stringArray = lineString.split(":");
							minionsPerPlayer = Integer.parseInt(stringArray[1]);
							System.out.println("Config: Set minionsPerPlayer to "+minionsPerPlayer);
						}
						else if (lineString.startsWith("evilDeedXPCost"))
						{
							String[] stringArray = lineString.split(":");
							evilDeedXPCost = Integer.parseInt(stringArray[1]);
							System.out.println("Config: Set Evil Deed XP Cost to "+evilDeedXPCost);
						}
						else if (lineString.startsWith("minionMenuKey"))
						{
							String[] stringArray = lineString.split(":");
							s_MenuKey = stringArray[1];
							i_MenuKey = Keyboard.getKeyIndex(s_MenuKey);
							System.out.println("Config: Set Minion Menu button to "+s_MenuKey);
						}
						else if (lineString.startsWith("minionsInSavegame"))
						{
							String[] stringArray = lineString.split(":");
							minionsInSavegame = (Integer.parseInt(stringArray[1]) != 0);
							System.out.println("Config: Set persisting Minions "+minionsInSavegame);
						}
						else if (lineString.startsWith("masterStaffItemID"))
                        {
                            String[] stringArray = lineString.split(":");
                            MinionsCore.masterStaffItemID = Integer.parseInt(stringArray[1]);
                            System.out.println("Config: Set master staff Item ID to "+MinionsCore.masterStaffItemID);
                        }
						else if (lineString.startsWith("registerBlockIDasTreeBlock"))
						{
						    String[] stringArray = lineString.split(":");
						    int id = Integer.parseInt(stringArray[1]);
						    foundTreeBlocks.add(id);
						    System.out.println("Config: registered additional tree block ID "+id);
						}
						else
						{
							String[] stringArray = lineString.split(":");

							AS_EvilDeed deed = new AS_EvilDeed(stringArray[0], stringArray[1], Integer.parseInt(stringArray[2]));
							evilDoings.add(deed);
						}
					}
				}

				var1.close();
			}
			else
			{
				System.out.println("Could not open /mods/mod_minions_evils.cfg, you suck");
			}
		}
		catch (Exception var6)
		{
			System.out.println("EXCEPTION BufferedReader: " + var6);
		}
	}

	public static boolean isBlockValuable(int blockID)
	{
		return MinionsCore.isBlockValueable(blockID);
	}

	public static void requestXPSettingFromServer()
	{
		if (mcinstance.thePlayer.worldObj.isRemote)
		{
			Object[] dummy = {0};
			ModLoader.sendPacket(ForgePacketWrapper.createPacket(MinionsCore.getPacketChannel(), 13, dummy));
		}
	}

	// HUD mask i might want to use someday
	private void renderPumpkinBlur()
	{    	
		ScaledResolution var5 = new ScaledResolution(mcinstance.gameSettings, mcinstance.displayWidth, mcinstance.displayHeight);
		int var1 = var5.getScaledWidth();
		int var2 = var5.getScaledHeight();

		GL11.glDisable(2929 /*GL_DEPTH_TEST*/);
		GL11.glDepthMask(false);
		GL11.glBlendFunc(770, 771);
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		GL11.glDisable(3008 /*GL_ALPHA_TEST*/);
		GL11.glBindTexture(3553 /*GL_TEXTURE_2D*/, mcinstance.renderEngine.getTexture("%blur%/misc/pumpkinblur.png"));
		Tessellator var3 = Tessellator.instance;
		var3.startDrawingQuads();
		var3.addVertexWithUV(0.0D, (double)var2, -90.0D, 0.0D, 1.0D);
		var3.addVertexWithUV((double)var1, (double)var2, -90.0D, 1.0D, 1.0D);
		var3.addVertexWithUV((double)var1, 0.0D, -90.0D, 1.0D, 0.0D);
		var3.addVertexWithUV(0.0D, 0.0D, -90.0D, 0.0D, 0.0D);
		var3.draw();
		GL11.glDepthMask(true);
		GL11.glEnable(2929 /*GL_DEPTH_TEST*/);
		GL11.glEnable(3008 /*GL_ALPHA_TEST*/);
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
	}

	@Override
	public void onConnect(NetworkManager network)
	{
		MessageManager.getInstance().registerChannel(network, this, MinionsCore.getPacketChannel());
	}

	@Override
	public void onLogin(NetworkManager network, Packet1Login login)
	{
	}

	@Override
	public void onDisconnect(NetworkManager network, String message, Object[] args)
	{
	}

	@Override
	public boolean clientSideRequired()
	{
		return true;
	}

	@Override
	public boolean serverSideRequired()
	{
		return false;
	}

	public static DataWatcher getEntityDataWatcher(Entity ent)
	{
		return ent.dataWatcher;
	}

	public static int getBlockDamageDropped(Block b, int x)
	{
		return b.damageDropped(x);
	}

	public static AS_PathEntity translateAStarPathtoPathEntity(ArrayList input)
	{
		PathPoint[] points = new PathPoint[input.size()];
		AS_AStarNode reading;
		int i = 0;
		int size = input.size();
		//System.out.println("Translating AStar Path with "+size+" Hops:");

		while(size > 0)
		{
			reading = (AS_AStarNode) input.get(size-1);
			points[i] = new PathPoint(reading.x, i == 0 ? reading.y+1 : reading.y, reading.z); // MC demands the first path point to be at +1 height for some fucking reason
			points[i].isFirst = i == 0;
			points[i].index = i;
			points[i].totalPathDistance = i;
			points[i].distanceToNext = 1F;
			points[i].distanceToTarget = size;

			if (i>0)
			{
				points[i].previous = points[i-1];
			}
			//System.out.println("PathPoint: ["+reading.x+"|"+reading.y+"|"+reading.z+"]");

			input.remove(size-1);
			size --;
			i++;
		}
		//System.out.println("Translated AStar PathEntity with length: "+ points.length);

		return new AS_PathEntity(points);
	}
	
    public static void notifyClientsOfMounting(AS_EntityMinion theMinion, EntityLiving target)
    {
        // not implemented on client
    }
}
