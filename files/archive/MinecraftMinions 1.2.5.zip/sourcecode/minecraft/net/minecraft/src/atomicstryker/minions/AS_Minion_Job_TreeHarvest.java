package net.minecraft.src.atomicstryker.minions;

import java.util.ArrayList;

import net.minecraft.src.ChunkCoordinates;
import net.minecraft.src.World;

/**
 * Minion Job class for scanning for Trees and then keeping track of the minions harvesting them.
 * 
 * 
 * @author AtomicStryker
 */

public class AS_Minion_Job_TreeHarvest extends AS_Minion_Job_Manager
{
	private volatile AS_TreeScanner treeScanWorker;
	private volatile Thread thread;
	private World worldObj;
	private boolean isWorking = false;
	private boolean doneLookingForTrees = false;
	
    public AS_Minion_Job_TreeHarvest(AS_EntityMinion[] minions, int ix, int iy, int iz)
    {
    	super(minions, ix, iy, iz);
    	this.worldObj = minions[0].worldObj;
    }
    
    @Override
    public void onJobStarted()
    {
    	super.onJobStarted();
    	
    	treeScanWorker = new AS_TreeScanner(this);
    	treeScanWorker.setup(pointOfOrigin, worldObj);
    	
    	thread = new Thread(treeScanWorker);
    	thread.start();
    }
    
    @Override
    public void onJobUpdateTick()
    {
    	super.onJobUpdateTick();
    	
    	if (!isWorking)
    	{
    		//System.out.println("onJobUpdateTick, starting Tree Job now!");
    		isWorking = true;
    		onJobStarted();
    		return;
    	}
    	
    	AS_BlockTask_TreeChop nextTree = null;
    	AS_EntityMinion worker = null;
    	boolean hasJobs = !this.jobQueue.isEmpty();
    	
    	if (hasJobs)
    	{
	    	nextTree = (AS_BlockTask_TreeChop) this.jobQueue.get(0);
	    	worker = this.getNearestAvailableWorker(nextTree.posX, nextTree.posY, nextTree.posZ);
    	}
    	else if (doneLookingForTrees) // only get a worker to fire from the job if there will be nothing left to do
    	{
    		worker = this.getAnyAvailableWorker();
    	}
    	if (worker != null)
    	{
    		if (hasJobs)
    		{
    			// order him to walk there and chop the tree
    			((AS_BlockTask_TreeChop) this.jobQueue.get(0)).setWorker(worker);
    			worker.giveTask((AS_BlockTask_TreeChop) this.jobQueue.get(0));
    			this.jobQueue.remove(0);
    		}
    		else
    		{
    			this.setWorkerFree(worker);
    		}
    	}
    }
    
    @Override
    public void onJobFinished()
    {
    	if (thread != null && !thread.isInterrupted())
    	{
    		thread.interrupt();
    	}
    	
    	super.onJobFinished();
    }
    
	public void onFoundTreeBase(int ix, int iy, int iz, ArrayList<ChunkCoordinates> treeBlockList, ArrayList<ChunkCoordinates> leaveBlockList)
	{		
		AS_BlockTask_TreeChop newJob = new AS_BlockTask_TreeChop(this, null, ix, iy, iz, treeBlockList, leaveBlockList);
		if (!this.jobQueue.contains(newJob))
		{
			this.jobQueue.add(newJob);
		}
		//System.out.println("Found Tree at: ["+ix+"|"+iy+"|"+iz+"], TreeBlocks: ["+treeBlockList.size()+"], Leaves: ["+leaveBlockList.size()+"] job Queue size now: "+this.jobQueue.size());
	}
	
	public void onDoneFindingTrees()
	{
		doneLookingForTrees = true;
	}
}