package net.minecraft.src.atomicstryker.minions;

import java.util.*;

/**
 * Blocktask for mining a single Block, then replacing it with another
 * 
 * 
 * @author AtomicStryker
 */

public class AS_BlockTask_ReplaceBlock extends AS_BlockTask_MineBlock
{
	public final int blockToPlace;
	public final int metaToPlace;
	
    public AS_BlockTask_ReplaceBlock(AS_Minion_Job_Manager boss, AS_EntityMinion input, int ix, int iy, int iz, int blockOrdered, int metaOrdered)
    {
    	super(boss, input, ix, iy, iz);
    	blockToPlace = blockOrdered;
    	metaToPlace = metaOrdered;
    }
    
    public void onFinishedTask()
    {
    	super.onFinishedTask();
    	
    	this.worker.worldObj.setBlockAndMetadataWithNotify(posX, posY, posZ, blockToPlace, metaToPlace);
    }
}