package net.minecraft.src.atomicstryker.minions;

/**
 * Minion state Enumeration
 * 
 * 
 * @author AtomicStryker
 */

public enum AS_EnumMinionState
{
    IDLE("IDLE", 0),
    FOLLOWING_PLAYER("FOLLOWING_PLAYER", 1),
    WALKING_TO_COORDS("WALKING_TO_COORDS", 2),
    AWAITING_JOB("AWAITING_JOB", 3),
    RETURNING_GOODS("RETURNING_GOODS", 4),
    THINKING("THINKING", 5),
    MINING("MINING", 6),
    STALKING_TO_GRAB("STALKING_TO_GRAB", 7);

    private String name;
    private int number;
    
    private AS_EnumMinionState(String var1, int var2)
    {
    	this.name = var1;
    	this.number = var2;
    }
    
    public String getName()
    {
    	return this.name;
    }
    
    public int getNumber()
    {
    	return this.number;
    }
    
    public static AS_EnumMinionState getStateByString(String input)
    {
    	for (AS_EnumMinionState check : AS_EnumMinionState.values())
    	{
    		if(check.getName().equals(input))
    		{
    			return check;
    		}
    	}
    	
    	return null;
    }
}
