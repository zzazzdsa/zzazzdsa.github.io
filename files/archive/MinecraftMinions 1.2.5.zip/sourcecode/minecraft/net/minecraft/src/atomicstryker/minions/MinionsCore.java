package net.minecraft.src.atomicstryker.minions;

import net.minecraft.src.*;
import net.minecraft.src.forge.*;

public class MinionsCore
{
	public static MinionsChunkManager minionsChunkManager = new MinionsChunkManager();
	private static long time = System.currentTimeMillis();
	
	private static long firstBootTime = System.currentTimeMillis();
	private static boolean hasBooted;
	
	public static int masterStaffItemID = 2527;
    public static Item itemMastersStaff;

	public static String getPacketChannel()
	{
		return "AS_Minions";
	}

	public static String getVersion()
	{
		return "1.2.8 @ MC 1.2.5";
	}

	public static boolean isBlockValueable(int blockID)
	{
		if (blockID == 0
		|| blockID == Block.dirt.blockID
		|| blockID == Block.grass.blockID
		|| blockID == Block.stone.blockID
		|| blockID == Block.cobblestone.blockID
		|| blockID == Block.gravel.blockID
		|| blockID == Block.sand.blockID
		|| blockID == Block.leaves.blockID
		|| blockID == Block.obsidian.blockID
		|| blockID == Block.bedrock.blockID
		|| blockID == Block.stairCompactCobblestone.blockID
		|| blockID == Block.netherrack.blockID
		|| blockID == Block.slowSand.blockID)
		{
			return false;
		}
		
		return true;
	}

	public static void load(mod_Minions mod)
	{
		MinecraftForge.registerConnectionHandler(mod);
		
		MinecraftForge.registerChunkLoadHandler(minionsChunkManager);
		
		MinecraftForge.registerEntity(AS_EntityMinion.class, mod, 17, 25, 5, true);
		
        if (mod.minionsInSavegame)
        {
        	ModLoader.registerEntityID(AS_EntityMinion.class, "Minion", 17);
        }
        
        itemMastersStaff = (new AS_ItemMastersStaff(masterStaffItemID)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mod_minions/masterstaff.png")).setItemName("Master's Staff");
        
        new MinionsUpdateHandler(mod);
	}
	
	public static void onTick(mod_Minions mod)
	{
		if (!hasBooted)
		{
			if (System.currentTimeMillis() > firstBootTime+10000L)
			{
				hasBooted = true;
			}
		}
		else if (System.currentTimeMillis() > time + 1000L)
		{
			MinionsChunkManager.updateLoadedChunks();
		}
	}
}
