package net.minecraft.src.atomicstryker.minions;

import java.util.*;
import net.minecraft.src.*;
import net.minecraft.src.forge.*;

public class MinionsChunkManager implements IChunkLoadHandler
{
	private static final int CHUNK_LENGTH = 16;
	private static final int LOAD_CHUNKS_IN_ALL_DIRECTIONS = 2;
	
	private static Set<Entity> loaderEntities;
	private static Set<ChunkCoordIntPair> loadedChunks;
	
	public MinionsChunkManager()
	{
		loaderEntities = new HashSet();;
		loadedChunks = new HashSet();
	}
	
	public static void registerChunkLoaderEntity(Entity ent)
	{
		loaderEntities.add(ent);
	}
	
	public static void unRegisterChunkLoaderEntity(Entity ent)
	{
		loaderEntities.remove(ent);
	}
	
	public static void updateLoadedChunks()
	{
		loadedChunks.clear();
		for (Entity ent : loaderEntities)
		{
			loadChunksAroundCoords(ent.worldObj, MathHelper.floor_double(ent.posX), MathHelper.floor_double(ent.posZ));
		}
	}
	
	private static void loadChunksAroundCoords(World world, int x, int z)
	{
		for (int xIter = -LOAD_CHUNKS_IN_ALL_DIRECTIONS; xIter <= LOAD_CHUNKS_IN_ALL_DIRECTIONS; xIter++)
		{
			for (int zIter = -LOAD_CHUNKS_IN_ALL_DIRECTIONS; zIter <= LOAD_CHUNKS_IN_ALL_DIRECTIONS; zIter++)
			{
				loadChunkAtCoords(world, x + (xIter*CHUNK_LENGTH), z + (zIter*CHUNK_LENGTH));
			}
		}
	}
	
	private static void loadChunkAtCoords(World world, int x, int z)
	{
		loadedChunks.add(world.getChunkFromBlockCoords(x, z).getChunkCoordIntPair());
	}

	@Override
	public void addActiveChunks(World world, Set<ChunkCoordIntPair> chunkList)
	{
		chunkList.addAll(loadedChunks);
	}

	@Override
	public boolean canUnloadChunk(Chunk chunk)
	{
		return loadedChunks.contains(chunk.getChunkCoordIntPair());
	}

	@Override
	public boolean canUpdateEntity(Entity entity)
	{
		return (entity instanceof AS_EntityMinion);
	}
}
