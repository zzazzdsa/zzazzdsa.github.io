// This file ONLY tells you what and where this mod specifically adds to the minecraft sourcecode.


public class World
    implements IBlockAccess
{

	public int getSkyBlockTypeBrightness(EnumSkyBlock par1EnumSkyBlock, int par2, int par3, int par4)
	{
		//replace:
				return par7.getSavedLightValue(par1EnumSkyBlock, par2 & 15, par3, par4 & 15);
		
		//with:
	       		int retVal = par7.getSavedLightValue(par1EnumSkyBlock, par2 & 15, par3, par4 & 15);
	
	    		if (par1EnumSkyBlock == EnumSkyBlock.Sky)
	    		{
	    			return retVal;
	    		}
	    		else
	    		{
	    			int cached = LightCache.cache.getLightValue(par2, par3, par4);
	    			if (cached > retVal) return cached;
	
	    			int torchLight = (int)java.lang.Math.round(PlayerTorchArray.getLightBrightness(this, par2, par3, par4));
	    			if(retVal < torchLight)
	    			{
	    				return torchLight;
	    			}
	    		}
	
	    		LightCache.cache.setLightValue(par2, par3, par4, retVal);
	    		return retVal;

	}

}