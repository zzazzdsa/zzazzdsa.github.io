// This file ONLY tells you what and where this mod specifically adds to the minecraft sourcecode.


public class ChunkCache
    implements IBlockAccess
{

	public int getSkyBlockTypeBrightness(EnumSkyBlock par1EnumSkyBlock, int par2, int par3, int par4)
	{
		//replace:
				return this.chunkArray[par5][par6].getSavedLightValue(par1EnumSkyBlock, par2 & 15, par3, par4 & 15);
		
		//with:
	       		int retVal = this.chunkArray[var5][var6].getSavedLightValue(par1EnumSkyBlock, par2 & 15, par3, par4 & 15);
	    		
	    		if (par1EnumSkyBlock == EnumSkyBlock.Sky)
	    		{
	    			return retVal;
	    		}
	    		else
	    		{
	    			int cached = LightCache.cache.getLightValue(par2, par3, par4);
	    			if (cached > retVal) return cached;
	
	    			int torchLight = (int)java.lang.Math.round(PlayerTorchArray.getLightBrightness(worldObj, par2, par3, par4));
	    			if(retVal < torchLight)
	    			{
	    				return torchLight;
	    			}
	    		}
	    		
	    		LightCache.cache.setLightValue(par2, par3, par4, retVal);
	    		return retVal;

	}
	
}
