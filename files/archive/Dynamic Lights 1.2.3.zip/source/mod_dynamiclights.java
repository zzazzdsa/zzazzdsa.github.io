package net.minecraft.src;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.util.*;

public class mod_dynamiclights extends BaseMod
{
	private static String togglekey = "L";
	private static int itogglekey = Keyboard.getKeyIndex(togglekey);
	private boolean toggleCD = false;
	private int lastEntityListHash = 0;
    private List entityList;
	long time;

	@Override
	public void load()
	{
		ModLoader.setInGameHook(this, true, false);
		
		time = System.currentTimeMillis();
	}
	
	public static void assignToggleButton(String input)
	{
		togglekey = input;
		itogglekey = Keyboard.getKeyIndex(togglekey);
	}
	
	@Override
	public boolean onTickInGame(float renderTick, net.minecraft.client.Minecraft mc)
	{
		if (mc.thePlayer == null || mc.theWorld == null) return false;
		
		boolean newsecond = false;
		if(System.currentTimeMillis() >= time + 1000L) 
		{
			newsecond = true;
			time = System.currentTimeMillis();
			toggleCD = false;
		}
		
		if(lastEntityListHash != mc.theWorld.loadedEntityList.hashCode())
		{
			entityList = mc.theWorld.loadedEntityList;
			lastEntityListHash = mc.theWorld.loadedEntityList.hashCode();
			
			UpdateTorchEntities(mc.theWorld);
		}
		
		TorchEntitiesDoTick(mc, newsecond);
		
		if (newsecond)
		{
			UpdateBurningEntities(mc);
		}
		
		if (Keyboard.getEventKeyState()
		&& Keyboard.getEventKey() == itogglekey
		&& !toggleCD)
		{
			PlayerTorchArray.ToggleDynamicLights();
			toggleCD = true;
		}
		
		return true;
	}
	
	private int targetBlockID = 0;
	private int targetBlockX;
	private int targetBlockY;
	private int targetBlockZ;
	
	private void TorchEntitiesDoTick(net.minecraft.client.Minecraft mc, boolean newsecond)
	{
		PlayerTorch torchLoopClass;
		Entity torchent;
		EntityPlayer entPlayer;
		for(int j = PlayerTorchArray.torchArray.size(); --j >= 0 ;) // loop the PlayerTorch List
		{
			torchLoopClass = (PlayerTorch)PlayerTorchArray.torchArray.get(j);
			torchent = torchLoopClass.GetTorchEntity();
			
			if(torchent instanceof EntityPlayer)
			{
				entPlayer = (EntityPlayer)torchent;
				TickPlayerEntity(mc, newsecond, torchLoopClass, entPlayer);
			}
			
			else if(torchent instanceof EntityItem)
			{
				TickItemEntity(mc, newsecond, torchLoopClass, torchent);
			}
			
			else
			{
				torchLoopClass.setTorchPos(mc.theWorld, (float)torchent.posX, (float)torchent.posY, (float)torchent.posZ);
			}
		}
	}
	
	private void TickPlayerEntity(net.minecraft.client.Minecraft mc, boolean newsecond, PlayerTorch torchLoopClass, EntityPlayer entPlayer)
	{
		int oldbrightness = torchLoopClass.isTorchActive() ? torchLoopClass.GetTorchBrightness() : 0;
		
		if (newsecond)
		{
			if (GetPlayerArmorLightValue(torchLoopClass, entPlayer, oldbrightness) == 0 && !entPlayer.isBurning()) // case no (more) shiny armor
			{
				torchLoopClass.IsArmorTorch = false;
			}
		}
		
		int itembrightness = 0;
		if (entPlayer.inventory.getCurrentItem() != null)
		{
			int ID = entPlayer.inventory.getCurrentItem().itemID;
			if (ID != torchLoopClass.currentItemID
			|| (newsecond && !torchLoopClass.IsArmorTorch))
			{
				torchLoopClass.currentItemID = ID;
				
				// this is a debug function for modder use.
				//mc.ingameGUI.addChatMessage("Player Item changed, item now: " + ID);
				
				itembrightness = PlayerTorchArray.GetItemBrightnessValue(ID);
				if (itembrightness >= oldbrightness)
				{
					if (torchLoopClass.IsArmorTorch)
						torchLoopClass.IsArmorTorch = false;
				
					torchLoopClass.SetTorchBrightness(itembrightness);
					torchLoopClass.SetTorchRange(PlayerTorchArray.GetItemLightRangeValue(ID));
					
					if (!torchLoopClass.hasDeathAge())
					{
						torchLoopClass.setDeathAge(PlayerTorchArray.GetItemDeathAgeTicksValue(ID));
					}
					
					torchLoopClass.SetWorksUnderwater(PlayerTorchArray.GetItemWorksUnderWaterValue(ID));
					torchLoopClass.setTorchState(entPlayer.worldObj, true);
				}
				else if(!torchLoopClass.IsArmorTorch && GetPlayerArmorLightValue(torchLoopClass, entPlayer, oldbrightness) == 0)
				{
					torchLoopClass.setTorchState(entPlayer.worldObj, false);
				}
			}
		}
		else
		{
			torchLoopClass.currentItemID = 0;
			if (!torchLoopClass.IsArmorTorch && GetPlayerArmorLightValue(torchLoopClass, entPlayer, oldbrightness) == 0)
			{
				torchLoopClass.setTorchState(entPlayer.worldObj, false);
			}
		}
		
		if (torchLoopClass.isTorchActive())
		{
			torchLoopClass.setTorchPos(entPlayer.worldObj, (float)entPlayer.posX, (float)entPlayer.posY, (float)entPlayer.posZ);
			
			if (!torchLoopClass.hasDeathAge()) return;

			if(torchLoopClass.hasReachedDeathAge())
			{
				entPlayer.worldObj.playSoundAtEntity(entPlayer, "random.fizz", 1.0F, 1.0F);
				if(--entPlayer.inventory.getCurrentItem().stackSize <= 0)
				{
					entPlayer.inventory.setInventorySlotContents(entPlayer.inventory.currentItem, null);
					PlayerTorchArray.RemoveTorchFromArray(entPlayer.worldObj, torchLoopClass);
				}
				else
				{
					torchLoopClass.setDeathAge(PlayerTorchArray.GetItemDeathAgeTicksValue(entPlayer.inventory.getCurrentItem().itemID));
				}
			}
			else if(newsecond)
			{
				torchLoopClass.doAgeTick();
			}
		}
	}
	
	private int GetPlayerArmorLightValue(PlayerTorch torchLoopClass, EntityPlayer entPlayer, int oldbrightness)
	{
		int armorbrightness = 0;
		int armorID;
		
		
		if(entPlayer.isBurning())
		{
			torchLoopClass.IsArmorTorch = true;
			torchLoopClass.SetTorchBrightness(15);
			torchLoopClass.SetTorchRange(31);
			torchLoopClass.setTorchState(entPlayer.worldObj, true);
		}
		else
		{
			ItemStack armorItem;
			for(int l = 4; --l >= 0;)
			{
				armorItem = entPlayer.inventory.armorItemInSlot(l);
				if(armorItem != null)
				{
					armorID = armorItem.itemID;
					armorbrightness = PlayerTorchArray.GetItemBrightnessValue(armorID);
					
					if (armorbrightness > oldbrightness)
					{
						oldbrightness = armorbrightness;
						torchLoopClass.IsArmorTorch = true;
						torchLoopClass.SetTorchBrightness(armorbrightness);
						torchLoopClass.SetTorchRange(PlayerTorchArray.GetItemLightRangeValue(armorID));
						torchLoopClass.SetWorksUnderwater(PlayerTorchArray.GetItemWorksUnderWaterValue(armorID));
						torchLoopClass.setTorchState(entPlayer.worldObj, true);
					}
				}
			}
		}
		
		return armorbrightness;
	}
	
	private void TickItemEntity(net.minecraft.client.Minecraft mc, boolean newsecond, PlayerTorch torchLoopClass, Entity torchent)
	{
		torchLoopClass.setTorchPos(mc.theWorld, (float)torchent.posX, (float)torchent.posY, (float)torchent.posZ);
		
		if (torchLoopClass.hasDeathAge())
		{
			if (torchLoopClass.hasReachedDeathAge())
			{
				mc.theWorld.playSoundAtEntity(torchent, "random.fizz", 1.0F, 1.0F);
				torchent.setEntityDead();
				PlayerTorchArray.RemoveTorchFromArray(mc.theWorld, torchLoopClass);
			}
			else if (newsecond)
			{
				torchLoopClass.doAgeTick();
			}
		}
	}
	
	private void UpdateBurningEntities(net.minecraft.client.Minecraft mc)
	{
		Entity tempent;
		PlayerTorch torchent;
		for(int k = entityList.size(); --k >= 0;) // we loop ALL entities
		{
			tempent = (Entity)entityList.get(k);
			
			if (tempent.isBurning())
			{
				//mc.ingameGUI.addChatMessage("Found burning entity: " + tempent);
			
				torchent = PlayerTorchArray.GetTorchForEntity(tempent);
			
				if (torchent == null) // if it is on fire and not yet a playertorch...
				{
					//mc.ingameGUI.addChatMessage("Burning ent has no Torch yet, adding");
				
					PlayerTorch newtorch = new PlayerTorch(tempent); // add one with torch data!
					PlayerTorchArray.AddTorchToArray(newtorch);
					newtorch.SetTorchBrightness(15);
					newtorch.SetTorchRange(31);
					newtorch.setTorchState(mc.theWorld, true);
				}
			}
		}
	}
	
	private void UpdateTorchEntities(World worldObj)
	{
		List tempList = new ArrayList();
	
		Entity tempent;
		EntityItem helpitem;
		for(int k = entityList.size(); --k >= 0;)
		{
			tempent = (Entity)entityList.get(k);
			
			if(tempent instanceof EntityPlayer)
			{
				tempList.add(tempent);
			}
			
			else if(tempent instanceof EntityItem)
			{
				helpitem = (EntityItem)tempent;
				int brightness = PlayerTorchArray.GetItemBrightnessValue(helpitem.item.itemID);
				if (brightness > 0)
				{			
					tempList.add(tempent);
				}
			}
		}
		// tempList is now a fresh list of all Entities that can have a PlayerTorch
		PlayerTorch torchLoopClass;
		Entity torchent;
		
		for(int j = PlayerTorchArray.torchArray.size(); --j >= 0;) // loop the old PlayerTorch List
		{
			torchLoopClass = (PlayerTorch)PlayerTorchArray.torchArray.get(j);
			torchent = torchLoopClass.GetTorchEntity();
			
			if (tempList.contains(torchent)) // check if the old entities are still in the world
			{
				tempList.remove(torchent); // if so remove them from the fresh list
			}
			else if ((!torchLoopClass.IsTorchCustom() && !torchent.isBurning()) // exclude foreign modded torches and burning stuff
					|| torchent != null && !torchent.isEntityAlive()) // but do delete dead stuff
			{
				PlayerTorchArray.RemoveTorchFromArray(worldObj, torchLoopClass); // else remove them from the PlayerTorch list
			}
		}
		
		Entity newent;
		EntityItem institem;
		for(int l = tempList.size(); --l >= 0;) // now to loop the remainder of the fresh list, the NEW lights
		{
			newent = (Entity)tempList.get(l);
			
			PlayerTorch newtorch = new PlayerTorch(newent);
			PlayerTorchArray.AddTorchToArray(newtorch);
			
			if(newent instanceof EntityItem)
			{
				institem = (EntityItem)newent;
				newtorch.SetTorchBrightness(PlayerTorchArray.GetItemBrightnessValue(institem.item.itemID));
				newtorch.SetTorchRange(PlayerTorchArray.GetItemLightRangeValue(institem.item.itemID));
				newtorch.setDeathAge(PlayerTorchArray.GetItemDeathAgeTicksValue(institem.item.itemID));
				newtorch.SetWorksUnderwater(PlayerTorchArray.GetItemWorksUnderWaterValue(institem.item.itemID));
				newtorch.setTorchState(worldObj, true);
			}
		}
	}
	
	@Override
	public String getVersion()
	{
		return "v1.2.3 MCP";
	}
}