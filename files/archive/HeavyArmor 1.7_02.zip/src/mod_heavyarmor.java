package net.minecraft.src;

import java.util.*;

public class mod_heavyarmor extends BaseMod
{
	final double pullforcePerPart = -0.003D;
	
	enum HeavyArmors {
	
		ChainHelmet(302),
		ChainChestPlate(303),
		ChainLeggings(304),
		ChainBoots(305),
		IronHelmet(306),
		IronChestPlate(307),
		IronLeggings(308),
		IronBoots(309),
		DiamondHelmet(310),
		DiamondChestPlate(311),
		DiamondLeggings(312),
		DiamondBoots(313),
		GoldHelmet(314),
		GoldChestPlate(315),
		GoldLeggings(316),
		GoldBoots(317);
		
		private int value;
		
		HeavyArmors(int value)
		{
			this.value = value;
		}
		
		int GetArmorID()
		{
			return value;
		}
		
	}

	long time;
	private double pullforce = 0.0D;
	boolean IsWearingHeavyArmor = false;

	public mod_heavyarmor()
	{
		ModLoader.SetInGameHook(this, true, false);
		time = System.currentTimeMillis();
	}
	
	public void OnTickInGame(net.minecraft.client.Minecraft mc)
	{
		if (mc.thePlayer == null || mc.theWorld == null) return;
		
		boolean newsecond = false;
		if(System.currentTimeMillis() >= time + 1000L) 
		{
			newsecond = true;
			time = System.currentTimeMillis();
		}
		
		if (newsecond)
		{
			CheckArmor(mc.thePlayer);
			//mc.ingameGUI.addChatMessage("Y Velocity:" + mc.thePlayer.motionY); // for debug purposes
		}
		
		MovementModTick(mc.thePlayer);
	}
	
	
	public void CheckArmor(EntityPlayer entPlayer)
	{
		IsWearingHeavyArmor = false;
		pullforce = 0.0D;
	
		for(int l = 0; l < 4; l++)
		{
			ItemStack armorItem = entPlayer.inventory.armorItemInSlot(l);
			if(armorItem != null)
			{
				if (IsHeavyArmor(armorItem.itemID))
				{
					IsWearingHeavyArmor = true;
					pullforce += pullforcePerPart;
				}
			}
		}
	}
	
	public void MovementModTick(EntityPlayer entPlayer)
	{
		if (!IsWearingHeavyArmor
		|| (entPlayer.ridingEntity != null)
		|| !entPlayer.isInWater())
		{
			return;
		}
		
		if (!entPlayer.onGround)
		{
			entPlayer.addVelocity(0, pullforce, 0);
		}
	}
	
	private boolean IsHeavyArmor(int ID)
	{
		for (HeavyArmors armorid : HeavyArmors.values())
		{
			if (ID == armorid.GetArmorID())
			{
				return true;
			}
		}
	
		return false;
	}
	
	public String Version()
	{
		return "v1.0.0";
	}
}