Small Modloader mod i made after having the sudden insight Minecraft players are swimming around in full metal armors.
Have you ever tried doing that in the real world?

So. This mod counts the "heavy" armor pieces you have on you and adds weight in water.
You will just barely be able to swim with one piece of metal/ diamond armor.
Anything above that: You will be pulled down relentlessly.


Source is included, if you wish to add other armor ID's go ahead.


-- AtomicStryker