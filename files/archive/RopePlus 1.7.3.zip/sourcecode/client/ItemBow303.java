// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import java.util.Random;

// Referenced classes of package net.minecraft.src:
//            Item, mod_Arrows303, EntityArrow303, EntityPlayer, 
//            InventoryPlayer, ItemStack, World

public class ItemBow303 extends Item
{

    public ItemBow303(int i)
    {
        super(i);
        maxStackSize = 1;
    }

    public ItemStack onItemRightClick(ItemStack itemstack, World world, EntityPlayer entityplayer)
    {
        mod_Arrows303.inst.selectArrow();
        EntityArrow303 entityarrow303 = mod_Arrows303.inst.selectedArrow;
        if(entityarrow303 == null)
        {
            return itemstack;
        }
        int i = mod_Arrows303.inst.burstSize;
        do
        {
            if(i <= 0)
            {
                break;
            }
            if(--entityplayer.inventory.mainInventory[mod_Arrows303.inst.selectedSlot].stackSize <= 0)
            {
                entityplayer.inventory.mainInventory[mod_Arrows303.inst.selectedSlot] = null;
                mod_Arrows303.inst.selectArrow();
            }
            world.playSoundAtEntity(entityplayer, "random.bow", 1.0F, 1.0F / (itemRand.nextFloat() * 0.4F + 0.8F));
            EntityArrow303 entityarrow303_1 = entityarrow303.newArrow(world, entityplayer);
            setPrecision(entityarrow303_1, mod_Arrows303.inst.burstSize);
            world.entityJoinedWorld(entityarrow303_1);
            if(entityarrow303 != mod_Arrows303.inst.selectedArrow)
            {
                break;
            }
            i--;
        }
		while(true);
		
        mod_Arrows303.inst.burstSize = 1;
        return itemstack;
    }

    public void setPrecision(EntityArrow303 entityarrow303, int i)
    {
        if(i == 1)
        {
            return;
        } else
        {
            float f = (float)i * precisionBase;
            float f1 = entityarrow303.speed * (float)Math.pow(0.97000002861022949D, i);
            entityarrow303.setArrowHeading(entityarrow303.motionX, entityarrow303.motionY, entityarrow303.motionZ, f1, f);
            return;
        }
    }

    public static float precisionBase = 1.5F;

}
