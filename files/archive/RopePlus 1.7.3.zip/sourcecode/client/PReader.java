// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import java.io.*;
import java.net.URL;
import java.security.CodeSource;
import java.security.ProtectionDomain;
import java.util.ArrayList;
import java.util.logging.*;
import org.lwjgl.opengl.Display;

public class PReader
{

    public PReader()
    {
        version = displayTitleStringArray[displayTitleStringArray.length - 1];
    }

    private static void log()
    {
        try
        {
            if(filehandler == null)
            {
                filehandler = new FileHandler(logfile.getPath());
                filehandler.setFormatter(new SimpleFormatter());
                logger.addHandler(filehandler);
                logger.setLevel(Level.ALL);
            }
        }
        catch(Exception exception)
        {
            System.out.println(exception);
        }
        logger.fine("PropertyReader Initialized");
    }

    public static String MF()
    {
        String s = "PlaceHold";
        try
        {
            File file = new File((net.minecraft.src.PReader.class).getProtectionDomain().getCodeSource().getLocation().toURI());
            String s2 = file.getParent();
            file = new File(s2);
            s = file.getParent();
        }
        catch(Exception exception)
        {
            logger.severe("Could not get path to MineCraft folder");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        String s1 = s;
        return s1;
    }

    public static boolean MakeFile(String s)
    {
        String s1 = (new StringBuilder()).append(MF()).append(s).toString();
        File file = new File(s1);
        String as[] = s.split("/");
        check = MF();
        try
        {
            for(int i = 0; i < as.length; i++)
            {
                check = (new StringBuilder()).append(check).append("/").append(as[i]).toString();
                File file1 = new File(check);
                Boolean boolean2;
                if(file1.exists())
                {
                    if(i + 1 == as.length)
                    {
                        if(file1.isDirectory())
                        {
                            file1.createNewFile();
                            System.out.println((new StringBuilder()).append("Could not find file.  Creating the file: ").append(s).append(".").toString());
                        }
                    } else
                    if(!file1.isDirectory())
                    {
                        file1.renameTo(new File((new StringBuilder()).append(check).append(".backup").toString()));
                        Boolean boolean1 = Boolean.valueOf(file1.mkdir());
                    }
                } else
                if(i + 1 == as.length)
                {
                    file1.createNewFile();
                } else
                {
                    boolean2 = Boolean.valueOf(file1.mkdir());
                }
            }

        }
        catch(Exception exception)
        {
            logger.severe("Could not find or create file");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
            return false;
        }
        return true;
    }

    public static boolean MakeFile(String s, String s1, String s2)
    {
        Boolean boolean1 = Boolean.valueOf(MakeFile(s));
        return boolean1.booleanValue();
    }

    public static String[] GetProp(String s, String s1, String s2)
    {
label0:
        {
            String as[] = new String[2];
            try
            {
                File file = new File((new StringBuilder()).append(MF()).append(s).toString());
                BufferedReader bufferedreader = new BufferedReader(new FileReader(file));
                String s3 = (new StringBuilder()).append(s1).append(" = ").toString();
                String s4 = (new StringBuilder()).append(s1).append("= ").toString();
                String s5 = (new StringBuilder()).append(s1).append("=").toString();
                String s6 = (new StringBuilder()).append(s1).append(" =").toString();
                String s7 = "";
                do
                {
                    if((s7 = bufferedreader.readLine()) == null)
                    {
                        break label0;
                    }
                    if(s7.startsWith(s3))
                    {
                        as[0] = s7;
                        as[1] = s3;
                        return as;
                    }
                    if(s7.startsWith(s4))
                    {
                        as[0] = s7;
                        as[1] = s4;
                        return as;
                    }
                    if(s7.startsWith(s5))
                    {
                        as[0] = s7;
                        as[1] = s5;
                        return as;
                    }
                } while(!s7.startsWith(s6));
                as[0] = s7;
                as[1] = s6;
                return as;
            }
            catch(Exception exception) { }
        }
        return null;
    }

    public static Boolean PropWriter(String s, String s1, String s2)
    {
        Boolean boolean1 = Boolean.valueOf(false);
        try
        {
            System.out.println((new StringBuilder()).append("Could not find property '").append(s1).append(".'  Creating it with the default of '").append(s2).append(".'").toString());
            FileWriter filewriter = new FileWriter((new StringBuilder()).append(MF()).append(s).toString(), true);
            BufferedWriter bufferedwriter = new BufferedWriter(filewriter);
            bufferedwriter.newLine();
            bufferedwriter.write((new StringBuilder()).append(s1).append(" = ").append(s2).toString());
            bufferedwriter.close();
            filewriter.close();
            boolean1 = Boolean.valueOf(true);
        }
        catch(Exception exception)
        {
            logger.warning((new StringBuilder()).append("Could not create property -").append(s1).append(" -in- ").append(MF()).append(s).toString());
            logger.warning((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return boolean1;
    }

    public static Boolean PropWriter(String s, String s1, String s2, String s3)
    {
        Boolean boolean1 = Boolean.valueOf(false);
        try
        {
            System.out.println((new StringBuilder()).append("Could not find property '").append(s1).append(".'  Creating it with the default of '").append(s2).append("'.").toString());
            FileWriter filewriter = new FileWriter((new StringBuilder()).append(MF()).append(s).toString(), true);
            BufferedWriter bufferedwriter = new BufferedWriter(filewriter);
            bufferedwriter.newLine();
            bufferedwriter.write((new StringBuilder()).append(s1).append(" = ").append(s2).toString());
            bufferedwriter.newLine();
            bufferedwriter.write(s3);
            bufferedwriter.close();
            filewriter.close();
            boolean1 = Boolean.valueOf(true);
        }
        catch(Exception exception)
        {
            System.out.println(exception);
        }
        return boolean1;
    }

    public static String PropReader(String s, String s1, String s2)
    {
        boolean flag = MakeFile(s);
        if(!flag)
        {
            logger.warning("Failed to create/load file");
            return s2;
        }
        if(GetProp(s, s1, s2) == null)
        {
            PropWriter(s, s1, s2);
        }
        String as[] = GetProp(s, s1, s2);
        if(as[0].compareTo(as[1]) == 0)
        {
            prop = s2;
        } else
        {
            prop = as[0].split(as[1])[1];
        }
        return prop;
    }

    public static String PropReader(String s, String s1, String s2, String s3)
    {
        boolean flag = MakeFile(s);
        if(!flag)
        {
            logger.warning("Failed to create/load file");
            return s2;
        }
        if(GetProp(s, s1, s2) == null)
        {
            PropWriter(s, s1, s2, s3);
        }
        String as[] = GetProp(s, s1, s2);
        if(as[0].compareTo(as[1]) == 0)
        {
            prop = s2;
        } else
        {
            prop = as[0].split(as[1])[1];
        }
        return prop;
    }

    public static String[] PropReader(String s, String as[], String as1[])
    {
        String as2[] = new String[as.length];
        boolean flag = MakeFile(s);
        if(!flag)
        {
            logger.warning("Failed to create/load file");
            return as1;
        }
        try
        {
            for(int i = 0; i < as.length; i++)
            {
                String s1 = as[i];
                String s2 = as1[i];
                if(GetProp(s, s1, s2) == null)
                {
                    PropWriter(s, s1, s2);
                }
                String as3[] = GetProp(s, s1, s2);
                if(as3[0].compareTo(as3[1]) == 0)
                {
                    as2[i] = as1[i];
                } else
                {
                    as2[i] = as3[0].split(as3[1])[1];
                }
            }

        }
        catch(Exception exception)
        {
            logger.severe("Could not get all properties");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return as2;
    }

    public static String[] PropReader(String s, String as[], String as1[], String as2[])
    {
        String as3[] = new String[as.length];
        boolean flag = MakeFile(s);
        if(!flag)
        {
            logger.warning("Failed to create/load file");
            return as1;
        }
        try
        {
            for(int i = 0; i < as.length; i++)
            {
                String s1 = as[i];
                String s2 = as1[i];
                if(GetProp(s, s1, s2) == null)
                {
                    if(i < as2.length)
                    {
                        String s3 = as2[i];
                        PropWriter(s, s1, s2, s3);
                    } else
                    {
                        PropWriter(s, s1, s2);
                    }
                }
                String as4[] = GetProp(s, s1, s2);
                if(as4[0].compareTo(as4[1]) == 0)
                {
                    as3[i] = as1[i];
                } else
                {
                    as3[i] = as4[0].split(as4[1])[1];
                }
            }

        }
        catch(Exception exception)
        {
            logger.severe("Could not get all properties");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return as3;
    }

    public static String PropArgs(String as[], String s, String s1, String s2)
    {
        prop = PropReader(s, s1, s2);
        String s3 = prop;
        for(int i = 0; i < as.length; i++)
        {
            if(as[i].equalsIgnoreCase(prop))
            {
                return prop;
            }
            s3 = s2;
        }

        return s3;
    }

    public static String PropArgs(String as[], String s, String s1, String s2, String s3)
    {
        prop = PropReader(s, s1, s2, s3);
        String s4 = prop;
        for(int i = 0; i < as.length; i++)
        {
            if(as[i].equalsIgnoreCase(prop))
            {
                return prop;
            }
            s4 = s2;
        }

        return s4;
    }

    public static String[] PropArgs(String as[], String s, String as1[], String as2[])
    {
        String as3[] = PropReader(s, as1, as2);
        String as4[] = as3;
label0:
        for(int i = 0; i < as3.length; i++)
        {
            int j = 0;
            do
            {
                if(j >= as.length)
                {
                    continue label0;
                }
                String s1 = as3[i];
                if(as[j].equalsIgnoreCase(s1))
                {
                    as4[i] = as3[i];
                    continue label0;
                }
                as4[i] = as3[i];
                j++;
            } while(true);
        }

        return as4;
    }

    public static String[] PropArgs(String as[], String s, String as1[], String as2[], String as3[])
    {
        String as4[] = PropReader(s, as1, as2, as3);
        String as5[] = as4;
label0:
        for(int i = 0; i < as4.length; i++)
        {
            int j = 0;
            do
            {
                if(j >= as.length)
                {
                    continue label0;
                }
                String s1 = as4[i];
                if(as[j].equalsIgnoreCase(s1))
                {
                    as5[i] = as4[i];
                    continue label0;
                }
                as5[i] = as4[i];
                j++;
            } while(true);
        }

        return as5;
    }

    public static float PropFloat(String as[], String s, String s1, String s2)
    {
        float f = 0.0F;
        try
        {
            prop = PropArgs(as, s, s1, s2);
            f = Float.valueOf(prop.trim()).floatValue();
        }
        catch(Exception exception)
        {
            logger.severe("Could not convert string to float");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return f;
    }

    public static float PropFloat(String as[], String s, String s1, String s2, String s3)
    {
        float f = 0.0F;
        try
        {
            prop = PropArgs(as, s, s1, s2, s3);
            f = Float.valueOf(prop.trim()).floatValue();
        }
        catch(Exception exception)
        {
            logger.severe("Could not convert string to float");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return f;
    }

    public static float PropFloat(String s, String s1, String s2)
    {
        float f = 0.0F;
        try
        {
            prop = PropReader(s, s1, s2);
            f = Float.valueOf(prop.trim()).floatValue();
        }
        catch(Exception exception)
        {
            logger.severe("Could not convert string to float");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return f;
    }

    public static float PropFloat(String s, String s1, String s2, String s3)
    {
        float f = 0.0F;
        try
        {
            prop = PropReader(s, s1, s2, s3);
            f = Float.valueOf(prop.trim()).floatValue();
        }
        catch(Exception exception)
        {
            logger.severe("Could not convert string to float");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return f;
    }

    public static float[] PropFloat(String s, String as[], String as1[])
    {
        String as2[] = PropReader(s, as, as1);
        float af[] = new float[as.length];
        for(int i = 0; i < af.length;)
        {
            try
            {
                prop = as2[i];
                af[i] = Float.valueOf(prop.trim()).floatValue();
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not convert string to float");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        return af;
    }

    public static float[] PropFloat(String s, String as[], String as1[], String as2[])
    {
        String as3[] = PropReader(s, as, as1, as2);
        float af[] = new float[as.length];
        for(int i = 0; i < af.length;)
        {
            try
            {
                prop = as3[i];
                af[i] = Float.valueOf(prop.trim()).floatValue();
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not convert string to float");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        return af;
    }

    public static float[] PropFloat(String as[], String s, String as1[], String as2[])
    {
        String as3[] = PropArgs(as, s, as1, as2);
        float af[] = new float[as1.length];
        for(int i = 0; i < af.length;)
        {
            try
            {
                prop = as3[i];
                af[i] = Float.valueOf(prop.trim()).floatValue();
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not convert string to float");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        return af;
    }

    public static float[] PropFloat(String as[], String s, String as1[], String as2[], String as3[])
    {
        String as4[] = PropArgs(as, s, as1, as2, as3);
        float af[] = new float[as1.length];
        for(int i = 0; i < af.length;)
        {
            try
            {
                prop = as4[i];
                af[i] = Float.valueOf(prop.trim()).floatValue();
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not convert string to float");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        return af;
    }

    public static double PropDouble(String as[], String s, String s1, String s2)
    {
        Double double1 = Double.valueOf(0.0D);
        try
        {
            prop = PropArgs(as, s, s1, s2);
            double1 = Double.valueOf(Double.valueOf(prop.trim()).doubleValue());
        }
        catch(Exception exception)
        {
            logger.severe("Could not convert string to double");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return double1.doubleValue();
    }

    public static double PropDouble(String as[], String s, String s1, String s2, String s3)
    {
        Double double1 = Double.valueOf(0.0D);
        try
        {
            prop = PropArgs(as, s, s1, s2, s3);
            double1 = Double.valueOf(Double.valueOf(prop.trim()).doubleValue());
        }
        catch(Exception exception)
        {
            logger.severe("Could not convert string to double");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return double1.doubleValue();
    }

    public static double PropDouble(String s, String s1, String s2)
    {
        Double double1 = Double.valueOf(0.0D);
        try
        {
            prop = PropReader(s, s1, s2);
            double1 = Double.valueOf(Double.valueOf(prop.trim()).doubleValue());
        }
        catch(Exception exception)
        {
            logger.severe("Could not convert string to double");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return double1.doubleValue();
    }

    public static double PropDouble(String s, String s1, String s2, String s3)
    {
        Double double1 = Double.valueOf(0.0D);
        try
        {
            prop = PropReader(s, s1, s2, s3);
            double1 = Double.valueOf(Double.valueOf(prop.trim()).doubleValue());
        }
        catch(Exception exception)
        {
            logger.severe("Could not convert string to double");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return double1.doubleValue();
    }

    public static double[] PropDouble(String s, String as[], String as1[])
    {
        String as2[] = PropReader(s, as, as1);
        double ad[] = new double[as.length];
        for(int i = 0; i < as2.length;)
        {
            try
            {
                prop = as2[i];
                ad[i] = Double.valueOf(prop.trim()).doubleValue();
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not convert string to double");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        return ad;
    }

    public static double[] PropDouble(String s, String as[], String as1[], String as2[])
    {
        String as3[] = PropReader(s, as, as1, as2);
        double ad[] = new double[as.length];
        for(int i = 0; i < as3.length;)
        {
            try
            {
                prop = as3[i];
                ad[i] = Double.valueOf(prop.trim()).doubleValue();
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not convert string to double");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        return ad;
    }

    public static double[] PropDouble(String as[], String s, String as1[], String as2[])
    {
        String as3[] = PropArgs(as, s, as1, as2);
        double ad[] = new double[as1.length];
        for(int i = 0; i < as3.length;)
        {
            try
            {
                prop = as3[i];
                ad[i] = Double.valueOf(prop.trim()).doubleValue();
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not convert string to double");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        return ad;
    }

    public static double[] PropDouble(String as[], String s, String as1[], String as2[], String as3[])
    {
        String as4[] = PropArgs(as, s, as1, as2, as3);
        double ad[] = new double[as1.length];
        for(int i = 0; i < as4.length;)
        {
            try
            {
                prop = as4[i];
                ad[i] = Double.valueOf(prop.trim()).doubleValue();
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not convert string to double");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        return ad;
    }

    public static boolean PropBoolean(String as[], String s, String s1, String s2)
    {
        boolean flag = false;
        try
        {
            prop = PropArgs(as, s, s1, s2);
            flag = Boolean.valueOf(prop).booleanValue();
        }
        catch(Exception exception)
        {
            logger.severe("Could not convert string to boolean");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return flag;
    }

    public static boolean PropBoolean(String as[], String s, String s1, String s2, String s3)
    {
        boolean flag = false;
        try
        {
            prop = PropArgs(as, s, s1, s2, s3);
            flag = Boolean.valueOf(prop).booleanValue();
        }
        catch(Exception exception)
        {
            logger.severe("Could not convert string to boolean");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return flag;
    }

    public static boolean PropBoolean(String s, String s1, String s2)
    {
        boolean flag = false;
        try
        {
            prop = PropReader(s, s1, s2);
            flag = Boolean.valueOf(prop).booleanValue();
        }
        catch(Exception exception)
        {
            logger.severe("Could not convert string to boolean");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return flag;
    }

    public static boolean PropBoolean(String s, String s1, String s2, String s3)
    {
        boolean flag = false;
        try
        {
            prop = PropReader(s, s1, s2, s3);
            flag = Boolean.valueOf(prop).booleanValue();
        }
        catch(Exception exception)
        {
            logger.severe("Could not convert string to boolean");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return flag;
    }

    public static boolean[] PropBoolean(String s, String as[], String as1[])
    {
        String as2[] = PropReader(s, as, as1);
        boolean aflag[] = new boolean[as.length];
        for(int i = 0; i < as2.length;)
        {
            try
            {
                prop = as2[i];
                aflag[i] = Boolean.valueOf(prop).booleanValue();
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not convert string to boolean");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        return aflag;
    }

    public static boolean[] PropBoolean(String s, String as[], String as1[], String as2[])
    {
        String as3[] = PropReader(s, as, as1, as2);
        boolean aflag[] = new boolean[as.length];
        for(int i = 0; i < as3.length;)
        {
            try
            {
                prop = as3[i];
                aflag[i] = Boolean.valueOf(prop).booleanValue();
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not convert string to boolean");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        return aflag;
    }

    public static boolean[] PropBoolean(String as[], String s, String as1[], String as2[])
    {
        String as3[] = PropArgs(as, s, as1, as2);
        boolean aflag[] = new boolean[as1.length];
        for(int i = 0; i < as3.length;)
        {
            try
            {
                prop = as3[i];
                aflag[i] = Boolean.valueOf(prop).booleanValue();
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not convert string to boolean");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        return aflag;
    }

    public static boolean[] PropBoolean(String as[], String s, String as1[], String as2[], String as3[])
    {
        String as4[] = PropArgs(as, s, as1, as2, as3);
        boolean aflag[] = new boolean[as1.length];
        for(int i = 0; i < as4.length;)
        {
            try
            {
                prop = as4[i];
                aflag[i] = Boolean.valueOf(prop).booleanValue();
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not convert string to boolean");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        return aflag;
    }

    public static String[] PropSplit(String as[], String s, String s1, String s2, String s3)
    {
        String s4 = PropArgs(as, s, s1, s2);
        try
        {
            String s5 = s4;
            propsplit2 = s5.split(s3);
        }
        catch(Exception exception)
        {
            logger.severe("Could not split string");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return propsplit2;
    }

    public static String[] PropSplit(String as[], String s, String s1, String s2, String s3, String s4)
    {
        String s5 = PropArgs(as, s, s1, s2, s4);
        try
        {
            String s6 = s5;
            propsplit2 = s6.split(s3);
        }
        catch(Exception exception)
        {
            logger.severe("Could not split string");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return propsplit2;
    }

    public static String[] PropSplit(String s, String s1, String s2, String s3)
    {
        String s4 = PropReader(s, s1, s2);
        try
        {
            String s5 = s4;
            propsplit2 = s5.split(s3);
        }
        catch(Exception exception)
        {
            logger.severe("Could not split string");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return propsplit2;
    }

    public static String[] PropSplit(String s, String s1, String s2, String s3, String s4)
    {
        String s5 = PropReader(s, s1, s2, s4);
        try
        {
            String s6 = s5;
            propsplit2 = s6.split(s3);
        }
        catch(Exception exception)
        {
            logger.severe("Could not split string");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return propsplit2;
    }

    public static String[][] PropSplit(String s, String as[], String as1[], String as2[])
    {
        String as3[] = PropReader(s, as, as1);
        String as4[][] = new String[as.length][0xf4240];
        int ai[] = new int[as.length];
        for(int i = 0; i < as.length;)
        {
            try
            {
                String s1 = as2[i];
                String s2 = as3[i];
                String as6[] = s2.split(s1);
                ai[i] = as6.length;
                System.arraycopy(as6, 0, as4[i], 0, as6.length);
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not split string");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        int j = 0;
        for(int k = 0; k < ai.length; k++)
        {
            if(ai[k] > j)
            {
                j = ai[k];
            }
        }

        String as5[][] = new String[as.length][j];
        for(int l = 0; l < as4.length; l++)
        {
            for(int i1 = 0; i1 < as4[l].length && as4[l][i1] != null; i1++)
            {
                as5[l][i1] = as4[l][i1];
            }

        }

        return as5;
    }

    public static String[][] PropSplit(String s, String as[], String as1[], String as2[], String as3[])
    {
        String as4[] = PropReader(s, as, as1, as3);
        String as5[][] = new String[as.length][0xf4240];
        int ai[] = new int[as.length];
        for(int i = 0; i < as.length;)
        {
            try
            {
                String s1 = as2[i];
                String s2 = as4[i];
                String as7[] = s2.split(s1);
                ai[i] = as7.length;
                System.arraycopy(as7, 0, as5[i], 0, as7.length);
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not split string");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        int j = 0;
        for(int k = 0; k < ai.length; k++)
        {
            if(ai[k] > j)
            {
                j = ai[k];
            }
        }

        String as6[][] = new String[as.length][j];
        for(int l = 0; l < as5.length; l++)
        {
            for(int i1 = 0; i1 < as5[l].length && as5[l][i1] != null; i1++)
            {
                as6[l][i1] = as5[l][i1];
            }

        }

        return as6;
    }

    public static String[][] PropSplit(String as[], String s, String as1[], String as2[], String as3[])
    {
        String as4[] = PropArgs(as, s, as1, as2);
        String as5[][] = new String[as1.length][0xf4240];
        int ai[] = new int[as1.length];
        for(int i = 0; i < as1.length;)
        {
            try
            {
                String s1 = as3[i];
                String s2 = as4[i];
                String as7[] = s2.split(s1);
                ai[i] = as7.length;
                System.arraycopy(as7, 0, as5[i], 0, as7.length);
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not split string");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        int j = 0;
        for(int k = 0; k < ai.length; k++)
        {
            if(ai[k] > j)
            {
                j = ai[k];
            }
        }

        String as6[][] = new String[as1.length][j];
        for(int l = 0; l < as5.length; l++)
        {
            for(int i1 = 0; i1 < as5[l].length && as5[l][i1] != null; i1++)
            {
                as6[l][i1] = as5[l][i1];
            }

        }

        return as6;
    }

    public static String[][] PropSplit(String as[], String s, String as1[], String as2[], String as3[], String as4[])
    {
        String as5[] = PropArgs(as, s, as1, as2, as4);
        String as6[][] = new String[as1.length][0xf4240];
        int ai[] = new int[as1.length];
        for(int i = 0; i < as1.length;)
        {
            try
            {
                String s1 = as3[i];
                String s2 = as5[i];
                String as8[] = s2.split(s1);
                ai[i] = as8.length;
                System.arraycopy(as8, 0, as6[i], 0, as8.length);
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not split string");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        int j = 0;
        for(int k = 0; k < ai.length; k++)
        {
            if(ai[k] > j)
            {
                j = ai[k];
            }
        }

        String as7[][] = new String[as1.length][j];
        for(int l = 0; l < as6.length; l++)
        {
            for(int i1 = 0; i1 < as6[l].length && as6[l][i1] != null; i1++)
            {
                as7[l][i1] = as6[l][i1];
            }

        }

        return as7;
    }

    public static int PropInt(String as[], String s, String s1, String s2)
    {
        int i = 0;
        try
        {
            prop = PropArgs(as, s, s1, s2);
            i = Integer.valueOf(prop.trim()).intValue();
        }
        catch(Exception exception)
        {
            logger.severe("Could not convert string to int");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return i;
    }

    public static int PropInt(String as[], String s, String s1, String s2, String s3)
    {
        int i = 0;
        try
        {
            prop = PropArgs(as, s, s1, s2, s3);
            i = Integer.valueOf(prop.trim()).intValue();
        }
        catch(Exception exception)
        {
            logger.severe("Could not convert string to int");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return i;
    }

    public static int PropInt(String s, String s1, String s2)
    {
        int i = 0;
        try
        {
            prop = PropReader(s, s1, s2);
            i = Integer.valueOf(prop.trim()).intValue();
        }
        catch(Exception exception)
        {
            logger.severe("Could not convert string to int");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return i;
    }

    public static int PropInt(String s, String s1, String s2, String s3)
    {
        int i = 0;
        try
        {
            prop = PropReader(s, s1, s2, s3);
            i = Integer.valueOf(prop.trim()).intValue();
        }
        catch(Exception exception)
        {
            logger.severe("Could not convert string to int");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return i;
    }

    public static int[] PropInt(String s, String as[], String as1[])
    {
        String as2[] = PropReader(s, as, as1);
        int ai[] = new int[as.length];
        for(int i = 0; i < as2.length;)
        {
            try
            {
                prop = as2[i];
                ai[i] = Integer.valueOf(prop.trim()).intValue();
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not convert string to int");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        return ai;
    }

    public static int[] PropInt(String s, String as[], String as1[], String as2[])
    {
        String as3[] = PropReader(s, as, as1, as2);
        int ai[] = new int[as.length];
        for(int i = 0; i < as3.length;)
        {
            try
            {
                prop = as3[i];
                ai[i] = Integer.valueOf(prop.trim()).intValue();
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not convert string to int");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        return ai;
    }

    public static int[] PropInt(String as[], String s, String as1[], String as2[])
    {
        String as3[] = PropArgs(as, s, as1, as2);
        int ai[] = new int[as1.length];
        for(int i = 0; i < as3.length;)
        {
            try
            {
                prop = as3[i];
                ai[i] = Integer.valueOf(prop.trim()).intValue();
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not convert string to int");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        return ai;
    }

    public static int[] PropInt(String as[], String s, String as1[], String as2[], String as3[])
    {
        String as4[] = PropArgs(as, s, as1, as2, as3);
        int ai[] = new int[as1.length];
        for(int i = 0; i < as4.length;)
        {
            try
            {
                prop = as4[i];
                ai[i] = Integer.valueOf(prop.trim()).intValue();
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not convert string to int");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        return ai;
    }

    public static byte PropByte(String s, String s1, String s2)
    {
        byte byte0 = 0;
        try
        {
            prop = PropReader(s, s1, s2);
            byte0 = Byte.valueOf(prop.trim()).byteValue();
        }
        catch(Exception exception)
        {
            logger.severe("Could not convert string to byte");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return byte0;
    }

    public static byte PropByte(String s, String s1, String s2, String s3)
    {
        byte byte0 = 0;
        try
        {
            prop = PropReader(s, s1, s2, s3);
            byte0 = Byte.valueOf(prop.trim()).byteValue();
        }
        catch(Exception exception)
        {
            logger.severe("Could not convert string to byte");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return byte0;
    }

    public static byte PropByte(String as[], String s, String s1, String s2)
    {
        byte byte0 = 0;
        try
        {
            prop = PropArgs(as, s, s1, s2);
            byte0 = Byte.valueOf(prop.trim()).byteValue();
        }
        catch(Exception exception)
        {
            logger.severe("Could not convert string to byte");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return byte0;
    }

    public static byte PropByte(String as[], String s, String s1, String s2, String s3)
    {
        byte byte0 = 0;
        try
        {
            prop = PropArgs(as, s, s1, s2, s3);
            byte0 = Byte.valueOf(prop.trim()).byteValue();
        }
        catch(Exception exception)
        {
            logger.severe("Could not convert string to byte");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return byte0;
    }

    public static byte[] PropByte(String s, String as[], String as1[])
    {
        String as2[] = PropReader(s, as, as1);
        byte abyte0[] = new byte[as.length];
        for(int i = 0; i < as2.length;)
        {
            try
            {
                prop = as2[i];
                abyte0[i] = Byte.valueOf(prop.trim()).byteValue();
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not convert string to byte");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        return abyte0;
    }

    public static byte[] PropByte(String s, String as[], String as1[], String as2[])
    {
        String as3[] = PropReader(s, as, as1, as2);
        byte abyte0[] = new byte[as.length];
        for(int i = 0; i < as3.length;)
        {
            try
            {
                prop = as3[i];
                abyte0[i] = Byte.valueOf(prop.trim()).byteValue();
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not convert string to byte");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        return abyte0;
    }

    public static byte[] PropByte(String as[], String s, String as1[], String as2[])
    {
        String as3[] = PropArgs(as, s, as1, as2);
        byte abyte0[] = new byte[as1.length];
        for(int i = 0; i < as3.length;)
        {
            try
            {
                prop = as3[i];
                abyte0[i] = Byte.valueOf(prop.trim()).byteValue();
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not convert string to byte");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        return abyte0;
    }

    public static byte[] PropByte(String as[], String s, String as1[], String as2[], String as3[])
    {
        String as4[] = PropArgs(as, s, as1, as2);
        byte abyte0[] = new byte[as1.length];
        for(int i = 0; i < as4.length;)
        {
            try
            {
                prop = as4[i];
                abyte0[i] = Byte.valueOf(prop.trim()).byteValue();
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not convert string to byte");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        return abyte0;
    }

    public static short PropShort(String s, String s1, String s2)
    {
        short word0 = 0;
        try
        {
            prop = PropReader(s, s1, s2);
            word0 = Short.valueOf(prop.trim()).shortValue();
        }
        catch(Exception exception)
        {
            logger.severe("Could not convert string to short");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return word0;
    }

    public static short PropShort(String s, String s1, String s2, String s3)
    {
        short word0 = 0;
        try
        {
            prop = PropReader(s, s1, s2, s3);
            word0 = Short.valueOf(prop.trim()).shortValue();
        }
        catch(Exception exception)
        {
            logger.severe("Could not convert string to short");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return word0;
    }

    public static short PropShort(String as[], String s, String s1, String s2)
    {
        short word0 = 0;
        try
        {
            prop = PropArgs(as, s, s1, s2);
            word0 = Short.valueOf(prop.trim()).shortValue();
        }
        catch(Exception exception)
        {
            logger.severe("Could not convert string to short");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return word0;
    }

    public static short PropShort(String as[], String s, String s1, String s2, String s3)
    {
        short word0 = 0;
        try
        {
            prop = PropArgs(as, s, s1, s2, s3);
            word0 = Short.valueOf(prop.trim()).shortValue();
        }
        catch(Exception exception)
        {
            logger.severe("Could not convert string to short");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return word0;
    }

    public static short[] PropShort(String s, String as[], String as1[])
    {
        String as2[] = PropReader(s, as, as1);
        short aword0[] = new short[as.length];
        for(int i = 0; i < as2.length;)
        {
            try
            {
                prop = as2[i];
                aword0[i] = Short.valueOf(prop.trim()).shortValue();
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not convert string to short");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        return aword0;
    }

    public static short[] PropShort(String s, String as[], String as1[], String as2[])
    {
        String as3[] = PropReader(s, as, as1, as2);
        short aword0[] = new short[as.length];
        for(int i = 0; i < as3.length;)
        {
            try
            {
                prop = as3[i];
                aword0[i] = Short.valueOf(prop.trim()).shortValue();
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not convert string to short");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        return aword0;
    }

    public static short[] PropShort(String as[], String s, String as1[], String as2[])
    {
        String as3[] = PropArgs(as, s, as1, as2);
        short aword0[] = new short[as1.length];
        for(int i = 0; i < as3.length;)
        {
            try
            {
                prop = as3[i];
                aword0[i] = Short.valueOf(prop.trim()).shortValue();
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not convert string to short");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        return aword0;
    }

    public static short[] PropShort(String as[], String s, String as1[], String as2[], String as3[])
    {
        String as4[] = PropArgs(as, s, as1, as2, as3);
        short aword0[] = new short[as1.length];
        for(int i = 0; i < as4.length;)
        {
            try
            {
                prop = as4[i];
                aword0[i] = Short.valueOf(prop.trim()).shortValue();
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not convert string to short");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        return aword0;
    }

    public static long PropLong(String s, String s1, String s2)
    {
        long l = 0L;
        try
        {
            prop = PropReader(s, s1, s2);
            l = Long.valueOf(prop.trim()).longValue();
        }
        catch(Exception exception)
        {
            logger.severe("Could not convert string to Long");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return l;
    }

    public static long PropLong(String s, String s1, String s2, String s3)
    {
        long l = 0L;
        try
        {
            prop = PropReader(s, s1, s2, s3);
            l = Long.valueOf(prop.trim()).longValue();
        }
        catch(Exception exception)
        {
            logger.severe("Could not convert string to Long");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return l;
    }

    public static long PropLong(String as[], String s, String s1, String s2)
    {
        long l = 0L;
        try
        {
            prop = PropArgs(as, s, s1, s2);
            l = Long.valueOf(prop.trim()).longValue();
        }
        catch(Exception exception)
        {
            logger.severe("Could not convert string to Long");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return l;
    }

    public static long PropLong(String as[], String s, String s1, String s2, String s3)
    {
        long l = 0L;
        try
        {
            prop = PropArgs(as, s, s1, s2, s3);
            l = Long.valueOf(prop.trim()).longValue();
        }
        catch(Exception exception)
        {
            logger.severe("Could not convert string to Long");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return l;
    }

    public static long[] PropLong(String s, String as[], String as1[])
    {
        String as2[] = PropReader(s, as, as1);
        long al[] = new long[as.length];
        for(int i = 0; i < as2.length;)
        {
            try
            {
                prop = as2[i];
                al[i] = Long.valueOf(prop.trim()).longValue();
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not convert string to Long");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        return al;
    }

    public static long[] PropLong(String s, String as[], String as1[], String as2[])
    {
        String as3[] = PropReader(s, as, as1, as2);
        long al[] = new long[as.length];
        for(int i = 0; i < as3.length;)
        {
            try
            {
                prop = as3[i];
                al[i] = Long.valueOf(prop.trim()).longValue();
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not convert string to Long");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        return al;
    }

    public static long[] PropLong(String as[], String s, String as1[], String as2[])
    {
        String as3[] = PropArgs(as, s, as1, as2);
        long al[] = new long[as1.length];
        for(int i = 0; i < as3.length;)
        {
            try
            {
                prop = as3[i];
                al[i] = Long.valueOf(prop.trim()).longValue();
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not convert string to Long");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        return al;
    }

    public static long[] PropLong(String as[], String s, String as1[], String as2[], String as3[])
    {
        String as4[] = PropArgs(as, s, as1, as2, as3);
        long al[] = new long[as1.length];
        for(int i = 0; i < as4.length;)
        {
            try
            {
                prop = as4[i];
                al[i] = Long.valueOf(prop.trim()).longValue();
                continue;
            }
            catch(Exception exception)
            {
                logger.severe("Could not convert string to Long");
                logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
                i++;
            }
        }

        return al;
    }

    public static int GetSessionID(String s)
    {
        for(int i = 0; i < propstring.size(); i++)
        {
            if(s.compareTo((String)propstring.get(i)) == 0)
            {
                return i;
            }
        }

        MakeFile(s);
        propstring.add(SessionID, s);
        int j = SessionID;
        propfile.add(SessionID, new File((new StringBuilder()).append(MF()).append(s).toString()));
        try
        {
            proplogger.add(SessionID, Logger.getLogger(s));
            prophandler.add(SessionID, new FileHandler((new StringBuilder()).append(MF()).append(s).toString()));
            ((FileHandler)prophandler.get(SessionID)).setFormatter(new SimpleFormatter());
            ((Logger)proplogger.get(SessionID)).addHandler((Handler)prophandler.get(SessionID));
            ((Logger)proplogger.get(SessionID)).setLevel(Level.ALL);
            logger.finer((new StringBuilder()).append(s).append(" initialized").toString());
            SessionID++;
        }
        catch(Exception exception)
        {
            logger.severe("Could not create log");
            logger.severe((new StringBuilder()).append("Error = ").append(exception).toString());
        }
        return j;
    }

    public static void logger(int i, String s, String s1)
    {
        s = s.toLowerCase();
        if(s.equals("severe"))
        {
            ((Logger)proplogger.get(i)).severe(s1);
        } else
        if(s.equals("warning"))
        {
            ((Logger)proplogger.get(i)).warning(s1);
        } else
        if(s.equals("info"))
        {
            ((Logger)proplogger.get(i)).info(s1);
        } else
        if(s.equals("fine"))
        {
            ((Logger)proplogger.get(i)).fine(s1);
        } else
        if(s.equals("finer"))
        {
            ((Logger)proplogger.get(i)).finer(s1);
        } else
        {
            ((Logger)proplogger.get(i)).info(s1);
        }
    }

    public static void logger(int i, String s)
    {
        Logger logger1 = (Logger)proplogger.get(i);
        logger1.info(s);
    }

    private static String check;
    private static String prop;
    private static String propsplit2[];
    private static final Logger logger = Logger.getLogger("PReader");
    private static FileHandler filehandler = null;
    private static File logfile = new File(MF(), "PReader.txt");
    private static ArrayList proplogger = new ArrayList();
    private static ArrayList propfile = new ArrayList();
    private static ArrayList prophandler = new ArrayList();
    private static int SessionID = 0;
    private static ArrayList propstring = new ArrayList();
    public static String displayTitleStringArray[] = Display.getTitle().split(" ");
    public final String version;

    static 
    {
        log();
        System.out.println("PropertyReader v1.40 Loaded");
    }
}
