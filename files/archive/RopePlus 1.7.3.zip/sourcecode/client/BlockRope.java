package net.minecraft.src;


public class BlockRope extends Block
{

    protected BlockRope(int i, int j)
    {
        super(i, Material.plants);
        blockIndexInTexture = mod_Rope.rtex;
        setTickOnLoad(true);
        float f = 0.1F;
        setBlockBounds(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, 1.0F, 0.5F + f);
    }

    public int getBlockTexture(IBlockAccess iblockaccess, int i, int j, int k, int l)
    {
        return mod_Rope.rtex;
    }

    public int getBlockTextureFromSide(int i)
    {
        return mod_Rope.rtex;
    }

    public void onBlockAdded(World world, int i, int j, int k)
    {
        byte xoffset = 0;
        byte zoffset = 0;
        byte byte2 = 0;
        if(world.getBlockId(i - 1, j, k + 0) == mod_Rope.rope.blockID)
        {
            xoffset = -1;
            zoffset = 0;
        }
        else if(world.getBlockId(i + 1, j, k + 0) == mod_Rope.rope.blockID)
        {
            xoffset = 1;
            zoffset = 0;
        }
        else if(world.getBlockId(i, j, k - 1) == mod_Rope.rope.blockID)
        {
            xoffset = 0;
            zoffset = -1;
        }
        else if(world.getBlockId(i, j, k + 1) == mod_Rope.rope.blockID)
        {
            xoffset = 0;
            zoffset = 1;
        }
        if(xoffset != 0 || zoffset != 0)
        {
            for(int length = 1; length <= 32; length++)
            {
                if((byte2 == 0) & world.isBlockOpaqueCube(i + xoffset, j - length, k + zoffset))
                {
                    byte2 = 2;
                }
                if((byte2 == 0) & (world.getBlockId(i + xoffset, j - length, k + zoffset) == 0))
                {
                    byte2 = 1;
                    world.setBlockWithNotify(i, j, k, 0);
                    world.setBlockWithNotify(i + xoffset, j - length, k + zoffset, mod_Rope.rope.blockID);
                }
            }

        }
        if((byte2 == 0 || byte2 == 2) & (world.getBlockId(i, j + 1, k) != mod_Rope.rope.blockID) && !world.isBlockOpaqueCube(i, j + 1, k))
        {
            dropBlockAsItem(world, i, j, k, world.getBlockMetadata(i, j, k));
            world.setBlockWithNotify(i, j, k, 0);
        }
    }

    public void onNeighborBlockChange(World world, int i, int j, int k, int l)
    {
        super.onNeighborBlockChange(world, i, j, k, l);
        boolean blockstays = false;
        if(world.getBlockId(i - 1, j, k + 0) == mod_Rope.rope.blockID)
        {
            blockstays = true;
        }
        if(world.getBlockId(i + 1, j, k + 0) == mod_Rope.rope.blockID)
        {
            blockstays = true;
        }
        if(world.getBlockId(i, j, k - 1) == mod_Rope.rope.blockID)
        {
            blockstays = true;
        }
        if(world.getBlockId(i, j, k + 1) == mod_Rope.rope.blockID)
        {
            blockstays = true;
        }
        if(world.isBlockOpaqueCube(i, j + 1, k))
        {
            blockstays = true;
        }
        if(world.getBlockId(i, j + 1, k) == mod_Rope.rope.blockID)
        {
            blockstays = true;
        }
        if((world.getBlockId(i, j + 1, k) == 0) & (world.getBlockId(i, j + 2, k) != 0))
        {
            blockstays = true;
            world.setBlockWithNotify(i, j + 1, k, mod_Rope.rope.blockID);
            world.setBlockWithNotify(i, j, k, 0);
        }
        if(!blockstays)
        {
            dropBlockAsItem(world, i, j, k, world.getBlockMetadata(i, j, k));
            world.setBlockWithNotify(i, j, k, 0);
        }
    }

    public boolean canPlaceBlockAt(World world, int i, int j, int k)
    {
        if(world.getBlockId(i - 1, j, k + 0) == mod_Rope.rope.blockID)
        {
            return true;
        }
        if(world.getBlockId(i + 1, j, k + 0) == mod_Rope.rope.blockID)
        {
            return true;
        }
        if(world.getBlockId(i, j, k - 1) == mod_Rope.rope.blockID)
        {
            return true;
        }
        if(world.getBlockId(i, j, k + 1) == mod_Rope.rope.blockID)
        {
            return true;
        }
        if(world.isBlockOpaqueCube(i, j + 1, k))
        {
            return true;
        }
        return world.getBlockId(i, j + 1, k) == mod_Rope.rope.blockID;
    }
	
    public void onBlockDestroyedByPlayer(World world, int a, int b, int c, int l)
    {
		int[] coords = mod_Rope.areCoordsArrowRope(a,b,c);
		if (coords == null) return;
		
		mod_Rope.removeCoordsFromRopeArray(coords);
		
        for(int x = -1; world.getBlockId(a, b+x, c) == mod_Rope.rope.blockID; x--)
		{
			coords = mod_Rope.areCoordsArrowRope(a, b+x, c);
			world.setBlockWithNotify(a, b+x, c, 0);
			if (coords != null)
			{
				mod_Rope.removeCoordsFromRopeArray(coords);
			}
		}
		
        for(int hx = 1; world.getBlockId(a, b+hx, c) == mod_Rope.rope.blockID; hx++)
		{
			coords = mod_Rope.areCoordsArrowRope(a, b+hx, c);
			world.setBlockWithNotify(a, b+hx, c, 0);
			if (coords != null)
			{
				mod_Rope.removeCoordsFromRopeArray(coords);
			}
		}
		
		if(!world.multiplayerWorld)
        {
			EntityItem entityitem = new EntityItem(world, a, b, c, new ItemStack(Item.stick));
			entityitem.delayBeforeCanPickup = 5;
			world.entityJoinedWorld(entityitem);
			
			entityitem = new EntityItem(world, a, b, c, new ItemStack(Item.feather));
			entityitem.delayBeforeCanPickup = 5;
			world.entityJoinedWorld(entityitem);
		}
		
		ModLoader.getMinecraftInstance().ingameGUI.addChatMessage("The Rope Arrow broke apart...");
	}

    public boolean isOpaqueCube()
    {
        return false;
    }

    public boolean renderAsNormalBlock()
    {
        return false;
    }

    public int getRenderType()
    {
        return 1;
    }
}
