package net.minecraft.src;

import java.util.*;


public class ASBlockRope extends BlockContainer
{

    protected ASBlockRope(int i, int j, int k)
    {
        super(i, j, Material.cloth);
        ascensionSpeed = 0.2F;
        descensionSpeed = -0.15F;
        renderType = k;
    }

	/*
    public void onEntityCollidedWithBlock(World world, int i, int j, int k, Entity entity)
    {
        if(entity instanceof EntityLiving)
        {
            entity.fallDistance = 0.0F;
            if(entity.motionY < (double)descensionSpeed)
            {
                entity.motionY = descensionSpeed;
            }
            if(entity.isCollidedHorizontally)
            {
                entity.motionY = ascensionSpeed;
            }
			if(entity.isSneaking())
			{
				entity.motionY = 0.0D;
			}
        }
    }
	*/

    protected TileEntity getBlockEntity()
    {
        return new ASTileEntityRope();
    }

    public AxisAlignedBB getCollisionBoundingBoxFromPool(World world, int i, int j, int k)
    {
        int l = world.getBlockMetadata(i, j, k);
        float f = 0.125F;
        if(l == 2)
        {
            setBlockBounds(0.0F, 0.0F, 1.0F - f, 1.0F, 1.0F, 1.0F);
        }
        if(l == 3)
        {
            setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, f);
        }
        if(l == 4)
        {
            setBlockBounds(1.0F - f, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
        }
        if(l == 5)
        {
            setBlockBounds(0.0F, 0.0F, 0.0F, f, 1.0F, 1.0F);
        }
        return super.getCollisionBoundingBoxFromPool(world, i, j, k);
    }

    public AxisAlignedBB getSelectedBoundingBoxFromPool(World world, int i, int j, int k)
    {
        int l = world.getBlockMetadata(i, j, k);
        float f = 0.125F;
        if(l == 2)
        {
            setBlockBounds(0.0F, 0.0F, 1.0F - f, 1.0F, 1.0F, 1.0F);
        }
        if(l == 3)
        {
            setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, f);
        }
        if(l == 4)
        {
            setBlockBounds(1.0F - f, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
        }
        if(l == 5)
        {
            setBlockBounds(0.0F, 0.0F, 0.0F, f, 1.0F, 1.0F);
        }
        return super.getSelectedBoundingBoxFromPool(world, i, j, k);
    }

    public boolean isOpaqueCube()
    {
        return false;
    }

    public boolean renderAsNormalBlock()
    {
        return false;
    }

    public int getRenderType()
    {
        return renderType;
    }

    public int quantityDropped(Random random)
    {
        return 0;
    }
	
    public void onBlockDestroyedByPlayer(World world, int a, int b, int c, int l)
    {
		if(world.multiplayerWorld)
        {
            return;
        }
	
        for(int x = -1; world.getBlockId(a, b+x, c) == mod_ASGrapplingHook.blockRope.blockID; x--)
		{
			world.setBlockWithNotify(a, b+x, c, 0);
		}
		
		int h = b;
        for(int hx = 1; world.getBlockId(a, b+hx, c) == mod_ASGrapplingHook.blockRope.blockID; hx++)
		{
			h++;
			world.setBlockWithNotify(a, b+hx, c, 0);
		}
		
		//ModLoader.getMinecraftInstance().ingameGUI.addChatMessage("Rope height of ["+(h-b)+"] removed");
		
		int candidates[][] = {
			{a-1, h+1, c},
			{a, h+1, c-1},
			{a, h+1, c+1},
			{a+1, h+1, c}
        };
		
		boolean IsHook = false;
		for(int y = 0; y < candidates.length; y++)
		{
			if(world.getBlockId(candidates[y][0], candidates[y][1], candidates[y][2]) == mod_ASGrapplingHook.blockGrapplingHook.blockID)
			{
				world.setBlockWithNotify(candidates[y][0], candidates[y][1], candidates[y][2], 0);
				
				EntityItem entityitem = new EntityItem(world, a, b, c, new ItemStack(mod_ASGrapplingHook.itemGrapplingHook));
				entityitem.delayBeforeCanPickup = 5;
				world.entityJoinedWorld(entityitem);
				
				IsHook = true;
				break;
			}
		}
		
		if (!IsHook)
		{
			EntityItem entityitem = new EntityItem(world, a, b, c, new ItemStack(mod_Arrows303.getArrowItemByTip(mod_Rope.rope)));
			entityitem.delayBeforeCanPickup = 5;
			world.entityJoinedWorld(entityitem);
		}
	}

    public float ascensionSpeed;
    public float descensionSpeed;
    private int renderType;
}
