package net.minecraft.src;

public class ASTileEntityRope extends TileEntity
{

    public ASTileEntityRope()
    {
        delay = 5;
    }

    public void updateEntity()
    {
        if(delay <= 0)
        {
            if(worldObj.getBlockId(xCoord, yCoord - 1, zCoord) == 0 || worldObj.getBlockId(xCoord, yCoord - 1, zCoord) == Block.snow.blockID)
            {
                worldObj.setBlockWithNotify(xCoord, yCoord - 1, zCoord, mod_ASGrapplingHook.blockRope.blockID);
                worldObj.setBlockMetadataWithNotify(xCoord, yCoord - 1, zCoord, worldObj.getBlockMetadata(xCoord, yCoord, zCoord));
                delay--;
            }
        }
		else
        {
            delay--;
        }
        super.updateEntity();
    }

    public void readFromNBT(NBTTagCompound nbttagcompound)
    {
        super.readFromNBT(nbttagcompound);
        delay = nbttagcompound.getShort("Delay");
    }

    public void writeToNBT(NBTTagCompound nbttagcompound)
    {
        super.writeToNBT(nbttagcompound);
        nbttagcompound.setShort("Delay", (short)delay);
    }

    public int delay;
}
