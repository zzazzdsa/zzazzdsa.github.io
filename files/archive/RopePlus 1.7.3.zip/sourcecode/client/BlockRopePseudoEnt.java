package net.minecraft.src;

public class BlockRopePseudoEnt
{

    public BlockRopePseudoEnt(World w, int x, int y, int z, int l)
    {
		world = w;
		ix = x;
		iy = y;
		iz = z;
		delay = 20;
		remainrope = l;
    }
	
	public boolean OnUpdate()
	{
		delay -= 1;
		
		if (delay <= 0)
		{
			if ((world.getBlockId(ix, iy - 1, iz) == 0 || world.getBlockId(ix, iy - 1, iz) == Block.snow.blockID))
			{
				remainrope -= 1;
				if (remainrope <= 0)
				{
					return true;
				}
				
				world.setBlockWithNotify(ix, iy - 1, iz, mod_Rope.rope.blockID);
				BlockRopePseudoEnt newent = new BlockRopePseudoEnt(world, ix, iy - 1, iz, remainrope);
				mod_Rope.addRopeToArray(newent);
				
				int[] coords = new int[3];
				coords[0] = ix;
				coords[1] = iy - 1;
				coords[2] = iz;
				mod_Rope.addCoordsToRopeArray(coords);
			}
			return true;
		}
		
		return false;
	}

	private int delay;
	private World world;
	private int ix;
	private int iy;
	private int iz;
	private int remainrope;
}
