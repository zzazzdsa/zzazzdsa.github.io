// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import net.minecraft.client.Minecraft;

// Referenced classes of package net.minecraft.src:
//            EntityArrow303, GuiModScreen, mod_Arrows303, SettingInt, 
//            ModSettings, Block, SettingBoolean, SettingMulti, 
//            WidgetClassicTwocolumn, WidgetInt, WidgetBoolean, WidgetMulti, 
//            WidgetSimplewindow, ModAction, ModSettingScreen, ItemStack, 
//            MathHelper, World, EntityDiggingFX, EffectRenderer, 
//            EntityLiving

public class EntityArrow303Dirt extends EntityArrow303
{

    public void subscreen()
    {
    }

    public void setupConfig()
    {
    }

    public void entityInit()
    {
        super.entityInit();
        name = "DirtArrow";
        craftingResults = 1;
        itemId = 132 + Block.blocksList.length;
        tip = Block.dirt;
        item = new ItemStack(itemId, 1, 0);
        spriteFile = "/arrows/dirtarrow.png";
    }

    public EntityArrow303Dirt(World world)
    {
        super(world);
    }

    public EntityArrow303Dirt(World world, EntityLiving entityliving)
    {
        super(world, entityliving);
    }

    public EntityArrow303Dirt(World world, double d, double d1, double d2)
    {
        super(world, d, d1, d2);
    }

    public boolean onHit()
    {
        spawnDirt();
        return true;
    }

    public boolean onHitBlock()
    {
        setEntityDead();
        return true;
    }

    public void spawnDirt()
    {

        int i = MathHelper.floor_double(posX);
        int j = MathHelper.floor_double(posY);
        int k = MathHelper.floor_double(posZ);
        for(int l = -0; l <= 0; l++)
        {
            for(int i1 = -0; i1 <= 0; i1++)
            {
                for(int j1 = -0; j1 <= 0; j1++)
                {
                    int k1 = i + l;
                    int l1 = j + j1;
                    int i2 = k + i1;

                    if(Math.abs(l) != 0 && Math.abs(j1) != 0 && Math.abs(i1) != 0)
                    {
                        continue;
                    }
                    if(!worldObj.canBlockBePlacedAt(defaultBlockId, k1, l1, i2, true, 1))
                    {
                        continue;
                    }
                    worldObj.setBlockWithNotify(k1, l1, i2, 1);
                    break;
                }

            }

        }

    }

    public void tickFlying()
    {
        super.tickFlying();
        if(true)
        {
			int i = rand.nextInt(6);
			int j = 0;
		
            EntityDiggingFX entitydiggingfx = new EntityDiggingFX(worldObj, posX, posY, posZ, 0.01D, 0.01D, 0.01D, Block.dirt, i, j);
            entitydiggingfx.motionX = entitydiggingfx.motionZ = entitydiggingfx.motionY = 0.01D;
            entitydiggingfx.renderDistanceWeight = 10D;
            mod_Arrows303.mc.effectRenderer.addEffect(entitydiggingfx);
        }
    }

    public static final int defaultBlockId;

    static 
    {
        defaultBlockId = Block.dirt.blockID;
    }
}
