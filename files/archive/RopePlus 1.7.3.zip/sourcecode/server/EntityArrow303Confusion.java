// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import java.util.*;


// Referenced classes of package net.minecraft.src:
//            EntityArrow303, Block, ItemStack, Entity, 
//            AxisAlignedBB, World, EntityCreature, mod_Arrows303, 
//            SettingBoolean, EntityDiggingFX, EntityFX, EffectRenderer, 
//            EntityLiving

public class EntityArrow303Confusion extends EntityArrow303
{

    public EntityArrow303Confusion(World world)
    {
        super(world);
    }

    public EntityArrow303Confusion(World world, EntityLiving entityliving)
    {
        super(world, entityliving);
    }

    public EntityArrow303Confusion(World world, double d, double d1, double d2)
    {
        super(world, d, d1, d2);
    }

    public void entityInit()
    {
        super.entityInit();
        name = "ConfusionArrow";
        craftingResults = 1;
        itemId = 3543 + Block.blocksList.length;
        tip = Block.sand;
        spriteFile = "/arrows/confusionarrow.png";
        item = new ItemStack(itemId, 1, 0);
    }

    public boolean onHitBlock()
    {
        confuse(this);
        return true;
    }

    public boolean onHitTarget(Entity entity)
    {
        confuse(entity);
        return true;
    }

    public void confuse(Entity entity)
    {
        List list = worldObj.getEntitiesWithinAABBExcludingEntity(this, entity.boundingBox.expand(radius, radius, radius));
        ArrayList arraylist = new ArrayList();
        Iterator iterator = list.iterator();
        do
        {
            if(!iterator.hasNext())
            {
                break;
            }
            Entity entity1 = (Entity)iterator.next();
            if((entity1 instanceof EntityCreature) && entity1 != shooter)
            {
                arraylist.add((EntityCreature)entity1);
            }
        } while(true);
        if(arraylist.size() < 2)
        {
            return;
        }
        for(int i = 0; i < arraylist.size(); i++)
        {
            EntityCreature entitycreature = (EntityCreature)arraylist.get(i);
            EntityCreature entitycreature1 = (EntityCreature)arraylist.get(i != 0 ? i - 1 : arraylist.size() - 1);
            entitycreature.attackEntityFrom(entitycreature1, 0);
            entitycreature1.playerToAttack = entitycreature;
        }

        setEntityDead();
    }

    public void tickFlying()
    {
    }

    public static double radius = 6D;

}
