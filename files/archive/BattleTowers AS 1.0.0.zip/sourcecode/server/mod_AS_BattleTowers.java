// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import java.io.*;
import java.util.*;
import java.security.*;
import java.net.*;
import net.minecraft.server.MinecraftServer;

// Referenced classes of package net.minecraft.src:
//            BaseMod, EntityGolem, ModLoader,
//            WorldGenTower, Block, World

public class mod_AS_BattleTowers extends BaseModMp
{
    public mod_AS_BattleTowers()
    {
        ModLoader.RegisterEntityID(AS_EntityGolem.class, "Golem", 27);
		ModLoaderMp.RegisterEntityTrackerEntry(AS_EntityGolemFireball.class, 27);
		ModLoaderMp.RegisterEntityTracker(AS_EntityGolemFireball.class, 160, 5);
		
        spawncounter = 200;
        try
        {
            Properties properties = new Properties();
			
			String s = (net.minecraft.src.mod_AS_BattleTowers.class).getProtectionDomain().getCodeSource().getLocation().toURI().getPath();
            s = s.substring(0, s.lastIndexOf('/'));
            s = s.substring(0, s.lastIndexOf('/'));
            s = (new StringBuilder()).append(s).append("/mods/BattleTowers.txt").toString();
			
            File file = new File(s);
            configpath = s;
            properties.load(new InputStreamReader(new FileInputStream(file)));
            rarity = Integer.valueOf(properties.getProperty("rarity")).intValue();
			minDistanceBetweenTowers = Double.valueOf(properties.getProperty("minDistanceBetweenTowers")).doubleValue();
			towerDestroyerEnabled = Integer.valueOf(properties.getProperty("towerDestroyerEnabled")).intValue();
        }
        catch(URISyntaxException urisyntaxexception)
        {
            System.err.println("BattleTowers URISyntaxException: "+urisyntaxexception);
			UseDefaults();
		}
        catch(FileNotFoundException filenotfoundexception)
        {
            System.err.println("BattleTowers properties file not found, using default values: "+filenotfoundexception);
			UseDefaults();
        }
        catch(IOException ioexception)
        {
            System.err.println("Error reading BattleTowers properties file, using default values: "+ioexception);
			UseDefaults();
        }
        catch(NumberFormatException numberformatexception)
        {
            System.err.println("Incorrect value property, using default value. "+numberformatexception);
			UseDefaults();
        }
        if(rarity < 1)
        {
            rarity = 1;
        }
		raritycounter = rarity * 100;
		
		TowerPositions = new ArrayList();
		TowerDestroyers = new ArrayList();
		
		time = System.currentTimeMillis();
		ModLoader.SetInGameHook(this, true, true);
		instance = this;
    }
	
	public void OnTickInGame(MinecraftServer mc)
	{
		if (System.currentTimeMillis() > time + 1000L) // its a one second timer OMFG
		{
			for(int i = 0; i < TowerDestroyers.size(); i++)
			{
				AS_TowerDestroyer temp = (AS_TowerDestroyer)TowerDestroyers.get(i);
				temp.Update();
			}
		}
	}
	
	public static void registerTowerDestroyer(AS_TowerDestroyer td)
	{
		forceAllClientsDestroyerSetting();
		
		if (towerDestroyerEnabled != 0)
		{
			TowerDestroyers.add(td);
		}
	}
	
	private static void forceAllClientsDestroyerSetting()
	{
		int[] dataInt = new int[1];
		dataInt[0] = towerDestroyerEnabled;
		Packet230ModLoader packet = new Packet230ModLoader();
		packet.packetType = 0;
		packet.dataInt = dataInt;
		ModLoaderMp.SendPacketToAll(instance, packet);
	}
	
	public void HandlePacket(Packet230ModLoader packet)
	{
		switch(packet.packetType)
		{
			case 1:
			{
				forceAllClientsDestroyerSetting();
			}
		}
	}
	
	public static void unRegisterTowerDestroyer(AS_TowerDestroyer td)
	{
		TowerDestroyers.remove(td);
	}
	
	public void UseDefaults()
	{
        rarity = 3;
		minDistanceBetweenTowers = 64D;
		towerDestroyerEnabled = 1;
	}

    public void ModsLoaded()
    {
        System.err.println("BATTLE TOWERS CONFIG");
        System.err.println((new StringBuilder()).append("Tower Rarity ").append(String.valueOf(rarity)).toString());
		System.err.println((new StringBuilder()).append("Min Tower Distance ").append(String.valueOf(minDistanceBetweenTowers)).toString());
        System.err.println((new StringBuilder()).append("MINECRAFT PROPERTIES ").append(String.valueOf(configpath)).toString());
    }
	
	static boolean isWorking = false;

    public void GenerateSurface(World world, Random random, int x, int z)
    {
		if (!isWorking)
		{
			isWorking = true;
			if(spawncounter > raritycounter)
			{
				boolean spawn = true;
				double dist;
				double mindist = 100D;
				
				for(int i = 0; i < TowerPositions.size(); i++)
				{
					ChunkCoordinates temp = (ChunkCoordinates)TowerPositions.get(i);
					dist = temp.getSqDistanceTo(x, 64, z);
					
					if (dist < mindist) mindist = dist;
					
					if (dist < minDistanceBetweenTowers)
					{
						spawn = false;
						break;
					}
				}

				if (spawn)
				{
					if(AttemptToSpawnTower(world, random, x, z))
					{
						if (TowerPositions.size() > 30)
						{
							TowerPositions.remove(0);
						}
						
						ChunkCoordinates temp = new ChunkCoordinates(x, 64, z);
						TowerPositions.add(temp);
						spawncounter = 0;
						
						//System.err.println("Battle Tower spawned at [ "+x+" | "+z+" ]");
					}
				}
			}
			else
			{
				spawncounter++;
			}
			isWorking = false;
		}
	}
	
	private boolean AttemptToSpawnTower(World world, Random random, int x, int z)
	{
		int y = GetSurfaceBlockHeight(world, x, z);
		if (y == 49) return false;
		
		return ((new AS_WorldGenTower()).generate(world, random, x, y, z));
	}
	
	private int GetSurfaceBlockHeight(World world, int x, int z)
	{
		int h = 50;
		
		do
		{
			h++;
		}
		while (world.getBlockId(x, h, z) != 0);
		
		return h-1;
	}

    public String Version()
    {
        return "1.0.0";
    }
	
	private List TowerPositions;
	private static List TowerDestroyers;
	private int raritycounter = 400;
    private int spawncounter;
    private static int rarity;
	private double minDistanceBetweenTowers;
	public static int towerDestroyerEnabled;
    public static String configpath;
	private long time;
	static BaseModMp instance;
}
