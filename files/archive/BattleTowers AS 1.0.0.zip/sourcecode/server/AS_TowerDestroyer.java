package net.minecraft.src;


public class AS_TowerDestroyer
{

    public AS_TowerDestroyer(World worldObj, ChunkCoordinates coords, long time, Entity golemkiller)
    {
		this.world = worldObj;
		this.player = golemkiller;
		this.x = coords.posX;
		this.y = coords.posY;
		this.z = coords.posZ;
		this.triggerTime = time;
		this.lastExplosionSoundTime = time;
		
		//world.playSoundEffect(x, y, z, "towerbreakstart", 4F, 1.0F);
    }
	
	public void Update()
	{

		if(floor == maxfloor && System.currentTimeMillis() > triggerTime + 30000L) // initial golem death time plus 30 seconds
		{
			triggerTime = System.currentTimeMillis();
			
			// kaboom baby
			if (!world.singleplayerWorld)
			{
				world.createExplosion(player, x, yCoord(), z, explosionPower);
				cleanUpStragglerBlocks();
			}
			

			floor--;
		}
		else if (floor < maxfloor && System.currentTimeMillis() > triggerTime + 10000L) // each floor bursts 10 seconds after that
		{
			if (floor < 1)
			{
				mod_AS_BattleTowers.unRegisterTowerDestroyer(this);
				return;
			}
			triggerTime = System.currentTimeMillis();
			
			// kaboom baby
			if (!world.singleplayerWorld)
			{
				world.createExplosion(player, x, yCoord(), z, explosionPower);
				cleanUpStragglerBlocks();
			}
			
			floor--;
		}
		else
		{
		}
	}
	
	private double yCoord()
	{
		return y - (floorDistance * Math.abs(maxfloor - floor));
	}
	
	private int randomTowerCoord(int i)
	{
		return i - 7 + world.rand.nextInt(15);
	}
	
	private void cleanUpStragglerBlocks()
	{
		int ytemp = (int)yCoord();
		for(int xIterator = -8; xIterator < 8; xIterator++) // do each X
		{
			for(int zIterator = -8; zIterator < 8; zIterator++) // do each Z
			{
				for(int yIterator = 1; yIterator < 9; yIterator++) // do Y 8 blocks high
				{
					if(world.getBlockId(x+xIterator, ytemp+yIterator, z+zIterator) != 0)
					{
						world.setBlock(x+xIterator, ytemp+yIterator, z+zIterator, 0);
					}
				}
			}
		}
	}
	

	private int x;
	private int y;
	private int z;
	private World world;
	private Entity player;
	private long triggerTime;
	private long lastExplosionSoundTime;
	private final int maxfloor = 6;
	private int floor = maxfloor;
	private final int floorDistance = 7;
	private final float explosionPower = 10F;
}
