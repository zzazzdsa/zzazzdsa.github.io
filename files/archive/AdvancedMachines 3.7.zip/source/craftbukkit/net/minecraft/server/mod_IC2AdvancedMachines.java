package net.minecraft.server;

import forge.*;
import ic2.api.*;
import net.minecraft.server.ic2.advancedmachines.*;

import java.io.File;
import java.lang.reflect.InvocationTargetException;

public class mod_IC2AdvancedMachines extends BaseModMp
{
    public static Configuration config;
    public static Block blockAdvancedMachine;
    public static int guiIdRotary;
    public static int guiIdSingularity;
    public static int guiIdCentrifuge;
    public static String advMaceName = "Rotary Macerator";
    public static String advCompName = "Singularity Compressor";
    public static String advExtcName = "Centrifuge Extractor";
    public static ItemStack overClockerStack;
    public static ItemStack transformerStack;
    public static ItemStack energyStorageUpgradeStack;
    public static String advMaceSound = null;
    public static String interruptSound = null;
    public static final Item refinedIronDust = (new Item(29775)).a("Refined Iron Dust");

    public mod_IC2AdvancedMachines()
    {
    }

    public String getVersion()
    {
        return "v3.7";
    }

    public static int getConfigInt(String s, int i, int j, boolean flag, String s1)
    {
        if (config == null)
        {
            return i;
        }
        try
        {
            if (flag)
            {
                Property property = config.getOrCreateIntProperty(s, j, i);
                property.comment = s1;
                return Integer.valueOf(property.value).intValue();
            }
            else
            {
                return Integer.valueOf(config.getOrCreateIntProperty(s, j, i).value).intValue();
            }
        }
        catch (Exception exception)
        {
            System.out.println("[Advanced Machines] Error while trying to access config, wasn't loaded properly!");
        }
        return i;
    }

    public static int getBlockId(String s, int i)
    {
        if (config == null)
        {
            return i;
        }
        try
        {
            return Integer.valueOf(config.getOrCreateBlockIdProperty(s, i).value).intValue();
        }
        catch (Exception exception)
        {
            System.out.println("[Advanced Machines] Error while trying to access config, wasn't loaded properly!");
        }
        return i;
    }

    public static void showGui(EntityHuman entityhuman, int i, TileEntity tileentity)
    {
        ModLoader.OpenGUI(entityhuman, i, entityhuman.inventory, ((TileEntityAdvancedMachine)tileentity).getGuiContainer(entityhuman.inventory));
    }

    public String getPriorities()
    {
        return "after:mod_IC2";
    }

    public void load()
    {
        try
        {
            config = new Configuration(new File((new File(".")).getPath(), "/config/IC2AdvancedMachine.cfg"));
            config.load();
        }
        catch (Exception exception)
        {
            System.out.println("[Advanced Machines] Error while trying to access configuration!");
            config = null;
        }
        blockAdvancedMachine = new BlockAdvancedMachines(getBlockId("blockAdvancedMachine", 188));
        guiIdRotary = getConfigInt("guiIdRotary", 40, 0, false, "");
        guiIdSingularity = getConfigInt("guiIdSingularity", 41, 0, false, "");
        guiIdCentrifuge = getConfigInt("guiIdCentrifuge", 42, 0, true, "GUI IDs. Only change them if you got a conflict.");
        if (config != null)
        {
            config.save();
        }
        ModLoader.RegisterBlock(blockAdvancedMachine, ItemAdvancedMachine.class);
        ModLoader.RegisterTileEntity(TileEntityRotaryMacerator.class, "Rotary Macerator");
        ModLoader.RegisterTileEntity(TileEntitySingularityCompressor.class, "Singularity Compressor");
        ModLoader.RegisterTileEntity(TileEntityCentrifugeExtractor.class, "Centrifuge Extractor");
    }

    public void ModsLoaded()
    {
        Ic2Recipes.addCraftingRecipe(new ItemStack(blockAdvancedMachine, 1, 0), new Object[]
                {
                    "RRR", "RMR", "RAR", Character.valueOf('R'), Items.getItem("refinedIronIngot"), Character.valueOf('M'), Items.getItem("macerator"), Character.valueOf('A'), Items.getItem("advancedMachine")
                });
        Ic2Recipes.addCraftingRecipe(new ItemStack(blockAdvancedMachine, 1, 1), new Object[]
                {
                    "RRR", "RMR", "RAR", Character.valueOf('R'), Block.OBSIDIAN, Character.valueOf('M'), Items.getItem("compressor"), Character.valueOf('A'), Items.getItem("advancedMachine")
                });
        Ic2Recipes.addCraftingRecipe(new ItemStack(blockAdvancedMachine, 1, 2), new Object[]
                {
                    "RRR", "RMR", "RAR", Character.valueOf('R'), Items.getItem("electrolyzedWaterCell"), Character.valueOf('M'), Items.getItem("extractor"), Character.valueOf('A'), Items.getItem("advancedMachine")
                });
        overClockerStack = Items.getItem("overclockerUpgrade");
        transformerStack = Items.getItem("transformerUpgrade");
        energyStorageUpgradeStack = Items.getItem("energyStorageUpgrade");
        refinedIronDust.textureId = ModLoader.addOverride("/gui/items.png", "ic2/sprites/refinedIronDust.png");
        ModLoader.AddSmelting(refinedIronDust.id, Items.getItem("refinedIronIngot"));
    }

    public static void explodeMachineAt(World world, int i, int j, int k)
    {
        try
        {
            Class class1 = Class.forName("mod_IC2");
            class1.getMethod("explodeMachineAt", new Class[]
                    {
                        World.class, Integer.TYPE, Integer.TYPE, Integer.TYPE
                    }).invoke(null, new Object[]
                            {
                                world, Integer.valueOf(i), Integer.valueOf(j), Integer.valueOf(k)
                            });
        }
        catch (NoSuchMethodException nosuchmethodexception) { }
        catch (SecurityException securityexception) { }
        catch (ClassNotFoundException classnotfoundexception) { }
        catch (IllegalAccessException illegalaccessexception) { }
        catch (IllegalArgumentException illegalargumentexception) { }
        catch (InvocationTargetException invocationtargetexception) { }
    }
}
