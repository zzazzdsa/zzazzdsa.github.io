package net.minecraft.server.ic2.advancedmachines;

import java.util.*;
import ic2.api.*;
import net.minecraft.server.*;

public class TileEntityBlock extends TileEntity
implements IWrenchable, INetworkDataProvider, INetworkTileEntityEventListener
{
protected boolean created;
public boolean active;
public short facing;
public boolean prevActive;
public short prevFacing;
public static List networkedFields;

public TileEntityBlock()
{
    created = false;
    active = false;
    facing = 5;
    prevActive = false;
    prevFacing = 0;
}

public void a(NBTTagCompound nbttagcompound)
{
    super.a(nbttagcompound);
    prevFacing = facing = nbttagcompound.getShort("facing");
}

public void b(NBTTagCompound nbttagcompound)
{
    super.b(nbttagcompound);
    nbttagcompound.setShort("facing", facing);
}

public void l_()
{
    if (!created)
    {
        created = true;
        networkedFields = new ArrayList();
        networkedFields.add("active");
        networkedFields.add("facing");
        NetworkHelper.requestInitialData(this);
        NetworkHelper.announceBlockUpdate(world, x, y, z);
    }
}

public boolean getActive()
{
    return active;
}

public void setActive(boolean flag)
{
    active = flag;
    if (prevActive != active)
    {
        NetworkHelper.updateTileEntityField(this, "active");
    }
    prevActive = flag;
}

public void setActiveWithoutNotify(boolean flag)
{
    active = flag;
    prevActive = flag;
}

public short getFacing()
{
    return facing;
}

public boolean wrenchCanSetFacing(EntityHuman entityhuman, int i)
{
    return i >= 2 && i != facing;
}

public void setFacing(short word0)
{
    facing = word0;
    NetworkHelper.updateTileEntityField(this, "facing");
    prevFacing = word0;
    NetworkHelper.announceBlockUpdate(world, x, y, z);
}

public boolean wrenchCanRemove(EntityHuman entityhuman)
{
    return true;
}

public float getWrenchDropRate()
{
    return 1.0F;
}

public List getNetworkedFields()
{
    return networkedFields;
}

public void onNetworkEvent(int i)
{
}
}
