package net.minecraft.server.ic2.advancedmachines;

import ic2.api.*;
import java.util.*;
import net.minecraft.server.*;

public class TileEntityRotaryMacerator extends TileEntityAdvancedMachine
implements IInventory
{
public int supplementedItemsLeft;
private int currentResultCount;
private int idIronDust;
private int idCopperDust;
private int idTinDust;
private int idCoalDust;
private int idWaterCell;
private ItemStack bronzeDust;
private ItemStack hydratedCoalDust;

public TileEntityRotaryMacerator()
{
    super("Rotary Macerator", "%5d RPM", 1, new int[]
            {
                0, 1
            }, new int[]
            {
                2, 3
            });
    supplementedItemsLeft = 0;
    idIronDust = Items.getItem("ironDust").id;
    idCopperDust = Items.getItem("copperDust").id;
    idTinDust = Items.getItem("tinDust").id;
    idCoalDust = Items.getItem("coalDust").id;
    idWaterCell = Items.getItem("waterCell").id;
    bronzeDust = Items.getItem("bronzeDust");
    hydratedCoalDust = Items.getItem("hydratedCoalDust");
}

public Container getGuiContainer(PlayerInventory playerinventory)
{
    return new ContainerRotaryMacerator(playerinventory, this);
}

protected List getResultMap()
{
    return Ic2Recipes.getMaceratorRecipes();
}

public ItemStack getResultFor(ItemStack itemstack, boolean flag)
{
    ItemStack itemstack1 = Ic2Recipes.getMaceratorOutputFor(itemstack, flag);
    ItemStack itemstack2 = inventory[8] == null ? null : inventory[8].cloneItemStack();
    if (itemstack2 != null)
    {
        if (supplementedItemsLeft > 0)
        {
            itemstack1 = getSpecialResultFor(itemstack1, itemstack2, flag);
        }
        else if (getSpecialResultFor(itemstack1, itemstack2, flag) != null)
        {
            itemstack1 = getSpecialResultFor(itemstack1, itemstack2, flag);
            supplementedItemsLeft = currentResultCount;
        }
    }
    return itemstack1;
}

public void onFinishedProcessingItem()
{
    if (supplementedItemsLeft != 0)
    {
        if (supplementedItemsLeft == 1)
        {
            inventory[8].count--;
            if (inventory[8].count == 0)
            {
                inventory[8] = null;
            }
        }
        supplementedItemsLeft--;
    }
    super.onFinishedProcessingItem();
}

private ItemStack getSpecialResultFor(ItemStack itemstack, ItemStack itemstack1, boolean flag)
{
    if (itemstack != null && itemstack1 != null)
    {
        ItemStack itemstack2 = Ic2Recipes.getMaceratorOutputFor(itemstack1, flag);
        if (itemstack.id == idIronDust && itemstack1.id == Item.COAL.id)
        {
            currentResultCount = 128;
            return new ItemStack(mod_IC2AdvancedMachines.refinedIronDust, 2);
        }
        if (itemstack.id == idCopperDust && itemstack2 != null && itemstack2.id == idTinDust)
        {
            currentResultCount = 4;
            return bronzeDust;
        }
        if (itemstack.id == idCoalDust && itemstack1.id == idWaterCell)
        {
            currentResultCount = 8;
            return hydratedCoalDust;
        }
    }
    return null;
}

public int getUpgradeSlotsStartSlot()
{
    return 4;
}
}