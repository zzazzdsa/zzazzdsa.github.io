package net.minecraft.src;

import org.lwjgl.input.Keyboard;
import java.util.*;

public class mod_dynamiclights extends BaseMod
{
	private final String togglekey = "L";
	private final int itogglekey = Keyboard.getKeyIndex(togglekey);
	
	private int lastListHash = 0;
    private List entityList;
	
	long time;

	public mod_dynamiclights()
	{
		ModLoader.SetInGameHook(this, true, false);
		
		time = System.currentTimeMillis();
	}
	
	public void OnTickInGame(net.minecraft.client.Minecraft mc)
	{
		if (mc.thePlayer == null || mc.theWorld == null) return;
		
		if(lastListHash != mc.theWorld.loadedEntityList.hashCode())
		{
			entityList = mc.theWorld.loadedEntityList;
			lastListHash = mc.theWorld.loadedEntityList.hashCode();
			
			UpdateTorchEntities(mc.theWorld);
		}
		
		boolean newsecond = false;
		if(System.currentTimeMillis() >= time + 1000L) 
		{
			newsecond = true;
			time = System.currentTimeMillis();
		}
		
		for(int j = 0; j < PlayerTorchArray.torchArray.size(); j++) // loop the PlayerTorch List
		{
			PlayerTorch torchLoopClass = (PlayerTorch)PlayerTorchArray.torchArray.get(j);
			Entity torchent = torchLoopClass.GetTorchEntity();
			
			
			if(torchent instanceof EntityPlayer)
			{
				EntityPlayer entPlayer = (EntityPlayer)torchent;
				
				if (entPlayer.inventory.mainInventory[entPlayer.inventory.currentItem] != null)
				{
					int ID = entPlayer.inventory.mainInventory[entPlayer.inventory.currentItem].itemID;
					
					if (ID != torchLoopClass.currentItemID)
					{
						torchLoopClass.currentItemID = ID;
						
						// this is a debug function for modder use.
						//Minecraft.theMinecraft.ingameGUI.addChatMessage("Player Item changed, item now: " + ID);
						
						int brightness = PlayerTorchArray.GetItemBrightnessValue(ID);
						if (brightness > 0)
						{
							torchLoopClass.SetTorchBrightness(brightness);
							torchLoopClass.SetTorchRange(PlayerTorchArray.GetItemLightRangeValue(ID));
							torchLoopClass.SetWorksUnderwater(PlayerTorchArray.GetItemWorksUnderWaterValue(ID));
							torchLoopClass.setTorchState(entPlayer.worldObj, true);
						}
						else
						{
							torchLoopClass.setTorchState(entPlayer.worldObj, false);
						}
					}
					
					if (torchLoopClass.isTorchActive())
					{
						torchLoopClass.setTorchPos(entPlayer.worldObj, (float)entPlayer.posX, (float)entPlayer.posY, (float)entPlayer.posZ);
					}
				}
				else
				{
					torchLoopClass.currentItemID = 0;
					torchLoopClass.setTorchState(entPlayer.worldObj, false);
				}
			
			}
			
			if(torchent instanceof EntityItem)
			{
				torchLoopClass.setTorchPos(mc.theWorld, (float)torchent.posX, (float)torchent.posY, (float)torchent.posZ);
				
				if (torchLoopClass.hasDeathAge())
				{
					if (torchLoopClass.hasReachedDeathAge())
					{
						torchLoopClass.GetTorchEntity().setEntityDead();
						PlayerTorchArray.RemoveTorchFromArray(mc.theWorld, torchLoopClass);
					}
					else if (newsecond)
					{
						torchLoopClass.doAgeTick();
					}
				}
			}
		}
		
		if (Keyboard.getEventKeyState()
		&& Keyboard.getEventKey() == itogglekey
		&& newsecond)
		{
			PlayerTorchArray.ToggleDynamicLights();
		}
	}
	
	private void UpdateTorchEntities(World worldObj)
	{
		List tempList = new ArrayList();
	
		for(int k = 0; k < entityList.size(); k++)
		{
			Entity tempent = (Entity)entityList.get(k);
			
			if(tempent instanceof EntityPlayer)
			{
				tempList.add(tempent);
			}
			
			if(tempent instanceof EntityItem)
			{
				EntityItem helpitem = (EntityItem)tempent;
				int brightness = PlayerTorchArray.GetItemBrightnessValue(helpitem.item.itemID);
				if (brightness > 0)
				{			
					tempList.add(tempent);
				}
			}
		}
		// tempList is now a fresh list of all Entities that can have a PlayerTorch
		
		for(int j = 0; j < PlayerTorchArray.torchArray.size(); j++) // loop the old PlayerTorch List
		{
			PlayerTorch torchLoopClass = (PlayerTorch)PlayerTorchArray.torchArray.get(j);
			Entity torchent = torchLoopClass.GetTorchEntity();
			
			if (tempList.contains(torchent)) // check if the old entities are still in the world
			{
				tempList.remove(torchent); // if so remove them from the fresh list
			}
			else
			{
				PlayerTorchArray.RemoveTorchFromArray(worldObj, torchLoopClass); // else remove them from the PlayerTorch list
			}
		}
		
		for(int l = 0; l < tempList.size(); l++) // now to loop the remainder of the fresh list, the NEW lights
		{
			Entity newent = (Entity)tempList.get(l);
			
			PlayerTorch newtorch = new PlayerTorch(newent);
			PlayerTorchArray.torchArray.add(newtorch);
			
			if(newent instanceof EntityItem)
			{
				EntityItem institem = (EntityItem)newent;
				newtorch.SetTorchBrightness(PlayerTorchArray.GetItemBrightnessValue(institem.item.itemID));
				newtorch.SetTorchRange(PlayerTorchArray.GetItemLightRangeValue(institem.item.itemID));
				newtorch.setDeathAge(PlayerTorchArray.GetItemDeathAgeValue(institem.item.itemID));
				newtorch.SetWorksUnderwater(PlayerTorchArray.GetItemWorksUnderWaterValue(institem.item.itemID));
				newtorch.setTorchState(worldObj, true);
			}
		}
	}
	
	public String Version()
	{
		return "v1.1.1";
	}
}