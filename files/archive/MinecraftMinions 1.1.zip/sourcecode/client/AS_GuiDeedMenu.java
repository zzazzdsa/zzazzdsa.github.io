package net.minecraft.src;

import java.util.*;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;
import static org.lwjgl.opengl.GL11.*;

/**
 * Evil Deed selection menu
 * 
 * 
 * @author AtomicStryker
 */

public class AS_GuiDeedMenu extends GuiScreen
{
    protected String screenTitle = "Choose your part!";
    
    private EntityPlayer playerBoss;
    private int actionCalled;
    
    private boolean fadeOutfadeInUnderWay = false;
    private int incrementingInt;
    private int fadeState = 1;
    private long timeStayBlack = 1000L;
    private long timeFadeStart = 0L;
    
    private ArrayList deedButtons;

    public AS_GuiDeedMenu(EntityPlayer caller)
    {
        this.playerBoss = caller;
    }

    public void initGui()
    {
        this.controlList.clear();
        
        this.controlList.add(new GuiButton(0, this.width / 2 - 100, this.height / 4 + 120, "Chicken out"));
        
    	ArrayList copy = (ArrayList) mod_Minions.evilDoings.clone();
    	
    	if (copy == null || copy.size() == 0)
    	{
    		System.out.println("Client: Evil Deed List empty, aborting Deed Menu");
    		this.mc.displayGuiScreen((GuiScreen)null);
    		return;
    	}
    	
    	deedButtons = new ArrayList();
    	Random rand = new Random();
    	
    	while (deedButtons.size() < 3)
    	{
    		int i = rand.nextInt(copy.size()-1);
    		deedButtons.add(copy.get(i));
    		copy.remove(i);
    	}
    	
    	this.controlList.clear();
    	
    	this.controlList.add(new GuiButton(0, this.width / 2 - 100, this.height / 4 + 120, "Nevermind"));
    	
    	for (int x = 0; x < 3; x++)
    	{
    		AS_EvilDeed deed = (AS_EvilDeed) deedButtons.get(x);
    		this.controlList.add(new GuiButton(x+1, this.width / 2 - 100, this.height / 4 + x*40, deed.getButtonText()));
    	}
    }

    public void onGuiClosed()
    {

    }

    public void updateScreen()
    {        
        if (fadeOutfadeInUnderWay)
        {
        	if (fadeState == 0 && timeFadeStart != 0L && System.currentTimeMillis() - timeFadeStart > timeStayBlack)
        	{
        		//System.out.println("Time passed, unfading now!");
        		fadeState = 2;
        		timeFadeStart = 0L;
        	}

        	else if (fadeState == 1)
        	{
        		incrementingInt+=5;

        		if (incrementingInt >= 180)
        		{
        			//System.out.println("Full Fade reached, waiting for time!");
        			incrementingInt = 180;
        			timeFadeStart = System.currentTimeMillis();
        			fadeState = 0;
        			
        			playerBoss.worldObj.playSoundAtEntity(playerBoss, ((AS_EvilDeed)this.deedButtons.get(actionCalled-1)).getSoundFile(), 1.0F, 1.0F);
        			timeStayBlack = ((AS_EvilDeed)this.deedButtons.get(actionCalled-1)).getSoundLength() * 1000L;
        		}
        	}
        	else if (fadeState == 2)
        	{
        		incrementingInt-=5;

        		if (incrementingInt <= 20)
        		{
        			incrementingInt = 20;
        			fadeState = 1;
        			fadeOutfadeInUnderWay = false;
        			timeFadeStart = 0L;
        			
        			if (playerBoss.worldObj.isRemote)
        			{
    					Packet230ModLoader packet = new Packet230ModLoader();
    					packet.packetType = 1; // evildeed call
    					
    					String[] datastring = new String[1];
    					datastring[0] = playerBoss.username;
    					packet.dataString = datastring;
    					ModLoaderMp.SendPacket(mod_Minions.instance, packet);
        			}
        			else
        			{
	        			mod_Minions.onMasterAddedEvil(playerBoss);
	        			playerBoss.removeExperience(mod_Minions.evilDeedXPCost);
        			}
        			
        			this.mc.displayGuiScreen((GuiScreen)null);
        			//System.out.println("Unfade finished, destroyed menu!");
        		}
        	}
        }
    }

    protected void actionPerformed(GuiButton var1)
    {
        if (var1.enabled)
        {
        	int ID = var1.id;
        	this.actionCalled = ID;
        	
        	if (ID == 0)
        	{
        		this.mc.displayGuiScreen((GuiScreen)null);
        	}
        	else
        	{
            	//System.out.println("Started Fade out!");
            	fadeState = 1;
            	fadeOutfadeInUnderWay = true;
        	}
        }
    }

    protected void keyTyped(char var1, int var2)
    {
    	
    }

    public void drawScreen(int var1, int var2, float var3)
    {
    	this.drawDefaultBackground();
    	this.drawCenteredString(this.fontRenderer, this.screenTitle, this.width / 2, 40, 16777215);
    	GL11.glPushMatrix();
    	GL11.glTranslatef((float)(this.width / 2), 0.0F, 50.0F);
    	float var4 = 93.75F;
    	GL11.glScalef(-var4, -var4, -var4);
    	GL11.glRotatef(180.0F, 0.0F, 1.0F, 0.0F);

    	GL11.glPopMatrix();
    	super.drawScreen(var1, var2, var3);
    	
    	if (fadeOutfadeInUnderWay)
    	{
    		if (fadeState == 0)
    		{
    			this.drawRect(0, 0, mc.displayWidth, mc.displayHeight, -16777216);
    			return;
    		}
    		
    		double d = (double)incrementingInt / 200;
    		d = 1.0D - d;
    		if(d < 0.0D) { d = 0.0D; }
    		if(d > 1.0D) { d = 1.0D; }
    		d *= d;
    		int j4 = (int)(255D * d);
    		int fadeIn = 0;
    		if(j4 < 255)
    		{
    			fadeIn = (j4 << 24);
    		}
    		this.drawRect(0, 0, mc.displayWidth, mc.displayHeight, 0 - fadeIn);
    	}
    }
}
