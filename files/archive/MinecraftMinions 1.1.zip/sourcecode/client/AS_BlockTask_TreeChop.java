package net.minecraft.src;

import java.util.*;

/**
 * BlockTask specifically designed to harvest any tree originating from one Block
 * 
 * 
 * @author AtomicStryker
 */

public class AS_BlockTask_TreeChop extends AS_BlockTask
{
	
    public AS_BlockTask_TreeChop(AS_Minion_Job_Manager boss, AS_EntityMinion input, int ix, int iy, int iz)
    {
    	super(boss, input, ix, iy, iz);
    	
    	this.setTaskDuration(5000L);
    }
    
    private int treeBlocks = 0;
    private int treeBlockID;
    private int treeBlockmetadata;

    public void onUpdate()
    {
    	super.onUpdate();
    }
    
    public void onFinishedTask()
    {
    	super.onFinishedTask();
    	
    	// count tree wood blocks, place wood in minion inventory, destroy tree
    	chopTree();
    	
    	if (treeBlockID != 0)
    	{
    		placeWoodInMinionInventory(this.worker);
    	}
    }
    
    private void placeWoodInMinionInventory(AS_EntityMinion output)
    {
    	ItemStack woodStack = Block.blocksList[treeBlockID].createStackedBlock(treeBlockmetadata);
    	woodStack.stackSize = treeBlocks;
    	
    	if (!output.inventory.addItemStackToInventory(woodStack))
    	{
    		EntityItem item = new EntityItem(output.worldObj, output.posX, output.posY - 0.30000001192092896D + (double)output.getEyeHeight(), output.posZ, woodStack);
    		item.delayBeforeCanPickup = 40;
    		output.worldObj.spawnEntityInWorld(item);
    	}
    }
    
    private void chopTree()
    {
    	treeBlockID = this.worker.worldObj.getBlockId(posX, posY, posZ);
    	treeBlockmetadata = this.worker.worldObj.getBlockMetadata(posX, posY, posZ);
    	chopTreeBlockRecursive(posX, posY, posZ);
    }
    
    private void chopTreeBlockRecursive(int ix, int iy, int iz)
    {
        byte one = 1;
        for (int xIter = -one; xIter <= one; xIter++)
        {
            for (int zIter = -one; zIter <= one; zIter++)
            {
                for (int yIter = 0; yIter <= one; yIter++)
                {
                    if (this.worker.worldObj.getBlockId(ix + xIter, iy + yIter, iz + zIter) == treeBlockID)
                    {
                        if (this.worker.worldObj.setBlockWithNotify(ix + xIter, iy + yIter, iz + zIter, 0))
                        {
                        	treeBlocks++;
                        	chopTreeBlockRecursive(ix + xIter, iy + yIter, iz + zIter);
                        }
                    }
                }
            }
        }
    }

}
