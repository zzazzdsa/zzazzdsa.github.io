package net.minecraft.src;

import java.io.*;
import java.util.*;

import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import net.minecraft.client.Minecraft;

/**
 * Minion Mod main class, provides all the MC and SMP interfaces
 * Client side class
 * 
 * @author AtomicStryker
 */

public class mod_Minions extends BaseModMp
{
	private static long loadTime;
	public static Minecraft mcinstance;
	public static BaseModMp instance;
	private World worldObj;
	
	private String s_MenuKey = "M";
	private int i_MenuKey = Keyboard.getKeyIndex(s_MenuKey);
	
	private static File configfile = new File(Minecraft.getMinecraftDir(), "mods/mod_minions_evils.cfg");
	
	public static final Item itemMastersStaff = (new AS_ItemMastersStaff(2527)).setIconIndex(ModLoader.addOverride("/gui/items.png", "/mod_minions/masterstaff.png")).setItemName("Master's Staff");
	private static MovingObjectPosition targetObjectMouseOver;
	
	public static ArrayList foundTreeBlocks = new ArrayList();
	public static ArrayList runningJobList = new ArrayList();
	public static ArrayList finishedJobList = new ArrayList();
	
	public static Map masterNames = new HashMap();
	public static Map masterCommits = new HashMap();
	
	public static boolean isSelectingMineArea = false;
	public static int mineAreaShape = 0;
	
	private static boolean hasMinionsSMPOverride = false;
	private static boolean hasAllMinionsSMPOverride = false;
	
	public static int evilDeedXPCost = 2;
	private static int minionsPerPlayer = 4;
	private boolean minionsInSavegame = false;
	
	public static ArrayList evilDoings = new ArrayList();
	
	@Override
    public void load()
    {		
		loadTime = System.currentTimeMillis();
		ModLoader.SetInGameHook(this, true, false);
		
        ModLoader.AddName(itemMastersStaff, "Master's Staff");
        /*
        ModLoader.AddRecipe(new ItemStack(mastersHand, 1), new Object[]
        {
            " # ", " # ", "###", Character.valueOf('#'), Item.stick
        });
        */
        
        ModLoaderMp.RegisterNetClientHandlerEntity(AS_EntityMinion.class, 85);
        
        // ModLoaderMp.RegisterGUI(this, 133);
        // ModLoaderMp.RegisterGUI(this, 134);
        
        instance = this;
        initializeSettingsFile();
        
        if (minionsInSavegame)
        {
        	ModLoader.RegisterEntityID(AS_EntityMinion.class, "Minion", 17);
        }
    }
    
	@Override
    public void ModsLoaded()
    {
    	getViableTreeBlocks();
    }
    
	@Override
    public String getVersion()
    {
        return "1.1";
    }
	
	@Override
    public void AddRenderer(Map var1)
    {
        var1.put(AS_EntityMinion.class, new AS_RenderMinion(new AS_ModelMinion(), 0.25F));
        var1.put(AS_RenderEntLahwran_Minions.class, new AS_MinionsRenderHook(ModLoader.getMinecraftInstance()));
    }
    
	@Override
	public boolean OnTickInGame(float derp, net.minecraft.client.Minecraft mc)
	{
		mcinstance = mc;
		if (mc.thePlayer == null || mc.theWorld == null) return false;
		
		if (mc.theWorld != worldObj)
		{
			boolean newGame = worldObj == null;
			worldObj = mc.theWorld;
			worldObj.addWeatherEffect(new AS_RenderEntLahwran_Minions(mc, worldObj));
			
			if (!worldObj.isRemote && !newGame)
			{
				masterNames = new HashMap();
			}
		}
		
		Iterator iter = runningJobList.iterator();
		while (iter.hasNext())
		{
			if (finishedJobList.contains(iter))
			{
				finishedJobList.remove(iter);
				runningJobList.remove(iter);
			}
			else
			{
				((AS_Minion_Job_Manager) iter.next()).onJobUpdateTick();
			}
		}
		
		// Menu
		if (Keyboard.isKeyDown(i_MenuKey) && mc.currentScreen == null)
		{
			mcinstance.displayGuiScreen(new AS_GuiMinionMenu(mc.thePlayer));
		}
		
		if (isSelectingMineArea)
		{
			if (mcinstance.objectMouseOver != null && mcinstance.objectMouseOver.typeOfHit == EnumMovingObjectType.TILE)
			{
				int x = mcinstance.objectMouseOver.blockX;
				int y = mcinstance.objectMouseOver.blockY;
				int z = mcinstance.objectMouseOver.blockZ;
				
				if (mineAreaShape == 0)
				{
					AS_MinionsRenderHook.setSelectionPoint(0, x, y, z);
					AS_MinionsRenderHook.setSelectionPoint(1, x+4, y, z+4);
					
					AS_MinionsRenderHook.deleteAdditionalCubes();
					AS_MinionsRenderHook.addAdditionalCube(x+1, y-1, z);
					AS_MinionsRenderHook.addAdditionalCube(x+2, y-2, z);
					AS_MinionsRenderHook.addAdditionalCube(x+3, y-3, z);
				}
				else if (mineAreaShape == 1)
				{
					AS_MinionsRenderHook.setSelectionPoint(0, x, y, z);
					AS_MinionsRenderHook.setSelectionPoint(1, x, y+1, z);
				}
			}
		}
		else
		{
			AS_MinionsRenderHook.deleteSelection();
		}
		
		return true;
	}
	
	public static void onJobHasFinished(AS_Minion_Job_Manager input)
	{
		if (!finishedJobList.contains(input))
		{
			finishedJobList.add(input);
		}
	}
	
	private static void cancelRunningJobsForMaster(String name)
	{
		AS_Minion_Job_Manager temp;
		Iterator iter = runningJobList.iterator();
		while (iter.hasNext())
		{
			temp = (AS_Minion_Job_Manager) iter.next();
			if (temp != null && temp.masterName != null && temp.masterName.equals(name))
			{
				temp.onJobFinished();
			}
		}
	}
	
	public static void MinionLoadRegister(AS_EntityMinion ent)
	{
		if (ent.masterUsername == null)
		{
			System.out.println("Loaded Minion without masterName, killing");
			ent.setEntityDead();
			return;
		}
		
		System.out.println("Loaded Minion, re-registering master: "+ent.masterUsername);
		String mastername = ent.masterUsername;
		
		if (!masterNames.containsKey(mastername))
		{
			masterNames.put(mastername, null);
		}
		AS_EntityMinion[] array = (AS_EntityMinion[]) masterNames.get(mastername);
		if (array == null)
		{
			System.out.println("registering new key for "+mastername);
			array = new AS_EntityMinion[1];
			array[0] = ent;
			masterNames.put(mastername, array);
		}
		else
		{
			if (array.length >= minionsPerPlayer)
			{
				System.out.println("Adding a minion too many for "+mastername+", killing it NOW");
				ent.setEntityDead();
				return;
			}
			
			AS_EntityMinion[] arrayplusone = new AS_EntityMinion[array.length+1];
			int index = 0;
			while (index < array.length)
			{
				arrayplusone[index] = array[index];
				index++;
			}
			arrayplusone[array.length] = ent;
			masterNames.put(mastername, arrayplusone);
			System.out.println("adding additional minion for "+mastername+", array now: "+arrayplusone);
		}
	}
	
	public static void onMasterAddedEvil(EntityPlayer player)
	{
		if (masterCommits.get(player.username) != null)
		{
			int commits = (Integer) masterCommits.get(player.username);
			commits++;
			
			if (commits == 4)
			{
				player.worldObj.playSoundAtEntity(player, "mod_minions.thegodshaverewardedyouroffering", 1.0F, 1.0F);
				// give master item to player
				player.inventory.addItemStackToInventory(new ItemStack(mod_Minions.itemMastersStaff.shiftedIndex, 1, 0));
			}
			else
			{
				masterCommits.put(player.username, commits);
				player.worldObj.playSoundAtEntity(player, "mod_minions.thegodsarepleaseedwithyoursacrifice", 1.0F, 1.0F);
			}
		}
		else
		{
			masterCommits.put(player.username, 1);
			player.worldObj.playSoundAtEntity(player, "mod_minions.thegodsarepleaseedwithyoursacrifice", 1.0F, 1.0F);
		}
	}
	
	public static boolean hasPlayerMinions(EntityPlayer player)
	{
		if (player.worldObj.isRemote)
		{
			return hasMinionsSMPOverride;
		}
		return (masterNames.get(player.username) != null);
	}
	
	@Override
    public GuiScreen HandleGUI(int inventoryType) 
    {
    	if(inventoryType == 133)
    	{
    		return new AS_GuiMinionMenu(ModLoader.getMinecraftInstance().thePlayer);
    	}
    	else if(inventoryType == 134)
    	{
    		return new AS_GuiDeedMenu(ModLoader.getMinecraftInstance().thePlayer);
    	}
    	else return null;
    }
	
	@Override
    public void HandlePacket(Packet230ModLoader packet)
	{
		if (packet.packetType == 0) // HasMinions override call from server to client
		{
			hasMinionsSMPOverride = (packet.dataInt[0] != 0);
			hasAllMinionsSMPOverride = (packet.dataInt[1] != 0);
			//System.out.println("Client hasMinionsSMPOverride = "+hasMinionsSMPOverride+", hasAllMinionsSMPOverride: "+hasAllMinionsSMPOverride);
		}
		else if (packet.packetType == 1) // Evil Deed Done Packet from client to server
		{

		}
		else if (packet.packetType == 2) // pickup entity from client to server
		{

		}
		else if (packet.packetType == 3) // minion drop command client to server
		{

		}
		else if (packet.packetType == 4) // minion spawn command client to server
		{

		}
		else if (packet.packetType == 5) // tree chop command client to server
		{

		}
		else if (packet.packetType == 6) // stairwell command client to server
		{

		}
		else if (packet.packetType == 7) // stripmine command client to server
		{

		}
		else if (packet.packetType == 8) // chest assign command client to server
		{

		}
		else if (packet.packetType == 9) // moveto command client to server
		{

		}
		else if (packet.packetType == 10) // mine ore vein command client to server
		{

		}
		else if (packet.packetType == 11) // follow master command client to server
		{

		}
		else if (packet.packetType == 12) // play sounds, server to client
		{
			int entID = packet.dataInt[0];
			String sound = packet.dataString[0];
			Entity temp = null;
			boolean found = false;
			
			Iterator iter = mcinstance.theWorld.loadedEntityList.iterator();
			while (iter.hasNext())
			{
				temp = (Entity) iter.next();
				if (temp.entityId == entID)
				{
					found = true;
					break;
				}
			}
			if (found)
			{
				mcinstance.theWorld.playSoundAtEntity(temp, sound, 1.0F, 1.0F);
			}
		}
		else if (packet.packetType == 13) // demand serverside XP cost setting, bidirectional
		{
			if (evilDeedXPCost != packet.dataInt[0])
			{
				evilDeedXPCost = packet.dataInt[0];
				
				if (this.mcinstance.currentScreen instanceof AS_GuiMinionMenu)
				{
					this.mcinstance.currentScreen = null;
					
					if (evilDeedXPCost != -1)
					{
						this.mcinstance.ingameGUI.addChatMessage("Server says you don't have enough XP for Evil Deeds");
					}
					else
					{
						this.mcinstance.ingameGUI.addChatMessage("Server says Minions are unobtainable through Evil Deeds here");
					}
				}
			}
		}
	}
	
	private static void orderMinionToPickupEntity(EntityPlayer playerEnt, EntityLiving target)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.username);
		
		for (int i = 0; i < minions.length; i++)
		{
			minions[i].master = playerEnt;

			if (minions[i].riddenByEntity == null)
			{
				minions[i].targetEntityToGrab = (EntityLiving) target;
				minions[i].worldObj.playSoundAtEntity(minions[i], "mod_minions.grabanimalorder", 1.0F, 1.0F);
				break;
			}
		}
	}
	
	private static void orderMinionToDrop(EntityPlayer playerEnt, AS_EntityMinion minion)
	{
		if (minion.riddenByEntity != null)
		{
			minion.worldObj.playSoundAtEntity(minion, "mod_minions.foryou", 1.0F, 1.0F);
			minion.riddenByEntity.mountEntity(null);
		}
		else if (minion.inventory.containsItems())
		{
			minion.worldObj.playSoundAtEntity(minion, "mod_minions.foryou", 1.0F, 1.0F);
			minion.faceEntity(playerEnt, 180F, 180F);
			minion.inventory.dropAllItems();
		}
	}
	
	private static void spawnMinionsForPlayer(EntityPlayer playerEnt, int x, int y, int z)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.username);
		
		if (minions == null || minions.length < minionsPerPlayer)
		{
			int prevArraySize = (minions == null) ? 0 : minions.length;
			AS_EntityMinion[] arrayplusone = new AS_EntityMinion[prevArraySize+1];
			int index = 0;
			while (index < prevArraySize)
			{
				arrayplusone[index] = minions[index];
				index++;
			}
			arrayplusone[prevArraySize] = new AS_EntityMinion(playerEnt.worldObj);
			arrayplusone[prevArraySize].setPosition(x, y+1, z);
			playerEnt.worldObj.spawnEntityInWorld(arrayplusone[prevArraySize]);
			arrayplusone[prevArraySize].setMaster(playerEnt);
			playerEnt.worldObj.playSoundAtEntity(arrayplusone[prevArraySize], "mod_minions.minionspawn", 1.0F, 1.0F);
			playerEnt.worldObj.spawnParticle("hugeexplosion", x, y, z, 0.0D, 0.0D, 0.0D);

			masterNames.put(playerEnt.username, arrayplusone);
			//System.out.println("spawned missing minion for "+var3.username);
		}
		
		orderMinionsToMoveTo(playerEnt, x, y, z);
	}
	
	private static void orderMinionsToChopTrees(EntityPlayer playerEnt, int x, int y, int z)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.username);
		
		for (int i = 0; i < minions.length; i++)
		{
			minions[i].master = playerEnt;
			minions[i].giveTask(null, true);
		}
		
		cancelRunningJobsForMaster(playerEnt.username);
		runningJobList.add(new AS_Minion_Job_TreeHarvest(minions, x, y, z));
		playerEnt.worldObj.playSoundAtEntity(playerEnt, "mod_minions.ordertreecutting", 1.0F, 1.0F);
	}
	
	private static void orderMinionsToDigStairWell(EntityPlayer playerEnt, int x, int y, int z)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.username);
		
		for (int i = 0; i < minions.length; i++)
		{
			minions[i].master = playerEnt;
			minions[i].giveTask(null, true);
		}
		
		// stairwell job
		cancelRunningJobsForMaster(playerEnt.username);
		runningJobList.add(new AS_Minion_Job_DigMineStairwell(minions, x, y-1, z));
		playerEnt.worldObj.playSoundAtEntity(playerEnt, "mod_minions.ordermineshaft", 1.0F, 1.0F);
	}
	
	private static void orderMinionsToDigStripMineShaft(EntityPlayer playerEnt, int x, int y, int z)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.username);
		
		for (int i = 0; i < minions.length; i++)
		{
			minions[i].master = playerEnt;
			minions[i].giveTask(null, true);
		}
		
		// strip mine job
		minions[0].master = playerEnt;
		runningJobList.add(new AS_Minion_Job_StripMine(minions, x, y-1, z));
		playerEnt.worldObj.playSoundAtEntity(playerEnt, "mod_minions.randomorder", 1.0F, 1.0F);
	}
	
	private static void orderMinionsToChestBlock(EntityPlayer playerEnt, int x, int y, int z)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.username);
		
		TileEntity chest;
		if ((chest = playerEnt.worldObj.getBlockTileEntity(x, y-1, z)) != null && chest instanceof TileEntityChest)
		{
			cancelRunningJobsForMaster(playerEnt.username);
			playerEnt.worldObj.playSoundAtEntity(playerEnt, "mod_minions.randomorder", 2.0F, 1.0F);
			for (int i = 0; i < minions.length; i++)
			{
				minions[i].master = playerEnt;
				minions[i].giveTask(null, true);
				minions[i].returnChest = (TileEntityChest) chest;
				minions[i].currentState = AS_EnumMinionState.RETURNING_GOODS;
			}
		}
	}
	
	private static void orderMinionsToMoveTo(EntityPlayer playerEnt, int x, int y, int z)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.username);
		
		cancelRunningJobsForMaster(playerEnt.username);
		playerEnt.worldObj.playSoundAtEntity(playerEnt, "mod_minions.randomorder", 1.0F, 0.8F);
		for (int i = 0; i < minions.length; i++)
		{
			minions[i].master = playerEnt;
			minions[i].giveTask(null, true);
			minions[i].currentState = AS_EnumMinionState.IDLE;
			minions[i].orderMinionToMoveTo(x, y, z, false);
		}
	}
	
	private static void orderMinionsToMineOre(EntityPlayer playerEnt, int x, int y, int z)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.username);
		
		if (isBlockValuable(playerEnt.worldObj.getBlockId(x, y-1, z)))
		{
			cancelRunningJobsForMaster(playerEnt.username);
			playerEnt.worldObj.playSoundAtEntity(playerEnt, "mod_minions.randomorder", 1.0F, 0.8F);
			for (int i = 0; i < minions.length; i++)
			{
				minions[i].master = playerEnt;

				if (!minions[i].hasTask())
				{
					minions[i].giveTask(new AS_BlockTask_MineOreVein(null, minions[i], x, y-1, z));
					break;
				}
			}
		}
	}
	
	private static void orderMinionsToFollow(EntityPlayer entPlayer)
	{
		cancelRunningJobsForMaster(entPlayer.username);
		
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(entPlayer.username);
		if (minions == null)
		{
			return;
		}
		
		entPlayer.worldObj.playSoundAtEntity(entPlayer, "mod_minions.orderfollowplayer", 1.0F, 0.8F);
		for (int i = 0; i < minions.length; i++)
		{
			minions[i].master = entPlayer;
			minions[i].giveTask(null, true);
			minions[i].currentState = AS_EnumMinionState.FOLLOWING_PLAYER;
		}
	}
	
	public static void OnMastersGloveRightClick(ItemStack var1, World worldObj, EntityPlayer playerEnt)
	{		
		targetObjectMouseOver = mcinstance.objectMouseOver; //mcinstance.renderViewEntity.rayTrace(30.0D, 1.0F);
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.username);
		//System.out.println("Master: "+playerEnt.username+", minionarray is: "+minions);
		Entity target;

		if (targetObjectMouseOver == null)
		{
			targetObjectMouseOver = mcinstance.renderViewEntity.rayTrace(30.0D, 1.0F);
		}

		if (targetObjectMouseOver == null)
		{

		}
		else if ((target = targetObjectMouseOver.entityHit) != null)
		{
			if (target instanceof EntityAnimal || target instanceof EntityPlayer)
			{
				if (worldObj.isRemote)
				{
					Packet230ModLoader packet = new Packet230ModLoader();
					packet.packetType = 2; // pickup entity command packet
					
					int[] dataint = new int[2];
					dataint[0] = playerEnt.entityId;
					dataint[1] = target.entityId;
					packet.dataInt = dataint;
					
					String[] datastring = new String[1];
					datastring[0] = playerEnt.username;
					packet.dataString = datastring;
					ModLoaderMp.SendPacket(instance, packet);
				}
				else
				{
					orderMinionToPickupEntity(playerEnt, (EntityLiving) target);
				}
			}
			else if (target instanceof AS_EntityMinion)
			{
				AS_EntityMinion minion = (AS_EntityMinion) target;
				
				if (worldObj.isRemote)
				{
					Packet230ModLoader packet = new Packet230ModLoader();
					packet.packetType = 3; // minion drop items command packet
					
					int[] dataint = new int[2];
					dataint[0] = playerEnt.entityId;
					dataint[1] = target.entityId;
					packet.dataInt = dataint;
					
					String[] datastring = new String[1];
					datastring[0] = playerEnt.username;
					packet.dataString = datastring;
					ModLoaderMp.SendPacket(instance, packet);
				}
				else
				{
					orderMinionToDrop(playerEnt, minion);
				}
			}
		}
		else if (targetObjectMouseOver.typeOfHit == EnumMovingObjectType.TILE)
		{
			int x = targetObjectMouseOver.blockX;
			int y = targetObjectMouseOver.blockY +1;
			int z = targetObjectMouseOver.blockZ;

			if (AS_AStarStatic.isPassableBlock(x, y-1, z))
			{
				y--;
			}

			if (worldObj.isRemote)
			{
				if (!hasAllMinionsSMPOverride)
				{
					Packet230ModLoader packet = new Packet230ModLoader();
					packet.packetType = 4; // minion spawn command packet
	
					int[] dataint = new int[4];
					dataint[0] = playerEnt.entityId;
					dataint[1] = x;
					dataint[2] = y;
					dataint[3] = z;
					packet.dataInt = dataint;
	
					String[] datastring = new String[1];
					datastring[0] = playerEnt.username;
					packet.dataString = datastring;
					ModLoaderMp.SendPacket(instance, packet);
					return;
				}
			}
			else
			{
				if (minions == null || minions.length < minionsPerPlayer)
				{
					spawnMinionsForPlayer(playerEnt, x, y, z);
					return;
				}
			}

			int ID = worldObj.getBlockId(x, y, z);
			TileEntity chest;
			
			if (foundTreeBlocks.contains(ID))
			{
				if (worldObj.isRemote)
				{
					Packet230ModLoader packet = new Packet230ModLoader();
					packet.packetType = 5; // treechop job command packet
					
					int[] dataint = new int[4];
					dataint[0] = playerEnt.entityId;
					dataint[1] = x;
					dataint[2] = y;
					dataint[3] = z;
					packet.dataInt = dataint;
					
					String[] datastring = new String[1];
					datastring[0] = playerEnt.username;
					packet.dataString = datastring;
					ModLoaderMp.SendPacket(instance, packet);
				}
				else
				{
					orderMinionsToChopTrees(playerEnt, x, y, z);
				}
			}
			else if (isSelectingMineArea)
			{
				if (mineAreaShape == 0)
				{
					if (worldObj.isRemote)
					{
						Packet230ModLoader packet = new Packet230ModLoader();
						packet.packetType = 6; // stairwell job command packet
						
						int[] dataint = new int[4];
						dataint[0] = playerEnt.entityId;
						dataint[1] = x;
						dataint[2] = y;
						dataint[3] = z;
						packet.dataInt = dataint;
						
						String[] datastring = new String[1];
						datastring[0] = playerEnt.username;
						packet.dataString = datastring;
						ModLoaderMp.SendPacket(instance, packet);
					}
					else
					{
						orderMinionsToDigStairWell(playerEnt, x, y, z);
					}

					isSelectingMineArea = false;
				}
				else if (mineAreaShape == 1)
				{
					if (worldObj.isRemote)
					{
						Packet230ModLoader packet = new Packet230ModLoader();
						packet.packetType = 7; // stripmine job command packet
						
						int[] dataint = new int[4];
						dataint[0] = playerEnt.entityId;
						dataint[1] = x;
						dataint[2] = y;
						dataint[3] = z;
						packet.dataInt = dataint;
						
						String[] datastring = new String[1];
						datastring[0] = playerEnt.username;
						packet.dataString = datastring;
						ModLoaderMp.SendPacket(instance, packet);
					}
					else
					{
						orderMinionsToDigStripMineShaft(playerEnt, x, y, z);
					}
					
					isSelectingMineArea = false;
				}
			}
			else if ((chest = worldObj.getBlockTileEntity(x, y-1, z)) != null && chest instanceof TileEntityChest)
			{
				if (worldObj.isRemote)
				{
					Packet230ModLoader packet = new Packet230ModLoader();
					packet.packetType = 8; // chest assign command packet
					
					int[] dataint = new int[4];
					dataint[0] = playerEnt.entityId;
					dataint[1] = x;
					dataint[2] = y;
					dataint[3] = z;
					packet.dataInt = dataint;
					
					String[] datastring = new String[1];
					datastring[0] = playerEnt.username;
					packet.dataString = datastring;
					ModLoaderMp.SendPacket(instance, packet);
				}
				else
				{
					orderMinionsToChestBlock(playerEnt, x, y, z);
				}
			}
			else if (AS_AStarStatic.isPassableBlock(x, y, z) && (minions != null || hasAllMinionsSMPOverride))
			{
				// check if player targets his own feet. if so, order minion carry
				if (MathHelper.floor_double(playerEnt.posX) == x
				&& MathHelper.floor_double(playerEnt.posZ) == z
				&& Math.abs(MathHelper.floor_double(playerEnt.posY) - y) < 3)
				{
					if (worldObj.isRemote)
					{
						Packet230ModLoader packet = new Packet230ModLoader();
						packet.packetType = 2; // pickup entity command packet
						
						int[] dataint = new int[2];
						dataint[0] = playerEnt.entityId;
						dataint[1] = playerEnt.entityId;
						packet.dataInt = dataint;
						
						String[] datastring = new String[1];
						datastring[0] = playerEnt.username;
						packet.dataString = datastring;
						ModLoaderMp.SendPacket(instance, packet);
					}
					else
					{
						orderMinionToPickupEntity(playerEnt, playerEnt);
					}
				}
				else
				{
					if (worldObj.isRemote)
					{
						Packet230ModLoader packet = new Packet230ModLoader();
						packet.packetType = 9; // moveto command packet
						
						int[] dataint = new int[4];
						dataint[0] = playerEnt.entityId;
						dataint[1] = x;
						dataint[2] = y;
						dataint[3] = z;
						packet.dataInt = dataint;
						
						String[] datastring = new String[1];
						datastring[0] = playerEnt.username;
						packet.dataString = datastring;
						ModLoaderMp.SendPacket(instance, packet);
					}
					else
					{
						orderMinionsToMoveTo(playerEnt, x, y, z);
					}
				}
			}
			else if (isBlockValuable(worldObj.getBlockId(x, y-1, z)))
			{
				if (worldObj.isRemote)
				{
					Packet230ModLoader packet = new Packet230ModLoader();
					packet.packetType = 10; // mine ore vein command packet
					
					int[] dataint = new int[4];
					dataint[0] = playerEnt.entityId;
					dataint[1] = x;
					dataint[2] = y;
					dataint[3] = z;
					packet.dataInt = dataint;
					
					String[] datastring = new String[1];
					datastring[0] = playerEnt.username;
					packet.dataString = datastring;
					ModLoaderMp.SendPacket(instance, packet);
				}
				else
				{
					orderMinionsToMineOre(playerEnt, x, y, z);
				}
			}
		}
	}

	public static void OnMastersGloveRightClickHeld(ItemStack var1, World var2, EntityPlayer var3)
	{
		if (var2.isRemote)
		{
			Packet230ModLoader packet = new Packet230ModLoader();
			packet.packetType = 11; // follow master command packet
			
			int[] dataint = new int[4];
			dataint[0] = var3.entityId;
			packet.dataInt = dataint;
			
			String[] datastring = new String[1];
			datastring[0] = var3.username;
			packet.dataString = datastring;
			ModLoaderMp.SendPacket(instance, packet);
		}
		else
		{
			orderMinionsToFollow(var3);
		}
	}
	
	private void getViableTreeBlocks()
	{		
		for (Block iter : Block.blocksList)
		{
			if (iter != null && iter.getBlockName() != null && (iter instanceof BlockLog || iter.getBlockName().contains("log")))
			{
				foundTreeBlocks.add(iter.blockID);
			}
		}
	}
	
	public static boolean isBlockIDViableTreeBlock(int ID)
	{
		return foundTreeBlocks.contains(ID);
	}
	
    void initializeSettingsFile()
    {
        File settingsFile = configfile;
         
        try
        {
            if (settingsFile.exists())
            {
                System.out.println("/mods/mod_minions_evils.cfg found and opened");
                BufferedReader var1 = new BufferedReader(new FileReader(settingsFile));

                String lineString;
                while ((lineString = var1.readLine()) != null)
                {
                    if (!lineString.startsWith("//"))
                    {
                        if (lineString.startsWith("minionsPerPlayer"))
                        {
                        	String[] stringArray = lineString.split(":");
                        	minionsPerPlayer = Integer.parseInt(stringArray[1]);
                            System.out.println("Config: Set minionsPerPlayer to "+minionsPerPlayer);
                        }
                        else if (lineString.startsWith("evilDeedXPCost"))
                        {
                        	String[] stringArray = lineString.split(":");
                        	evilDeedXPCost = Integer.parseInt(stringArray[1]);
                            System.out.println("Config: Set Evil Deed XP Cost to "+evilDeedXPCost);
                        }
                        else if (lineString.startsWith("minionMenuKey"))
                        {
                        	String[] stringArray = lineString.split(":");
                        	s_MenuKey = stringArray[1];
                        	i_MenuKey = Keyboard.getKeyIndex(s_MenuKey);
                            System.out.println("Config: Set Minion Menu button to "+s_MenuKey);
                        }
                        else if (lineString.startsWith("minionsInSavegame"))
                        {
                        	String[] stringArray = lineString.split(":");
                        	minionsInSavegame = (Integer.parseInt(stringArray[1]) != 0);
                            System.out.println("Config: Set persisting Minions "+minionsInSavegame);
                        }
                        else
                        {
                            String[] stringArray = lineString.split(":");
                            
                            AS_EvilDeed deed = new AS_EvilDeed(stringArray[0], stringArray[1], Integer.parseInt(stringArray[2]));
                            evilDoings.add(deed);
                        }
                    }
                }

                var1.close();
            }
            else
            {
            	System.out.println("Could not open /mods/mod_minions_evils.cfg, you suck");
            }
        }
        catch (Exception var6)
        {
            System.out.println("EXCEPTION BufferedReader: " + var6);
        }
    }
	
	public static boolean isBlockValuable(int blockID)
	{
		if (blockID == 0
		|| blockID == Block.dirt.blockID
		|| blockID == Block.grass.blockID
		|| blockID == Block.stone.blockID
		|| blockID == Block.cobblestone.blockID
		|| blockID == Block.gravel.blockID
		|| blockID == Block.sand.blockID
		|| blockID == Block.leaves.blockID
		|| blockID == Block.obsidian.blockID
		|| blockID == Block.bedrock.blockID
		|| blockID == Block.stairCompactCobblestone.blockID)
		{
			return false;
		}
		
		return true;
	}
	
	public static void requestXPSettingFromServer()
	{
		if (mcinstance.thePlayer.worldObj.isRemote)
		{
			Packet230ModLoader packet = new Packet230ModLoader();
			packet.packetType = 13; // xp setting request, bidirectional
			ModLoaderMp.SendPacket(instance, packet);
		}
	}

	// HUD mask i might want to use someday
    private void renderPumpkinBlur()
    {    	
        ScaledResolution var5 = new ScaledResolution(mcinstance.gameSettings, mcinstance.displayWidth, mcinstance.displayHeight);
        int var1 = var5.getScaledWidth();
        int var2 = var5.getScaledHeight();
    	
        GL11.glDisable(2929 /*GL_DEPTH_TEST*/);
        GL11.glDepthMask(false);
        GL11.glBlendFunc(770, 771);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        GL11.glDisable(3008 /*GL_ALPHA_TEST*/);
        GL11.glBindTexture(3553 /*GL_TEXTURE_2D*/, mcinstance.renderEngine.getTexture("%blur%/misc/pumpkinblur.png"));
        Tessellator var3 = Tessellator.instance;
        var3.startDrawingQuads();
        var3.addVertexWithUV(0.0D, (double)var2, -90.0D, 0.0D, 1.0D);
        var3.addVertexWithUV((double)var1, (double)var2, -90.0D, 1.0D, 1.0D);
        var3.addVertexWithUV((double)var1, 0.0D, -90.0D, 1.0D, 0.0D);
        var3.addVertexWithUV(0.0D, 0.0D, -90.0D, 0.0D, 0.0D);
        var3.draw();
        GL11.glDepthMask(true);
        GL11.glEnable(2929 /*GL_DEPTH_TEST*/);
        GL11.glEnable(3008 /*GL_ALPHA_TEST*/);
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    }

}
