package net.minecraft.server;

import java.util.ArrayList;
import java.util.Iterator;

public class AS_Minion_Job_Manager
{
    protected ArrayList workerList;
    public ChunkCoordinates pointOfOrigin;
    protected ArrayList jobQueue;
    public String masterName;

    public AS_Minion_Job_Manager()
    {
        workerList = new ArrayList();
        jobQueue = new ArrayList();
        masterName = null;
    }

    public AS_Minion_Job_Manager(AS_EntityMinion aas_entityminion[], int i, int j, int k)
    {
        workerList = new ArrayList();
        jobQueue = new ArrayList();
        masterName = null;
        for (int l = 0; l < aas_entityminion.length; l++)
        {
            workerList.add(aas_entityminion[l]);
            aas_entityminion[l].currentState = AS_EnumMinionState.AWAITING_JOB;
            aas_entityminion[l].lastOrderedState = AS_EnumMinionState.WALKING_TO_COORDS;
            if (aas_entityminion[l].passenger != null)
            {
                aas_entityminion[l].passenger.mount(null);
            }
            if (masterName == null)
            {
                masterName = aas_entityminion[l].masterUsername;
            }
        }

        pointOfOrigin = new ChunkCoordinates(i, j, k);
    }

    public AS_EntityMinion getNearestAvailableWorker(int i, int j, int k)
    {
        Iterator iterator = workerList.iterator();
        AS_EntityMinion as_entityminion1 = null;
        double d = 9999D;
        do
        {
            if (!iterator.hasNext())
            {
                break;
            }
            AS_EntityMinion as_entityminion = (AS_EntityMinion)iterator.next();
            if (as_entityminion.currentState == AS_EnumMinionState.AWAITING_JOB && !as_entityminion.hasTask() || as_entityminion.currentState == AS_EnumMinionState.IDLE && as_entityminion.lastOrderedState == AS_EnumMinionState.RETURNING_GOODS)
            {
                double d1 = as_entityminion.e(i, j, k);
                if (d1 < d)
                {
                    as_entityminion1 = as_entityminion;
                    d = d1;
                }
            }
        }
        while (true);
        return as_entityminion1;
    }

    public AS_EntityMinion getAnyAvailableWorker()
    {
        if (workerList.isEmpty())
        {
            return null;
        }
        for (Iterator iterator = workerList.iterator(); iterator.hasNext();)
        {
            AS_EntityMinion as_entityminion = (AS_EntityMinion)iterator.next();
            if (as_entityminion.currentState == AS_EnumMinionState.AWAITING_JOB && !as_entityminion.hasTask())
            {
                return as_entityminion;
            }
        }

        return null;
    }

    public void setWorkerFree(AS_EntityMinion as_entityminion)
    {
        as_entityminion.giveTask(null);
        workerList.remove(as_entityminion);
        if (workerList.isEmpty())
        {
            onJobFinished();
        }
    }

    public void onJobStarted()
    {
    }

    public void onJobUpdateTick()
    {
    }

    public void onJobFinished()
    {
        for (; !workerList.isEmpty(); setWorkerFree((AS_EntityMinion)workerList.get(0))) { }
        mod_Minions.onJobHasFinished(this);
    }
}
