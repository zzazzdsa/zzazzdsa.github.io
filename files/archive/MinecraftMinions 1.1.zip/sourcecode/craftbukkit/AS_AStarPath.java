package net.minecraft.server;

import java.util.ArrayList;

public class AS_AStarPath
{
    private volatile AS_AStarWorker worker;
    private volatile Thread thread;
    private World worldObj;
    private boolean isWorking;
    private ArrayList pathResult;
    private AS_IAStarPathedEntity pathedEntity;
    private long timeStarted;

    public AS_AStarPath(World world)
    {
        isWorking = false;
        timeStarted = 0L;
        worldObj = world;
    }

    public AS_AStarPath(World world, AS_IAStarPathedEntity as_iastarpathedentity)
    {
        isWorking = false;
        timeStarted = 0L;
        worldObj = world;
        pathedEntity = as_iastarpathedentity;
    }

    public boolean isBusy()
    {
        if (timeStarted != 0L && System.currentTimeMillis() - timeStarted > 5000L)
        {
            timeStarted = 0L;
            OnNoPathAvailable();
        }
        return isWorking;
    }

    public void getPath(int i, int j, int k, int l, int i1, int j1, boolean flag)
    {
        AS_AStarNode as_astarnode = new AS_AStarNode(i, j, k, 0);
        AS_AStarNode as_astarnode1 = new AS_AStarNode(l, i1, j1, -1);
        getPath(as_astarnode, as_astarnode1, flag);
    }

    public void getPath(AS_AStarNode as_astarnode, AS_AStarNode as_astarnode1, boolean flag)
    {
        if (isWorking)
        {
            stopPathSearch();
        }
        timeStarted = System.currentTimeMillis();
        worker = new AS_AStarWorker(this);
        worker.setup(worldObj, as_astarnode, as_astarnode1, flag);
        thread = new Thread(worker);
        thread.start();
        isWorking = true;
    }

    public void OnFoundPath(ArrayList arraylist)
    {
        flushWorker();
        pathResult = arraylist;
        isWorking = false;
        if (pathedEntity != null)
        {
            pathedEntity.OnFoundPath(arraylist);
        }
    }

    public void OnNoPathAvailable()
    {
        flushWorker();
        isWorking = false;
        if (pathedEntity != null)
        {
            pathedEntity.OnNoPathAvailable();
        }
    }

    public void stopPathSearch()
    {
        flushWorker();
        isWorking = false;
        if (pathedEntity != null)
        {
            pathedEntity.OnNoPathAvailable();
        }
    }

    private void flushWorker()
    {
        timeStarted = 0L;
        if (worker != null)
        {
            if (thread != null)
            {
                thread.interrupt();
            }
            worker = null;
            thread = null;
        }
    }
}
