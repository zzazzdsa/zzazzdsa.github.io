package net.minecraft.server;

public class AS_ItemMastersStaff extends Item
{
    public AS_ItemMastersStaff(int i)
    {
        super(i);
        maxStackSize = 1;
    }

    public void a(ItemStack itemstack, World world, EntityHuman entityhuman, int i)
    {
    }

    public ItemStack b(ItemStack itemstack, World world, EntityHuman entityhuman)
    {
        return itemstack;
    }

    public int c(ItemStack itemstack)
    {
        return 0x11940;
    }

    public EnumAnimation d(ItemStack itemstack)
    {
        return EnumAnimation.d;
    }

    public ItemStack a(ItemStack itemstack, World world, EntityHuman entityhuman)
    {
        entityhuman.a(itemstack, c(itemstack));
        return itemstack;
    }
}
