package net.minecraft.server;

public class AS_InventoryMinion
    implements IInventory
{
    public ItemStack mainInventory[];
    public AS_EntityMinion minion;
    public boolean inventoryChanged;

    public AS_InventoryMinion(AS_EntityMinion as_entityminion)
    {
        mainInventory = new ItemStack[24];
        inventoryChanged = false;
        minion = as_entityminion;
    }

    public boolean containsItems()
    {
        return getFirstEmptyStack() != 0;
    }

    private int getInventorySlotContainItem(int i)
    {
        for (int j = 0; j < mainInventory.length; j++)
        {
            if (mainInventory[j] != null && mainInventory[j].id == i)
            {
                return j;
            }
        }

        return -1;
    }

    private int getInventorySlotContainItemAndDamage(int i, int j)
    {
        for (int k = 0; k < mainInventory.length; k++)
        {
            if (mainInventory[k] != null && mainInventory[k].id == i && mainInventory[k].getData() == j)
            {
                return k;
            }
        }

        return -1;
    }

    private int storeItemStack(ItemStack itemstack)
    {
        for (int i = 0; i < mainInventory.length; i++)
        {
            if (mainInventory[i] != null && mainInventory[i].id == itemstack.id && mainInventory[i].isStackable() && mainInventory[i].count < mainInventory[i].getMaxStackSize() && mainInventory[i].count < getMaxStackSize() && (!mainInventory[i].usesData() || mainInventory[i].getData() == itemstack.getData()) && ItemStack.equals(mainInventory[i], itemstack))
            {
                return i;
            }
        }

        return -1;
    }

    private int getFirstEmptyStack()
    {
        for (int i = 0; i < mainInventory.length; i++)
        {
            if (mainInventory[i] == null)
            {
                return i;
            }
        }

        return -1;
    }

    private int storePartialItemStack(ItemStack itemstack)
    {
        int i = itemstack.id;
        int j = itemstack.count;
        if (itemstack.getMaxStackSize() == 1)
        {
            int k = getFirstEmptyStack();
            if (k < 0)
            {
                return j;
            }
            if (mainInventory[k] == null)
            {
                mainInventory[k] = ItemStack.b(itemstack);
            }
            return 0;
        }
        int l = storeItemStack(itemstack);
        if (l < 0)
        {
            l = getFirstEmptyStack();
        }
        if (l < 0)
        {
            return j;
        }
        if (mainInventory[l] == null)
        {
            mainInventory[l] = new ItemStack(i, 0, itemstack.getData());
            if (itemstack.hasTag())
            {
                mainInventory[l].setTag((NBTTagCompound)itemstack.getTag().clone());
            }
        }
        int i1 = j;
        if (j > mainInventory[l].getMaxStackSize() - mainInventory[l].count)
        {
            i1 = mainInventory[l].getMaxStackSize() - mainInventory[l].count;
        }
        if (i1 > getMaxStackSize() - mainInventory[l].count)
        {
            i1 = getMaxStackSize() - mainInventory[l].count;
        }
        if (i1 == 0)
        {
            return j;
        }
        else
        {
            j -= i1;
            mainInventory[l].count += i1;
            mainInventory[l].b = 5;
            return j;
        }
    }

    public boolean consumeInventoryItem(int i)
    {
        int j = getInventorySlotContainItem(i);
        if (j < 0)
        {
            return false;
        }
        if (--mainInventory[j].count <= 0)
        {
            mainInventory[j] = null;
        }
        return true;
    }

    public boolean hasItem(int i)
    {
        int j = getInventorySlotContainItem(i);
        return j >= 0;
    }

    public boolean addItemStackToInventory(ItemStack itemstack)
    {
        if (itemstack.id > 0 && itemstack.d() && itemstack.f())
        {
            int i = getFirstEmptyStack();
            if (i >= 0)
            {
                mainInventory[i] = ItemStack.b(itemstack);
                mainInventory[i].b = 5;
                itemstack.count = 0;
                return true;
            }
            else
            {
                return false;
            }
        }
        int j;
        do
        {
            j = itemstack.count;
            itemstack.count = storePartialItemStack(itemstack);
        }
        while (itemstack.count > 0 && itemstack.count < j);
        return itemstack.count < j;
    }

    public ItemStack splitStack(int i, int j)
    {
        ItemStack aitemstack[] = mainInventory;
        if (i >= mainInventory.length)
        {
            i -= mainInventory.length;
        }
        if (aitemstack[i] != null)
        {
            if (aitemstack[i].count <= j)
            {
                ItemStack itemstack = aitemstack[i];
                aitemstack[i] = null;
                return itemstack;
            }
            ItemStack itemstack1 = aitemstack[i].a(j);
            if (aitemstack[i].count == 0)
            {
                aitemstack[i] = null;
            }
            return itemstack1;
        }
        else
        {
            return null;
        }
    }

    public void setItem(int i, ItemStack itemstack)
    {
        ItemStack aitemstack[] = mainInventory;
        if (i >= aitemstack.length)
        {
            i -= aitemstack.length;
        }
        aitemstack[i] = itemstack;
    }

    public NBTTagList writeToNBT(NBTTagList nbttaglist)
    {
        for (int i = 0; i < mainInventory.length; i++)
        {
            if (mainInventory[i] != null)
            {
                NBTTagCompound nbttagcompound = new NBTTagCompound();
                nbttagcompound.setByte("Slot", (byte)i);
                mainInventory[i].b(nbttagcompound);
                nbttaglist.add(nbttagcompound);
            }
        }

        return nbttaglist;
    }

    public void readFromNBT(NBTTagList nbttaglist)
    {
        mainInventory = new ItemStack[36];
        for (int i = 0; i < nbttaglist.size(); i++)
        {
            NBTTagCompound nbttagcompound = (NBTTagCompound)nbttaglist.get(i);
            int j = nbttagcompound.getByte("Slot") & 0xff;
            ItemStack itemstack = ItemStack.a(nbttagcompound);
            if (itemstack != null && j >= 0 && j < mainInventory.length)
            {
                mainInventory[j] = itemstack;
            }
        }
    }

    public int getSize()
    {
        return mainInventory.length + 4;
    }

    public ItemStack getItem(int i)
    {
        ItemStack aitemstack[] = mainInventory;
        if (i >= aitemstack.length)
        {
            i -= aitemstack.length;
        }
        return aitemstack[i];
    }

    public String getName()
    {
        return "MinionInventory";
    }

    public int getMaxStackSize()
    {
        return 64;
    }

    public void dropAllItems()
    {
        for (int i = 0; i < mainInventory.length; i++)
        {
            if (mainInventory[i] != null)
            {
                minion.dropMinionItemWithRandomChoice(mainInventory[i]);
                mainInventory[i] = null;
            }
        }
    }

    public void putAllItemsToChest(TileEntityChest tileentitychest)
    {
        for (int i = 0; i < mainInventory.length; i++)
        {
            if (mainInventory[i] == null)
            {
                continue;
            }
            if (addItemStackToChest(tileentitychest, mainInventory[i]) || tileentitychest.d != null && addItemStackToChest(tileentitychest.d, mainInventory[i]) || tileentitychest.c != null && addItemStackToChest(tileentitychest.c, mainInventory[i]) || tileentitychest.b != null && addItemStackToChest(tileentitychest.b, mainInventory[i]) || tileentitychest.e != null && addItemStackToChest(tileentitychest.e, mainInventory[i]))
            {
                mainInventory[i] = null;
            }
            else
            {
                dropAllItems();
                return;
            }
        }
    }

    private boolean addItemStackToChest(TileEntityChest tileentitychest, ItemStack itemstack)
    {
        if (itemstack.id > 0 && itemstack.d() && itemstack.f())
        {
            int i = getChestFirstEmptyStack(tileentitychest);
            if (i >= 0)
            {
                tileentitychest.setItem(i, ItemStack.b(itemstack));
                tileentitychest.getItem(i).b = 5;
                itemstack.count = 0;
                return true;
            }
            else
            {
                return false;
            }
        }
        int j;
        do
        {
            j = itemstack.count;
            itemstack.count = storePartialItemStackInChest(tileentitychest, itemstack);
        }
        while (itemstack.count > 0 && itemstack.count < j);
        return itemstack.count < j;
    }

    private int storeItemStackInChest(TileEntityChest tileentitychest, ItemStack itemstack)
    {
        for (int i = 0; i < tileentitychest.getSize(); i++)
        {
            if (tileentitychest.getItem(i) != null && tileentitychest.getItem(i).id == itemstack.id && tileentitychest.getItem(i).isStackable() && tileentitychest.getItem(i).count < tileentitychest.getItem(i).getMaxStackSize() && tileentitychest.getItem(i).count < tileentitychest.getMaxStackSize() && (!tileentitychest.getItem(i).usesData() || tileentitychest.getItem(i).getData() == itemstack.getData()) && ItemStack.equals(tileentitychest.getItem(i), itemstack))
            {
                return i;
            }
        }

        return -1;
    }

    private int getChestFirstEmptyStack(TileEntityChest tileentitychest)
    {
        for (int i = 0; i < tileentitychest.getSize(); i++)
        {
            if (tileentitychest.getItem(i) == null)
            {
                return i;
            }
        }

        return -1;
    }

    private int storePartialItemStackInChest(TileEntityChest tileentitychest, ItemStack itemstack)
    {
        int i = itemstack.id;
        int j = itemstack.count;
        if (itemstack.getMaxStackSize() == 1)
        {
            int k = getChestFirstEmptyStack(tileentitychest);
            if (k < 0)
            {
                return j;
            }
            if (tileentitychest.getItem(k) == null)
            {
                tileentitychest.setItem(k, ItemStack.b(itemstack));
            }
            return 0;
        }
        int l = storeItemStackInChest(tileentitychest, itemstack);
        if (l < 0)
        {
            l = getChestFirstEmptyStack(tileentitychest);
        }
        if (l < 0)
        {
            return j;
        }
        if (tileentitychest.getItem(l) == null)
        {
            tileentitychest.setItem(l, new ItemStack(i, 0, itemstack.getData()));
            if (itemstack.hasTag())
            {
                tileentitychest.getItem(l).setTag((NBTTagCompound)itemstack.getTag().clone());
            }
        }
        int i1 = j;
        if (j > tileentitychest.getItem(l).getMaxStackSize() - tileentitychest.getItem(l).count)
        {
            i1 = tileentitychest.getItem(l).getMaxStackSize() - tileentitychest.getItem(l).count;
        }
        if (i1 > tileentitychest.getMaxStackSize() - tileentitychest.getItem(l).count)
        {
            i1 = tileentitychest.getMaxStackSize() - tileentitychest.getItem(l).count;
        }
        if (i1 == 0)
        {
            return j;
        }
        else
        {
            j -= i1;
            tileentitychest.getItem(l).count += i1;
            tileentitychest.getItem(l).b = 5;
            return j;
        }
    }

    public void update()
    {
        inventoryChanged = true;
    }

    public boolean a(EntityHuman entityhuman)
    {
        return entityhuman.name.equals(minion.masterUsername) && entityhuman.i(minion) <= 64D;
    }

    public boolean hasItemStack(ItemStack itemstack)
    {
        for (int i = 0; i < mainInventory.length; i++)
        {
            if (mainInventory[i] != null && mainInventory[i].c(itemstack))
            {
                return true;
            }
        }

        return false;
    }

    public void f()
    {
    }

    public void g()
    {
    }

    public void copyInventory(AS_InventoryMinion as_inventoryminion)
    {
        for (int i = 0; i < mainInventory.length; i++)
        {
            mainInventory[i] = ItemStack.b(as_inventoryminion.mainInventory[i]);
        }
    }

	@Override
	public ItemStack[] getContents()
	{
		return this.mainInventory;
	}
}
