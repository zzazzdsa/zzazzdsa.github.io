package net.minecraft.server;

import java.io.*;
import java.util.*;

import net.minecraft.server.MinecraftServer;

/**
 * Minion Mod main class, provides all the MC and SMP interfaces
 * Server side class
 * 
 * @author AtomicStryker
 */

public class mod_Minions extends BaseModMp
{
	private static long loadTime;
	public static MinecraftServer mcinstance;
	public static BaseModMp instance;
	
	private static File configfile = new File("mods/mod_minions_evils.cfg");
	
	public static final Item itemMastersStaff = (new AS_ItemMastersStaff(2527)).d(ModLoader.addOverride("/gui/items.png", "/mod_minions/masterstaff.png")).a("Master's Staff");
	private static MovingObjectPosition targetObjectMouseOver;
	
	public static ArrayList foundTreeBlocks = new ArrayList();
	public static ArrayList runningJobList = new ArrayList();
	public static ArrayList finishedJobList = new ArrayList();
	
	public static Map masterNames = new HashMap();
	public static Map masterCommits = new HashMap();
	
	private static int evilDeedXPCost = 2;
	private static int minionsPerPlayer = 4;
	private boolean minionsInSavegame = false;
	
	public static ArrayList evilDoings = new ArrayList();
	
	private boolean loaded = false;
	
    public void load()
    {
    	if (loaded) return;
    	loaded = true;
    	
		loadTime = System.currentTimeMillis();
		ModLoader.SetInGameHook(this, true, false);
        
		ModLoaderMp.RegisterEntityTrackerEntry(AS_EntityMinion.class, 85);
		ModLoaderMp.RegisterEntityTracker(AS_EntityMinion.class, 160, 5);
        
        instance = this;
        initializeSettingsFile();
        
        if (minionsInSavegame)
        {
        	ModLoader.RegisterEntityID(AS_EntityMinion.class, "Minion", 17);
        }
    }
    
    public void ModsLoaded()
    {
    	load();
    	getViableTreeBlocks();
    }
    
    public String getVersion()
    {
        return "1.1";
    }
	
    public void OnTickInGame(MinecraftServer mc)
	{
		mcinstance = mc;
		if (mc.worlds == null) return;
		
		Iterator iter = runningJobList.iterator();
		while (iter.hasNext())
		{
			if (finishedJobList.contains(iter))
			{
				finishedJobList.remove(iter);
				runningJobList.remove(iter);
			}
			else
			{
				((AS_Minion_Job_Manager) iter.next()).onJobUpdateTick();
			}
		}
	}
	
	public static void onJobHasFinished(AS_Minion_Job_Manager input)
	{
		if (!finishedJobList.contains(input))
		{
			finishedJobList.add(input);
		}
	}
	
	private static void cancelRunningJobsForMaster(String name)
	{
		AS_Minion_Job_Manager temp;
		Iterator iter = runningJobList.iterator();
		while (iter.hasNext())
		{
			temp = (AS_Minion_Job_Manager) iter.next();
			if (temp != null && temp.masterName != null && temp.masterName.equals(name))
			{
				temp.onJobFinished();
			}
		}
	}
	
	public static void MinionLoadRegister(AS_EntityMinion ent)
	{
		if (ent.masterUsername == null)
		{
			System.out.println("Loaded Minion without masterName, killing");
			ent.die();
			return;
		}
		
		//System.out.println("Loaded Minion, re-registering master");
		String mastername = ent.masterUsername;
		
		if (!masterNames.containsKey(mastername))
		{
			masterNames.put(mastername, null);
		}
		AS_EntityMinion[] array = (AS_EntityMinion[]) masterNames.get(mastername);
		if (array == null)
		{
			//System.out.println("registering new key for "+mastername);
			array = new AS_EntityMinion[1];
			array[0] = ent;
			masterNames.put(mastername, array);
		}
		else
		{
			if (array.length >= minionsPerPlayer)
			{
				System.out.println("Adding a minion too many for "+mastername+", killing it NOW");
				ent.die();
				return;
			}
			
			AS_EntityMinion[] arrayplusone = new AS_EntityMinion[array.length+1];
			int index = 0;
			while (index < array.length)
			{
				arrayplusone[index] = array[index];
				index++;
			}
			arrayplusone[array.length] = ent;
			masterNames.put(mastername, arrayplusone);
			//System.out.println("adding additional minion for "+mastername);
		}
	}
	
	public static void onMasterAddedEvil(EntityPlayer player)
	{
		if (masterCommits.get(player.name) != null)
		{
			int commits = (Integer) masterCommits.get(player.name);
			commits++;
			
			if (commits == 4)
			{
				sendSoundToClients(player, "mod_minions.thegodshaverewardedyouroffering");
				// give master item to player
				player.inventory.pickup(new ItemStack(mod_Minions.itemMastersStaff.id, 1, 0));
			}
			else
			{
				masterCommits.put(player.name, commits);
				sendSoundToClients(player, "mod_minions.thegodsarepleaseedwithyoursacrifice");
			}
		}
		else
		{
			masterCommits.put(player.name, 1);
			sendSoundToClients(player, "mod_minions.thegodsarepleaseedwithyoursacrifice");
		}
	}
	
	public static boolean hasPlayerMinions(EntityPlayer player)
	{
		return (masterNames.get(player.name) != null);
	}
	
	public static boolean hasAllMinions(EntityPlayer player)
	{
		AS_EntityMinion[] array = (AS_EntityMinion[]) masterNames.get(player.name);
		
		if (array == null) return false;
		return (array.length >= minionsPerPlayer);
	}
	
	private ArrayList findEntitiesWithID(int ID)
	{
		ArrayList result = new ArrayList();
		int i = 0;
		while(i < mcinstance.worlds.size() && mcinstance.worlds.get(i) != null)
		{
			List entList = mcinstance.worlds.get(i).entityList;
			Entity ent;
			Iterator iter = entList.iterator();
			{
				while (iter.hasNext())
				{
					ent = (Entity) iter.next();
					if (ent.id == ID)
					{
						result.add(ent);
					}
				}
			}
			i++;
		}
		return result;
	}
	
	private EntityPlayer findPlayerByName(String username)
	{
		List entList = mcinstance.serverConfigurationManager.players;
		EntityPlayer result;
		Iterator iter = entList.iterator();
		{
			while (iter.hasNext())
			{
				result = (EntityPlayer) iter.next();
				if (result.name.equals(username))
				{
					return result;
				}
			}
		}
		
		return null;
	}
	
	public void HandlePacket(Packet230ModLoader packet, EntityPlayer player)
	{
		if (packet.packetType == 0) // HasMinions override call from server to client
		{
			// done
		}
		else if (packet.packetType == 1) // Evil Deed Done Packet from client to server
		{
			String username = packet.dataString[0];
			
			//EntityPlayer player = this.findPlayerByName(username);
			
			if (player != null && player.expLevel >= evilDeedXPCost)
			{
				player.levelDown(evilDeedXPCost);
				onMasterAddedEvil(player);
			}
		}
		else if (packet.packetType == 2) // pickup entity from client to server
		{
			String username = packet.dataString[0];
			
			int playerID = packet.dataInt[0];
			int targetID = packet.dataInt[1];
			
			//EntityPlayer player = this.findPlayerByName(username);
			ArrayList entList = this.findEntitiesWithID(targetID);
			Iterator iter = entList.iterator();
			while (iter.hasNext())
			{
				Entity fromList = (Entity) iter.next();
				
				if (fromList instanceof EntityAnimal || fromList instanceof EntityPlayer)
				{
					EntityLiving target = (EntityLiving) fromList;
					orderMinionToPickupEntity(player, target);
					break;
				}
			}
		}
		else if (packet.packetType == 3) // minion drop command client to server
		{
			String username = packet.dataString[0];
			
			int playerID = packet.dataInt[0];
			int targetID = packet.dataInt[1];
			
			//EntityPlayer player = this.findPlayerByName(username);
			ArrayList entList = this.findEntitiesWithID(targetID);
			Iterator iter = entList.iterator();
			while (iter.hasNext())
			{
				Entity fromList = (Entity) iter.next();
				
				if (fromList instanceof AS_EntityMinion)
				{
					AS_EntityMinion target = (AS_EntityMinion) fromList;
					orderMinionToDrop(player, target);
					break;
				}
			}
		}
		else if (packet.packetType == 4) // minion spawn command client to server
		{
			String username = packet.dataString[0];
			
			int playerID = packet.dataInt[0];
			int x = packet.dataInt[1];
			int y = packet.dataInt[2];
			int z = packet.dataInt[3];
			
			//EntityPlayer player = this.findPlayerByName(username);
			spawnMinionsForPlayer(player, x, y, z);
			
			Packet230ModLoader answerpacket = new Packet230ModLoader();
			answerpacket.packetType = 0; // HasMinions override call from server to client
			answerpacket.dataInt = new int[2];
			answerpacket.dataInt[0] = hasPlayerMinions(player) ? 1 : 0;
			answerpacket.dataInt[1] = hasAllMinions(player) ? 1 : 0;
			ModLoaderMp.SendPacketTo(instance, player, answerpacket);
		}
		else if (packet.packetType == 5) // tree chop command client to server
		{
			String username = packet.dataString[0];
			
			int playerID = packet.dataInt[0];
			int x = packet.dataInt[1];
			int y = packet.dataInt[2];
			int z = packet.dataInt[3];
			
			//EntityPlayer player = this.findPlayerByName(username);
			orderMinionsToChopTrees(player, x, y, z);
		}
		else if (packet.packetType == 6) // stairwell command client to server
		{
			String username = packet.dataString[0];
			
			int playerID = packet.dataInt[0];
			int x = packet.dataInt[1];
			int y = packet.dataInt[2];
			int z = packet.dataInt[3];
			
			//EntityPlayer player = this.findPlayerByName(username);
			orderMinionsToDigStairWell(player, x, y, z);
		}
		else if (packet.packetType == 7) // stripmine command client to server
		{
			String username = packet.dataString[0];
			
			int playerID = packet.dataInt[0];
			int x = packet.dataInt[1];
			int y = packet.dataInt[2];
			int z = packet.dataInt[3];
			
			//EntityPlayer player = this.findPlayerByName(username);
			orderMinionsToDigStripMineShaft(player, x, y, z);
		}
		else if (packet.packetType == 8) // chest assign command client to server
		{
			String username = packet.dataString[0];
			
			int playerID = packet.dataInt[0];
			int x = packet.dataInt[1];
			int y = packet.dataInt[2];
			int z = packet.dataInt[3];
			
			//EntityPlayer player = this.findPlayerByName(username);
			orderMinionsToChestBlock(player, x, y, z);
		}
		else if (packet.packetType == 9) // moveto command client to server
		{
			String username = packet.dataString[0];
			
			int playerID = packet.dataInt[0];
			int x = packet.dataInt[1];
			int y = packet.dataInt[2];
			int z = packet.dataInt[3];
			
			//EntityPlayer player = this.findPlayerByName(username);
			orderMinionsToMoveTo(player, x, y, z);
		}
		else if (packet.packetType == 10) // mine ore vein command client to server
		{
			String username = packet.dataString[0];
			
			int playerID = packet.dataInt[0];
			int x = packet.dataInt[1];
			int y = packet.dataInt[2];
			int z = packet.dataInt[3];
			
			//EntityPlayer player = this.findPlayerByName(username);
			orderMinionsToMineOre(player, x, y, z);
		}
		else if (packet.packetType == 11) // follow master command client to server
		{
			String username = packet.dataString[0];
			
			int playerID = packet.dataInt[0];
			
			//EntityPlayer player = this.findPlayerByName(username);
			orderMinionsToFollow(player);
		}
		else if (packet.packetType == 666) // filthy cheater
		{
			player.giveExp(200);
		}
	}
	
	static void sendSoundToClients(Entity target, String soundEffect)
	{
		Packet230ModLoader soundPacket = new Packet230ModLoader();
		soundPacket.packetType = 12; // play sounds, server to client
		
		soundPacket.dataInt = new int[1];
		soundPacket.dataInt[0] = target.id;
		soundPacket.dataString = new String[1];
		soundPacket.dataString[0] = soundEffect;
		
		ModLoaderMp.SendPacketToAll(instance, soundPacket);
	}
	
	private static void orderMinionToPickupEntity(EntityPlayer playerEnt, EntityLiving target)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.name);
		
		for (int i = 0; i < minions.length; i++)
		{
			minions[i].master = playerEnt;

			if (minions[i].passenger == null)
			{
				minions[i].targetEntityToGrab = (EntityLiving) target;
				sendSoundToClients(minions[i], "mod_minions.grabanimalorder");
				break;
			}
		}
	}
	
	private static void orderMinionToDrop(EntityPlayer playerEnt, AS_EntityMinion minion)
	{
		if (minion.passenger != null)
		{
			sendSoundToClients(minion, "mod_minions.foryou");
			minion.passenger.mount(null);
		}
		else if (minion.inventory.containsItems())
		{
			sendSoundToClients(minion, "mod_minions.foryou");
			minion.a(playerEnt, 180F, 180F);
			minion.inventory.dropAllItems();
		}
	}
	
	private static void spawnMinionsForPlayer(EntityPlayer playerEnt, int x, int y, int z)
	{	
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.name);
		
		if (minions == null || minions.length < minionsPerPlayer)
		{
			int prevArraySize = (minions == null) ? 0 : minions.length;
			AS_EntityMinion[] arrayplusone = new AS_EntityMinion[prevArraySize+1];
			int index = 0;
			while (index < prevArraySize)
			{
				arrayplusone[index] = minions[index];
				index++;
			}
			arrayplusone[prevArraySize] = new AS_EntityMinion(playerEnt.world);
			arrayplusone[prevArraySize].setPosition(x, y+1, z);
			playerEnt.world.addEntity(arrayplusone[prevArraySize]);
			arrayplusone[prevArraySize].setMaster(playerEnt);
			// playerEnt.world.makeSound(arrayplusone[prevArraySize], "mod_minions.minionspawn", 1.0F, 1.0F);
			// playerEnt.world.spawnParticle("hugeexplosion", x, y, z, 0.0D, 0.0D, 0.0D);

			masterNames.put(playerEnt.name, arrayplusone);
			//System.out.println("spawned missing minion for "+var3.name);
		}
		
		//AS_EntityMinion[] readout = (AS_EntityMinion[]) masterNames.get(playerEnt.name);
		orderMinionsToMoveTo(playerEnt, x, y, z);
	}
	
	private static void orderMinionsToChopTrees(EntityPlayer playerEnt, int x, int y, int z)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.name);
		
		for (int i = 0; i < minions.length; i++)
		{
			minions[i].master = playerEnt;
			minions[i].giveTask(null, true);
		}
		
		cancelRunningJobsForMaster(playerEnt.name);
		runningJobList.add(new AS_Minion_Job_TreeHarvest(minions, x, y, z));
		playerEnt.world.makeSound(playerEnt, "mod_minions.ordertreecutting", 1.0F, 1.0F);
	}
	
	private static void orderMinionsToDigStairWell(EntityPlayer playerEnt, int x, int y, int z)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.name);
		
		for (int i = 0; i < minions.length; i++)
		{
			minions[i].master = playerEnt;
			minions[i].giveTask(null, true);
		}
		
		// stairwell job
		cancelRunningJobsForMaster(playerEnt.name);
		runningJobList.add(new AS_Minion_Job_DigMineStairwell(minions, x, y-1, z));
		playerEnt.world.makeSound(playerEnt, "mod_minions.ordermineshaft", 1.0F, 1.0F);
	}
	
	private static void orderMinionsToDigStripMineShaft(EntityPlayer playerEnt, int x, int y, int z)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.name);
		
		for (int i = 0; i < minions.length; i++)
		{
			minions[i].master = playerEnt;
			minions[i].giveTask(null, true);
		}
		
		// strip mine job
		minions[0].master = playerEnt;
		runningJobList.add(new AS_Minion_Job_StripMine(minions, x, y-1, z));
		playerEnt.world.makeSound(playerEnt, "mod_minions.randomorder", 1.0F, 1.0F);
	}
	
	private static void orderMinionsToChestBlock(EntityPlayer playerEnt, int x, int y, int z)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.name);
		
		TileEntity chest;
		if ((chest = playerEnt.world.getTileEntity(x, y-1, z)) != null && chest instanceof TileEntityChest)
		{
			cancelRunningJobsForMaster(playerEnt.name);
			playerEnt.world.makeSound(playerEnt, "mod_minions.randomorder", 2.0F, 1.0F);
			for (int i = 0; i < minions.length; i++)
			{
				minions[i].master = playerEnt;
				minions[i].giveTask(null, true);
				minions[i].returnChest = (TileEntityChest) chest;
				minions[i].currentState = AS_EnumMinionState.RETURNING_GOODS;
			}
		}
	}
	
	private static void orderMinionsToMoveTo(EntityPlayer playerEnt, int x, int y, int z)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.name);
		
		cancelRunningJobsForMaster(playerEnt.name);
		playerEnt.world.makeSound(playerEnt, "mod_minions.randomorder", 1.0F, 0.8F);
		for (int i = 0; i < minions.length; i++)
		{
			minions[i].master = playerEnt;
			minions[i].giveTask(null, true);
			minions[i].currentState = AS_EnumMinionState.IDLE;
			minions[i].orderMinionToMoveTo(x, y, z, false);
		}
	}
	
	private static void orderMinionsToMineOre(EntityPlayer playerEnt, int x, int y, int z)
	{
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(playerEnt.name);
		
		if (isBlockValuable(playerEnt.world.getTypeId(x, y-1, z)))
		{
			cancelRunningJobsForMaster(playerEnt.name);
			playerEnt.world.makeSound(playerEnt, "mod_minions.randomorder", 1.0F, 0.8F);
			for (int i = 0; i < minions.length; i++)
			{
				minions[i].master = playerEnt;

				if (!minions[i].hasTask())
				{
					minions[i].giveTask(new AS_BlockTask_MineOreVein(null, minions[i], x, y-1, z));
					break;
				}
			}
		}
	}
	
	private static void orderMinionsToFollow(EntityPlayer entPlayer)
	{
		cancelRunningJobsForMaster(entPlayer.name);
		
		AS_EntityMinion[] minions = (AS_EntityMinion[]) masterNames.get(entPlayer.name);
		if (minions == null)
		{
			return;
		}
		
		entPlayer.world.makeSound(entPlayer, "mod_minions.orderfollowplayer", 1.0F, 0.8F);
		for (int i = 0; i < minions.length; i++)
		{
			minions[i].master = entPlayer;
			minions[i].giveTask(null, true);
			minions[i].currentState = AS_EnumMinionState.FOLLOWING_PLAYER;
		}
	}
	
	private void getViableTreeBlocks()
	{		
		for (Block iter : Block.byId)
		{
			if (iter != null && iter.n() != null && iter.n().contains("log"))
			{
				foundTreeBlocks.add(iter.id);
			}
		}
	}
	
	public static boolean isBlockIDViableTreeBlock(int ID)
	{
		return foundTreeBlocks.contains(ID);
	}
	
    void initializeSettingsFile()
    {
        File settingsFile = configfile;
         
        try
        {
            if (settingsFile.exists())
            {
                System.out.println("/mods/mod_minions_evils.cfg found and opened");
                BufferedReader var1 = new BufferedReader(new FileReader(settingsFile));

                String lineString;
                while ((lineString = var1.readLine()) != null)
                {
                    if (!lineString.startsWith("//"))
                    {
                        if (lineString.startsWith("minionsPerPlayer"))
                        {
                        	String[] stringArray = lineString.split(":");
                        	minionsPerPlayer = Integer.parseInt(stringArray[1]);
                            System.out.println("Config: Set minionsPerPlayer to "+minionsPerPlayer);
                        }
                        else if (lineString.startsWith("evilDeedXPCost"))
                        {
                        	String[] stringArray = lineString.split(":");
                        	evilDeedXPCost = Integer.parseInt(stringArray[1]);
                            System.out.println("Config: Set Evil Deed XP Cost to "+evilDeedXPCost);
                        }
                        else if (lineString.startsWith("minionMenuKey"))
                        {

                        }
                        else if (lineString.startsWith("minionsInSavegame"))
                        {
                        	String[] stringArray = lineString.split(":");
                        	minionsInSavegame = (Integer.parseInt(stringArray[1]) != 0);
                            System.out.println("Config: Set persisting Minions "+minionsInSavegame);
                        }
                        else
                        {
                            String[] stringArray = lineString.split(":");
                            
                            AS_EvilDeed deed = new AS_EvilDeed(stringArray[0], stringArray[1], Integer.parseInt(stringArray[2]));
                            evilDoings.add(deed);
                        }
                    }
                }

                var1.close();
            }
            else
            {
            	System.out.println("Could not open /mods/mod_minions_evils.cfg, you suck");
            }
        }
        catch (Exception var6)
        {
            System.out.println("EXCEPTION BufferedReader: " + var6);
        }
    }
	
	public static boolean isBlockValuable(int blockID)
	{
		if (blockID == 0
		|| blockID == Block.DIRT.id
		|| blockID == Block.GRASS.id
		|| blockID == Block.STONE.id
		|| blockID == Block.COBBLESTONE.id
		|| blockID == Block.GRAVEL.id
		|| blockID == Block.SAND.id
		|| blockID == Block.LEAVES.id
		|| blockID == Block.OBSIDIAN.id
		|| blockID == Block.BEDROCK.id
		|| blockID == Block.COBBLESTONE_STAIRS.id)
		{
			return false;
		}
		
		return true;
	}
}
