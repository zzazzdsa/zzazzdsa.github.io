package net.minecraft.server;

public class AS_AStarNode
{
    public final int x;
    public final int y;
    public final int z;
    public AS_AStarNode parent;
    public int parentxoffset;
    public int parentyoffset;
    public int parentzoffset;
    public int g_BlockDistToStart;
    public double f_distanceToGoal;
    public double h_reachCost;

    public AS_AStarNode(int i, int j, int k, int l)
    {
        parent = null;
        x = i;
        y = j;
        z = k;
        g_BlockDistToStart = l;
    }

    public AS_AStarNode(int i, int j, int k, int l, AS_AStarNode as_astarnode)
    {
        parent = null;
        x = i;
        y = j;
        z = k;
        g_BlockDistToStart = l;
        parent = as_astarnode;
        updateParentOffset();
    }

    public void updateReachCost(double d)
    {
        f_distanceToGoal = d;
        h_reachCost = (double)g_BlockDistToStart + f_distanceToGoal;
    }

    public boolean updateDistance(int i, AS_AStarNode as_astarnode)
    {
        if (i < g_BlockDistToStart)
        {
            g_BlockDistToStart = i;
            h_reachCost = (double)g_BlockDistToStart + f_distanceToGoal;
            parent = as_astarnode;
            updateParentOffset();
            return true;
        }
        else
        {
            return false;
        }
    }

    public void updateParentOffset()
    {
        parentxoffset = parent.x - x;
        parentyoffset = parent.y - y;
        parentzoffset = parent.z - z;
    }

    public boolean equals(Object obj)
    {
        if (obj instanceof AS_AStarNode)
        {
            AS_AStarNode as_astarnode = (AS_AStarNode)obj;
            if (as_astarnode.hashCode() == hashCode() && as_astarnode.x == x && as_astarnode.y == y && as_astarnode.z == z)
            {
                return true;
            }
        }
        return false;
    }

    public int compare(Object obj, Object obj1)
    {
        if ((obj instanceof AS_AStarNode) && (obj1 instanceof AS_AStarNode))
        {
            AS_AStarNode as_astarnode = (AS_AStarNode)obj;
            AS_AStarNode as_astarnode1 = (AS_AStarNode)obj1;
            if (as_astarnode.h_reachCost == as_astarnode1.h_reachCost)
            {
                return 0;
            }
            return as_astarnode.h_reachCost >= as_astarnode1.h_reachCost ? 1 : -1;
        }
        else
        {
            return 0;
        }
    }

    public int hashCode()
    {
        return x << 16 ^ z ^ y << 24;
    }
}
