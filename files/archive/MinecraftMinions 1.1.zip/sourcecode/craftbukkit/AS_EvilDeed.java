package net.minecraft.server;

public class AS_EvilDeed
{
    private final String buttonText;
    private final String soundFile;
    private final int soundLength;

    public AS_EvilDeed(String s, String s1, int i)
    {
        buttonText = s;
        soundFile = s1;
        soundLength = i;
    }

    public String getButtonText()
    {
        return buttonText;
    }

    public String getSoundFile()
    {
        return soundFile;
    }

    public int getSoundLength()
    {
        return soundLength;
    }
}
