package net.minecraft.server;

import java.io.PrintStream;

public class AS_BlockTask
{
    public AS_Minion_Job_Manager boss;
    public final int posX;
    public final int posY;
    public final int posZ;
    public boolean startedTask;
    public AS_EntityMinion worker;
    protected double accessRange;
    protected long taskDurationMillis;
    public boolean isWorkerInRange;
    protected long timeBlockReached;
    protected AS_AStarNode possibleAccessNodes[];
    protected int currentAccessNode;
    private long taskTimeStarted;
    private double startMinionX;
    private double startMinionZ;

    public AS_BlockTask(AS_Minion_Job_Manager as_minion_job_manager, AS_EntityMinion as_entityminion, int i, int j, int k)
    {
        startedTask = false;
        accessRange = 4D;
        taskDurationMillis = 1000L;
        isWorkerInRange = false;
        boss = as_minion_job_manager;
        worker = as_entityminion;
        posX = i;
        posY = j;
        posZ = k;
    }

    public void setWorker(AS_EntityMinion as_entityminion)
    {
        worker = as_entityminion;
    }

    public void setAccessRange(double d)
    {
        accessRange = d;
    }

    public void setTaskDuration(long l)
    {
        taskDurationMillis = l;
    }

    public void onUpdate()
    {
        if (!startedTask)
        {
            if (!worker.inventoryFull)
            {
                onStartedTask();
            }
            else
            {
                worker.currentState = AS_EnumMinionState.RETURNING_GOODS;
                System.out.println("Blocktask worker is full, sending to return goods");
            }
        }
        else if (!isWorkerInRange && System.currentTimeMillis() - taskTimeStarted > 3000L)
        {
            if (Math.abs(startMinionX - worker.locX) < 1.0D && Math.abs(startMinionZ - worker.locZ) < 1.0D)
            {
                onTaskNotPathable();
            }
            else
            {
                taskTimeStarted = System.currentTimeMillis();
                startMinionX = worker.locX;
                startMinionZ = worker.locZ;
            }
        }
        if (isWorking())
        {
            worker.faceBlock(posX, posY, posZ);
            worker.datawatcher.watch(12, Integer.valueOf(1));
            worker.datawatcher.watch(13, Integer.valueOf(posX));
            worker.datawatcher.watch(14, Integer.valueOf(posY));
            worker.datawatcher.watch(15, Integer.valueOf(posZ));
        }
        if (!isWorkerInRange)
        {
            if (Math.sqrt(worker.e((double)posX + 0.5D, (double)posY + 0.5D, (double)posZ + 0.5D)) < accessRange)
            {
                onReachedTaskBlock();
                isWorkerInRange = true;
            }
        }
        else if ((float)(System.currentTimeMillis() - timeBlockReached) > (float)taskDurationMillis / worker.workSpeed)
        {
            onFinishedTask();
        }
    }

    public void onWorkerPathFailed()
    {
        if (possibleAccessNodes != null && currentAccessNode < possibleAccessNodes.length - 1)
        {
            currentAccessNode++;
            worker.orderMinionToMoveTo(possibleAccessNodes[currentAccessNode].x, possibleAccessNodes[currentAccessNode].y, possibleAccessNodes[currentAccessNode].z, false);
        }
        else
        {
            worker.enderTeleportTo(possibleAccessNodes[currentAccessNode].x, possibleAccessNodes[currentAccessNode].y, possibleAccessNodes[currentAccessNode].z);
        }
    }

    public void onReachedTaskBlock()
    {
        timeBlockReached = System.currentTimeMillis();
        worker.currentState = AS_EnumMinionState.MINING;
        worker.setPathEntity(null);
    }

    public void onStartedTask()
    {
        if (startedTask)
        {
            return;
        }
        startedTask = true;
        taskTimeStarted = System.currentTimeMillis();
        startMinionX = worker.locX;
        startMinionZ = worker.locZ;
        worker.currentState = AS_EnumMinionState.THINKING;
        currentAccessNode = 0;
        possibleAccessNodes = getAccessNodesSorted((int)Math.floor(worker.locX), (int)Math.floor(worker.locY) - 1, (int)Math.floor(worker.locZ));
        if (possibleAccessNodes.length != 0)
        {
            worker.orderMinionToMoveTo(possibleAccessNodes[currentAccessNode].x, possibleAccessNodes[currentAccessNode].y, possibleAccessNodes[currentAccessNode].z, false);
            worker.currentState = AS_EnumMinionState.WALKING_TO_COORDS;
        }
        else
        {
            onTaskNotPathable();
        }
    }

    public void onTaskNotPathable()
    {
        worker.currentState = AS_EnumMinionState.AWAITING_JOB;
        worker.datawatcher.watch(12, Integer.valueOf(0));
        worker.currentState = AS_EnumMinionState.AWAITING_JOB;
        worker.giveTask(null, true);
    }

    public void onFinishedTask()
    {
        worker.datawatcher.watch(12, Integer.valueOf(0));
        worker.currentState = AS_EnumMinionState.AWAITING_JOB;
        worker.giveTask(null, true);
    }

    public boolean isWorking()
    {
        return isWorkerInRange;
    }

    public boolean isEntityInAccessRange(EntityLiving entityliving)
    {
        return entityliving.e(posX, posY, posZ) < accessRange;
    }

    public AS_AStarNode[] getAccessNodesSorted(int i, int j, int k)
    {
        return AS_AStarStatic.getAccessNodesSorted(worker.world, i, j, k, posX, posY, posZ);
    }
}
