package net.minecraft.server;

public final class AS_EnumMinionState
{
    public static final AS_EnumMinionState IDLE;
    public static final AS_EnumMinionState FOLLOWING_PLAYER;
    public static final AS_EnumMinionState WALKING_TO_COORDS;
    public static final AS_EnumMinionState AWAITING_JOB;
    public static final AS_EnumMinionState RETURNING_GOODS;
    public static final AS_EnumMinionState THINKING;
    public static final AS_EnumMinionState MINING;
    private String name;
    private int number;
    private static final AS_EnumMinionState $VALUES[];

    public static AS_EnumMinionState[] values()
    {
        return (AS_EnumMinionState[])$VALUES.clone();
    }

    private AS_EnumMinionState(String s, int i, String s1, int j)
    {
        name = s1;
        number = j;
    }

    public String getName()
    {
        return name;
    }

    public int getNumber()
    {
        return number;
    }

    public static AS_EnumMinionState getStateByString(String s)
    {
        AS_EnumMinionState aas_enumminionstate[] = values();
        int i = aas_enumminionstate.length;
        for (int j = 0; j < i; j++)
        {
            AS_EnumMinionState as_enumminionstate = aas_enumminionstate[j];
            if (as_enumminionstate.getName().equals(s))
            {
                return as_enumminionstate;
            }
        }

        return null;
    }

    static
    {
        IDLE = new AS_EnumMinionState("IDLE", 0, "IDLE", 0);
        FOLLOWING_PLAYER = new AS_EnumMinionState("FOLLOWING_PLAYER", 1, "FOLLOWING_PLAYER", 1);
        WALKING_TO_COORDS = new AS_EnumMinionState("WALKING_TO_COORDS", 2, "WALKING_TO_COORDS", 2);
        AWAITING_JOB = new AS_EnumMinionState("AWAITING_JOB", 3, "AWAITING_JOB", 3);
        RETURNING_GOODS = new AS_EnumMinionState("RETURNING_GOODS", 4, "RETURNING_GOODS", 4);
        THINKING = new AS_EnumMinionState("THINKING", 5, "THINKING", 5);
        MINING = new AS_EnumMinionState("MINING", 6, "MINING", 6);
        $VALUES = (new AS_EnumMinionState[]
                {
                    IDLE, FOLLOWING_PLAYER, WALKING_TO_COORDS, AWAITING_JOB, RETURNING_GOODS, THINKING, MINING
                });
    }
}
