package net.minecraft.server;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Random;

public class AS_EntityMinion extends EntityCreature
    implements AS_IAStarPathedEntity
{
    public EntityHuman master;
    public String masterUsername;
    private ItemStack heldItem;
    public AS_InventoryMinion inventory;
    public boolean inventoryFull;
    public TileEntityChest returnChest;
    public AS_AStarPath pathPlanner;
    public AS_EnumMinionState currentState;
    public AS_EnumMinionState lastOrderedState;
    public AS_EnumMinionState nextState;
    private AS_PathEntity pathToWalkInputCache;
    private AS_PathEntity pathToWalkActive;
    public ChunkCoordinates currentTarget;
    private final int pathingCooldownTicks = 30;
    private int currentPathNotFoundCooldownTick;
    private int pathFindingFails;
    private int currentPathingStopCooldownTick;
    private AS_BlockTask currentTask;
    public EntityLiving targetEntityToGrab;
    public float workSpeed;
    private long workBoostTime;
    public boolean isStripMining;
    private long timeLastSound;

    public AS_EntityMinion(World world)
    {
        super(world);
        heldItem = new ItemStack(Item.IRON_PICKAXE, 1);
        inventory = new AS_InventoryMinion(this);
        inventoryFull = false;
        currentState = AS_EnumMinionState.FOLLOWING_PLAYER;
        lastOrderedState = AS_EnumMinionState.FOLLOWING_PLAYER;
        nextState = null;
        currentPathNotFoundCooldownTick = 0;
        pathFindingFails = 0;
        currentPathingStopCooldownTick = 0;
        workSpeed = 1.0F;
        workBoostTime = 0L;
        isStripMining = false;
        fireProof = true;
        bb = 3F;
        width *= 0.40000000000000002D;
        texture = "/mod_minions/AS_EntityMinion.png";
        pathPlanner = new AS_AStarPath(world, this);
    }

    public AS_EntityMinion(World world, double d, double d1, double d2)
    {
        super(world);
        heldItem = new ItemStack(Item.IRON_PICKAXE, 1);
        inventory = new AS_InventoryMinion(this);
        inventoryFull = false;
        currentState = AS_EnumMinionState.FOLLOWING_PLAYER;
        lastOrderedState = AS_EnumMinionState.FOLLOWING_PLAYER;
        nextState = null;
        currentPathNotFoundCooldownTick = 0;
        pathFindingFails = 0;
        currentPathingStopCooldownTick = 0;
        workSpeed = 1.0F;
        workBoostTime = 0L;
        isStripMining = false;
        enderTeleportTo(d, d1, d2);
        texture = "/mod_minions/AS_EntityMinion.png";
        world.makeSound(this, "mod_minions.minionspawn", 1.0F, 1.0F);
        world.a("hugeexplosion", d, d1, d2, 0.0D, 0.0D, 0.0D);
    }

    public void setMaster(EntityHuman entityhuman)
    {
        master = entityhuman;
        masterUsername = master.name;
    }

    protected void b()
    {
        super.b();
        datawatcher.a(12, new Integer(0));
        datawatcher.a(13, new Integer(0));
        datawatcher.a(14, new Integer(0));
        datawatcher.a(15, new Integer(0));
    }

    public void giveTask(AS_BlockTask as_blocktask, boolean flag)
    {
        if (flag)
        {
            currentTask = as_blocktask;
        }
        else
        {
            giveTask(as_blocktask);
        }
    }

    public void giveTask(AS_BlockTask as_blocktask)
    {
        currentTask = as_blocktask;
        if (currentTask == null)
        {
            ao = 0.0F;
            currentState = AS_EnumMinionState.RETURNING_GOODS;
            lastOrderedState = AS_EnumMinionState.RETURNING_GOODS;
        }
    }

    public AS_BlockTask getCurrentTask()
    {
        return currentTask;
    }

    public boolean hasTask()
    {
        return currentTask != null;
    }

    public int getMaxHealth()
    {
        return 20;
    }

    public ItemStack getHeldItem()
    {
        return heldItem;
    }

    public boolean e_()
    {
        return true;
    }

    public boolean f_()
    {
        return false;
    }

    public void a_(EntityHuman entityhuman)
    {
    }

    public void collide(Entity entity)
    {
    }

    protected boolean d_()
    {
        return false;
    }

    public void b(NBTTagCompound nbttagcompound)
    {
        super.b(nbttagcompound);
        nbttagcompound.set("MinionInventory", inventory.writeToNBT(new NBTTagList()));
        nbttagcompound.setString("masterUsername", masterUsername);
    }

    public void a(NBTTagCompound nbttagcompound)
    {
        super.a(nbttagcompound);
        NBTTagList nbttaglist = nbttagcompound.getList("MinionInventory");
        inventory.readFromNBT(nbttaglist);
        masterUsername = nbttagcompound.getString("masterUsername");
        master = world.a(masterUsername);
        mod_Minions.MinionLoadRegister(this);
    }

    private void performTeleportToTarget()
    {
        enderTeleportTo(currentTarget.x, currentTarget.y, currentTarget.z);
        world.makeSound(this, "random.pop", 1.0F, 1.0F);
    }

    public void performRecallTeleportToMaster()
    {
        if (master != null)
        {
            enderTeleportTo(master.locX + 1.0D, master.locY, master.locZ + 1.0D);
            world.makeSound(this, "random.pop", 1.0F, 1.0F);
        }
    }

    public void orderMinionToMoveTo(int i, int j, int k, boolean flag)
    {
        if (pathPlanner.isBusy())
        {
            pathPlanner.stopPathSearch();
        }
        datawatcher.watch(12, Integer.valueOf(0));
        currentTarget = new ChunkCoordinates(i, j, k);
        pathPlanner.getPath(doubleToInt(locX), doubleToInt(locY) - 1, doubleToInt(locZ), i, j, k, flag);
    }

    public void y_()
    {
        super.y_();
        if (passenger != null && passenger.equals(master) && !E())
        {
            yaw = pitch = 0.0F;
        }
        if (datawatcher.getInt(12) != 0)
        {
            ao += 0.085000000894069672D * (double)workSpeed;
            if (ao > 1.0F)
            {
                ao = 0.0F;
            }
            int i = datawatcher.getInt(13);
            int j = datawatcher.getInt(14);
            int k = datawatcher.getInt(15);
            int l = world.getTypeId(i, j, k);
            if (l > 0)
            {
                long l1 = System.currentTimeMillis();
                if ((float)(l1 - timeLastSound) > 500F / workSpeed)
                {
                    Block block = Block.byId[l];
                    world.makeSound(this, block.stepSound.getName(), (block.stepSound.getVolume1() + 1.0F) / 2.0F, block.stepSound.getVolume2() * 0.8F);
                    timeLastSound = l1;
                }
                world.a((new StringBuilder()).append("tilecrack_").append(l).toString(), locX + ((double)random.nextFloat() - 0.5D), locY + 1.5D, locZ + ((double)random.nextFloat() - 0.5D), 1.0D, 1.0D, 1.0D);
            }
        }
        else
        {
            ao = 0.0F;
        }
    }

    public void am()
    {
        super.am();
        if (workBoostTime != 0L && System.currentTimeMillis() - workBoostTime > 30000L)
        {
            workBoostTime = 0L;
            workSpeed = 1.0F;
        }
        if (targetEntityToGrab != null)
        {
            if (h(targetEntityToGrab) > 3F)
            {
                if (!E() || pathPlanner.isBusy())
                {
                    if (currentPathNotFoundCooldownTick > 0)
                    {
                        currentPathNotFoundCooldownTick--;
                    }
                    else
                    {
                        int i = doubleToInt(targetEntityToGrab.locX);
                        int j = doubleToInt(targetEntityToGrab.locY);
                        int k;
                        for (k = doubleToInt(targetEntityToGrab.locZ); !AS_AStarStatic.isViable(world, new AS_AStarNode(i, j, k, 0), 1); j--) { }
                        orderMinionToMoveTo(i, j, k, false);
                        currentTarget = new ChunkCoordinates(doubleToInt(targetEntityToGrab.locX), doubleToInt(targetEntityToGrab.locY), doubleToInt(targetEntityToGrab.locZ));
                    }
                }
            }
            else if (passenger != targetEntityToGrab)
            {
                targetEntityToGrab.mount(this);
                targetEntityToGrab = null;
            }
        }
        else if (currentState == AS_EnumMinionState.WALKING_TO_COORDS || currentState == AS_EnumMinionState.THINKING)
        {
            if (hasReachedTarget())
            {
                pathToWalkActive = null;
                if (nextState != null)
                {
                    if (nextState == AS_EnumMinionState.WALKING_TO_COORDS)
                    {
                        nextState = lastOrderedState;
                    }
                    currentState = nextState;
                }
                else
                {
                    currentState = lastOrderedState;
                }
            }
            else if (pathToWalkActive != null && pathToWalkActive.getTimeSinceLastPathIncrement() > 750L)
            {
                currentPathingStopCooldownTick++;
                if (currentPathingStopCooldownTick > 30)
                {
                    currentPathingStopCooldownTick = 0;
                    PathPoint pathpoint = pathToWalkActive.getCurrentTargetPathPoint();
                    if (pathpoint != null)
                    {
                        pathToWalkActive.a();
                        enderTeleportTo((double)pathpoint.a + 0.5D, (double)pathpoint.b + 0.5D, (double)pathpoint.c + 0.5D);
                        motX = 0.0D;
                        motZ = 0.0D;
                        pathPlanner.getPath(doubleToInt(locX), doubleToInt(locY) - 1, doubleToInt(locZ), currentTarget.x, currentTarget.y, currentTarget.z, false);
                    }
                    else
                    {
                        performTeleportToTarget();
                    }
                }
            }
        }
        else if ((currentState == AS_EnumMinionState.FOLLOWING_PLAYER || currentState == AS_EnumMinionState.RETURNING_GOODS && returnChest == null) && master != null && !E())
        {
            if (h(master) > 5F && !pathPlanner.isBusy())
            {
                if (currentPathNotFoundCooldownTick > 0)
                {
                    currentPathNotFoundCooldownTick--;
                }
                else
                {
                    if (h(master) > 40F)
                    {
                        performRecallTeleportToMaster();
                    }
                    AS_AStarNode aas_astarnode[] = AS_AStarStatic.getAccessNodesSorted(world, doubleToInt(locX), doubleToInt(locY), doubleToInt(locZ), doubleToInt(master.locX), doubleToInt(master.locY) - 1, doubleToInt(master.locZ));
                    if (aas_astarnode.length != 0)
                    {
                        orderMinionToMoveTo(aas_astarnode[0].x, aas_astarnode[0].y, aas_astarnode[0].z, false);
                        currentTarget = new ChunkCoordinates(doubleToInt(master.locX), doubleToInt(master.locY) - 1, doubleToInt(master.locZ));
                    }
                }
            }
            else if (h(master) < 5F && currentState == AS_EnumMinionState.RETURNING_GOODS && returnChest == null && inventory.containsItems())
            {
                world.makeSound(this, "mod_minions.foryou", 1.0F, 1.0F);
                a(master, 180F, 180F);
                inventory.dropAllItems();
            }
        }
        else if (currentState == AS_EnumMinionState.RETURNING_GOODS && returnChest != null)
        {
            if (getDistanceToEntity(returnChest) > 4D)
            {
                if (!E() || pathPlanner.isBusy())
                {
                    if (currentPathNotFoundCooldownTick > 0)
                    {
                        currentPathNotFoundCooldownTick--;
                    }
                    else
                    {
                        AS_AStarNode aas_astarnode1[] = AS_AStarStatic.getAccessNodesSorted(world, doubleToInt(locX), doubleToInt(locY), doubleToInt(locZ), returnChest.x, returnChest.y, returnChest.z);
                        if (aas_astarnode1.length != 0)
                        {
                            orderMinionToMoveTo(aas_astarnode1[0].x, aas_astarnode1[0].y, aas_astarnode1[0].z, false);
                            currentTarget = new ChunkCoordinates(aas_astarnode1[0].x, aas_astarnode1[0].y, aas_astarnode1[0].z);
                        }
                    }
                }
            }
            else
            {
                if (inventory.containsItems())
                {
                    openChest(returnChest);
                    inventory.putAllItemsToChest(returnChest);
                }
                currentState = AS_EnumMinionState.IDLE;
                orderMinionToMoveTo(doubleToInt(locX), doubleToInt(locY) - 1, doubleToInt(locZ), false);
            }
        }
    }

    private void openChest(TileEntityChest tileentitychest)
    {
        if (tileentitychest.c != null)
        {
            tileentitychest.c.f = 1.0F;
        }
        else if (tileentitychest.d != null)
        {
            tileentitychest.d.f = 1.0F;
        }
        else if (tileentitychest.e != null)
        {
            tileentitychest.e.f = 1.0F;
        }
        else if (tileentitychest.b != null)
        {
            tileentitychest.b.f = 1.0F;
        }
        tileentitychest.f = 1.0F;
    }

    private double getDistanceToEntity(TileEntity tileentity)
    {
        return AS_AStarStatic.getDistanceBetweenCoords(doubleToInt(locX), doubleToInt(locY), doubleToInt(locZ), tileentity.x, tileentity.y, tileentity.z);
    }

    public boolean hasReachedTarget()
    {
        return !E() && currentTarget != null && AS_AStarStatic.getDistanceBetweenCoords(doubleToInt(locX), doubleToInt(locY), doubleToInt(locZ), currentTarget.x, currentTarget.y, currentTarget.z) < 1.5D;
    }

    public void m_()
    {
        super.m_();
        if (onGround)
        {
            double d = AS_AStarStatic.getEntityLandSpeed(this);
            if (d > 0.10000000000000001D && d < 0.29999999999999999D)
            {
                motX *= 1.25D;
                motZ *= 1.25D;
            }
        }
        if (pathToWalkInputCache != null)
        {
            setPathEntity(pathToWalkInputCache);
            currentState = AS_EnumMinionState.WALKING_TO_COORDS;
            pathToWalkActive = pathToWalkInputCache;
            pathToWalkInputCache = null;
        }
        if (hasTask())
        {
            currentTask.onUpdate();
        }
    }

    protected void D()
    {
        if (currentState != AS_EnumMinionState.IDLE || currentTarget == null || passenger != null)
        {
            return;
        }
        MethodProfiler.a("stroll");
        boolean flag = false;
        int i = -1;
        int j = -1;
        int k = -1;
        float f = -99999F;
        for (int l = 0; l < 10; l++)
        {
            int i1 = MathHelper.floor(((double)currentTarget.x + (double)random.nextInt(6)) - 6D);
            int j1 = MathHelper.floor(((double)currentTarget.y + (double)random.nextInt(3)) - 3D);
            int k1 = MathHelper.floor(((double)currentTarget.z + (double)random.nextInt(6)) - 6D);
            float f1 = a(i1, j1, k1);
            if (f1 > f)
            {
                f = f1;
                i = i1;
                j = j1;
                k = k1;
                flag = true;
            }
        }

        if (flag)
        {
            setPathEntity(world.a(this, i, j, k, 10F));
        }
        MethodProfiler.a();
    }

    public boolean damageEntity(DamageSource damagesource, int i)
    {
        if (damagesource.getEntity() != null)
        {
            if (damagesource.getEntity().equals(master))
            {
                workBoostTime = System.currentTimeMillis();
                workSpeed = 2.0F;
                master.c(this);
                world.makeSound(this, "mod_minions.minionsqueak", 1.0F, 1.0F);
                if (passenger != null)
                {
                    passenger.mount(null);
                    return true;
                }
                else
                {
                    return true;
                }
            }
            if ((damagesource.getEntity() instanceof EntityHuman) && passenger != null)
            {
                passenger.mount(null);
                return true;
            }
        }
        return false;
    }

    public void faceBlock(int i, int j, int k)
    {
        double d = (double)i - locX;
        double d1 = (double)k - locZ;
        double d2 = (double)j - locY;
        double d3 = MathHelper.sqrt(d * d + d1 * d1);
        float f = (float)((Math.atan2(d1, d) * 180D) / 3.1415927410125732D) - 90F;
        float f1 = (float)(-((Math.atan2(d2, d3) * 180D) / 3.1415927410125732D));
        pitch = -f1;
        yaw = f;
    }

    private AS_PathEntity getCurrentEntityPath()
    {
        AS_EntityMinion as_entityminion = this;
        as_entityminion.getClass().getDeclaredFields()[0].setAccessible(true);
        try
        {
            Object obj = as_entityminion.getClass().getDeclaredFields()[0].get(this);
            if (obj instanceof AS_PathEntity)
            {
                return (AS_PathEntity)obj;
            }
        }
        catch (IllegalArgumentException illegalargumentexception)
        {
            illegalargumentexception.printStackTrace();
        }
        catch (SecurityException securityexception)
        {
            securityexception.printStackTrace();
        }
        catch (IllegalAccessException illegalaccessexception)
        {
            illegalaccessexception.printStackTrace();
        }
        return null;
    }

    public void OnFoundPath(ArrayList arraylist)
    {
        currentPathNotFoundCooldownTick = 30;
        pathFindingFails = 0;
        pathToWalkInputCache = AS_AStarStatic.translateAStarPathtoPathEntity(arraylist);
        nextState = currentState;
    }

    public void OnNoPathAvailable()
    {
        if (hasTask())
        {
            currentTask.onWorkerPathFailed();
        }
        currentPathNotFoundCooldownTick = 30;
        pathFindingFails++;
        if (pathFindingFails == 3)
        {
            performTeleportToTarget();
            pathFindingFails = 0;
        }
    }

    public String getDisplayName()
    {
        return null;
    }

    public void dropMinionItemWithRandomChoice(ItemStack itemstack)
    {
        if (itemstack != null)
        {
            EntityItem entityitem = new EntityItem(world, locX, (locY - 0.30000001192092896D) + (double)y(), locZ, itemstack);
            entityitem.pickupDelay = 40;
            float f = 0.1F;
            entityitem.motX = -MathHelper.sin((yaw / 180F) * 3.141593F) * MathHelper.cos((pitch / 180F) * 3.141593F) * f;
            entityitem.motZ = MathHelper.cos((yaw / 180F) * 3.141593F) * MathHelper.cos((pitch / 180F) * 3.141593F) * f;
            entityitem.motY = -MathHelper.sin((pitch / 180F) * 3.141593F) * f + 0.1F;
            f = 0.02F;
            float f1 = random.nextFloat() * 3.141593F * 2.0F;
            f *= random.nextFloat();
            entityitem.motX += Math.cos(f1) * (double)f;
            entityitem.motY += (random.nextFloat() - random.nextFloat()) * 0.1F;
            entityitem.motZ += Math.sin(f1) * (double)f;
            world.addEntity(entityitem);
        }
    }

    public int doubleToInt(double d)
    {
        return AS_AStarStatic.getIntCoordFromDoubleCoord(d);
    }
}
