package net.minecraft.server;

public class AS_BlockTask_ReplaceBlock extends AS_BlockTask_MineBlock
{
    public final int blockToPlace;
    public final int metaToPlace;

    public AS_BlockTask_ReplaceBlock(AS_Minion_Job_Manager as_minion_job_manager, AS_EntityMinion as_entityminion, int i, int j, int k, int l, int i1)
    {
        super(as_minion_job_manager, as_entityminion, i, j, k);
        blockToPlace = l;
        metaToPlace = i1;
    }

    public void onFinishedTask()
    {
        super.onFinishedTask();
        worker.world.setTypeIdAndData(posX, posY, posZ, blockToPlace, metaToPlace);
    }
}
