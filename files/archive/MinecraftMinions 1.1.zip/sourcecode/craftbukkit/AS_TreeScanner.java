package net.minecraft.server;

import java.io.PrintStream;
import java.util.ArrayList;

public class AS_TreeScanner
    implements Runnable
{
    private AS_Minion_Job_TreeHarvest boss;
    private ChunkCoordinates startCoords;
    private World worldObj;
    private int foundTreeCount;
    private int currentX;
    private int currentZ;
    private int currentMaxX;
    private int currentMaxZ;

    public AS_TreeScanner(AS_Minion_Job_TreeHarvest as_minion_job_treeharvest)
    {
        foundTreeCount = 0;
        currentMaxX = 0;
        currentMaxZ = 0;
        boss = as_minion_job_treeharvest;
    }

    public void setup(ChunkCoordinates chunkcoordinates, World world)
    {
        startCoords = chunkcoordinates;
        currentX = chunkcoordinates.x;
        currentZ = chunkcoordinates.z;
        worldObj = world;
    }

    public void run()
    {
        System.out.println((new StringBuilder()).append("AS_TreeScanner starting to run at [").append(currentX).append("|").append(currentZ).append("]").toString());
        boolean flag = false;
        while (foundTreeCount < 16 && currentMaxX < 64)
        {
            for (int i = currentX + (flag ? currentMaxX * -1 : currentMaxX); currentX != i;)
            {
                checkForTreeAtCoords();
                if (flag)
                {
                    currentX--;
                }
                else
                {
                    currentX++;
                }
            }

            for (int j = currentZ + (flag ? currentMaxZ * -1 : currentMaxZ); currentZ != j;)
            {
                checkForTreeAtCoords();
                if (flag)
                {
                    currentZ--;
                }
                else
                {
                    currentZ++;
                }
            }

            flag = !flag;
            currentMaxX++;
            currentMaxZ++;
        }
        System.out.println((new StringBuilder()).append("AS_TreeScanner finished work, found: ").append(foundTreeCount).append("; checked length: ").append(currentMaxX).toString());
        boss.onDoneFindingTrees();
    }

    private void checkForTreeAtCoords()
    {
        int i = worldObj.f(currentX, currentZ);
        if (i != -1)
        {
            int j = worldObj.getTypeId(currentX, i - 1, currentZ);
            if (mod_Minions.foundTreeBlocks.contains(Integer.valueOf(j)))
            {
                int k;
                while ((k = worldObj.getTypeId(currentX, --i, currentZ)) == j) ;
                if (k == 0 || Block.byId[k].material == Material.LEAVES)
                {
                    return;
                }
                onFoundTreeBase(currentX, i + 1, currentZ);
            }
        }
        Thread.yield();
    }

    private void onFoundTreeBase(int i, int j, int k)
    {
        foundTreeCount++;
        boss.onFoundTreeBase(i, j, k);
    }
}
