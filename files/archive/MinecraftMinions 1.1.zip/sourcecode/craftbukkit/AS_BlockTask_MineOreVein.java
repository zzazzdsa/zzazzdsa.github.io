package net.minecraft.server;

import java.util.ArrayList;

public class AS_BlockTask_MineOreVein extends AS_BlockTask_MineBlock
{
    private ArrayList oreVeinBlocks;

    public AS_BlockTask_MineOreVein(AS_Minion_Job_Manager as_minion_job_manager, AS_EntityMinion as_entityminion, int i, int j, int k)
    {
        super(as_minion_job_manager, as_entityminion, i, j, k);
    }

    public AS_BlockTask_MineOreVein(AS_Minion_Job_Manager as_minion_job_manager, AS_EntityMinion as_entityminion, ArrayList arraylist, int i, int j, int k)
    {
        super(as_minion_job_manager, as_entityminion, i, j, k);
        oreVeinBlocks = arraylist;
    }

    public void onStartedTask()
    {
        super.onStartedTask();
    }

    public void onReachedTaskBlock()
    {
        super.onReachedTaskBlock();
        if (oreVeinBlocks == null)
        {
            oreVeinBlocks = new ArrayList();
        }
        checkAdjacentBlocks();
    }

    public void onUpdate()
    {
        super.onUpdate();
    }

    public void onTaskNotPathable()
    {
        super.onTaskNotPathable();
        worker.datawatcher.watch(12, Integer.valueOf(0));
        ChunkCoordinates chunkcoordinates = new ChunkCoordinates(posX, posY, posZ);
        if (oreVeinBlocks != null && oreVeinBlocks.contains(chunkcoordinates))
        {
            oreVeinBlocks.remove(chunkcoordinates);
        }
        if (oreVeinBlocks != null && !oreVeinBlocks.isEmpty())
        {
            ChunkCoordinates chunkcoordinates1 = (ChunkCoordinates)oreVeinBlocks.get(0);
            AS_BlockTask_MineOreVein as_blocktask_mineorevein = new AS_BlockTask_MineOreVein(boss, worker, oreVeinBlocks, chunkcoordinates1.x, chunkcoordinates1.y, chunkcoordinates1.z);
            worker.giveTask(as_blocktask_mineorevein);
        }
        else
        {
            worker.currentState = AS_EnumMinionState.AWAITING_JOB;
            worker.giveTask(null, true);
        }
    }

    public void onFinishedTask()
    {
        worker.datawatcher.watch(12, Integer.valueOf(0));
        checkDangers();
        blockID = worker.world.getTypeId(posX, posY, posZ);
        checkBlockForCaveIn(posX, posY + 1, posZ);
        if (blockID != 0 && Block.byId[blockID].l() >= 0.0F && blockID != Block.CHEST.id && worker.world.setTypeId(posX, posY, posZ, 0))
        {
            putBlockHarvestInWorkerInventory();
        }
        checkForVeinContinueTask();
    }

    private void checkBlockForCaveIn(int i, int j, int k)
    {
        int l = worker.world.getTypeId(i, j, k);
        if (l > 0 && (l == Block.SAND.id || l == Block.GRAVEL.id))
        {
            worker.inventory.consumeInventoryItem(Block.DIRT.id);
            worker.world.setTypeId(i, j, k, Block.DIRT.id);
        }
    }

    private void checkForVeinContinueTask()
    {
        if (oreVeinBlocks == null)
        {
            oreVeinBlocks = new ArrayList();
        }
        ChunkCoordinates chunkcoordinates = new ChunkCoordinates(posX, posY, posZ);
        if (oreVeinBlocks.contains(chunkcoordinates))
        {
            oreVeinBlocks.remove(chunkcoordinates);
        }
        if (!oreVeinBlocks.isEmpty())
        {
            ChunkCoordinates chunkcoordinates1 = (ChunkCoordinates)oreVeinBlocks.get(0);
            AS_BlockTask_MineOreVein as_blocktask_mineorevein = new AS_BlockTask_MineOreVein(boss, worker, oreVeinBlocks, chunkcoordinates1.x, chunkcoordinates1.y, chunkcoordinates1.z);
            worker.giveTask(as_blocktask_mineorevein);
        }
        else
        {
            worker.currentState = AS_EnumMinionState.AWAITING_JOB;
            worker.giveTask(null, true);
        }
    }

    public void checkAdjacentBlocks()
    {
        checkBlockForVein(posX, posY - 1, posZ);
        checkBlockForVein(posX, posY + 1, posZ);
        checkBlockForVein(posX + 1, posY, posZ);
        checkBlockForVein(posX - 1, posY, posZ);
        checkBlockForVein(posX, posY, posZ + 1);
        checkBlockForVein(posX, posY, posZ - 1);
    }

    private void checkBlockForVein(int i, int j, int k)
    {
        int l = worker.world.getTypeId(i, j, k);
        if (!mod_Minions.isBlockValuable(l))
        {
            return;
        }
        if (l == blockID)
        {
            ChunkCoordinates chunkcoordinates = new ChunkCoordinates(i, j, k);
            if (!oreVeinBlocks.contains(chunkcoordinates))
            {
                oreVeinBlocks.add(chunkcoordinates);
            }
        }
    }
}
