package net.minecraft.server;

public class AS_PathEntity extends PathEntity
{
    private long timeLastPathIncrement;
    private final PathPoint pointsCopy[];
    private int pathIndexCopy;

    public AS_PathEntity(PathPoint apathpoint[])
    {
        super(apathpoint);
        timeLastPathIncrement = 0L;
        timeLastPathIncrement = System.currentTimeMillis();
        pointsCopy = apathpoint;
        pathIndexCopy = 0;
    }

    public void a()
    {
        super.a();
        timeLastPathIncrement = System.currentTimeMillis();
        pathIndexCopy++;
    }

    public long getTimeSinceLastPathIncrement()
    {
        return System.currentTimeMillis() - timeLastPathIncrement;
    }

    public PathPoint getCurrentTargetPathPoint()
    {
        if (b())
        {
            return null;
        }
        else
        {
            return pointsCopy[pathIndexCopy];
        }
    }

    public Vec3D a(Entity entity)
    {
        if (super.b())
        {
            return null;
        }
        else
        {
            return super.a(entity);
        }
    }
}
