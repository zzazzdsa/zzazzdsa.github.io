package net.minecraft.server;

import java.util.ArrayList;

public interface AS_IAStarPathedEntity
{
    public abstract void OnFoundPath(ArrayList arraylist);

    public abstract void OnNoPathAvailable();
}
