package net.minecraft.server;

import java.util.ArrayList;

public final class AS_AStarStatic
{
    static final int candidates[][] =
    {
        {
            0, 0, -1, 1
        }, {
            0, 0, 1, 1
        }, {
            0, 1, 0, 1
        }, {
            1, 0, 0, 1
        }, {
            -1, 0, 0, 1
        }, {
            1, 1, 0, 2
        }, {
            -1, 1, 0, 2
        }, {
            0, 1, 1, 2
        }, {
            0, 1, -1, 2
        }, {
            1, -1, 0, 1
        }, {
            -1, -1, 0, 1
        }, {
            0, -1, 1, 1
        }, {
            0, -1, -1, 1
        }
    };
    static final int candidates_allowdrops[][] =
    {
        {
            0, 0, -1, 1
        }, {
            0, 0, 1, 1
        }, {
            1, 0, 0, 1
        }, {
            -1, 0, 0, 1
        }, {
            1, 1, 0, 2
        }, {
            -1, 1, 0, 2
        }, {
            0, 1, 1, 2
        }, {
            0, 1, -1, 2
        }, {
            1, -1, 0, 1
        }, {
            -1, -1, 0, 1
        }, {
            0, -1, 1, 1
        }, {
            0, -1, -1, 1
        }, {
            1, -2, 0, 1
        }, {
            -1, -2, 0, 1
        }, {
            0, -2, 1, 1
        }, {
            0, -2, -1, 1
        }
    };

    public AS_AStarStatic()
    {
    }

    static boolean isViable(World world, AS_AStarNode as_astarnode, int i)
    {
        int j = as_astarnode.x;
        int k = as_astarnode.y;
        int l = as_astarnode.z;
        int i1 = world.getTypeId(j, k, l);
        if (i1 == Block.LADDER.id)
        {
            return true;
        }
        if (!isPassableBlock(world, j, k, l) || !isPassableBlock(world, j, k + 1, l) || isPassableBlock(world, j, k - 1, l) && (i1 != Block.STATIONARY_WATER.id || i1 != Block.WATER.id))
        {
            return false;
        }
        if (i < 0)
        {
            i *= -1;
        }
        for (int j1 = 1; j1 <= i; j1++)
        {
            if (!isPassableBlock(world, j, k + i, l))
            {
                return false;
            }
        }

        return true;
    }

    static boolean isPassableBlock(World world, int i, int j, int k)
    {
        int l = world.getTypeId(i, j, k);
        if (l != 0)
        {
            return !Block.byId[l].material.isBuildable();
        }
        else
        {
            return true;
        }
    }

    static int getIntCoordFromDoubleCoord(double d)
    {
        return MathHelper.floor(d);
    }

    static double getEntityLandSpeed(EntityLiving entityliving)
    {
        return Math.sqrt(entityliving.motX * entityliving.motX + entityliving.motZ * entityliving.motZ);
    }

    static double getDistanceBetweenNodes(AS_AStarNode as_astarnode, AS_AStarNode as_astarnode1)
    {
        return (double)(Math.abs(as_astarnode.x - as_astarnode1.x) + Math.abs(as_astarnode.y - as_astarnode1.y) + Math.abs(as_astarnode.z - as_astarnode1.z));
    }

    static double getDistanceBetweenCoords(int i, int j, int k, int l, int i1, int j1)
    {
        return Math.sqrt(Math.pow(i - l, 2D) + Math.pow(j - i1, 2D) + Math.pow(k - j1, 2D));
    }

    static boolean isLadder(int i)
    {
        return i == Block.LADDER.id || i == 242 || i == 243;
    }

    static AS_AStarNode[] getAccessNodesSorted(World world, int i, int j, int k, int l, int i1, int j1)
    {
        ArrayList arraylist = new ArrayList();
        for (int k1 = -2; k1 <= 2; k1++)
        {
            for (int i2 = -2; i2 <= 2; i2++)
            {
                for (int j2 = -2; j2 <= 2; j2++)
                {
                    AS_AStarNode as_astarnode = new AS_AStarNode(l + k1, i1 + j2, j1 + i2, 0);
                    if (!isViable(world, as_astarnode, 1))
                    {
                        continue;
                    }
                    as_astarnode.f_distanceToGoal = getDistanceBetweenCoords(i, j, k, as_astarnode.x, as_astarnode.y, as_astarnode.z);
                    int k2 = 0;
                    if (arraylist.size() != 0)
                    {
                        for (; k2 < arraylist.size() && arraylist.get(k2) != null && ((AS_AStarNode)arraylist.get(k2)).f_distanceToGoal <= as_astarnode.f_distanceToGoal; k2++) { }
                    }
                    arraylist.add(k2, as_astarnode);
                }
            }
        }

        int l1 = 0;
        AS_AStarNode aas_astarnode[] = new AS_AStarNode[arraylist.size()];
        AS_AStarNode as_astarnode1;
        while (!arraylist.isEmpty() && (as_astarnode1 = (AS_AStarNode)arraylist.get(0)) != null)
        {
            aas_astarnode[l1] = as_astarnode1;
            arraylist.remove(0);
            l1++;
        }
        return aas_astarnode;
    }

    static AS_PathEntity translateAStarPathtoPathEntity(ArrayList arraylist)
    {
        PathPoint apathpoint[] = new PathPoint[arraylist.size()];
        int i = 0;
        for (int j = arraylist.size(); j > 0;)
        {
            AS_AStarNode as_astarnode = (AS_AStarNode)arraylist.get(j - 1);
            apathpoint[i] = new PathPoint(as_astarnode.x, as_astarnode.y, as_astarnode.z);
            apathpoint[i].i = i == 0;
            apathpoint[i].d = i;
            apathpoint[i].e = i;
            apathpoint[i].f = 1.0F;
            apathpoint[i].g = j;
            if (i > 0)
            {
                apathpoint[i].h = apathpoint[i - 1];
            }
            arraylist.remove(j - 1);
            j--;
            i++;
        }

        return new AS_PathEntity(apathpoint);
    }
}
