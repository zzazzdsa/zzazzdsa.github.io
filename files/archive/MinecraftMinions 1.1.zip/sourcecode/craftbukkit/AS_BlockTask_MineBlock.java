package net.minecraft.server;

public class AS_BlockTask_MineBlock extends AS_BlockTask
{
    public Block targetBlock;
    private int blocksDropped;
    public int blockID;
    public int blockmetadata;
    public boolean disableDangerCheck;

    public AS_BlockTask_MineBlock(AS_Minion_Job_Manager as_minion_job_manager, AS_EntityMinion as_entityminion, int i, int j, int k)
    {
        super(as_minion_job_manager, as_entityminion, i, j, k);
        blocksDropped = 0;
        disableDangerCheck = false;
    }

    public void onStartedTask()
    {
        super.onStartedTask();
    }

    public void onReachedTaskBlock()
    {
        super.onReachedTaskBlock();
        blockID = worker.world.getTypeId(posX, posY, posZ);
        if (blockID == 0)
        {
            onFinishedTask();
        }
        else
        {
            blockmetadata = worker.world.getData(posX, posY, posZ);
            targetBlock = Block.byId[blockID];
        }
    }

    public void onUpdate()
    {
        super.onUpdate();
    }

    public void onFinishedTask()
    {
        super.onFinishedTask();
        checkDangers();
        blockID = worker.world.getTypeId(posX, posY, posZ);
        if (blockID != 0 && Block.byId[blockID].l() >= 0.0F && worker.world.setTypeId(posX, posY, posZ, 0))
        {
            putBlockHarvestInWorkerInventory();
        }
    }

    public void putBlockHarvestInWorkerInventory()
    {
        putBlockHarvestInWorkerInventory(targetBlock, blockID, blockmetadata);
    }

    public void putBlockHarvestInWorkerInventory(Block block, int i, int j)
    {
        if (block.material.isLiquid())
        {
            return;
        }
        int k = block.a(worker.random);
        if (k > 0)
        {
            int l = block.getDropType(i, worker.random, 0);
            if (l > 0)
            {
                ItemStack itemstack = new ItemStack(block.getDropType(i, worker.random, 0), 1, block.getDropData(j));
                if (itemstack != null)
                {
                    itemstack.count = k;
                    if (!worker.inventory.addItemStackToInventory(itemstack))
                    {
                        worker.inventoryFull = true;
                        worker.world.addEntity(new EntityItem(worker.world, posX, posY, posZ, itemstack));
                    }
                }
            }
        }
    }

    public void checkDangers()
    {
        if (!disableDangerCheck)
        {
            checkBlockForDanger(posX, posY - 1, posZ, true);
            checkBlockForDanger(posX + 1, posY, posZ);
            checkBlockForDanger(posX - 1, posY, posZ);
            checkBlockForDanger(posX, posY, posZ + 1);
            checkBlockForDanger(posX, posY, posZ - 1);
        }
        checkBlockForCaveIn(posX, posY + 1, posZ);
    }

    private void checkBlockForCaveIn(int i, int j, int k)
    {
        int l = worker.world.getTypeId(i, j, k);
        if (l > 0 && (l == Block.SAND.id || l == Block.GRAVEL.id))
        {
            putBlockHarvestInWorkerInventory(Block.byId[l], l, 0);
            worker.inventory.consumeInventoryItem(Block.DIRT.id);
            worker.world.setTypeId(i, j, k, Block.DIRT.id);
        }
    }

    private void checkBlockForDanger(int i, int j, int k)
    {
        checkBlockForDanger(i, j, k, false);
    }

    private void checkBlockForDanger(int i, int j, int k, boolean flag)
    {
        int l = worker.world.getTypeId(i, j, k);
        int i1 = 0;
        boolean flag1 = false;
        if (l == 0)
        {
            if (flag)
            {
                flag1 = true;
            }
        }
        else if (!Block.byId[l].material.isBuildable() && l != Block.TORCH.id)
        {
            i1 = worker.world.getData(i, j, k);
            flag1 = true;
        }
        if (flag1)
        {
            if (l != 0 && worker.world.setTypeId(i, j, k, 0))
            {
                putBlockHarvestInWorkerInventory(Block.byId[l], l, i1);
            }
            worker.inventory.consumeInventoryItem(Block.DIRT.id);
            worker.world.setTypeId(i, j, k, Block.DIRT.id);
        }
    }
}
