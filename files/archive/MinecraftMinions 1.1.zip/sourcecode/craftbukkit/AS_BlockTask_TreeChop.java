package net.minecraft.server;

public class AS_BlockTask_TreeChop extends AS_BlockTask
{
    private int treeBlocks;
    private int treeBlockID;
    private int treeBlockmetadata;

    public AS_BlockTask_TreeChop(AS_Minion_Job_Manager as_minion_job_manager, AS_EntityMinion as_entityminion, int i, int j, int k)
    {
        super(as_minion_job_manager, as_entityminion, i, j, k);
        treeBlocks = 0;
        setTaskDuration(5000L);
    }

    public void onUpdate()
    {
        super.onUpdate();
    }

    public void onFinishedTask()
    {
        super.onFinishedTask();
        chopTree();
        if (treeBlockID != 0)
        {
            placeWoodInMinionInventory(worker);
        }
    }

    private void placeWoodInMinionInventory(AS_EntityMinion as_entityminion)
    {
        ItemStack itemstack = Block.byId[treeBlockID].a_(treeBlockmetadata);
        itemstack.count = treeBlocks;
        if (!as_entityminion.inventory.addItemStackToInventory(itemstack))
        {
            EntityItem entityitem = new EntityItem(as_entityminion.world, as_entityminion.locX, (as_entityminion.locY - 0.30000001192092896D) + (double)as_entityminion.y(), as_entityminion.locZ, itemstack);
            entityitem.pickupDelay = 40;
            as_entityminion.world.addEntity(entityitem);
        }
    }

    private void chopTree()
    {
        treeBlockID = worker.world.getTypeId(posX, posY, posZ);
        treeBlockmetadata = worker.world.getData(posX, posY, posZ);
        chopTreeBlockRecursive(posX, posY, posZ);
    }

    private void chopTreeBlockRecursive(int i, int j, int k)
    {
        int l = 1;
        for (int i1 = -l; i1 <= l; i1++)
        {
            for (int j1 = -l; j1 <= l; j1++)
            {
                for (int k1 = 0; k1 <= l; k1++)
                {
                    if (worker.world.getTypeId(i + i1, j + k1, k + j1) == treeBlockID && worker.world.setTypeId(i + i1, j + k1, k + j1, 0))
                    {
                        treeBlocks++;
                        chopTreeBlockRecursive(i + i1, j + k1, k + j1);
                    }
                }
            }
        }
    }
}
