package net.minecraft.server;

import java.util.ArrayList;

public class AS_AStarWorker
    implements Runnable
{
    private AS_AStarPath boss;
    private boolean isRunning;
    public ArrayList closedNodes;
    private AS_AStarNode startNode;
    private AS_AStarNode targetNode;
    private boolean searchMode;
    private World worldObj;
    private long startingTime;
    private int checkedCubes;
    public int maxCheckedCubes;
    public int maxSize;
    public int maxSizeSq;
    public int maxSizeSqMinusOne;
    private AS_AStarNode openList[];
    private int addedItems;

    public AS_AStarWorker(AS_AStarPath as_astarpath)
    {
        isRunning = false;
        closedNodes = new ArrayList();
        checkedCubes = 0;
        maxCheckedCubes = 1000;
        maxSize = 20;
        maxSizeSq = maxSize * maxSize;
        maxSizeSqMinusOne = maxSizeSq - 1;
        openList = new AS_AStarNode[maxSizeSq];
        addedItems = 1;
        boss = as_astarpath;
    }

    public void run()
    {
        if (isRunning)
        {
            return;
        }
        isRunning = true;
        ArrayList arraylist = null;
        arraylist = getPath(startNode, targetNode, searchMode);
        if (arraylist == null)
        {
            boss.OnNoPathAvailable();
        }
        else
        {
            boss.OnFoundPath(arraylist);
        }
    }

    public void setup(World world, AS_AStarNode as_astarnode, AS_AStarNode as_astarnode1, boolean flag)
    {
        worldObj = world;
        startNode = as_astarnode;
        targetNode = as_astarnode1;
        searchMode = flag;
    }

    public void resetSearch()
    {
        closedNodes = new ArrayList();
        checkedCubes = 0;
        openList = new AS_AStarNode[maxSizeSq + 1];
        addedItems = 1;
    }

    public ArrayList getPath(int i, int j, int k, int l, int i1, int j1, boolean flag)
    {
        AS_AStarNode as_astarnode = new AS_AStarNode(i, j, k, 0);
        AS_AStarNode as_astarnode1 = new AS_AStarNode(l, i1, j1, -1);
        return getPath(as_astarnode, as_astarnode1, flag);
    }

    public ArrayList getPath(AS_AStarNode as_astarnode, AS_AStarNode as_astarnode1, boolean flag)
    {
        openList[1] = as_astarnode;
        startingTime = System.currentTimeMillis();
        targetNode = as_astarnode1;
        as_astarnode.f_distanceToGoal = AS_AStarStatic.getDistanceBetweenNodes(as_astarnode, targetNode);
        AS_AStarNode as_astarnode2;
        for (as_astarnode2 = as_astarnode; !as_astarnode2.equals(as_astarnode1); as_astarnode2 = openList[1])
        {
            deleteLowestValueInHeap();
            closedNodes.add(as_astarnode2);
            checkPossibleLadder(as_astarnode2);
            getNextCandidates(as_astarnode2, flag);
            if (addedItems == 0 || addedItems == maxSizeSqMinusOne || Thread.interrupted() || checkedCubes >= maxCheckedCubes)
            {
                return null;
            }
        }

        ArrayList arraylist = new ArrayList();
        arraylist.add(as_astarnode2);
        for (; as_astarnode2 != as_astarnode; as_astarnode2 = as_astarnode2.parent)
        {
            arraylist.add(as_astarnode2.parent);
        }

        return arraylist;
    }

    private void addToBinaryHeap(AS_AStarNode as_astarnode)
    {
        addedItems++;
        if (addedItems == maxSizeSqMinusOne)
        {
            Thread.yield();
            return;
        }
        else
        {
            openList[addedItems] = as_astarnode;
            sortBinaryHeap();
            checkedCubes++;
            return;
        }
    }

    private void sortBinaryHeap()
    {
        sortBinaryHeapFromValue(addedItems);
    }

    private void sortBinaryHeapFromValue(int i)
    {
        for (; i > 1 && openList[i].f_distanceToGoal <= openList[i / 2].f_distanceToGoal; i /= 2)
        {
            AS_AStarNode as_astarnode = openList[i / 2];
            openList[i / 2] = openList[i];
            openList[i] = as_astarnode;
        }
    }

    private void deleteLowestValueInHeap()
    {
        openList[1] = openList[addedItems];
        addedItems--;
        int i = 1;
        do
        {
            int j = i;
            if (2 * j + 1 <= addedItems)
            {
                if (openList[j].f_distanceToGoal >= openList[2 * j].f_distanceToGoal)
                {
                    i = 2 * j;
                }
                if (openList[i].f_distanceToGoal >= openList[2 * j + 1].f_distanceToGoal)
                {
                    i = 2 * j + 1;
                }
            }
            else if (2 * j <= addedItems && openList[j].f_distanceToGoal >= openList[2 * j].f_distanceToGoal)
            {
                i = 2 * j;
            }
            if (j != i)
            {
                AS_AStarNode as_astarnode = openList[j];
                openList[j] = openList[i];
                openList[i] = as_astarnode;
            }
            else
            {
                return;
            }
        }
        while (true);
    }

    private void checkPossibleLadder(AS_AStarNode as_astarnode)
    {
        int i = as_astarnode.x;
        int j = as_astarnode.y;
        int k = as_astarnode.z;
        if (AS_AStarStatic.isLadder(worldObj.getTypeId(i, j, k)))
        {
            Object obj = null;
            if (AS_AStarStatic.isLadder(worldObj.getTypeId(i, j + 1, k)))
            {
                AS_AStarNode as_astarnode1 = new AS_AStarNode(i, j + 1, k, as_astarnode.g_BlockDistToStart + 1, as_astarnode);
                as_astarnode1.f_distanceToGoal = AS_AStarStatic.getDistanceBetweenNodes(as_astarnode1, targetNode);
                if (!tryToFindExistingHeapNode(as_astarnode, as_astarnode1))
                {
                    addToBinaryHeap(as_astarnode1);
                }
            }
            if (AS_AStarStatic.isLadder(worldObj.getTypeId(i, j - 1, k)))
            {
                AS_AStarNode as_astarnode2 = new AS_AStarNode(i, j - 1, k, as_astarnode.g_BlockDistToStart + 1, as_astarnode);
                as_astarnode2.f_distanceToGoal = AS_AStarStatic.getDistanceBetweenNodes(as_astarnode2, targetNode);
                if (!tryToFindExistingHeapNode(as_astarnode, as_astarnode2))
                {
                    addToBinaryHeap(as_astarnode2);
                }
            }
        }
    }

    public void getNextCandidates(AS_AStarNode as_astarnode, boolean flag)
    {
        int i = as_astarnode.x;
        int j = as_astarnode.y;
        int k = as_astarnode.z;
        int l = as_astarnode.g_BlockDistToStart;
        int ai[][] = flag ? AS_AStarStatic.candidates_allowdrops : AS_AStarStatic.candidates;
        for (int i1 = 0; i1 < ai.length; i1++)
        {
            AS_AStarNode as_astarnode1 = new AS_AStarNode(i + ai[i1][0], j + ai[i1][1], k + ai[i1][2], l + ai[i1][3], as_astarnode);
            as_astarnode1.f_distanceToGoal = AS_AStarStatic.getDistanceBetweenNodes(as_astarnode1, targetNode);
            if (closedNodes.contains(as_astarnode1))
            {
                ((AS_AStarNode)closedNodes.get(closedNodes.indexOf(as_astarnode1))).updateDistance(as_astarnode1.g_BlockDistToStart, as_astarnode);
                continue;
            }
            if (!tryToFindExistingHeapNode(as_astarnode, as_astarnode1) && AS_AStarStatic.isViable(worldObj, as_astarnode1, ai[i1][1]))
            {
                addToBinaryHeap(as_astarnode1);
            }
        }
    }

    private boolean tryToFindExistingHeapNode(AS_AStarNode as_astarnode, AS_AStarNode as_astarnode1)
    {
        for (int i = 1; i <= addedItems; i++)
        {
            if (openList[i] != null && openList[i].equals(as_astarnode1))
            {
                if (openList[i].updateDistance(as_astarnode1.g_BlockDistToStart, as_astarnode))
                {
                    sortBinaryHeapFromValue(i);
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        return false;
    }
}
