package net.minecraft.src;

import java.util.*;

/**
 * Static parts of AStarPath calculation and translation
 * 
 * @author AtomicStryker
 */

public final class AS_AStarStatic
{
	
	static boolean isViable(World worldObj, AS_AStarNode target, int yoffset)
	{
		int x = target.x;
		int y = target.y;
		int z = target.z;
		int id = worldObj.getBlockId(x, y, z);

		if (id == Block.ladder.blockID)
		{
			return true;
		}

		if (!isPassableBlock(worldObj, x, y, z)
		|| !isPassableBlock(worldObj, x, y+1, z)
		|| (isPassableBlock(worldObj, x, y-1, z) && (id != Block.waterStill.blockID || id != Block.waterMoving.blockID)))
		{
			return false;
		}

		if (yoffset < 0) yoffset *= -1;
		int ycheckhigher = 1;
		while (ycheckhigher <= yoffset)
		{
			if (!isPassableBlock(worldObj, x, y+yoffset, z))
			{
				return false;
			}
			ycheckhigher++;
		}

		return true;
	}
	
	static boolean isPassableBlock(World worldObj, int ix, int iy, int iz)
	{
		int id = worldObj.getBlockId(ix, iy, iz);

		if (id != 0)
		{
			return !Block.blocksList[id].blockMaterial.isSolid();
		}

		return true;
	}
	
	static int getIntCoordFromDoubleCoord(double input)
	{
		return MathHelper.floor_double(input);
	}
	
	static double getEntityLandSpeed(EntityLiving entLiving)
	{
		return Math.sqrt((entLiving.motionX * entLiving.motionX) + (entLiving.motionZ * entLiving.motionZ));
	}
	
	static double getDistanceBetweenNodes(AS_AStarNode a, AS_AStarNode b)
	{
		return (Math.abs(a.x-b.x) + Math.abs(a.y - b.y) + Math.abs(a.z - b.z));
		//return Math.sqrt(Math.pow((a.x - b.x), 2) + Math.pow((a.y - b.y), 2) + Math.pow((a.z - b.z), 2));
	}
	
	static double getDistanceBetweenCoords(int x, int y, int z, int posX, int posY, int posZ)
	{
		return Math.sqrt(Math.pow(x-posX, 2) + Math.pow(y-posY, 2) + Math.pow(z-posZ, 2));
	}
	
	final static int candidates[][] =
	{
		{
			0, 0, -1, 1
		}, {
			0, 0, 1, 1
		}, {
			0, 1, 0, 1
		}, {
			1, 0, 0, 1
		}, {
			-1, 0, 0, 1
		}, {
			1, 1, 0, 2
		}, {
			-1, 1, 0, 2
		}, {
			0, 1, 1, 2
		}, {
			0, 1, -1, 2
		}, {
			1, -1, 0, 1
		}, {
			-1, -1, 0, 1
		}, {
			0, -1, 1, 1
		}, {
			0, -1, -1, 1
		}
	};

	final static int candidates_allowdrops[][] =
	{
		{
			0, 0, -1, 1
		}, {
			0, 0, 1, 1
		}, {
			1, 0, 0, 1
		}, {
			-1, 0, 0, 1
		}, {
			1, 1, 0, 2
		}, {
			-1, 1, 0, 2
		}, {
			0, 1, 1, 2
		}, {
			0, 1, -1, 2
		}, {
			1, -1, 0, 1
		}, {
			-1, -1, 0, 1
		}, {
			0, -1, 1, 1
		}, {
			0, -1, -1, 1
		}, {
			1, -2, 0, 1
		}, {
			-1, -2, 0, 1
		}, {
			0, -2, 1, 1
		}, {
			0, -2, -1, 1
		}
	};
	
	static boolean isLadder(int id)
	{
		return (id == Block.ladder.blockID
			|| id == 242
			|| id == 243);
	}
	
    static AS_AStarNode[] getAccessNodesSorted(World worldObj, int workerX, int workerY, int workerZ, int posX, int posY, int posZ)
    {
    	ArrayList resultList = new ArrayList();

		AS_AStarNode check;
		for (int xIter = -2; xIter <= 2; xIter++)
		{
			for (int zIter = -2; zIter <= 2; zIter++)
			{
				for (int yIter = -2; yIter <= 2; yIter++)
				{
					check = new AS_AStarNode(posX+xIter, posY+yIter, posZ+zIter, 0);
					
					if (AS_AStarStatic.isViable(worldObj, check, 1))
					{
						check.f_distanceToGoal = ((AS_AStarStatic.getDistanceBetweenCoords(workerX, workerY, workerZ, check.x, check.y, check.z)));
						
						int index = 0;
						if (resultList.size() != 0)
						{
							while(index < resultList.size() && resultList.get(index) != null && ((AS_AStarNode)resultList.get(index)).f_distanceToGoal <= check.f_distanceToGoal)
							{
								index++;
							}
						}
						resultList.add(index, check);
					}
				}
			}
		}
		
		int count = 0;
		AS_AStarNode[] returnVal = new AS_AStarNode[resultList.size()];
		while (!resultList.isEmpty() && (check = (AS_AStarNode) resultList.get(0)) != null)
		{
			returnVal[count] = check;
			resultList.remove(0);
			count++;
		}
		
    	return returnVal;
    }
	
	static AS_PathEntity translateAStarPathtoPathEntity(ArrayList input)
	{
		PathPoint[] points = new PathPoint[input.size()];
		AS_AStarNode reading;
		int i = 0;
		int size = input.size();
		//System.out.println("Translating AStar Path with "+size+" Hops:");
		
		while(size > 0)
		{
			reading = (AS_AStarNode) input.get(size-1);
			points[i] = new PathPoint(reading.x, reading.y, reading.z);
			points[i].isFirst = i == 0;
			points[i].index = i;
			points[i].totalPathDistance = i;
			points[i].distanceToNext = 1F;
			points[i].distanceToTarget = size;
			
			if (i>0)
			{
				points[i].previous = points[i-1];
			}
			//System.out.println("PathPoint: ["+reading.x+"|"+reading.y+"|"+reading.z+"]");
			
			input.remove(size-1);
			size --;
			i++;
		}
		//System.out.println("Translated AStar PathEntity with length: "+ points.length);
		
		return new AS_PathEntity(points);
	}
}