package atomicstryker.battletowers.common;

public class CommonProxy
{
    public void load()
    {
        
    }
}
