package net.minecraft.src;

import java.util.Map;
import org.lwjgl.input.*;
import net.minecraft.client.Minecraft;
import java.util.*;

public class mod_FinderCompassForOptifine extends BaseMod
{
	@Override
	public void load()
	{
        ModLoader.SetInGameHook(this, true, false);
	}
	
    public String getVersion()
	{
        return "1.0.0";
    }

    public boolean OnTickInGame(float renderTick, Minecraft mc)
	{
    	if (!TextureCompassFX.isHackedIn)
    	{
    		TextureCompassFX replacement = new TextureCompassFX(mc);
    		
    		if (TextureCompassFX.isHackedIn)
    		{
    			mc.renderEngine.registerTextureFX(replacement);
    		}
    	}
        
        return true;
    }
}
