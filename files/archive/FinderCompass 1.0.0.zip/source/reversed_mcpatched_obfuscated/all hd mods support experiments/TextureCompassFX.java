package net.minecraft.src;

import java.awt.image.BufferedImage;
import java.io.*;
import java.util.*;
import java.util.Map.*;

import net.minecraft.client.Minecraft;
import java.lang.reflect.*;

import javax.imageio.ImageIO;

public class TextureCompassFX extends TextureFX {

   private Minecraft mc;
   private int[] tsize;
   private double[] i = new double[30];
   private double[] j = new double[30];
   private int[] spawnNeedlecolor = new int[]{255, 20, 20};
   private int[] strongholdNeedlecolor = new int[]{175, 220, 0};
   private static Map customNeedles = new HashMap();
   private static Map customNeedleTargets = new HashMap();
   private static boolean areSettingsLoaded = false;
   static File settingsFile;
   final double HEADING_DOWN = 0.0D;
   final double HEADING_UP = 135.0D;
   private int x;
   private int y;
   private int z;
   private final ChunkCoordinates NullChunk = new ChunkCoordinates(0, 0, 0);
   private long lastTime;
   private int seccounter = 0;
   private boolean updateScan = false;
   private ChunkCoordinates nextStronghold = new ChunkCoordinates(0, 0, 0);
   
   public int modState = -1; // tracks which texture mod is running in this Minecraft. 0 is default, 1 mcpatcher, 2 optifine
   public int tilesize_intsize = 16;
   public int tilesize_numpixels = 256;
   public BufferedImage texture;
   
   public int tileSize_int_compassCrossMin = -4;
   public int tileSize_int_compassCrossMax = 4;
   public double tileSize_double_compassCenterMin = tilesize_intsize / 2 - 0.5D;
   public double tileSize_double_compassCenterMax = tilesize_intsize / 2 + 0.5D;
   public int tileSize_int_compassNeedleMin = -8;
   public int tileSize_int_compassNeedleMax = 16;
   public static boolean isHackedIn = false;

   public TextureCompassFX(Minecraft var1)
   {
	   super(Item.compass.getIconFromDamage(0));
	   this.mc = var1;
	   
	   checkModState();
      
	   this.tsize = new int[tilesize_numpixels];
	   this.tileImage = 1;
		
	   BufferedImage var2 = texture;
	   int var3 = this.iconIndex % 16 * tilesize_intsize;
	   int var4 = this.iconIndex / 16 * tilesize_intsize;
	   var2.getRGB(var3, var4, tilesize_intsize, tilesize_intsize, this.tsize, 0, tilesize_intsize);
   }

   private void checkModState()
   {
	   try
	   {
		   texture = ImageIO.read(Minecraft.class.getResource("/gui/items.png"));
	   }
	   catch (IOException e)
	   {
		   e.printStackTrace();
	   }
	   
	   Class finder = null;
	   try
	   {
		   finder = Class.forName("com.pclewis.mcpatcher.mod.TileSize");
	   }
	   catch (ClassNotFoundException e)
	   {
		   System.out.println("Finder Compass: Did not detect mcpatcher HD Textures");
	   }
	   
	   if (finder != null)
	   {
		   System.out.println("Finder Compass: mcpatcher HD Textures detected, setting up...");
		   modState = 1;
		   
		   try
		   {
			   tilesize_intsize = (Integer) finder.getField("int_size").get(null);
			   tilesize_numpixels = (Integer) finder.getField("int_numPixels").get(null);
			   tileSize_int_compassCrossMin = (Integer) finder.getField("int_compassCrossMin").get(null);
			   tileSize_int_compassCrossMax = (Integer) finder.getField("int_compassCrossMax").get(null);
			   tileSize_int_compassNeedleMin = (Integer) finder.getField("int_compassNeedleMin").get(null);
			   tileSize_int_compassNeedleMax = (Integer) finder.getField("int_compassNeedleMax").get(null);
			   tileSize_double_compassCenterMin = (Double) finder.getField("double_compassCenterMin").get(null);
			   tileSize_double_compassCenterMax = (Double) finder.getField("double_compassCenterMax").get(null);
			   
			   finder = Class.forName("com.pclewis.mcpatcher.mod.TextureUtils");
			   Method[] ms = finder.getMethods();
			   for (int i = 0; i < ms.length; i++)
			   {
				   Method m = ms[i];
				   if (m.getName().equals("getResourceAsBufferedImage") && m.getParameterTypes().length == 1)
				   {
					   Object[] args = {new String("/gui/items.png")};
					   texture = (BufferedImage) m.invoke(null, args);
				   }
			   }
		   } catch (IllegalArgumentException e) {
			   e.printStackTrace();
		   } catch (SecurityException e) {
			   e.printStackTrace();
		   } catch (IllegalAccessException e) {
			   e.printStackTrace();
		   } catch (NoSuchFieldException e) {
			   e.printStackTrace();
		   } catch (InvocationTargetException e) {
			   e.printStackTrace();
		   } catch (ClassNotFoundException e) {
			   e.printStackTrace();
		   }
		   
		   isHackedIn = true;
		   return;
	   }
	   
	   try
	   {
		   finder = Class.forName("TextureHDCompassFX");
	   }
	   catch (ClassNotFoundException e)
	   {
		   System.out.println("Finder Compass: Did not detect Optifine HD Textures");
	   }
	   
	   if (finder != null)
	   {
		   System.out.println("Finder Compass: Optifine HD Textures detected, setting up...");
		   modState = 2;
		   
		   try
		   {
			   if (mc == null || mc.renderEngine == null)
			   {
				   System.out.println("MC or MC.renderEngine null!!");
				   return;
			   }
			   
			   Field[] f = mc.renderEngine.getClass().getDeclaredFields();
			   Object optifinecompass = null;
			   System.out.println("Searching for List, found class "+mc.renderEngine.getClass()+" got "+f.length+" fields");
			   for (int i = 0; i < f.length; i++)
			   {
				   f[i].setAccessible(true);
				   if (f[i].get(mc.renderEngine) instanceof java.util.ArrayList)
				   {
					   ArrayList textureFXthings = (ArrayList) f[i].get(mc.renderEngine);
					   System.out.println("Found TextFX list with "+ textureFXthings.size() +" items, now checking for instance of "+finder);
					   for (int j = 0; j < textureFXthings.size(); j++)
					   {
						   System.out.println("TextFX item "+j+" has "+textureFXthings.get(j).getClass());
						   if (textureFXthings.get(j).getClass().equals(finder))
						   {
							   System.out.println("Found Optifine Compass!");
							   optifinecompass = textureFXthings.get(j);
							   break;
						   }
					   }
				   }
			   }
			   
			   if (optifinecompass == null)
			   {
				   System.out.println("Found no Optifine Compass, derp!");
				   return;
			   }

			   Field width = finder.getDeclaredField("tileWidth");
			   width.setAccessible(true);
			   tilesize_intsize = (Integer) width.get(optifinecompass);
			   tilesize_numpixels = tilesize_intsize * tilesize_intsize;
			   tileSize_double_compassCenterMin = tilesize_intsize / 2 - 0.5D;
			   tileSize_double_compassCenterMax = tilesize_intsize / 2 + 0.5D;
			   
			   this.imageData = new byte[4*tilesize_numpixels];
			   tileSize_int_compassNeedleMin = (int) (Math.sqrt(tilesize_numpixels) / -2);
			   tileSize_int_compassNeedleMax =  (int) Math.sqrt(tilesize_numpixels);
			   
			   System.out.println("Optifine Compass Values reading finished; tilesize_intsize = "+tilesize_intsize+"; tilesize_numpixels = "+tilesize_numpixels+";");
			   
			   Field texturebaseoptifine = finder.getDeclaredField("texturePackBase");
			   texturebaseoptifine.setAccessible(true);
			   
			   if (texturebaseoptifine.get(optifinecompass) != null)
			   {
				   Class texturePackBase = texturebaseoptifine.get(optifinecompass).getClass();
				   Method[] ms = texturePackBase.getMethods();
				   for (int i = 0; i < ms.length; i++)
				   {
					   Method m = ms[i];
					   if (m.getReturnType().equals(java.io.InputStream.class) && m.getParameterTypes().length == 1)
					   {
						   Object[] args = {new String("/gui/items.png")};
						   texture = ImageIO.read((InputStream) m.invoke(texturebaseoptifine.get(optifinecompass), args));
					   }
				   }
			   }

		   } catch (IllegalArgumentException e) {
			   e.printStackTrace();
		   } catch (SecurityException e) {
			   e.printStackTrace();
		   } catch (IllegalAccessException e) {
			   e.printStackTrace();
		   } catch (NoSuchFieldException e) {
			   e.printStackTrace();
		   } catch (InvocationTargetException e) {
			   e.printStackTrace();
		   } catch (IOException e) {
			e.printStackTrace();
		   }
		   isHackedIn = true;
		   return;
	   }
	   
	   System.out.println("Finder Compass: Did not detect any HD Textures, going with vanilla");
	   modState = 0;
	   isHackedIn = true;
   }

   ChunkCoordinates getStrongholdChunk() {
      ChunkPosition var1 = this.getStrongholdPos();
      return var1 != null?new ChunkCoordinates(var1.x, var1.y, var1.z):this.NullChunk;
   }

   ChunkPosition getStrongholdPos() {
      return this.mc.theWorld.func_40477_b("Stronghold", this.x, this.y, this.z);
   }

   public void onTick() {
      int var1;
      int var2;
      for(int var3 = 0; var3 < tilesize_numpixels; ++var3) {
         int var4 = this.tsize[var3] >> 24 & 255;
         var1 = this.tsize[var3] >> 16 & 255;
         int var5 = this.tsize[var3] >> 8 & 255;
         var2 = this.tsize[var3] >> 0 & 255;
         if(this.anaglyphEnabled) {
            int var6 = (var1 * 30 + var5 * 59 + var2 * 11) / 100;
            int var7 = (var1 * 30 + var5 * 70) / 100;
            int var8 = (var1 * 30 + var2 * 70) / 100;
            var1 = var6;
            var5 = var7;
            var2 = var8;
         }

         this.imageData[var3 * 4 + 0] = (byte)var1;
         this.imageData[var3 * 4 + 1] = (byte)var5;
         this.imageData[var3 * 4 + 2] = (byte)var2;
         this.imageData[var3 * 4 + 3] = (byte)var4;
      }

      if(this.mc.theWorld != null && this.mc.thePlayer != null) {
         if(!areSettingsLoaded) {
            this.lastTime = System.currentTimeMillis();
            this.initializeSettingsFile();
         }

         boolean var9 = false;
         boolean var10 = false;
         if(System.currentTimeMillis() > this.lastTime + 1000L) {
            var9 = true;
            ++this.seccounter;
            this.lastTime = System.currentTimeMillis();
         }

         this.drawNeedle(0, this.computeNeedleHeading(this.mc.theWorld.getSpawnPoint()), this.spawnNeedlecolor, true);
         this.drawNeedle(1, this.computeNeedleHeading(this.nextStronghold), this.strongholdNeedlecolor, false);
         if((int)this.mc.thePlayer.posX != this.x || (int)this.mc.thePlayer.posY != this.y || (int)this.mc.thePlayer.posZ != this.z) {
            this.x = (int)this.mc.thePlayer.posX;
            this.y = (int)this.mc.thePlayer.posY;
            this.z = (int)this.mc.thePlayer.posZ;
            this.updateScan = true;
         }

         if(this.updateScan && var9 && this.seccounter > 14) {
            this.seccounter = 0;
            var10 = true;
            this.nextStronghold = this.getStrongholdChunk();
         }

         int[] var11;
         ChunkCoordinates var12;
         Iterator var13;
         Entry var14;
         if(this.updateScan && var9) {
            this.updateScan = false;
            var13 = customNeedles.entrySet().iterator();

            while(var13.hasNext()) {
               var14 = (Entry)var13.next();
               var2 = ((Integer)var14.getKey()).intValue();
               var11 = (int[])((int[])((int[])((int[])var14.getValue())));
               if(var10 || var11[7] == 0) {
                  var12 = this.findNearestBlockChunkOfIDInRange(var2, this.x, this.y, this.z, var11[3], var11[4], var11[5], var11[6]);
                  if(!var12.equals(this.NullChunk)) {
                     if(customNeedleTargets.containsKey(var11)) {
                        customNeedleTargets.remove(var11);
                     }

                     customNeedleTargets.put(var11, var12);
                  } else {
                     customNeedleTargets.remove(var11);
                  }
               }
            }
         }

         var1 = 3;
         var13 = customNeedleTargets.entrySet().iterator();

         while(var13.hasNext()) {
            var14 = (Entry)var13.next();
            var11 = (int[])((int[])((int[])((int[])var14.getKey())));
            var12 = (ChunkCoordinates)var14.getValue();
            ++var1;
            this.drawNeedle(var1, this.computeNeedleHeading(var12), var11, false);
         }
      }

   }

   public double computeNeedleHeading(ChunkCoordinates var1) {
      double var2 = 0.0D;
      if(this.mc.theWorld != null && this.mc.thePlayer != null) {
         double var4 = (double)var1.posX - this.mc.thePlayer.posX;
         double var6 = (double)var1.posZ - this.mc.thePlayer.posZ;
         var2 = (double)(this.mc.thePlayer.rotationYaw - 90.0F) * 3.141592653589793D / 180.0D - Math.atan2(var6, var4);
         if(this.mc.theWorld.worldProvider.isNether) {
            var2 = Math.random() * 3.1415927410125732D * 2.0D;
         }
      }

      return var2;
   }

   public void drawNeedle(int var1, double var2, int[] var4, boolean var5) {
      double var6;
      for(var6 = var2 - this.i[var1]; var6 < -3.141592653589793D; var6 += 6.283185307179586D) {
         ;
      }

      while(var6 >= 3.141592653589793D) {
         var6 -= 6.283185307179586D;
      }

      if(var6 < -1.0D) {
         var6 = -1.0D;
      }

      if(var6 > 1.0D) {
         var6 = 1.0D;
      }

      this.i[var1] += var6 * 0.1D;
      this.j[var1] *= 0.8D;
      this.j[var1] += this.i[var1];
      double var8 = Math.sin(this.i[var1]);
      double var10 = Math.cos(this.i[var1]);
      int var12;
      int var13;
      int var14;
      int var15;
      int var17;
      int var16;
      short var19;
      int var18;
      int var21;
      int var20;
      int var22;
      if(var5) {
         for(var12 = tileSize_int_compassCrossMin; var12 <= tileSize_int_compassCrossMax; ++var12) {
            var13 = (int)(tileSize_double_compassCenterMax + var10 * (double)var12 * 0.3D);
            var14 = (int)(tileSize_double_compassCenterMin - var8 * (double)var12 * 0.3D * 0.5D);
            var15 = var14 * tilesize_intsize + var13;
            var16 = 100;
            var17 = 100;
            var18 = 100;
            var19 = 255;
            if(this.anaglyphEnabled) {
               var20 = (var16 * 30 + var17 * 59 + var18 * 11) / 100;
               var21 = (var16 * 30 + var17 * 70) / 100;
               var22 = (var16 * 30 + var18 * 70) / 100;
               var16 = var20;
               var17 = var21;
               var18 = var22;
            }

            this.imageData[var15 * 4 + 0] = (byte)var16;
            this.imageData[var15 * 4 + 1] = (byte)var17;
            this.imageData[var15 * 4 + 2] = (byte)var18;
            this.imageData[var15 * 4 + 3] = (byte)var19;
         }
      }

      for(var12 = tileSize_int_compassNeedleMin; var12 <= tileSize_int_compassNeedleMax; ++var12) {
         var13 = (int)(tileSize_double_compassCenterMax + var8 * (double)var12 * 0.3D);
         var14 = (int)(tileSize_double_compassCenterMin + var10 * (double)var12 * 0.3D * 0.5D);
         var15 = var14 * tilesize_intsize + var13;
         var16 = var12 < 0?100:var4[0];
         var17 = var12 < 0?100:var4[1];
         var18 = var12 < 0?100:var4[2];
         var19 = 255;
         if(this.anaglyphEnabled) {
            var20 = (var16 * 30 + var17 * 59 + var18 * 11) / 100;
            var21 = (var16 * 30 + var17 * 70) / 100;
            var22 = (var16 * 30 + var18 * 70) / 100;
            var16 = var20;
            var17 = var21;
            var18 = var22;
         }

         this.imageData[var15 * 4 + 0] = (byte)var16;
         this.imageData[var15 * 4 + 1] = (byte)var17;
         this.imageData[var15 * 4 + 2] = (byte)var18;
         this.imageData[var15 * 4 + 3] = (byte)var19;
      }

   }

   void initializeSettingsFile() {
      settingsFile = new File(Minecraft.getAppDir("minecraft"), "findercompass.cfg");
      System.out.println("initializeSettingsFile() running");

      try {
         if(settingsFile.exists()) {
            System.out.println(".minecraft/findercompass.cfg found and opened");
            BufferedReader var1 = new BufferedReader(new FileReader(settingsFile));

            String var2;
            while((var2 = var1.readLine()) != null) {
               if(!var2.startsWith("//")) {
                  String[] var3 = var2.split(":");
                  int var4 = Integer.parseInt(var3[0]);
                  int[] var5 = new int[8];
                  var5[0] = Integer.parseInt(var3[1]);
                  var5[1] = Integer.parseInt(var3[2]);
                  var5[2] = Integer.parseInt(var3[3]);
                  System.out.println("Finder Compass: loaded custom needle of id " + var4 + ", color [" + var5[0] + "," + var5[1] + "," + var5[2]);
                  var5[3] = Integer.parseInt(var3[4]);
                  var5[4] = Integer.parseInt(var3[5]);
                  var5[5] = Integer.parseInt(var3[6]);
                  var5[6] = Integer.parseInt(var3[7]);
                  var5[7] = Integer.parseInt(var3[8]);
                  System.out.println("Full readout: " + var5[0] + ":" + var5[1] + ":" + var5[2] + ":" + var5[3] + ":" + var5[4] + ":" + var5[5] + ":" + var5[6] + ":" + var5[7]);
                  customNeedles.put(Integer.valueOf(var4), var5);
               }
            }

            var1.close();
         } else {
            this.mc.ingameGUI.addChatMessage(".minecraft/findercompass.cfg not found, Finder Compass NOT ACTIVE");
         }
      } catch (Exception var6) {
         System.out.println("EXCEPTION BufferedReader");
      }

      this.mc.ingameGUI.addChatMessage("Finder Compass config loaded; " + customNeedles.size() + " custom needles loaded");
      System.out.println("config file reading finished");
      areSettingsLoaded = true;
   }

   ChunkCoordinates findNearestBlockChunkOfIDInRange(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      List var9 = this.findBlocksOfIDInRange(var1, var2, var3, var4, var5, var6, var7, var8);
      ChunkCoordinates var10 = new ChunkCoordinates(var2, var3, var4);
      ChunkCoordinates var11 = new ChunkCoordinates(0, 0, 0);
      double var12 = 9999.0D;

      for(int var14 = 0; var14 < var9.size(); ++var14) {
         ChunkCoordinates var15 = (ChunkCoordinates)var9.get(var14);
         double var16 = this.GetDistanceBetweenChunks(var10, var15);
         if(var16 < var12) {
            var11 = var15;
            var12 = var16;
         }
      }

      ChunkCoordinates var18 = new ChunkCoordinates(var11.posX, var11.posY, var11.posZ);
      return var18;
   }

   List findBlocksOfIDInRange(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      ArrayList var9 = new ArrayList();

      for(int var10 = var3 - var6 - 1; var10 <= var3 + var6; ++var10) {
         if(var10 >= var7 && var10 <= var8) {
            for(int var11 = var4 - var5; var11 <= var4 + var5; ++var11) {
               for(int var12 = var2 - var5; var12 <= var2 + var5; ++var12) {
                  if(this.mc.theWorld.getBlockId(var12, var10, var11) == var1) {
                     ChunkCoordinates var13 = new ChunkCoordinates(var12, var10, var11);
                     var9.add(var13);
                  }
               }
            }
         }
      }

      return var9;
   }

   double GetDistanceBetweenChunks(ChunkCoordinates var1, ChunkCoordinates var2) {
      int var3 = Math.abs(var1.posX - var2.posX);
      int var4 = Math.abs(var1.posY - var2.posY);
      int var5 = Math.abs(var1.posZ - var2.posZ);
      return Math.sqrt(Math.pow((double)var3, 2.0D) + Math.pow((double)var4, 2.0D) + Math.pow((double)var5, 2.0D));
   }

}
