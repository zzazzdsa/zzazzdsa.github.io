import com.pclewis.mcpatcher.mod.TextureUtils;
import com.pclewis.mcpatcher.mod.TileSize;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.client.Minecraft;

public class aih extends dt {

   private Minecraft mc;
   private int[] tsize;
   private double[] i = new double[30];
   private double[] j = new double[30];
   private int[] spawnNeedlecolor = new int[]{255, 20, 20};
   private int[] strongholdNeedlecolor = new int[]{175, 220, 0};
   private static Map customNeedles = new HashMap();
   private static Map customNeedleTargets = new HashMap();
   private static boolean areSettingsLoaded = false;
   static File settingsFile;
   final double HEADING_DOWN = 0.0D;
   final double HEADING_UP = 135.0D;
   private int x;
   private int y;
   private int z;
   private final dh NullChunk = new dh(0, 0, 0);
   private long lastTime;
   private int seccounter = 0;
   private boolean updateScan = false;
   private dh nextStronghold = new dh(0, 0, 0);


   public aih(Minecraft var1) {
      super(acy.aP.a(0));
      this.tsize = new int[TileSize.int_numPixels];
      this.mc = var1;
      this.f = 1;

      try {
         BufferedImage var5 = TextureUtils.getResourceAsBufferedImage("/gui/items.png");
         int var3 = this.b % 16 * TileSize.int_size;
         int var4 = this.b / 16 * TileSize.int_size;
         var5.getRGB(var3, var4, TileSize.int_size, TileSize.int_size, this.tsize, 0, TileSize.int_size);
      } catch (IOException var51) {
         var51.printStackTrace();
      }

   }

   dh getStrongholdChunk() {
      am cp = this.getStrongholdPos();
      return cp != null?new dh(cp.a, cp.b, cp.c):this.NullChunk;
   }

   // find this class ChunkPosition by numbers 8976890 and 981131 used for hashcode calc.
   am getStrongholdPos() {
      return this.mc.f.b("Stronghold", this.x, this.y, this.z);
   }

   public void a() {
      int var3;
      int var5;
      for(int var9 = 0; var9 < TileSize.int_numPixels; ++var9) {
         int var10 = this.tsize[var9] >> 24 & 255;
         var3 = this.tsize[var9] >> 16 & 255;
         int var14 = this.tsize[var9] >> 8 & 255;
         var5 = this.tsize[var9] >> 0 & 255;
         if(this.c) {
            int var16 = (var3 * 30 + var14 * 59 + var5 * 11) / 100;
            int var12 = (var3 * 30 + var14 * 70) / 100;
            int var15 = (var3 * 30 + var5 * 70) / 100;
            var3 = var16;
            var14 = var12;
            var5 = var15;
         }

         this.a[var9 * 4 + 0] = (byte)var3;
         this.a[var9 * 4 + 1] = (byte)var14;
         this.a[var9 * 4 + 2] = (byte)var5;
         this.a[var9 * 4 + 3] = (byte)var10;
      }

      if(this.mc.f != null && this.mc.h != null) {
         if(!areSettingsLoaded) {
            this.lastTime = System.currentTimeMillis();
            this.initializeSettingsFile();
         }

         boolean var91 = false;
         boolean var101 = false;
         if(System.currentTimeMillis() > this.lastTime + 1000L) {
            var91 = true;
            ++this.seccounter;
            this.lastTime = System.currentTimeMillis();
         }

         this.drawNeedle(0, this.computeNeedleHeading(this.mc.f.v()), this.spawnNeedlecolor, true);
         this.drawNeedle(1, this.computeNeedleHeading(this.nextStronghold), this.strongholdNeedlecolor, false);
         if((int)this.mc.h.s != this.x || (int)this.mc.h.t != this.y || (int)this.mc.h.u != this.z) {
            this.x = (int)this.mc.h.s;
            this.y = (int)this.mc.h.t;
            this.z = (int)this.mc.h.u;
            this.updateScan = true;
         }

         if(this.updateScan && var91 && this.seccounter > 14) {
            this.seccounter = 0;
            var101 = true;
            this.nextStronghold = this.getStrongholdChunk();
         }

         int[] var11;
         dh var121;
         Iterator var13;
         Entry var141;
         if(this.updateScan && var91) {
            this.updateScan = false;
            var13 = customNeedles.entrySet().iterator();

            while(var13.hasNext()) {
               var141 = (Entry)var13.next();
               var5 = ((Integer)var141.getKey()).intValue();
               var11 = (int[])((int[])((int[])var141.getValue()));
               if(var101 || var11[7] == 0) {
                  var121 = this.findNearestBlockChunkOfIDInRange(var5, this.x, this.y, this.z, var11[3], var11[4], var11[5], var11[6]);
                  if(!var121.equals(this.NullChunk)) {
                     if(customNeedleTargets.containsKey(var11)) {
                        customNeedleTargets.remove(var11);
                     }

                     customNeedleTargets.put(var11, var121);
                  } else {
                     customNeedleTargets.remove(var11);
                  }
               }
            }
         }

         var3 = 3;
         var13 = customNeedleTargets.entrySet().iterator();

         while(var13.hasNext()) {
            var141 = (Entry)var13.next();
            var11 = (int[])((int[])((int[])var141.getKey()));
            var121 = (dh)var141.getValue();
            ++var3;
            this.drawNeedle(var3, this.computeNeedleHeading(var121), var11, false);
         }
      }

   }

   public double computeNeedleHeading(dh var1) {
      double var2 = 0.0D;
      if(this.mc.f != null && this.mc.h != null) {
         double var4 = (double)var1.a - this.mc.h.s;
         double var6 = (double)var1.c - this.mc.h.u;
         var2 = (double)(this.mc.h.y - 90.0F) * 3.141592653589793D / 180.0D - Math.atan2(var6, var4);
         if(this.mc.f.y.c) {
            var2 = Math.random() * 3.1415927410125732D * 2.0D;
         }
      }

      return var2;
   }

   public void drawNeedle(int var1, double var2, int[] var4, boolean var5) {
      double var6;
      for(var6 = var2 - this.i[var1]; var6 < -3.141592653589793D; var6 += 6.283185307179586D) {
         ;
      }

      while(var6 >= 3.141592653589793D) {
         var6 -= 6.283185307179586D;
      }

      if(var6 < -1.0D) {
         var6 = -1.0D;
      }

      if(var6 > 1.0D) {
         var6 = 1.0D;
      }

      this.i[var1] += var6 * 0.1D;
      this.j[var1] *= 0.8D;
      this.j[var1] += this.i[var1];
      double var8 = Math.sin(this.i[var1]);
      double var10 = Math.cos(this.i[var1]);
      int var12;
      int var13;
      int var14;
      int var15;
      int var16;
      int var17;
      int var18;
      short var19;
      int var20;
      int var21;
      int var22;
      if(var5) {
         for(var12 = TileSize.int_compassCrossMin; var12 <= TileSize.int_compassCrossMax; ++var12) {
            var13 = (int)(TileSize.double_compassCenterMax + var10 * (double)var12 * 0.3D);
            var14 = (int)(TileSize.double_compassCenterMin - var8 * (double)var12 * 0.3D * 0.5D);
            var15 = var14 * TileSize.int_size + var13;
            var16 = 100;
            var17 = 100;
            var18 = 100;
            var19 = 255;
            if(this.c) {
               var20 = (var16 * 30 + var17 * 59 + var18 * 11) / 100;
               var21 = (var16 * 30 + var17 * 70) / 100;
               var22 = (var16 * 30 + var18 * 70) / 100;
               var16 = var20;
               var17 = var21;
               var18 = var22;
            }

            this.a[var15 * 4 + 0] = (byte)var16;
            this.a[var15 * 4 + 1] = (byte)var17;
            this.a[var15 * 4 + 2] = (byte)var18;
            this.a[var15 * 4 + 3] = (byte)var19;
         }
      }

      for(var12 = TileSize.int_compassNeedleMin; var12 <= TileSize.int_compassNeedleMax; ++var12) {
         var13 = (int)(TileSize.double_compassCenterMax + var8 * (double)var12 * 0.3D);
         var14 = (int)(TileSize.double_compassCenterMin + var10 * (double)var12 * 0.3D * 0.5D);
         var15 = var14 * TileSize.int_size + var13;
         var16 = var12 < 0?100:var4[0];
         var17 = var12 < 0?100:var4[1];
         var18 = var12 < 0?100:var4[2];
         var19 = 255;
         if(this.c) {
            var20 = (var16 * 30 + var17 * 59 + var18 * 11) / 100;
            var21 = (var16 * 30 + var17 * 70) / 100;
            var22 = (var16 * 30 + var18 * 70) / 100;
            var16 = var20;
            var17 = var21;
            var18 = var22;
         }

         this.a[var15 * 4 + 0] = (byte)var16;
         this.a[var15 * 4 + 1] = (byte)var17;
         this.a[var15 * 4 + 2] = (byte)var18;
         this.a[var15 * 4 + 3] = (byte)var19;
      }

   }

   void initializeSettingsFile() {
      settingsFile = new File(Minecraft.a("minecraft"), "findercompass.cfg");
      System.out.println("initializeSettingsFile() running");

      try {
         if(settingsFile.exists()) {
            System.out.println(".minecraft/findercompass.cfg found and opened");
            BufferedReader var6 = new BufferedReader(new FileReader(settingsFile));

            String var2;
            while((var2 = var6.readLine()) != null) {
               if(!var2.startsWith("//")) {
                  String[] var3 = var2.split(":");
                  int var4 = Integer.parseInt(var3[0]);
                  int[] var5 = new int[8];
                  var5[0] = Integer.parseInt(var3[1]);
                  var5[1] = Integer.parseInt(var3[2]);
                  var5[2] = Integer.parseInt(var3[3]);
                  System.out.println("Finder Compass: loaded custom needle of id " + var4 + ", color [" + var5[0] + "," + var5[1] + "," + var5[2]);
                  var5[3] = Integer.parseInt(var3[4]);
                  var5[4] = Integer.parseInt(var3[5]);
                  var5[5] = Integer.parseInt(var3[6]);
                  var5[6] = Integer.parseInt(var3[7]);
                  var5[7] = Integer.parseInt(var3[8]);
                  System.out.println("Full readout: " + var5[0] + ":" + var5[1] + ":" + var5[2] + ":" + var5[3] + ":" + var5[4] + ":" + var5[5] + ":" + var5[6] + ":" + var5[7]);
                  customNeedles.put(Integer.valueOf(var4), var5);
               }
            }

            var6.close();
         } else {
            this.mc.w.a(".minecraft/findercompass.cfg not found, Finder Compass NOT ACTIVE");
         }
      } catch (Exception var61) {
         System.out.println("EXCEPTION BufferedReader");
      }

      this.mc.w.a("Finder Compass config loaded; " + customNeedles.size() + " custom needles loaded");
      System.out.println("config file reading finished");
      areSettingsLoaded = true;
   }

   dh findNearestBlockChunkOfIDInRange(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      List var9 = this.findBlocksOfIDInRange(var1, var2, var3, var4, var5, var6, var7, var8);
      dh var10 = new dh(var2, var3, var4);
      dh var11 = new dh(0, 0, 0);
      double var12 = 9999.0D;

      for(int var18 = 0; var18 < var9.size(); ++var18) {
         dh var15 = (dh)var9.get(var18);
         double var16 = this.GetDistanceBetweenChunks(var10, var15);
         if(var16 < var12) {
            var11 = var15;
            var12 = var16;
         }
      }

      dh var181 = new dh(var11.a, var11.b, var11.c);
      return var181;
   }

   List findBlocksOfIDInRange(int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8) {
      ArrayList var9 = new ArrayList();

      for(int var10 = var3 - var6 - 1; var10 <= var3 + var6; ++var10) {
         if(var10 >= var7 && var10 <= var8) {
            for(int var11 = var4 - var5; var11 <= var4 + var5; ++var11) {
               for(int var12 = var2 - var5; var12 <= var2 + var5; ++var12) {
                  if(this.mc.f.a(var12, var10, var11) == var1) {
                     dh var13 = new dh(var12, var10, var11);
                     var9.add(var13);
                  }
               }
            }
         }
      }

      return var9;
   }

   double GetDistanceBetweenChunks(dh var1, dh var2) {
      int var3 = Math.abs(var1.a - var2.a);
      int var4 = Math.abs(var1.b - var2.b);
      int var5 = Math.abs(var1.c - var2.c);
      return Math.sqrt(Math.pow((double)var3, 2.0D) + Math.pow((double)var4, 2.0D) + Math.pow((double)var5, 2.0D));
   }

}
