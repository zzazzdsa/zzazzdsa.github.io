package net.minecraft.src;

import java.util.Map;
import org.lwjgl.input.*;
import net.minecraft.client.Minecraft;
import java.util.*;
import org.lwjgl.opengl.GL11;

public class mod_KenshiroStyle extends BaseMod
{
    public static World lastworld = null;
	public static final boolean DEBUGMODE = false;
	public static Minecraft minecraft;
	private static EntityPlayer entPlayer;
    public static AS_RenderEntityLahwran renderEnt;
	
	private static boolean canKenshiro = false;
	private static boolean chargingSound = false;
	private static boolean triggeredKenshiro = false;
	private static boolean triggeredKick = false;
	private static long kickTime = 0L;
	private static long triggerTime = 0L;
	private static long smashTime = 0L;
	private static boolean shindeiru = false;
	private static long shindeiruTime = 0L;
	
	private List entitesHit = new ArrayList();

    public mod_KenshiroStyle()
	{
        ModLoader.SetInGameHook(this, true, true);
    }
	
    public boolean OnTickInGame(Minecraft mc)
	{
        if (mc.theWorld != lastworld)
		{
        	minecraft = mc;
            spawn(mc);
            lastworld = mc.theWorld;
        }
        
        entPlayer = mc.thePlayer;
        canKenshiro = false;
        
        long currtime = System.currentTimeMillis();
        
        if (triggeredKenshiro)
        {
        	entPlayer.isSwinging = true;
        	
        	if (mc.objectMouseOver != null)
        	{
        		if(mc.objectMouseOver.typeOfHit == EnumMovingObjectType.TILE)
        		{
        			int x = mc.objectMouseOver.blockX;
        			int y = mc.objectMouseOver.blockY;
        			int z = mc.objectMouseOver.blockZ;
        			
        			int blockID = mc.theWorld.getBlockId(x, y, z);
        			int metadata = mc.theWorld.getBlockMetadata(x, y, z);
        			float hardness = Block.blocksList[blockID].getHardness();
        			
        			if (((hardness <= 3.0F && hardness >= 0F) || blockID == Block.wood.blockID || blockID == Block.web.blockID)
        				&& currtime > smashTime+150L)
        			{
        				smashTime = currtime;
        				mc.playerController.sendBlockRemoved(x, y, z, metadata);
        				Block.blocksList[blockID].harvestBlock(mc.theWorld, mc.thePlayer, x, y, z, metadata);
        			}
        		}
        		else if(mc.objectMouseOver.typeOfHit == EnumMovingObjectType.ENTITY)
        		{
        			Entity ent = mc.objectMouseOver.entityHit;
        			
        			if (ent instanceof EntityLiving)
        			{
	        			if (!entitesHit.contains(ent))
	        			{
	        				if (ent instanceof EntityMob)
	        				{
	        					((EntityMob) ent).attackStrength = 0;
	        				}
	        				((EntityLiving) ent).moveSpeed = 0;
	        				
	        				entitesHit.add(ent);
	        				ent.worldObj.spawnParticle("explode", ent.posX, ent.posY, ent.posZ, 0, 0.2, 0);
	        				ent.worldObj.spawnParticle("largeexplode", ent.posX, ent.posY, ent.posZ, 0, 0.2, 0);
	        				mc.effectRenderer.addEffect(new EntityCrit2FX(mc.theWorld, ent));
	        				entPlayer.worldObj.playSoundAtEntity(entPlayer, "mob.kenshiropunch", entPlayer.getSoundVolume(), (entPlayer.rand.nextFloat() - entPlayer.rand.nextFloat()) * 0.2F + 1.0F);
	        			}
	        			else if (currtime > smashTime+350L)
	        			{
	        				smashTime = currtime;
	        				ent.worldObj.spawnParticle("explode", ent.posX, ent.posY, ent.posZ, 0, 0.2, 0);
	        				ent.worldObj.spawnParticle("largeexplode", ent.posX, ent.posY, ent.posZ, 0, 0.2, 0);
	        				mc.effectRenderer.addEffect(new EntityCrit2FX(mc.theWorld, ent));
	        				entPlayer.worldObj.playSoundAtEntity(entPlayer, "mob.kenshiropunch", entPlayer.getSoundVolume(), (entPlayer.rand.nextFloat() - entPlayer.rand.nextFloat()) * 0.2F + 1.0F);
	        			}
        			}
        		}
        	}
        	
        	if (entPlayer.inventory.mainInventory[entPlayer.inventory.currentItem] != null)
        	{
        		entPlayer.inventory.currentItem = 9;
        	}
        	
        	if (currtime > triggerTime+3700L)
        	{
        		triggeredKenshiro = false;
        		triggerTime = 0L;
        		chargingSound = false;
        		
        		DebugPrint("Kenshiro ended!");
        		
        		if (!entitesHit.isEmpty())
        		{
        			shindeiruTime = currtime;
        			if (entPlayer.rand.nextInt(3) == 0)
        			{
        				entPlayer.worldObj.playSoundAtEntity(entPlayer, "mob.kenshiroshindeiru", entPlayer.getSoundVolume(), (entPlayer.rand.nextFloat() - entPlayer.rand.nextFloat()) * 0.2F + 1.0F);
        				minecraft.ingameGUI.addChatMessage("[You are already dead.]");
        			}
        			else
        			{
        				entPlayer.worldObj.playSoundAtEntity(entPlayer, "mob.kenshiroheartbeat", entPlayer.getSoundVolume(), (entPlayer.rand.nextFloat() - entPlayer.rand.nextFloat()) * 0.2F + 1.0F);
        			}
        		}
        	}
        }
        
        Entity ent;
    	for (int i = 0; i < entitesHit.size(); i++)
    	{
    		ent = (Entity)entitesHit.get(i);
    		
    		if (ent instanceof EntityCreeper)
    		{
    			((EntityCreeper)ent).timeSinceIgnited = 1;
    		}
    		else if (ent instanceof EntitySkeleton)
    		{
    			((EntitySkeleton) ent).attackTime = 60;
    		}
    	}
        
        if (shindeiruTime != 0L && currtime > shindeiruTime + 3500L)
        {
        	shindeiruTime = 0L;
        	
        	for (int i = 0; i < entitesHit.size(); i++)
        	{
        		ent = (Entity)entitesHit.get(i);
        		ent.attackEntityFrom(DamageSource.causePlayerDamage(entPlayer), 25);
        	}
        	
        	entitesHit.clear();
        }
        
        if (kickTime != 0L && currtime > kickTime + 1000L)
        {
        	kickTime = 0L;
        	triggeredKick = false;
        }
        
        if (!triggeredKenshiro
        && !triggeredKick
        && entPlayer != null
        && !entPlayer.worldObj.multiplayerWorld
        && entPlayer.getFoodStats().getFoodLevel() >= 10
        && entPlayer.inventory.mainInventory[entPlayer.inventory.currentItem] == null // bare hands
        && entPlayer.inventory.armorInventory[2] == null // bare chest
        && minecraft.currentScreen == null) 
        {
        	canKenshiro = true;
        }
        
        if (canKenshiro)
        {
        	if (Mouse.isButtonDown(1))
        	{
        		if (!triggeredKick
        			&& !entPlayer.onGround
        			&& mc.objectMouseOver != null
        			&& mc.objectMouseOver.typeOfHit == EnumMovingObjectType.ENTITY
        			&& mc.objectMouseOver.entityHit instanceof EntityLiving)
        		{
        			triggeredKick = true;
        			kickTime = currtime;
        			entPlayer.getFoodStats().setFoodLevel(entPlayer.getFoodStats().getFoodLevel() - 2);
        			entPlayer.worldObj.playSoundAtEntity(entPlayer, "mob.kenshirosmash", entPlayer.getSoundVolume(), (entPlayer.rand.nextFloat() - entPlayer.rand.nextFloat()) * 0.2F + 1.0F);
        			
        			mc.objectMouseOver.entityHit.attackEntityFrom(DamageSource.causePlayerDamage(entPlayer), 4);
        			
                    double var9 = entPlayer.posX - mc.objectMouseOver.entityHit.posX;
                    double var7;
                    for(var7 = entPlayer.posZ - mc.objectMouseOver.entityHit.posZ; var9 * var9 + var7 * var7 < 1.0E-4D; var7 = (Math.random() - Math.random()) * 0.01D) {
                       var9 = (Math.random() - Math.random()) * 0.01D;
                    }
                    //((EntityLiving) mc.objectMouseOver.entityHit).knockBack(entPlayer, 10, var9, var7);
                    
                    float quad = MathHelper.sqrt_double(var9-var9 + var7*var7);
                    mc.objectMouseOver.entityHit.motionX -= var9 / (double)quad;
                    mc.objectMouseOver.entityHit.motionY += 0.6000000059604645D;
                    mc.objectMouseOver.entityHit.motionZ -= var7 / (double)quad;
        			
        		}
        		else
        		{
		        	if (triggerTime == 0L)
		        	{
		        		triggerTime = currtime;
		        	}
		        	else if (currtime > triggerTime+750L)
		        	{
		        		if (currtime > triggerTime+2250L)
		        		{
			        		triggerTime = currtime;
			        		triggeredKenshiro = true;
			        		// play sound ATATATATA
			        		entPlayer.worldObj.playSoundAtEntity(entPlayer, "mob.kenshirostyle", entPlayer.getSoundVolume(), (entPlayer.rand.nextFloat() - entPlayer.rand.nextFloat()) * 0.2F + 1.0F);
			        		DebugPrint("Rage unleashed!");
			        		
			        		entPlayer.getFoodStats().setFoodLevel(entPlayer.getFoodStats().getFoodLevel() - 7);
		        		}
		        		else if (!chargingSound)
		        		{
			        		// play sound "charging rage"
		        			chargingSound = true;
			        		entPlayer.worldObj.playSoundAtEntity(entPlayer, "mob.kenshirocharge", entPlayer.getSoundVolume(), (entPlayer.rand.nextFloat() - entPlayer.rand.nextFloat()) * 0.2F + 1.0F);
			        		DebugPrint("Charge starting!");
		        		}
		        	}
        		}
        	}
        	else
        	{
        		if (triggerTime != 0L)
        		{
        			chargingSound = false;
        			DebugPrint("Charge aborted!");
        		}
        		triggerTime = 0L;
        	}
        }
        else if (!triggeredKenshiro)
        {
        	triggerTime = 0L;
        }
		
        return true;
    }
    
    public static boolean getKenshiroMode()
    {
    	if (triggeredKenshiro) return true;
    	
    	return (canKenshiro && entPlayer.prevSwingProgress == 0F);
    }

    public String Version()
	{
        return "1.8.1";
    }

    public static void spawn(Minecraft mc)
	{
    	renderEnt = new AS_RenderEntityLahwran(mc, mc.theWorld);
        mc.theWorld.addWeatherEffect(renderEnt);
        renderEnt.setPosition(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ);
    }
    
    @SuppressWarnings({ "unchecked", "rawtypes" })
    @Override
    public void AddRenderer(Map map)
	{
        map.put(AS_RenderEntityLahwran.class, new AS_KenshiroRenderHooks());
    }
	
	public static void DebugPrint(String s)
	{
		if(DEBUGMODE)
		{
			minecraft.ingameGUI.addChatMessage(s);
		}
		else
		{
			System.out.println(s);
		}
	}
}
