package atomicstryker.findercompass.common;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.EnumSet;
import java.util.Map;
import org.lwjgl.input.*;

import atomicstryker.findercompass.client.AS_FinderCompass;
import atomicstryker.findercompass.client.ClientPacketHandler;

import cpw.mods.fml.client.FMLClientHandler;
import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.ITickHandler;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.Init;
import cpw.mods.fml.common.Side;
import cpw.mods.fml.common.TickType;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.network.IPacketHandler;
import cpw.mods.fml.common.network.NetworkMod;
import cpw.mods.fml.common.network.PacketDispatcher;
import cpw.mods.fml.common.network.Player;
import cpw.mods.fml.common.network.NetworkMod.NULL;
import cpw.mods.fml.common.network.NetworkMod.SidedPacketHandler;
import cpw.mods.fml.common.registry.TickRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.src.ChunkPosition;
import net.minecraft.src.EntityPlayer;
import net.minecraft.src.NetworkManager;
import net.minecraft.src.Packet250CustomPayload;

import java.util.*;

@Mod(modid = "AS_FinderCompass", name = "Finder Compass", version = "1.3.2C")
@NetworkMod(
clientPacketHandlerSpec = @SidedPacketHandler(channels = { "FindrCmps" }, packetHandler = ClientPacketHandler.class),
serverPacketHandlerSpec = @SidedPacketHandler(channels = { "FindrCmps" }, packetHandler = ServerPacketHandler.class),
connectionHandler = ConnectionHandler.class)
public class FinderCompassMod
{
    private long time = 0;

    @Init
    public void load(FMLInitializationEvent evt)
    {
        if (FMLCommonHandler.instance().getEffectiveSide().isClient())
        {
            TickRegistry.registerTickHandler(new onTick(), Side.CLIENT);
        }
    }

    private class onTick implements ITickHandler
    {
        private EnumSet tickTypes = EnumSet.of(TickType.CLIENT);

        @Override
        public void tickStart(EnumSet<TickType> type, Object... tickData)
        {
        }

        @Override
        public void tickEnd(EnumSet<TickType> type, Object... tickData)
        {
            Minecraft mc = FMLClientHandler.instance().getClient();
            if (mc.theWorld != null && mc.thePlayer != null && !AS_FinderCompass.isHackedIn)
            {
                if (time == 0)
                {
                    time = System.currentTimeMillis();
                }
                else if (System.currentTimeMillis() > time + 5000L)
                {
                    AS_FinderCompass replacement = new AS_FinderCompass(mc);
                    if (AS_FinderCompass.isHackedIn)
                    {
                        mc.renderEngine.registerTextureFX(replacement);
                        tickTypes = EnumSet.of(TickType.WORLDLOAD); // stop
                                                                    // ticking!
                    }
                }
            }
        }

        @Override
        public EnumSet<TickType> ticks()
        {
            return tickTypes;
        }

        @Override
        public String getLabel()
        {
            return "FinderCompass";
        }
    }
}
