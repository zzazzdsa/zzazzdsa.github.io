// This file ONLY tells you what and where this mod specifically adds to the minecraft sourcecode.


public class ChunkCache
    implements IBlockAccess
{
	// 1.6.4 added this new function (MCP does not have a name for it yet), its the one directly above getlightbrightness and essentially is a cached version of that
	// you MUST replace it also or there will be no light
	
	/*
    public float getBrightness(int i, int j, int k, int l)
    {
        int i1 = getLightValue(i, j, k);
        if(i1 < l)
        {
            i1 = l;
        }
        return worldObj.worldProvider.lightBrightnessTable[i1];
    }
	*/
	
    public float getBrightness(int i, int j, int k, int l)
    {
		float lc = LightCache.cache.getLightValue(i, j, k);
		if(lc > l)
		{
			return lc;
		}
	
		int lightValue = getLightValue(i, j, k);
		float torchLight = PlayerTorchArray.getLightBrightness(worldObj, i, j, k);
		if(lightValue < torchLight)
		{
			int floorValue = (int)java.lang.Math.floor(torchLight);
			if(floorValue==15)
			{
				return worldObj.worldProvider.lightBrightnessTable[15];
			}
			else
			{
				int ceilValue = (int)java.lang.Math.ceil(torchLight);
				float lerpValue = torchLight-floorValue;
				return (1.0f-lerpValue)*worldObj.worldProvider.lightBrightnessTable[floorValue]+lerpValue*worldObj.worldProvider.lightBrightnessTable[ceilValue];
			}
		}

		lc = worldObj.worldProvider.lightBrightnessTable[lightValue];
		LightCache.cache.setLightValue(i, j, k, lc);
		return lc;
    }

	/*
    public float getLightBrightness(int i, int j, int k)
    {
        return worldObj.worldProvider.lightBrightnessTable[getLightValue(i, j, k)];
    }
	*/
	
	public float getLightBrightness(int i, int j, int k)
	{   
		float l = LightCache.cache.getLightValue(i, j, k);
		if(l >= 0)
		{
			return l;
		}

		int lightValue = getLightValue(i, j, k);
		float torchLight = PlayerTorchArray.getLightBrightness(worldObj, i, j, k);
		if(lightValue < torchLight)
		{
			int floorValue = (int)java.lang.Math.floor(torchLight);
			if(floorValue==15)
			{
				return worldObj.worldProvider.lightBrightnessTable[15];
			}
			else
			{
				int ceilValue = (int)java.lang.Math.ceil(torchLight);
				float lerpValue = torchLight-floorValue;
				return (1.0f-lerpValue)*worldObj.worldProvider.lightBrightnessTable[floorValue]+lerpValue*worldObj.worldProvider.lightBrightnessTable[ceilValue];
			}
		}

		l = worldObj.worldProvider.lightBrightnessTable[lightValue];
		LightCache.cache.setLightValue(i, j, k, l);
		return l;
	}
	
}
