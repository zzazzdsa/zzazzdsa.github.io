// This file ONLY tells you what and where this mod specifically adds to the minecraft sourcecode.

public class AxisAlignedBB
{

	// new global objects
	private static int nextFrameTime;
	private static long prevFrameTimeForAvg;
	private static long[] tFrameTimes = new long[60];

	
    public static void clearBoundingBoxPool()
    {
        numBoundingBoxesInUse = 0;
		
		// ADD THESE IN HERE	
		prevFrameTimeForAvg = System.nanoTime();
		tFrameTimes[nextFrameTime] = prevFrameTimeForAvg;
		nextFrameTime = ((nextFrameTime + 1) % 60);
    }
	
	// add this function
	public static long getAvgFrameTime()
	{
		if (tFrameTimes[nextFrameTime] != 0L)
		{
			return (prevFrameTimeForAvg - tFrameTimes[nextFrameTime]) / 60L;
		}
		return 23333333L;
	}

}
