// This file ONLY tells you what and where this mod specifically adds to the minecraft sourcecode.

// new import
import org.lwjgl.input.Keyboard;


public abstract class EntityPlayer extends EntityLiving
{
	// into class
    public EntityPlayer(Minecraft minecraft, World world, Session session, int i)
    {
		playertorch = new PlayerTorch(this);
		PlayerTorchArray.AddTorchToArray(playertorch);
		time = System.currentTimeMillis();
    }
	
	// new globals
	public PlayerTorch playertorch;
	private int carriedItemID;
	private long time;
	private boolean buttonCD = false;
	private final String togglekey = "L";
	private final int itogglekey = Keyboard.getKeyIndex(togglekey);
	
	// new functions
	private int GetPlayerArmorLightValue(PlayerTorch playertorch, int oldbrightness)
	{
		int armorbrightness = 0;
		int armorID;
		
		if(this.isBurning())
		{
			playertorch.IsArmorTorch = true;
			playertorch.SetTorchBrightness(15);
			playertorch.SetTorchRange(31);
			playertorch.setTorchState(worldObj, true);
		}
		else
		{
			for(int l = 0; l < 4; l++)
			{
				ItemStack armorItem = inventory.armorItemInSlot(l);
				if(armorItem != null)
				{
					armorID = armorItem.itemID;
					armorbrightness = PlayerTorchArray.GetItemBrightnessValue(armorID);
					
					if (armorbrightness > oldbrightness)
					{
						oldbrightness = armorbrightness;
						playertorch.IsArmorTorch = true;
						playertorch.SetTorchBrightness(armorbrightness);
						playertorch.SetTorchRange(PlayerTorchArray.GetItemLightRangeValue(armorID));
						playertorch.SetWorksUnderwater(PlayerTorchArray.GetItemWorksUnderWaterValue(armorID));
						playertorch.setTorchState(worldObj, true);
					}
				}
			}
		}
		
		return armorbrightness;
	}
	
	private void UpdateBurningEntities(World world)
	{
		List entityList = world.loadedEntityList;
	
		for(int k = 0; k < entityList.size(); k++) // we loop ALL entities
		{
			Entity tempent = (Entity)entityList.get(k);
			
			if (tempent.isBurning())
			{
				//mc.ingameGUI.addChatMessage("Found burning entity: " + tempent);
			
				PlayerTorch torchent = PlayerTorchArray.GetTorchForEntity(tempent);
			
				if (torchent == null) // if it is on fire and not yet a playertorch...
				{
					//mc.ingameGUI.addChatMessage("Burning ent has no Torch yet, adding");
				
					PlayerTorch newtorch = new PlayerTorch(tempent); // add one with torch data!
					PlayerTorchArray.AddTorchToArray(newtorch);
					newtorch.SetTorchBrightness(15);
					newtorch.SetTorchRange(31);
					newtorch.setTorchState(world, true);
				}
			}
		}
	}
	
	// the bigger function 3 above from string "Notch"
    public void onLivingUpdate()
    {	
		//.....
		
		boolean newsecond = false;
		if(System.currentTimeMillis() >= time + 1000L) 
		{
			newsecond = true;
			time = System.currentTimeMillis();
			buttonCD = false;
		}
		
		int oldbrightness = playertorch.isTorchActive() ? playertorch.GetTorchBrightness() : 0;
		
		if (newsecond)
		{
			UpdateBurningEntities(worldObj);
		
			if (GetPlayerArmorLightValue(playertorch, oldbrightness) == 0 && !this.isBurning()) // case no (more) shiny armor
			{
				playertorch.IsArmorTorch = false;
			}
		}
		
		if (Keyboard.getEventKeyState()
		&& Keyboard.getEventKey() == itogglekey
		&& !buttonCD)
		{
			buttonCD = true;
			PlayerTorchArray.ToggleDynamicLights();
		}
		
		if (this.inventory.mainInventory[this.inventory.currentItem] != null)
		{
			int ID = this.inventory.mainInventory[this.inventory.currentItem].itemID;
			
			if (ID != carriedItemID || (newsecond && !playertorch.IsArmorTorch))
			{
				// this is a debug function for modder use.
				//Minecraft.theMinecraft.ingameGUI.addChatMessage("Player Item changed, item now: " + ID);
			
				int itembrightness = PlayerTorchArray.GetItemBrightnessValue(ID);
				if (itembrightness >= oldbrightness)
				{
					if (playertorch.IsArmorTorch)
						playertorch.IsArmorTorch = false;
				
					playertorch.SetTorchBrightness(itembrightness);
					playertorch.SetTorchRange(PlayerTorchArray.GetItemLightRangeValue(ID));
					playertorch.SetWorksUnderwater(PlayerTorchArray.GetItemWorksUnderWaterValue(ID));
					playertorch.setTorchState(worldObj, true);
				}
				else if(!playertorch.IsArmorTorch && GetPlayerArmorLightValue(playertorch, oldbrightness) == 0)
				{
					playertorch.setTorchState(worldObj, false);
				}
			}
		}
		else
		{
			playertorch.currentItemID = 0;
			if (!playertorch.IsArmorTorch && GetPlayerArmorLightValue(playertorch, oldbrightness) == 0)
			{
				playertorch.setTorchState(worldObj, false);
			}
		}
		
		if (playertorch.isTorchActive())
		{
			playertorch.setTorchPos(worldObj, (float)posX, (float)posY, (float)posZ);
		}
	}
}
