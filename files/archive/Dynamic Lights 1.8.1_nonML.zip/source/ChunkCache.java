// This file ONLY tells you what and where this mod specifically adds to the minecraft sourcecode.


public class ChunkCache
    implements IBlockAccess
{

	public int getLightyBySkyBlockType(EnumSkyBlock var1, int i, int j, int k)
	{
		//replace:
		return this.chunkArray[blockID][var6].getSavedLightValue(var1, i & 15, j, k & 15);
		
		//with:
		int retVal = this.chunkArray[blockID][var6].getSavedLightValue(var1, i & 15, j, k & 15);
		
		if (var1 == EnumSkyBlock.Sky)
		{
			return retVal;
		}
		else
		{
			int cached = (int)java.lang.Math.ceil(LightCache.cache.getLightValue(i, j, k));
			if (cached > retVal) return cached;

			int torchLight = (int)java.lang.Math.round(PlayerTorchArray.getLightBrightness(worldObj, i, j, k));
			if(retVal < torchLight)
			{
				return torchLight;
			}
		}
		
		LightCache.cache.setLightValue(i, j, k, retVal);
		return retVal;

	}
	
}
