// This file ONLY tells you what and where this mod specifically adds to the minecraft sourcecode.


public class ChunkCache
    implements IBlockAccess
{
	// replace the entire getlight function with this one, the old one is here for reference
	
	/*
    public float getLightBrightness(int i, int j, int k)
    {
        return worldObj.worldProvider.lightBrightnessTable[getLightValue(i, j, k)];
    }
	*/
	
    public float getLightBrightness(int i, int j, int k)
    {   
       float l = LightCache.cache.getLightValue(i, j, k);
       if(l >= 0)
       {
          return l;
       }
	   
       int lightValue = getLightValue(i, j, k);
       float torchLight = PlayerTorchArray.getLightBrightness(worldObj, i, j, k);
       if(lightValue < torchLight)
       {
          int floorValue = (int)java.lang.Math.floor(torchLight);
          if(floorValue==15)
          {
             return worldObj.worldProvider.lightBrightnessTable[15];
          }
          else
          {
             int ceilValue = (int)java.lang.Math.ceil(torchLight);
             float lerpValue = torchLight-floorValue;
             return (1.0f-lerpValue)*worldObj.worldProvider.lightBrightnessTable[floorValue]+lerpValue*worldObj.worldProvider.lightBrightnessTable[ceilValue];
          }
       }
	   
       l = worldObj.worldProvider.lightBrightnessTable[lightValue];
       LightCache.cache.setLightValue(i, j, k, l);
       return l;
    }
	
}
