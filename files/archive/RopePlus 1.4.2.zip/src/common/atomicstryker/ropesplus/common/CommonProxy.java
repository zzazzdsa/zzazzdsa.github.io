package atomicstryker.ropesplus.common;

import java.io.File;

public class CommonProxy
{
    public void loadConfig(File configFile)
    {
        // NOOP
    }
    
    public void load()
    {
        // NOOP
    }
}
