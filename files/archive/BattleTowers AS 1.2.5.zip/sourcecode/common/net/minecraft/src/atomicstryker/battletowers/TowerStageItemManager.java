package net.minecraft.src.atomicstryker.battletowers;

import java.util.Random;

import net.minecraft.src.*;

public class TowerStageItemManager
{
	/*
	 *  Example setting string: 75-50-1-4;73-20-1-1
	 *  Spawns Redstone(75) with 50 percent chance, at least 1, max 4
	 *  Spawns Saddle(73) with 20 percent chance, at least 1, max 1
	 */
	
	private final int[] itemID;
	private final int[] chanceToSpawn;
	private final int[] minAmount;
	private final int[] maxAmount;
	private int curIndex = 0;
	
	/**
	 * @param configString see TowerStageItemManager in AS_BattleTowersCore for example String
	 */
	public TowerStageItemManager(String configString)
	{
		String[] elements = configString.split(";");
		itemID = new int[elements.length];
		chanceToSpawn = new int[elements.length];
		minAmount = new int[elements.length];
		maxAmount = new int[elements.length];
		
		for (int i = 0; i < elements.length; i++)
		{
			String[] settings = elements[i].trim().split("-");
			
			itemID[i] = Integer.parseInt(settings[0]);
			chanceToSpawn[i] = Integer.parseInt(settings[1]);
			minAmount[i] = Integer.parseInt(settings[2]);
			maxAmount[i] = Integer.parseInt(settings[3]);
			//System.out.println("TowerStageItemManager parsed Item/Block of ID "+itemID[i]+", spawnChance: "+chanceToSpawn[i]+", min: "+minAmount[i]+", max: "+maxAmount[i]);
		}
	}
	
	/**
	 * @param toCopy TowerStageItemManager you need an image of
	 */
	public TowerStageItemManager(TowerStageItemManager toCopy)
	{
		itemID = toCopy.itemID;
		chanceToSpawn = toCopy.chanceToSpawn;
		minAmount = toCopy.minAmount;
		maxAmount = toCopy.maxAmount;			
	}
	
	/**
	 * @return true if there is still Items configured to be put into the chest of the Managers floor
	 */
	public boolean floorHasItemsLeft()
	{
		return (curIndex < itemID.length);
	}
	
	/**
	 * @param rand your WorldGen Random
	 * @return ItemStack instance of the configured Block or Item with amount, or null
	 */
	public ItemStack getStageItem(Random rand)
	{
		ItemStack result = null;
		
		if (floorHasItemsLeft()
		&& rand.nextInt(100) <= chanceToSpawn[curIndex])
		{
			if (itemID[curIndex] < Block.blocksList.length
			&& Block.blocksList[itemID[curIndex]] != null)
			{
				result = new ItemStack(Block.blocksList[itemID[curIndex]], minAmount[curIndex]+rand.nextInt(maxAmount[curIndex]));
			}
			else if (itemID[curIndex] < Item.itemsList.length
			&& Item.itemsList[itemID[curIndex]] != null)
			{
				result = new ItemStack(Item.itemsList[itemID[curIndex]], minAmount[curIndex]+rand.nextInt(maxAmount[curIndex]));
			}
		}

		curIndex++;
		return result;
	}
}
