package net.minecraft.src.atomicstryker.battletowers;

import java.io.*;
import java.util.*;

import net.minecraft.src.*;
import net.minecraft.src.forge.*;
import net.minecraft.src.atomicstryker.battletowers.*;

public class AS_BattleTowersCore
{
	private List TowerPositions;
	private List TowerDestroyers;
	public int raritycounter = 400;
	public int spawncounter;
    public int rarity;
	public double minDistanceBetweenTowers;
	public int towerDestroyerEnabled;
    public String configpath;
    static boolean isWorking = false;
    
    private TowerStageItemManager[] floorItemManagers = new TowerStageItemManager[10];
    
    static Configuration configuration = new Configuration(new File(mod_AS_BattleTowers.getMinecraftDir(), "config/BattleTowers.cfg"));
	
	public String getVersion()
	{
		return "1.1.2 @ MC 1.2.5";
	}
	
	public String getPacketChannelName()
	{
		return "AS_BattleTowers";
	}
	
    public void load(mod_AS_BattleTowers mod)
    {
    	MinecraftForge.registerConnectionHandler(mod);
    	
    	ModLoader.registerEntityID(AS_EntityGolem.class, "AS_EntityGolem", 27);
		MinecraftForge.registerEntity(AS_EntityGolem.class, mod, 1, 50, 5, true);
		ModLoader.registerEntityID(AS_EntityGolemFireball.class, "AS_EntityGolemFireball", 28);
		MinecraftForge.registerEntity(AS_EntityGolemFireball.class, mod, 2, 50, 5, true);
		
        spawncounter = 200;
        
        loadForgeConfig();
        
        if(rarity < 1)
        {
            rarity = 1;
        }
		raritycounter = rarity * 100;
		
		TowerPositions = new ArrayList();
		TowerDestroyers = new ArrayList();
    }
    
    public int loadForgeConfig()
    {
            configuration.load();
            rarity = Integer.parseInt(configuration.getOrCreateIntProperty("BattleTower Rarity", "Main", 5).value);
            minDistanceBetweenTowers = Integer.parseInt(configuration.getOrCreateIntProperty("Minimum Distance between 2 BattleTowers", "Main", 96).value);
            towerDestroyerEnabled = Integer.parseInt(configuration.getOrCreateIntProperty("Tower Destroying Enabled", "Main", 1).value);
            
            // 280-50-6-5 sticks
            // 295-50-3-5 seeds
            // 5-50-6-5 planks
            // 83-50-3-5 sugarcane
            floorItemManagers[0] = new TowerStageItemManager(configuration.getOrCreateProperty("Floor 1", "BattleTower Chest Items", "280-50-6-5;295-50-3-5;5-50-6-5;83-50-3-5").value);
            
            // 274-25-1-1 stone pick
            // 275-25-1-1 stone axe
            // 50-75-3-3 torches
            // 77-50-2-2 stone button
            floorItemManagers[1] = new TowerStageItemManager(configuration.getOrCreateProperty("Floor 2", "BattleTower Chest Items", "274-25-1-1;275-25-1-1;50-75-3-3;77-50-2-2").value);
            
            // 281-50-2-4 wooden bowl
            // 263-75-4-4 coal
            // 287-50-5-5 string
            // 35-25-2-2 wool
            floorItemManagers[2] = new TowerStageItemManager(configuration.getOrCreateProperty("Floor 3", "BattleTower Chest Items", "281-50-2-4;263-75-4-4;287-50-5-5;35-25-2-2").value);
            
            // 20-50-3-3 glass
            // 288-25-4-4 feather
            // 297-50-2-2 bread
            // 260-75-2-2 apple
            floorItemManagers[3] = new TowerStageItemManager(configuration.getOrCreateProperty("Floor 4", "BattleTower Chest Items", "20-50-3-3;288-25-4-4;297-50-2-2;260-75-2-2").value);
            
            // 39-50-2-2 brown mushroom
            // 40-50-2-2 red mushroom
            // 6-75-3-3 saplings
            // 296-25-4-4 wheat
            floorItemManagers[4] = new TowerStageItemManager(configuration.getOrCreateProperty("Floor 5", "BattleTower Chest Items", "39-50-2-2;40-50-2-2;6-75-3-3;296-25-4-4").value);
            
            // 323-50-1-2 sign
            // 346-75-1-1 fishing rod
            // 361-25-2-2 pumpkin seeds
            // 362-25-3-3 Melon Seeds
            floorItemManagers[5] = new TowerStageItemManager(configuration.getOrCreateProperty("Floor 6", "BattleTower Chest Items", "323-50-1-2;346-75-1-1;361-25-2-2;362-25-3-3").value);
            
            // 267-25-1-1 iron sword
            // 289-25-3-3 gunpowder
            // 334-50-4-4 leather
            // 349-75-3-3 raw fish
            // 351-50-1-2 dye
            floorItemManagers[6] = new TowerStageItemManager(configuration.getOrCreateProperty("Floor 7", "BattleTower Chest Items", "267-25-1-1;289-25-3-3;334-50-4-4;349-75-3-3;351-50-1-2").value);
            
            // 302-25-1-1 chain helmet
            // 303-25-1-1 chain chestplate
            // 304-25-1-1 chain leggings
            // 305-25-1-1 chain boots
            floorItemManagers[7] = new TowerStageItemManager(configuration.getOrCreateProperty("Floor 8", "BattleTower Chest Items", "302-25-1-1;303-25-1-1;304-25-1-1;305-25-1-1").value);
            
            // 57-50-1-3 bookshelf
            // 123-25-2-2 redstone lamp
            // 111-75-3-3 Lily Plants
            // 117-25-1-1 brewing stand
            floorItemManagers[8] = new TowerStageItemManager(configuration.getOrCreateProperty("Floor 9", "BattleTower Chest Items", "57-50-1-3;123-25-2-2;111-75-3-3;117-25-1-1").value);
            
            // 368-50-2-2 ender pearl
            // 264-50-2-2 diamond
            // 331-75-5-5 redstone dust
            // 266-75-8-8 gold ingot
            floorItemManagers[9] = new TowerStageItemManager(configuration.getOrCreateProperty("Top Floor", "BattleTower Chest Items", "368-50-2-2;264-50-2-2;331-75-5-5;266-75-8-8").value);
            
            configuration.save();
            return 0;
    }
    
    public void onNewInGameSecond()
    {
		for(int i = 0; i < TowerDestroyers.size(); i++)
		{
			AS_TowerDestroyer temp = (AS_TowerDestroyer)TowerDestroyers.get(i);
			temp.Update();
		}
    }
    
	public void onBattleTowerDestroyed(AS_TowerDestroyer td)
	{
		mod_AS_BattleTowers.onBattleTowerDestroyed(td);
		TowerDestroyers.add(td);
	}
	
	public void unRegisterTowerDestroyer(AS_TowerDestroyer td)
	{
		TowerDestroyers.remove(td);
	}
	
	/*
	public static void UseDefaults()
	{
        rarity = 3;
		minDistanceBetweenTowers = 64D;
		towerDestroyerEnabled = 1;
	}
	*/
	
	public void generateSurface(World world, Random random, int x, int z)
	{
		if (!isWorking)
		{
			isWorking = true;
			if(spawncounter > raritycounter)
			{
				boolean spawn = true;
				double dist;
				double mindist = 100D;
				
				for(int i = 0; i < TowerPositions.size(); i++)
				{
					ChunkCoordinates temp = (ChunkCoordinates)TowerPositions.get(i);
					dist = temp.getEuclideanDistanceTo(x, 64, z);
					
					if (dist < mindist) mindist = dist;
					
					if (dist < minDistanceBetweenTowers)
					{
						spawn = false;
						break;
					}
				}

				if (spawn)
				{
					if(AttemptToSpawnTower(world, random, x, z))
					{
						if (TowerPositions.size() > 30)
						{
							TowerPositions.remove(0);
						}
						
						ChunkCoordinates temp = new ChunkCoordinates(x, 64, z);
						TowerPositions.add(temp);
						spawncounter = 0;
						
						//System.err.println("Battle Tower spawned at [ "+x+" | "+z+" ]");
					}
				}
			}
			else
			{
				spawncounter++;
			}
			isWorking = false;
		}
	}
	
	private boolean AttemptToSpawnTower(World world, Random random, int x, int z)
	{
		int y = GetSurfaceBlockHeight(world, x, z);
		if (y == 49) return false;
		
		return ((new AS_WorldGenTower(this)).generate(world, random, x, y, z));
	}
	
	private int GetSurfaceBlockHeight(World world, int x, int z)
	{
		int h = 50;
		
		do
		{
			h++;
		}
		while (world.getBlockId(x, h, z) != 0);
		
		return h-1;
	}
	
	public TowerStageItemManager getTowerStageManagerForFloor(int floor, Random rand)
	{
		floor--; // subtract 1 to match the floors to the array
		
		if (floor >= floorItemManagers.length)
		{
			floor = floorItemManagers.length-1;
		}
		
		return new TowerStageItemManager(floorItemManagers[floor]);
	}
}
