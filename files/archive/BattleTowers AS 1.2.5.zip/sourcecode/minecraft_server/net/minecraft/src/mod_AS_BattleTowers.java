package net.minecraft.src;

import java.io.*;
import java.net.URISyntaxException;
import java.util.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.src.atomicstryker.ForgePacketWrapper;
import net.minecraft.src.atomicstryker.battletowers.*;
import net.minecraft.src.forge.*;

public class mod_AS_BattleTowers extends NetworkMod implements IConnectionHandler, IPacketHandler
{
	public static AS_BattleTowersCore coreInstance;
	private long time;
	
	public mod_AS_BattleTowers()
	{
		coreInstance = new AS_BattleTowersCore();
	}
	
	@Override
    public void load()
    {
		coreInstance.load(this);
		
		time = System.currentTimeMillis();
		ModLoader.setInGameHook(this, true, true);
    }
	
	@Override
	public void onPacketData(NetworkManager network, String channel, byte[] bytes)
	{
		DataInputStream data = new DataInputStream(new ByteArrayInputStream(bytes));
		
		int packetID = ForgePacketWrapper.readPacketID(data);
		
		if (packetID == 2)
		{
			System.out.println("Server received packet: Client is hammering away at a BattleTower chest!");
			// client to server: client is hacking away at a chest with a Golem nearby
			
			Class[] decodeAs = {Integer.class};
			Object[] packetReadout = ForgePacketWrapper.readPacketData(data, decodeAs);
			
			int golemID = (Integer) packetReadout[0];
			
			NetServerHandler handler = ((NetServerHandler)network.getNetHandler());
	        WorldServer world = handler.mcServer.getWorldManager(handler.getPlayerEntity().dimension);
	        Entity golem = world.getEntityByID(golemID);
	        
	        if (golem != null
	        && golem instanceof AS_EntityGolem)
	        {
	        	System.out.println("Found BattleTower chest golem, waking!");
	        	((AS_EntityGolem)golem).setAwake();
	        }
		}
	}
	
	@Override
	public boolean onTickInGame(MinecraftServer mc)
	{		
		if (System.currentTimeMillis() > time + 1000L) // its a one second timer OMFG
		{
			coreInstance.onNewInGameSecond();
		}
		
		return true;
	}
	
	@Override
    public void modsLoaded()
    {
        System.err.println("BATTLE TOWERS CONFIG");
        System.err.println((new StringBuilder()).append("Tower Rarity ").append(String.valueOf(coreInstance.rarity)).toString());
		System.err.println((new StringBuilder()).append("Min Tower Distance ").append(String.valueOf(coreInstance.minDistanceBetweenTowers)).toString());
        System.err.println((new StringBuilder()).append("MINECRAFT PROPERTIES ").append(String.valueOf(coreInstance.configpath)).toString());
    }

	@Override
    public void generateSurface(World world, Random random, int x, int z)
    {
		coreInstance.generateSurface(world, random, x, z);
	}

	@Override
    public String getVersion()
    {
        return coreInstance.getVersion();
    }

	@Override
	public boolean clientSideRequired()
	{
		return true;
	}

	@Override
	public boolean serverSideRequired()
	{
		return false;
	}

	@Override
	public void onConnect(NetworkManager network)
	{
	}

	@Override
	public void onLogin(NetworkManager network, Packet1Login login)
	{
		MessageManager.getInstance().registerChannel(network, this, coreInstance.getPacketChannelName());
		
		Object[] packetDataToEncode = {coreInstance.towerDestroyerEnabled};
		Packet250CustomPayload packet = ForgePacketWrapper.createPacket(coreInstance.getPacketChannelName(), 1, packetDataToEncode);
		network.addToSendQueue(packet);
	}

	@Override
	public void onDisconnect(NetworkManager network, String message, Object[] args)
	{
	}

	public static File getMinecraftDir()
	{
        String basepath = "";
		try
		{
			basepath = ModLoader.class.getProtectionDomain().getCodeSource().getLocation().toURI().getPath();
			basepath = basepath.substring(0, basepath.lastIndexOf(47));
		}
		catch (URISyntaxException e)
		{
			e.printStackTrace();
		}
        
		return new File(basepath);
	}

	public static void onBattleTowerDestroyed(AS_TowerDestroyer td)
	{
		Packet3Chat packet = new Packet3Chat("A Battletower's Guardian has fallen! Without it's power, the Tower will collapse...");
		ModLoader.getMinecraftServerInstance().configManager.sendPacketToAllPlayers(packet);
	}
}
