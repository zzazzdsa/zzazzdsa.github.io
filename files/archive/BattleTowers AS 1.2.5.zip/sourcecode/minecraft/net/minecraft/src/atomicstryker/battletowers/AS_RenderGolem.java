// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

package net.minecraft.src;

import org.lwjgl.opengl.GL11;

// Referenced classes of package net.minecraft.src:
//            RenderBiped, ModelBiped, EntityGolem, EntityLiving

public class AS_RenderGolem extends RenderBiped
{

    public AS_RenderGolem()
    {
        super(new ModelBiped(), 1.0F);
        setRenderPassModel(new ModelBiped());
    }

    protected void func_15310_scalegolem(AS_EntityGolem entitygolem, float f)
    {
        GL11.glScalef(2.0F, 2.0F, 2.0F);
    }

    protected void preRenderCallback(EntityLiving entityliving, float f)
    {
        func_15310_scalegolem((AS_EntityGolem)entityliving, f);
    }
}
