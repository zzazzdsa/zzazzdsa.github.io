// This file ONLY tells you what and where this mod specifically adds to the minecraft sourcecode.

public class RenderGlobal
    implements IWorldAccess
{

	// this function is fairly hard to find. look for the nonsense boolean...
	// otherwise, its the function ABOVE another that has the string "/terrain.png" in it, twice even
    public boolean updateRenderers(EntityLiving entityliving, boolean flag)
    {
        boolean flag1 = false;
        if(flag1)
        {
			//....
        }

		int numToUpdate = 0;
		long avgTime = 0L;
		boolean torchesActive = PlayerTorchArray.AreTorchesActive();
		if (torchesActive)
		{
			avgTime = AxisAlignedBB.getAvgFrameTime();
		}
		
		// the first FOR inside the function
        for(int j1 = 0; j1 < l; j1++)
        {
			//......

			if (torchesActive)
			{
				numToUpdate++;
				if ((numToUpdate >= 2) || (avgTime > 16666666L))
				{
					break;
				}
			}
        }
		
		// further down, find the 2 calls to *.updateRenderer(); and change them like this
		
		boolean update = *.needsUpdate;
		*.updateRenderer();
		if (update)
		{
			LightCache.cache.clear();
			BlockCoord.resetPool();
		}
    }
}