// This file ONLY tells you what and where this mod specifically adds to the minecraft sourcecode.


public class World
    implements IBlockAccess
{

	public int getSkyBlockTypeBrightness(EnumSkyBlock var1, int i, int j, int k)
	{
		//replace:
				return var13.getSavedLightValue(var1, i & 15, j, k & 15);
		
		//with:
	       		int retVal = var13.getSavedLightValue(var1, i & 15, j, k & 15);
	
	    		if (var1 == EnumSkyBlock.Sky)
	    		{
	    			return retVal;
	    		}
	    		else
	    		{
	    			int cached = LightCache.cache.getLightValue(i, j, k);
	    			if (cached > retVal) return cached;
	
	    			int torchLight = (int)java.lang.Math.round(PlayerTorchArray.getLightBrightness(this, i, j, k));
	    			if(retVal < torchLight)
	    			{
	    				return torchLight;
	    			}
	    		}
	
	    		LightCache.cache.setLightValue(i, j, k, retVal);
	    		return retVal;

	}

}