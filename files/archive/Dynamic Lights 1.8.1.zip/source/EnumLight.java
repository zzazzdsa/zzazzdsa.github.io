package net.minecraft.src;

public enum EnumLight
{
	l0(0), 
	l1(1), 
	l2(2), 
	l3(3), 
	l4(4), 
	l5(5), 
	l6(6), 
	l7(7), 
	l8(8), 
	l9(9), 
	la(10), 
	lb(11), 
	lc(12), 
	ld(13), 
	le(14), 
	lf(15);

	private EnumLight(int i)
	{
		this.value = i;
	}
	
	public final int value;
	public static final EnumLight[] values;
	
	static
	{
		values = new EnumLight[16];
		
		values[0] = l0;
		values[1] = l1;
		values[2] = l2;
		values[3] = l3;
		values[4] = l4;
		values[5] = l5;
		values[6] = l6;
		values[7] = l7;
		values[8] = l8;
		values[9] = l9;
		values[10] = la;
		values[11] = lb;
		values[12] = lc;
		values[13] = ld;
		values[14] = le;
		values[15] = lf;
	}
}
