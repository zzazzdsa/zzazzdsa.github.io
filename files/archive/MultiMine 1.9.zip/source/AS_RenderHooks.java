package net.minecraft.src;

import java.util.*;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;

public class AS_RenderHooks extends Render
{
    
    @SuppressWarnings("static-access")
    private void render(float renderTick)
	{
        RenderHelper.disableStandardItemLighting();
        Minecraft mc = ModLoader.getMinecraftInstance();
        
        GL11.glColor3f(1.0f, 1.0f, 1.0f);
        
        //render here
        
		ArrayList list = (ArrayList)mod_MultiMine.partiallyMinedBlocksList.clone();
		EntityPlayer entityplayer = mc.thePlayer;
		float backup = mc.renderGlobal.damagePartialTime;
		
		boolean selfRepair = AS_Settings_MultiMine.blockSelfRepair;
		float selfRepairRate = 0F;
		if(selfRepair)
		{
			selfRepairRate = AS_Settings_MultiMine.blockSelfRepairRate;
		}
		
		GL11.glDisable(3008 /*GL_ALPHA_TEST*/);
		for (int x = 0; x < list.size(); x++)
		{
			AS_BlockWithDamage temp = (AS_BlockWithDamage)list.get(x);
			MovingObjectPosition obj = (MovingObjectPosition)temp.getObject();
			
			if(entityplayer.worldObj.getBlockId(obj.blockX, obj.blockY, obj.blockZ) == 0)
			{
				mod_MultiMine.partiallyMinedBlocksList.remove(temp);
			}
			else
			{
				if(selfRepair)
				{
					temp.setDamage(temp.getDamage() - selfRepairRate);
				}
			
				mc.renderGlobal.damagePartialTime = temp.getDamage();
				mc.renderGlobal.drawBlockBreaking(entityplayer, obj, 0, entityplayer.inventory.getCurrentItem(), renderTick);
			}
		}
		GL11.glEnable(3008 /*GL_ALPHA_TEST*/);
		
		mc.renderGlobal.damagePartialTime = backup;
		
        RenderHelper.enableStandardItemLighting();
    }

    @Override
    public void doRender(Entity dontcare0, double dontcare1, double dontcare2, double dontcare3, float dontcare4, float renderTick)
	{
        render(renderTick);
    }
}
