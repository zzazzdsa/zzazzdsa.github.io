Credits:

Big thanks to Lahwran for helping me with Rendering. Without his Rendering Hook this mod would change quite a lot more files.
Err actually just one, but an important and popular among modders file.



Usage:

Mine multiple Blocks without finishing them.
Right clicking a Block fixes him back to pristine state.

There is now an automatically generating config file, to be found at minecraft/mods/MultiMine.txt.
Inside, you can set how many blocks are supposed to be damagible at the same time, and the rate at which damaged blocks regenerate.




Installation:

Requirement:

Modloader
http://www.minecraftforum.net/topic/75440-v166-risugamis-mods-updates/


Put the files into minecraft.jar as instructed, using winrar or something. Delete META-INF if you havent done so already.