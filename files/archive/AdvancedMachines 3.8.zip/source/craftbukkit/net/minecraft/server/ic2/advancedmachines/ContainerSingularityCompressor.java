package net.minecraft.server.ic2.advancedmachines;

import net.minecraft.server.Container;
import net.minecraft.server.EntityHuman;
import net.minecraft.server.ICrafting;
import net.minecraft.server.ItemStack;
import net.minecraft.server.PlayerInventory;
import net.minecraft.server.Slot;
import net.minecraft.server.SlotResult2;
import net.minecraft.server.mod_IC2AdvancedMachines;

public class ContainerSingularityCompressor extends Container
{
    public TileEntitySingularityCompressor tileentity;
    public int progress = 0;
    public int energy = 0;
    public int PSI = 0;

    public ContainerSingularityCompressor(PlayerInventory var1, TileEntitySingularityCompressor var2)
    {
        this.tileentity = var2;
        this.a(new Slot(var2, 0, 56, 17));
        this.a(new Slot(var2, 1, 56, 53));
        this.a(new SlotResult2(var1.player, var2, 2, 115, 35));
        this.a(new Slot(var2, 3, 152, 6));
        this.a(new Slot(var2, 4, 152, 24));
        this.a(new Slot(var2, 5, 152, 42));
        this.a(new Slot(var2, 6, 152, 60));
        int var3;

        for (var3 = 0; var3 < 3; ++var3)
        {
            for (int var4 = 0; var4 < 9; ++var4)
            {
                this.a(new Slot(var1, var4 + var3 * 9 + 9, 8 + var4 * 18, 84 + var3 * 18));
            }
        }

        for (var3 = 0; var3 < 9; ++var3)
        {
            this.a(new Slot(var1, var3, 8 + var3 * 18, 142));
        }
    }

    /**
     * update the crafting matrix
     */
    public void a()
    {
        super.a();

        for (int var1 = 0; var1 < this.listeners.size(); ++var1)
        {
            ICrafting var2 = (ICrafting)this.listeners.get(var1);

            if (this.progress != this.tileentity.progress)
            {
                var2.setContainerData(this, 0, this.tileentity.progress);
            }

            if (this.energy != this.tileentity.energy)
            {
                var2.setContainerData(this, 1, this.tileentity.energy & 65535);
                var2.setContainerData(this, 2, this.tileentity.energy >>> 16);
            }

            if (this.PSI != this.tileentity.speed)
            {
                var2.setContainerData(this, 3, this.tileentity.speed);
            }
        }

        this.progress = this.tileentity.progress;
        this.energy = this.tileentity.energy;
        this.PSI = this.tileentity.speed;
    }

    /**
     * Called to transfer a stack from one inventory to the other eg. when shift clicking.
     */
    public ItemStack a(int var1)
    {
        ItemStack var2 = null;
        Slot var3 = (Slot)this.e.get(var1);

        if (var3 != null && var3.c())
        {
            ItemStack var4 = var3.getItem();
            var2 = var4.cloneItemStack();

            if (var1 < 9)
            {
                this.a(var4, 9, 38, false);
            }
            else if (var4.id != mod_IC2AdvancedMachines.overClockerStack.id && var4.id != mod_IC2AdvancedMachines.transformerStack.id && var4.id != mod_IC2AdvancedMachines.energyStorageUpgradeStack.id)
            {
                this.a(var4, 0, 1, false);
            }
            else
            {
                this.a(var4, 3, 6, false);
            }

            if (var4.count == 0)
            {
                var3.set((ItemStack)null);
            }
            else
            {
                var3.d();
            }

            if (var4.count == var2.count)
            {
                return null;
            }

            var3.set(var4);
        }

        return var2;
    }

    public void updateProgressBar(int var1, int var2)
    {
        switch (var1)
        {
            case 0:
                this.tileentity.progress = (short)var2;
                break;

            case 1:
                this.tileentity.energy = this.tileentity.energy & -65536 | var2;
                break;

            case 2:
                this.tileentity.energy = this.tileentity.energy & 65535 | var2 << 16;
                break;

            case 3:
                this.tileentity.speed = (short)var2;
        }
    }

    public boolean b(EntityHuman var1)
    {
        return this.tileentity.a(var1);
    }

    public int guiInventorySize()
    {
        return 7;
    }

    public int getInput()
    {
        return 0;
    }
}
