package net.minecraft.server.ic2.advancedmachines;

import ic2.api.Ic2Recipes;
import java.util.List;
import net.minecraft.server.Container;
import net.minecraft.server.ItemStack;
import net.minecraft.server.PlayerInventory;

public class TileEntitySingularityCompressor extends TileEntityAdvancedMachine
{
    public TileEntitySingularityCompressor()
    {
        super("Singularity Compressor", "%6d PSI", 10, new int[] {0}, new int[] {2});
    }

    public Container getGuiContainer(PlayerInventory var1)
    {
        return new ContainerSingularityCompressor(var1, this);
    }

    protected List getResultMap()
    {
        return Ic2Recipes.getCompressorRecipes();
    }

    public ItemStack getResultFor(ItemStack var1, boolean var2)
    {
        return Ic2Recipes.getCompressorOutputFor(var1, var2);
    }
}
