package net.minecraft.server.ic2.advancedmachines;

import java.lang.reflect.Method;
import net.minecraft.server.TileEntity;

public class IC2AudioSource
{
    private static boolean initFailed = false;
    private static Class audioManagerClass;
    private static Method audioManagercreateSource;
    private static Method audioManagerremoveSource;
    private static Method audioManagerplayOnce;
    private static Class audioSourceClass;
    private static Method audioSourcePlay;
    private static Method audioSourceStop;
    private static Method audioSourceRemove;
    private Object audioSourceinstance;

    public IC2AudioSource(TileEntity var1, String var2) {}

    public static void removeSource(Object var0) {}

    public static void playOnce(TileEntity var0, String var1) {}

    public void play() {}

    public void stop() {}

    public void remove() {}
}
