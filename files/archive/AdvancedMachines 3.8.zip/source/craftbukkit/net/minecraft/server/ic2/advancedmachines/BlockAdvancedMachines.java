package net.minecraft.server.ic2.advancedmachines;

import forge.ITextureProvider;
import ic2.api.Items;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import net.minecraft.server.BlockContainer;
import net.minecraft.server.EntityHuman;
import net.minecraft.server.EntityItem;
import net.minecraft.server.EntityLiving;
import net.minecraft.server.IBlockAccess;
import net.minecraft.server.IInventory;
import net.minecraft.server.ItemStack;
import net.minecraft.server.Material;
import net.minecraft.server.MathHelper;
import net.minecraft.server.TileEntity;
import net.minecraft.server.World;
import net.minecraft.server.mod_IC2AdvancedMachines;

public class BlockAdvancedMachines extends BlockContainer implements ITextureProvider
{
    public BlockAdvancedMachines(int var1)
    {
        super(var1, Material.ORE);
        this.c(2.0F);
        this.a(i);
    }

    /**
     * Returns the TileEntity used by this block.
     */
    public TileEntity a_()
    {
        return null;
    }

    /**
     * Called whenever the block is added into the world. Args: world, x, y, z
     */
    public void onPlace(World var1, int var2, int var3, int var4)
    {
        TileEntityAdvancedMachine var5 = this.getBlockEntity(var1.getData(var2, var3, var4));
        var1.setTileEntity(var2, var3, var4, var5);
    }

    public ArrayList getBlockDropped(World var1, int var2, int var3, int var4, int var5, int var6)
    {
        ArrayList var7 = super.getBlockDropped(var1, var2, var3, var4, var5, var6);
        TileEntity var8 = var1.getTileEntity(var2, var3, var4);

        if (var8 instanceof IInventory)
        {
            IInventory var9 = (IInventory)var8;

            for (int var10 = 0; var10 < var9.getSize(); ++var10)
            {
                ItemStack var11 = var9.getItem(var10);

                if (var11 != null)
                {
                    var7.add(var11);
                    var9.setItem(var10, (ItemStack)null);
                }
            }
        }

        return var7;
    }

    /**
     * Called whenever the block is removed.
     */
    public void remove(World var1, int var2, int var3, int var4)
    {
        boolean var5 = true;

        for (Iterator var6 = this.getBlockDropped(var1, var2, var3, var4, var1.getData(var2, var3, var4), 0).iterator(); var6.hasNext(); var5 = false)
        {
            ItemStack var7 = (ItemStack)var6.next();

            if (!var5)
            {
                if (var7 == null)
                {
                    return;
                }

                double var8 = 0.7D;
                double var10 = (double)var1.random.nextFloat() * var8 + (1.0D - var8) * 0.5D;
                double var12 = (double)var1.random.nextFloat() * var8 + (1.0D - var8) * 0.5D;
                double var14 = (double)var1.random.nextFloat() * var8 + (1.0D - var8) * 0.5D;
                EntityItem var16 = new EntityItem(var1, (double)var2 + var10, (double)var3 + var12, (double)var4 + var14, var7);
                var16.pickupDelay = 10;
                var1.addEntity(var16);
                return;
            }
        }
    }

    /**
     * Returns the ID of the items to drop on destruction.
     */
    public int getDropType(int var1, Random var2, int var3)
    {
        return Items.getItem("advancedMachine").id;
    }

    /**
     * Determines the damage on the item the block drops. Used in cloth and wood.
     */
    protected int getDropData(int var1)
    {
        return 12;
    }

    public Integer getGui(World var1, int var2, int var3, int var4, EntityHuman var5)
    {
        switch (var1.getData(var2, var3, var4))
        {
            case 0:
                return Integer.valueOf(mod_IC2AdvancedMachines.guiIdRotary);

            case 1:
                return Integer.valueOf(mod_IC2AdvancedMachines.guiIdSingularity);

            case 2:
                return Integer.valueOf(mod_IC2AdvancedMachines.guiIdCentrifuge);

            default:
                return null;
        }
    }

    public TileEntityAdvancedMachine getBlockEntity(int var1)
    {
        switch (var1)
        {
            case 0:
                return new TileEntityRotaryMacerator();

            case 1:
                return new TileEntitySingularityCompressor();

            case 2:
                return new TileEntityCentrifugeExtractor();

            default:
                return null;
        }
    }

    /**
     * Called when a block is using an item and passed in who placed it. Args: x, y, z, entityLiving
     */
    public void postPlace(World var1, int var2, int var3, int var4, EntityLiving var5)
    {
        int var6 = MathHelper.floor((double)(var5.yaw * 4.0F / 360.0F) + 0.5D) & 3;
        TileEntityAdvancedMachine var7 = (TileEntityAdvancedMachine)var1.getTileEntity(var2, var3, var4);

        switch (var6)
        {
            case 0:
                var7.setFacing((short)2);
                break;

            case 1:
                var7.setFacing((short)5);
                break;

            case 2:
                var7.setFacing((short)3);
                break;

            case 3:
                var7.setFacing((short)4);
        }
    }

    /**
     * Called upon block activation (left or right click on the block.). The three integers represent x,y,z of the
     * block.
     */
    public boolean interact(World var1, int var2, int var3, int var4, EntityHuman var5)
    {
        if (var5.isSneaking())
        {
            return false;
        }
        else
        {
            Integer var6 = this.getGui(var1, var2, var3, var4, var5);

            if (var6 == null)
            {
                return false;
            }
            else
            {
                mod_IC2AdvancedMachines.showGui(var5, var6.intValue(), var1.getTileEntity(var2, var3, var4));
                return true;
            }
        }
    }

    public static boolean isActive(IBlockAccess var0, int var1, int var2, int var3)
    {
        return ((TileEntityAdvancedMachine)var0.getTileEntity(var1, var2, var3)).getActive();
    }

    public static int getFacing(IBlockAccess var0, int var1, int var2, int var3)
    {
        return ((TileEntityAdvancedMachine)var0.getTileEntity(var1, var2, var3)).getFacing();
    }

    public static float getWrenchRate(IBlockAccess var0, int var1, int var2, int var3)
    {
        return ((TileEntityAdvancedMachine)var0.getTileEntity(var1, var2, var3)).getWrenchDropRate();
    }

    public void randomDisplayTick(World var1, int var2, int var3, int var4, Random var5)
    {
        int var6 = var1.getData(var2, var3, var4);

        if (var6 == 0 && isActive(var1, var2, var3, var4))
        {
            float var7 = (float)var2 + 1.0F;
            float var8 = (float)var3 + 1.0F;
            float var9 = (float)var4 + 1.0F;

            for (int var10 = 0; var10 < 4; ++var10)
            {
                float var11 = -0.2F - var5.nextFloat() * 0.6F;
                float var12 = -0.1F + var5.nextFloat() * 0.2F;
                float var13 = -0.2F - var5.nextFloat() * 0.6F;
                var1.a("smoke", (double)(var7 + var11), (double)(var8 + var12), (double)(var9 + var13), 0.0D, 0.0D, 0.0D);
            }
        }
    }

    public String getTextureFile()
    {
        return null;
    }
}
