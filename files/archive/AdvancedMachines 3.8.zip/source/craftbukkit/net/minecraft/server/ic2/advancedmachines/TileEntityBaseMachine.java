package net.minecraft.server.ic2.advancedmachines;

import ic2.api.Direction;
import ic2.api.ElectricItem;
import ic2.api.EnergyNet;
import ic2.api.IElectricItem;
import ic2.api.IEnergySink;
import ic2.api.Items;
import net.minecraft.server.Item;
import net.minecraft.server.NBTTagCompound;
import net.minecraft.server.TileEntity;
import net.minecraft.server.mod_IC2AdvancedMachines;

public abstract class TileEntityBaseMachine extends TileEntityMachine implements IEnergySink
{
    public int energy = 0;
    public int fuelslot;
    public int maxEnergy;
    public int maxInput;
    public int tier = 0;
    public boolean addedToEnergyNet = false;

    public TileEntityBaseMachine(int var1, int var2, int var3, int var4)
    {
        super(var1);
        this.fuelslot = var2;
        this.maxEnergy = var3;
        this.maxInput = var4;
        this.tier = 1;
    }

    /**
     * Reads a tile entity from NBT.
     */
    public void a(NBTTagCompound var1)
    {
        super.a(var1);
        this.energy = var1.getInt("energy");
    }

    /**
     * Writes a tile entity to NBT.
     */
    public void b(NBTTagCompound var1)
    {
        super.b(var1);
        var1.setInt("energy", this.energy);
    }

    /**
     * Allows the entity to update its state. Overridden in most subclasses, e.g. the mob spawner uses this to count
     * ticks and creates a new spawn inside its implementation.
     */
    public void q_()
    {
        super.q_();

        if (!this.addedToEnergyNet)
        {
            EnergyNet.getForWorld(this.world).addTileEntity(this);
            this.addedToEnergyNet = true;
        }
    }

    /**
     * called after adding all blocks, only implemented in BlockFire. Sets al the burn rates.
     */
    public void j()
    {
        if (this.addedToEnergyNet)
        {
            EnergyNet.getForWorld(this.world).removeTileEntity(this);
            this.addedToEnergyNet = false;
        }

        super.j();
    }

    public boolean provideEnergy()
    {
        if (this.inventory[this.fuelslot] == null)
        {
            return false;
        }
        else
        {
            int var1 = this.inventory[this.fuelslot].id;

            if (Item.byId[var1] instanceof IElectricItem)
            {
                if (!((IElectricItem)Item.byId[var1]).canProvideEnergy())
                {
                    return false;
                }
                else
                {
                    int var2 = ElectricItem.discharge(this.inventory[this.fuelslot], this.maxEnergy - this.energy, this.tier, false, false);
                    this.energy += var2;
                    return var2 > 0;
                }
            }
            else if (var1 == Item.REDSTONE.id)
            {
                this.energy += this.maxEnergy;
                --this.inventory[this.fuelslot].count;

                if (this.inventory[this.fuelslot].count <= 0)
                {
                    this.inventory[this.fuelslot] = null;
                }

                return true;
            }
            else if (var1 == Items.getItem("suBattery").id)
            {
                this.energy += 1000;
                --this.inventory[this.fuelslot].count;

                if (this.inventory[this.fuelslot].count <= 0)
                {
                    this.inventory[this.fuelslot] = null;
                }

                return true;
            }
            else
            {
                return false;
            }
        }
    }

    public boolean isAddedToEnergyNet()
    {
        return this.addedToEnergyNet;
    }

    public boolean demandsEnergy()
    {
        return this.energy <= this.maxEnergy - this.maxInput;
    }

    public int injectEnergy(Direction var1, int var2)
    {
        if (var2 > this.maxInput)
        {
            mod_IC2AdvancedMachines.explodeMachineAt(this.world, this.x, this.y, this.z);
            return 0;
        }
        else
        {
            this.energy += var2;
            int var3 = 0;

            if (this.energy > this.maxEnergy)
            {
                var3 = this.energy - this.maxEnergy;
                this.energy = this.maxEnergy;
            }

            return var3;
        }
    }

    public boolean acceptsEnergyFrom(TileEntity var1, Direction var2)
    {
        return true;
    }

    public boolean isRedstonePowered()
    {
        return this.world.isBlockIndirectlyPowered(this.x, this.y, this.z);
    }
}
