package net.minecraft.server.ic2.advancedmachines;

import ic2.api.INetworkDataProvider;
import ic2.api.INetworkTileEntityEventListener;
import ic2.api.IWrenchable;
import ic2.api.NetworkHelper;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.server.EntityHuman;
import net.minecraft.server.NBTTagCompound;
import net.minecraft.server.TileEntity;

public class TileEntityBlock extends TileEntity implements IWrenchable, INetworkDataProvider, INetworkTileEntityEventListener
{
    protected boolean created = false;
    public boolean active = false;
    public short facing = 5;
    public boolean prevActive = false;
    public short prevFacing = 0;
    public static List networkedFields;

    public TileEntityBlock()
    {
        if (networkedFields == null)
        {
            networkedFields = new ArrayList();
            networkedFields.add("active");
            networkedFields.add("facing");
        }
    }

    /**
     * Reads a tile entity from NBT.
     */
    public void a(NBTTagCompound var1)
    {
        super.a(var1);
        this.prevFacing = this.facing = var1.getShort("facing");
    }

    /**
     * Writes a tile entity to NBT.
     */
    public void b(NBTTagCompound var1)
    {
        super.b(var1);
        var1.setShort("facing", this.facing);
    }

    /**
     * Allows the entity to update its state. Overridden in most subclasses, e.g. the mob spawner uses this to count
     * ticks and creates a new spawn inside its implementation.
     */
    public void q_()
    {
        if (!this.created)
        {
            this.created = true;
            NetworkHelper.requestInitialData(this);
            NetworkHelper.announceBlockUpdate(this.world, this.x, this.y, this.z);
        }
    }

    public boolean getActive()
    {
        return this.active;
    }

    public void setActive(boolean var1)
    {
        this.active = var1;

        if (this.prevActive != this.active)
        {
            NetworkHelper.updateTileEntityField(this, "active");
        }

        this.prevActive = var1;
    }

    public void setActiveWithoutNotify(boolean var1)
    {
        this.active = var1;
        this.prevActive = var1;
    }

    public short getFacing()
    {
        return this.facing;
    }

    public boolean wrenchCanSetFacing(EntityHuman var1, int var2)
    {
        return var2 >= 2 && var2 != this.facing;
    }

    public void setFacing(short var1)
    {
        this.facing = var1;
        NetworkHelper.updateTileEntityField(this, "facing");
        this.prevFacing = var1;
        NetworkHelper.announceBlockUpdate(this.world, this.x, this.y, this.z);
    }

    public boolean wrenchCanRemove(EntityHuman var1)
    {
        return true;
    }

    public float getWrenchDropRate()
    {
        return 1.0F;
    }

    public List getNetworkedFields()
    {
        return networkedFields;
    }

    public void onNetworkEvent(int var1) {}
}
