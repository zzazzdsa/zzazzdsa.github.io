package net.minecraft.server.ic2.advancedmachines;

import forge.ISidedInventory;
import ic2.api.Direction;
import ic2.api.NetworkHelper;
import java.util.List;
import net.minecraft.server.Container;
import net.minecraft.server.ItemStack;
import net.minecraft.server.NBTTagCompound;
import net.minecraft.server.PlayerInventory;
import net.minecraft.server.mod_IC2AdvancedMachines;

public abstract class TileEntityAdvancedMachine extends TileEntityBaseMachine implements ISidedInventory
{
    private static final int MAX_PROGRESS = 4000;
    private static final int MAX_ENERGY = 5000;
    private static final int MAX_SPEED = 7500;
    private static final int MAX_INPUT = 32;
    private String inventoryName;
    private int[] inputs;
    private int[] outputs;
    short speed;
    short progress;
    private String dataFormat;
    private int dataScaling;
    private IC2AudioSource audioSource;
    private static final int EventStart = 0;
    private static final int EventInterrupt = 1;
    private static final int EventStop = 2;
    private int energyConsume = 2;
    private int defaultEnergyConsume = 3;
    private int acceleration = 1;
    private int defaultAcceleration = 1;
    private int maxSpeed;
    private ItemStack[] lastInventory;

    public TileEntityAdvancedMachine(String var1, String var2, int var3, int[] var4, int[] var5)
    {
        super(var4.length + var5.length + 5, var4.length, 5000, 32);
        this.inventoryName = var1;
        this.dataFormat = var2;
        this.dataScaling = var3;
        this.inputs = var4;
        this.outputs = var5;
        this.speed = 0;
        this.progress = 0;
    }

    /**
     * Reads a tile entity from NBT.
     */
    public void a(NBTTagCompound var1)
    {
        super.a(var1);
        this.speed = var1.getShort("speed");
        this.progress = var1.getShort("progress");
    }

    /**
     * Writes a tile entity to NBT.
     */
    public void b(NBTTagCompound var1)
    {
        super.b(var1);
        var1.setShort("speed", this.speed);
        var1.setShort("progress", this.progress);
    }

    /**
     * Returns the name of the inventory.
     */
    public String getName()
    {
        return this.inventoryName;
    }

    public int gaugeProgressScaled(int var1)
    {
        return var1 * this.progress / 4000;
    }

    public int gaugeFuelScaled(int var1)
    {
        return var1 * this.energy / this.maxEnergy;
    }

    /**
     * Allows the entity to update its state. Overridden in most subclasses, e.g. the mob spawner uses this to count
     * ticks and creates a new spawn inside its implementation.
     */
    public void q_()
    {
        super.q_();
        boolean var1 = false;

        if (this.energy <= this.maxEnergy)
        {
            var1 = this.provideEnergy();
        }

        boolean var2 = this.getActive();

        if (this.progress >= 4000)
        {
            this.operate();
            var1 = true;
            this.progress = 0;
            var2 = false;
            NetworkHelper.initiateTileEntityEvent(this, 2, true);
        }

        boolean var3 = this.canOperate();

        if (this.energy > 0 && (var3 || this.isRedstonePowered()))
        {
            this.setOverclockRates();

            if (this.speed < this.maxSpeed)
            {
                this.speed = (short)(this.speed + this.acceleration);
                this.energy -= this.energyConsume;
            }
            else
            {
                this.speed = (short)this.maxSpeed;
                this.energy -= this.defaultEnergyConsume;
            }

            var2 = true;
            NetworkHelper.initiateTileEntityEvent(this, 0, true);
        }
        else
        {
            boolean var4 = this.speed != 0;
            this.speed = (short)(this.speed - Math.min(this.speed, 4));

            if (var4 && this.speed == 0)
            {
                NetworkHelper.initiateTileEntityEvent(this, 1, true);
            }
        }

        if (var2 && this.progress != 0)
        {
            if (!var3 || this.speed == 0)
            {
                if (!var3)
                {
                    this.progress = 0;
                }

                var2 = false;
            }
        }
        else if (var3)
        {
            if (this.speed != 0)
            {
                var2 = true;
            }
        }
        else
        {
            this.progress = 0;
        }

        if (var2 && var3)
        {
            this.progress = (short)(this.progress + this.speed / 30);
        }

        if (var1)
        {
            this.update();
        }
    }

    public int injectEnergy(Direction var1, int var2)
    {
        this.setOverclockRates();
        return super.injectEnergy(var1, var2);
    }

    public void operate()
    {
        if (this.canOperate())
        {
            ItemStack var1 = this.getResultFor(this.inventory[this.inputs[0]], false).cloneItemStack();
            int[] var2 = new int[this.outputs.length];
            int var3 = var1.getMaxStackSize();
            int var4;

            for (var4 = 0; var4 < this.outputs.length; ++var4)
            {
                if (this.inventory[this.outputs[var4]] == null)
                {
                    var2[var4] = var3;
                }
                else if (this.inventory[this.outputs[var4]].doMaterialsMatch(var1))
                {
                    var2[var4] = var3 - this.inventory[this.outputs[var4]].count;
                }
            }

            for (var4 = 0; var4 < var2.length; ++var4)
            {
                if (var2[var4] > 0)
                {
                    int var5 = Math.min(var1.count, var2[var4]);

                    if (this.inventory[this.outputs[var4]] == null)
                    {
                        this.inventory[this.outputs[var4]] = var1.cloneItemStack();
                        this.onFinishedProcessingItem();
                    }
                    else
                    {
                        this.inventory[this.outputs[var4]].count += var5;
                        this.onFinishedProcessingItem();
                    }

                    var1.count -= var5;
                }

                if (var1.count <= 0)
                {
                    break;
                }
            }

            if (this.inventory[this.inputs[0]].getItem().k())
            {
                this.inventory[this.inputs[0]] = new ItemStack(this.inventory[this.inputs[0]].getItem().j());
            }
            else
            {
                --this.inventory[this.inputs[0]].count;
            }

            if (this.inventory[this.inputs[0]].count <= 0)
            {
                this.inventory[this.inputs[0]] = null;
            }
        }
    }

    public void onFinishedProcessingItem() {}

    public boolean canOperate()
    {
        if (this.inventory[this.inputs[0]] == null)
        {
            return false;
        }
        else
        {
            ItemStack var1 = this.getResultFor(this.inventory[this.inputs[0]], false);

            if (var1 == null)
            {
                return false;
            }
            else
            {
                int var2 = var1.getMaxStackSize();
                int var3 = 0;
                int[] var4 = this.outputs;
                int var5 = var4.length;

                for (int var6 = 0; var6 < var5; ++var6)
                {
                    int var7 = var4[var6];

                    if (this.inventory[var7] == null)
                    {
                        var3 += var2;
                    }
                    else if (this.inventory[var7].doMaterialsMatch(var1))
                    {
                        var3 += var2 - this.inventory[var7].count;
                    }
                }

                return var3 >= var1.count;
            }
        }
    }

    public abstract ItemStack getResultFor(ItemStack var1, boolean var2);

    protected abstract List getResultMap();

    public abstract Container getGuiContainer(PlayerInventory var1);

    public int getStartInventorySide(int var1)
    {
        switch (var1)
        {
            case 0:
                return this.inputs.length;

            case 1:
                return this.inputs[0];

            default:
                return this.outputs[0];
        }
    }

    public int getSizeInventorySide(int var1)
    {
        switch (var1)
        {
            case 0:
                return 1;

            case 1:
                return this.inputs.length;

            default:
                return this.outputs.length;
        }
    }

    public String printFormattedData()
    {
        return String.format(this.dataFormat, new Object[] {Integer.valueOf(this.speed * this.dataScaling)});
    }

    /**
     * invalidates a tile entity
     */
    public void j()
    {
        if (this.audioSource != null)
        {
            IC2AudioSource.removeSource(this.audioSource);
            this.audioSource = null;
        }

        super.j();
    }

    public String getStartSoundFile()
    {
        return null;
    }

    public String getInterruptSoundFile()
    {
        return null;
    }

    public void onNetworkEvent(int var1)
    {
        super.onNetworkEvent(var1);

        if (this.audioSource == null && this.getStartSoundFile() != null)
        {
            this.audioSource = new IC2AudioSource(this, this.getStartSoundFile());
        }

        switch (var1)
        {
            case 0:
                this.setActiveWithoutNotify(true);

                if (this.audioSource != null)
                {
                    this.audioSource.play();
                }

                break;

            case 1:
                this.setActiveWithoutNotify(false);

                if (this.audioSource != null)
                {
                    this.audioSource.stop();

                    if (this.getInterruptSoundFile() != null)
                    {
                        IC2AudioSource.playOnce(this, this.getInterruptSoundFile());
                    }
                }

                break;

            case 2:
                this.setActiveWithoutNotify(false);

                if (this.audioSource != null)
                {
                    this.audioSource.stop();
                }
        }

        NetworkHelper.announceBlockUpdate(this.world, this.x, this.y, this.z);
    }

    public int getUpgradeSlotsStartSlot()
    {
        return this.inventory.length - 4;
    }

    public void setOverclockRates()
    {
        if (this.lastInventory == null || !this.lastInventory.equals(this.inventory))
        {
            this.lastInventory = (ItemStack[])this.inventory.clone();
            int var1 = 0;
            int var2 = 0;
            int var3 = 0;

            for (int var4 = 0; var4 < 4; ++var4)
            {
                ItemStack var5 = this.inventory[this.getUpgradeSlotsStartSlot() + var4];

                if (var5 != null)
                {
                    if (var5.doMaterialsMatch(mod_IC2AdvancedMachines.overClockerStack))
                    {
                        var1 += var5.count;
                    }
                    else if (var5.doMaterialsMatch(mod_IC2AdvancedMachines.transformerStack))
                    {
                        var2 += var5.count;
                    }
                    else if (var5.doMaterialsMatch(mod_IC2AdvancedMachines.energyStorageUpgradeStack))
                    {
                        var3 += var5.count;
                    }
                }
            }

            if (var1 > 32)
            {
                var1 = 32;
            }

            if (var2 > 10)
            {
                var2 = 10;
            }

            this.energyConsume = (int)((double)this.defaultEnergyConsume * Math.pow(2.0D, (double)var1));
            this.acceleration = (int)((double)(this.defaultAcceleration * 2) * Math.pow(1.6D, (double)var1) / 2.0D);
            this.maxSpeed = 7500 + var1 * 500;
            this.maxInput = 32 * (int)Math.pow(4.0D, (double)var2);
            this.maxEnergy = 5000 + var3 * 5000 + this.maxInput - 1;
            this.tier = var2;
        }
    }
}
