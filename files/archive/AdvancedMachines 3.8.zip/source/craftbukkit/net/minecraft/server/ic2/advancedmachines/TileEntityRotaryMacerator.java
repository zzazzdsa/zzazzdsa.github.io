package net.minecraft.server.ic2.advancedmachines;

import ic2.api.Ic2Recipes;
import ic2.api.Items;
import java.util.List;
import net.minecraft.server.Container;
import net.minecraft.server.IInventory;
import net.minecraft.server.Item;
import net.minecraft.server.ItemStack;
import net.minecraft.server.PlayerInventory;
import net.minecraft.server.mod_IC2AdvancedMachines;

public class TileEntityRotaryMacerator extends TileEntityAdvancedMachine implements IInventory
{
    public int supplementedItemsLeft = 0;
    private int currentResultCount;
    private int idIronDust;
    private int idCopperDust;
    private int idTinDust;
    private int idCoalDust;
    private int idWaterCell;
    private ItemStack bronzeDust;
    private ItemStack hydratedCoalDust;

    public TileEntityRotaryMacerator()
    {
        super("Rotary Macerator", "%5d RPM", 1, new int[] {0, 1}, new int[] {2, 3});
        this.idIronDust = Items.getItem("ironDust").id;
        this.idCopperDust = Items.getItem("copperDust").id;
        this.idTinDust = Items.getItem("tinDust").id;
        this.idCoalDust = Items.getItem("coalDust").id;
        this.idWaterCell = Items.getItem("waterCell").id;
        this.bronzeDust = Items.getItem("bronzeDust");
        this.hydratedCoalDust = Items.getItem("hydratedCoalDust");
    }

    public Container getGuiContainer(PlayerInventory var1)
    {
        return new ContainerRotaryMacerator(var1, this);
    }

    protected List getResultMap()
    {
        return Ic2Recipes.getMaceratorRecipes();
    }

    public ItemStack getResultFor(ItemStack var1, boolean var2)
    {
        ItemStack var3 = Ic2Recipes.getMaceratorOutputFor(var1, var2);
        ItemStack var4 = this.inventory[8] != null ? this.inventory[8].cloneItemStack() : null;

        if (var4 != null)
        {
            if (this.supplementedItemsLeft > 0)
            {
                var3 = this.getSpecialResultFor(var1, var3, var4, var2);
            }
            else if (this.getSpecialResultFor(var1, var3, var4, var2) != null)
            {
                var3 = this.getSpecialResultFor(var1, var3, var4, var2);
                this.supplementedItemsLeft = this.currentResultCount;
            }
        }

        return var3;
    }

    public void onFinishedProcessingItem()
    {
        if (this.supplementedItemsLeft != 0)
        {
            if (this.supplementedItemsLeft == 1)
            {
                --this.inventory[8].count;

                if (this.inventory[8].count == 0)
                {
                    this.inventory[8] = null;
                }
            }

            --this.supplementedItemsLeft;
        }

        super.onFinishedProcessingItem();
    }

    private ItemStack getSpecialResultFor(ItemStack var1, ItemStack var2, ItemStack var3, boolean var4)
    {
        if (var2 != null && var3 != null)
        {
            ItemStack var5 = Ic2Recipes.getMaceratorOutputFor(var3, var4);

            if (var2.id == this.idIronDust && var3.id == Item.COAL.id)
            {
                this.currentResultCount = 128;
                return new ItemStack(mod_IC2AdvancedMachines.refinedIronDust, var1.id == Item.IRON_INGOT.id ? 1 : 2);
            }

            if (var2.id == this.idCopperDust && var5 != null && var5.id == this.idTinDust)
            {
                this.currentResultCount = 4;
                return new ItemStack(this.bronzeDust.getItem(), var1.getItem().getName().contains("ngot") ? 1 : 2);
            }

            if (var2.id == this.idCoalDust && var3.id == this.idWaterCell)
            {
                this.currentResultCount = 8;
                return this.hydratedCoalDust;
            }
        }

        return null;
    }

    public int getUpgradeSlotsStartSlot()
    {
        return 4;
    }

    public String getStartSoundFile()
    {
        return mod_IC2AdvancedMachines.advMaceSound;
    }

    public String getInterruptSoundFile()
    {
        return mod_IC2AdvancedMachines.interruptSound;
    }
}
