package net.minecraft.server;

import forge.Configuration;
import forge.Property;
import net.minecraft.server.ic2.advancedmachines.BlockAdvancedMachines;
import net.minecraft.server.ic2.advancedmachines.ItemAdvancedMachine;
import net.minecraft.server.ic2.advancedmachines.TileEntityAdvancedMachine;
import net.minecraft.server.ic2.advancedmachines.TileEntityCentrifugeExtractor;
import net.minecraft.server.ic2.advancedmachines.TileEntityRotaryMacerator;
import net.minecraft.server.ic2.advancedmachines.TileEntitySingularityCompressor;
import ic2.api.Ic2Recipes;
import ic2.api.Items;
import java.io.File;
import java.lang.reflect.InvocationTargetException;

public class mod_IC2AdvancedMachines extends BaseModMp
{
    public static Configuration config;
    public static Block blockAdvancedMachine;
    public static int guiIdRotary;
    public static int guiIdSingularity;
    public static int guiIdCentrifuge;
    public static String advMaceName = "Rotary Macerator";
    public static String advCompName = "Singularity Compressor";
    public static String advExtcName = "Centrifuge Extractor";
    public static ItemStack overClockerStack;
    public static ItemStack transformerStack;
    public static ItemStack energyStorageUpgradeStack;
    public static String advMaceSound = null;
    public static String interruptSound = null;
    public static final Item refinedIronDust = (new Item(29775)).a("Refined Iron Dust");

    public String getVersion()
    {
        return "v3.8";
    }

    public static int getConfigInt(String var0, int var1, int var2, boolean var3, String var4)
    {
        if (config == null)
        {
            return var1;
        }
        else
        {
            try
            {
                if (var3)
                {
                    Property var5 = config.getOrCreateIntProperty(var0, var2, var1);
                    var5.comment = var4;
                    return Integer.valueOf(var5.value).intValue();
                }
                else
                {
                    return Integer.valueOf(config.getOrCreateIntProperty(var0, var2, var1).value).intValue();
                }
            }
            catch (Exception var6)
            {
                System.out.println("[Advanced Machines] Error while trying to access config, wasn\'t loaded properly!");
                return var1;
            }
        }
    }

    public static int getBlockId(String var0, int var1)
    {
        if (config == null)
        {
            return var1;
        }
        else
        {
            try
            {
                return Integer.valueOf(config.getOrCreateBlockIdProperty(var0, var1).value).intValue();
            }
            catch (Exception var3)
            {
                System.out.println("[Advanced Machines] Error while trying to access config, wasn\'t loaded properly!");
                return var1;
            }
        }
    }

    public static void showGui(EntityHuman var0, int var1, TileEntity var2)
    {
        ModLoader.openGUI(var0, var1, var0.inventory, ((TileEntityAdvancedMachine)var2).getGuiContainer(var0.inventory));
    }

    public String getPriorities()
    {
        return "after:mod_IC2";
    }

    public void load()
    {
        try
        {
            config = new Configuration(new File((new File(".")).getPath(), "/config/IC2AdvancedMachine.cfg"));
            config.load();
        }
        catch (Exception var2)
        {
            System.out.println("[Advanced Machines] Error while trying to access configuration!");
            config = null;
        }

        blockAdvancedMachine = new BlockAdvancedMachines(getBlockId("blockAdvancedMachine", 188));
        guiIdRotary = getConfigInt("guiIdRotary", 40, 0, false, "");
        guiIdSingularity = getConfigInt("guiIdSingularity", 41, 0, false, "");
        guiIdCentrifuge = getConfigInt("guiIdCentrifuge", 42, 0, true, "GUI IDs. Only change them if you got a conflict.");

        if (config != null)
        {
            config.save();
        }

        ModLoader.registerBlock(blockAdvancedMachine, ItemAdvancedMachine.class);
        ModLoader.registerTileEntity(TileEntityRotaryMacerator.class, "Rotary Macerator");
        ModLoader.registerTileEntity(TileEntitySingularityCompressor.class, "Singularity Compressor");
        ModLoader.registerTileEntity(TileEntityCentrifugeExtractor.class, "Centrifuge Extractor");
    }

    public void modsLoaded()
    {
        Ic2Recipes.addCraftingRecipe(new ItemStack(blockAdvancedMachine, 1, 0), new Object[] {"RRR", "RMR", "RAR", 'R', Items.getItem("refinedIronIngot"), 'M', Items.getItem("macerator"), 'A', Items.getItem("advancedMachine")});
        Ic2Recipes.addCraftingRecipe(new ItemStack(blockAdvancedMachine, 1, 1), new Object[] {"RRR", "RMR", "RAR", 'R', Block.OBSIDIAN, 'M', Items.getItem("compressor"), 'A', Items.getItem("advancedMachine")});
        Ic2Recipes.addCraftingRecipe(new ItemStack(blockAdvancedMachine, 1, 2), new Object[] {"RRR", "RMR", "RAR", 'R', Items.getItem("electrolyzedWaterCell"), 'M', Items.getItem("extractor"), 'A', Items.getItem("advancedMachine")});
        overClockerStack = Items.getItem("overclockerUpgrade");
        transformerStack = Items.getItem("transformerUpgrade");
        energyStorageUpgradeStack = Items.getItem("energyStorageUpgrade");
        refinedIronDust.textureId = ModLoader.addOverride("/gui/items.png", "ic2/sprites/refinedIronDust.png");
        ModLoader.addSmelting(refinedIronDust.id, Items.getItem("refinedIronIngot"));
    }

    public static void explodeMachineAt(World var0, int var1, int var2, int var3)
    {
        try
        {
            Class var4 = Class.forName("mod_IC2");
            var4.getMethod("explodeMachineAt", new Class[] {World.class, Integer.TYPE, Integer.TYPE, Integer.TYPE}).invoke((Object)null, new Object[] {var0, Integer.valueOf(var1), Integer.valueOf(var2), Integer.valueOf(var3)});
        }
        catch (NoSuchMethodException var5)
        {
            ;
        }
        catch (SecurityException var6)
        {
            ;
        }
        catch (ClassNotFoundException var7)
        {
            ;
        }
        catch (IllegalAccessException var8)
        {
            ;
        }
        catch (IllegalArgumentException var9)
        {
            ;
        }
        catch (InvocationTargetException var10)
        {
            ;
        }
    }
}
