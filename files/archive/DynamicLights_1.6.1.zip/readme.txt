
Dynamic Lights now modular!

BurningEntitiesLightSource -> Living Entities that burst into flames! Multithreaded! *expensive*
ChargingCreeperLightSource -> Creepers about to explode light up! *cheap*
DroppedItemsLightSource -> Dropped Items in the world. Also when they're on fire. Multithreaded! *expensive*
PlayerSelfLightSource -> Handheld Items and Armor on yourself. Also when you're on fire. *cheap*
PlayerOthersLightSource -> Handheld Items and Armor on others. Also when they're on fire. Multithreaded! *fairly cheap*

To remove modules you dont want or cant afford (your machine is an asthmatic train wreck, or a Mac),
simply remove (delete) them from the mod .jar /atomicstryker/dynamiclights/client/modules folder.
Yes, the mod will continue to work. If you delete all modules, the mod won't do anything.

CAUTION: Each has it's own config! (or none) There is no global config file!
You can set an important performance setting (update interval) for each module in their config.

There is a global on/off button which you can find and rebind in the Options "Control" menu. It defaults to "L".


To install:

Dynamic Lights is now a FML coremod. That means drag and drop installation! Simply put the .jar found in /setup/coremods/ into your .minecraft/coremods/ folder!

Out of the box support for Optifine!