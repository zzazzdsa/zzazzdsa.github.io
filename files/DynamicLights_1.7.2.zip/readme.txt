
To install:

Put the .jar(s) found in /mods/ into your .minecraft/mods/ folder!
My Update Checker is also found in that folder, if you choose to use it.
Out of the box support for Optifine!


Dynamic Lights now modular! You may delete any module if you feel your performance is suffering too much.

BurningEntitiesLightSource -> Living Entities that burst into flames! Multithreaded! *expensive*
ChargingCreeperLightSource -> Creepers about to explode light up! *cheap*
DroppedItemsLightSource -> Dropped Items in the world. Also when they're on fire. Multithreaded! *expensive*
EntityClassLightSource -> Living Entities of a specific class! Multithreaded! *extremely expensive*
EntityLivingEquipmentLightSource -> Entities carrying specific Items! Multithreaded! *expensive*
FlameEnchantedArrowLightSource -> Enchanted Flame Arrows *cheap*
PlayerOthersLightSource -> Handheld Items and Armor on others. Also when they're on fire. Multithreaded! *fairly cheap*
PlayerSelfLightSource -> Handheld Items and Armor on yourself. Also when you're on fire. *cheap*


To remove modules you dont want or cant afford (your machine is an asthmatic train wreck, or a Mac),
simply remove (delete) them from the mod .jar /atomicstryker/dynamiclights/client/modules folder.
Yes, the mod will continue to work. If you delete all modules, the mod won't do anything.

CAUTION: Each has it's own config! (or none) There is no global config file!
You can set an important performance setting (update interval) for each module in their config.

There is a global on/off button which you can find and rebind in the Options "Control" menu. It defaults to "L".



Read the modules' respective config files on how to add your own items which should shine light.
You may also ask in the Minecraftforum thread for help or examples.
