package atomicstryker.multimine.common;

public class CommonProxy
{
    public void onPreInit()
    {
        new MultiMineServer();
    }
    
    public void onLoad()
    {
        // NOOP
    }
}
